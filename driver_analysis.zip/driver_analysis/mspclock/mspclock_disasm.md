# mspclock.sys — Disassembly Dump

## All Executable Sections

### Section: .text (VA=0x1c0001000, 2157 instructions)
```asm
0x1c0001000: int3     
0x1c0001001: int3     
0x1c0001002: int3     
0x1c0001003: int3     
0x1c0001004: int3     
0x1c0001005: int3     
0x1c0001006: int3     
0x1c0001007: int3     
0x1c0001008: int3     
0x1c0001009: int3     
0x1c000100a: int3     
0x1c000100b: int3     
0x1c000100c: int3     
0x1c000100d: int3     
0x1c000100e: int3     
0x1c000100f: int3     
0x1c0001010: mov      ecx, 2
0x1c0001015: int      0x29
0x1c0001017: int3     
0x1c0001018: int3     
0x1c0001019: int3     
0x1c000101a: int3     
0x1c000101b: int3     
0x1c000101c: int3     
0x1c000101d: int3     
0x1c000101e: int3     
0x1c000101f: int3     
0x1c0001020: jmp      qword ptr [rip + 0x4059]  ; -> KsiPropertyDefaultClockGetFunctionTable
0x1c0001027: int3     
0x1c0001028: int3     
0x1c0001029: int3     
0x1c000102a: int3     
0x1c000102b: int3     
0x1c000102c: int3     
0x1c000102d: int3     
0x1c000102e: int3     
0x1c000102f: int3     
0x1c0001030: int3     
0x1c0001031: int3     
0x1c0001032: int3     
0x1c0001033: int3     
0x1c0001034: int3     
0x1c0001035: int3     
0x1c0001036: int3     
0x1c0001037: int3     
0x1c0001038: int3     
0x1c0001039: int3     
0x1c000103a: int3     
0x1c000103b: int3     
0x1c000103c: int3     
0x1c000103d: int3     
0x1c000103e: int3     
0x1c000103f: int3     
0x1c0001040: jmp      qword ptr [rip + 0x4041]  ; -> KsiPropertyDefaultClockGetCorrelatedTime
0x1c0001047: int3     
0x1c0001048: int3     
0x1c0001049: int3     
0x1c000104a: int3     
0x1c000104b: int3     
0x1c000104c: int3     
0x1c000104d: int3     
0x1c000104e: int3     
0x1c000104f: int3     
0x1c0001050: int3     
0x1c0001051: int3     
0x1c0001052: int3     
0x1c0001053: int3     
0x1c0001054: int3     
0x1c0001055: int3     
0x1c0001056: int3     
0x1c0001057: int3     
0x1c0001058: int3     
0x1c0001059: int3     
0x1c000105a: int3     
0x1c000105b: int3     
0x1c000105c: int3     
0x1c000105d: int3     
0x1c000105e: int3     
0x1c000105f: int3     
0x1c0001060: jmp      qword ptr [rip + 0x4029]  ; -> KsiDefaultClockAddMarkEvent
0x1c0001067: int3     
0x1c0001068: int3     
0x1c0001069: int3     
0x1c000106a: int3     
0x1c000106b: int3     
0x1c000106c: int3     
0x1c000106d: int3     
0x1c000106e: int3     
0x1c000106f: int3     
0x1c0001070: int3     
0x1c0001071: int3     
0x1c0001072: int3     
0x1c0001073: int3     
0x1c0001074: int3     
0x1c0001075: int3     
0x1c0001076: int3     
0x1c0001077: int3     
0x1c0001078: int3     
0x1c0001079: int3     
0x1c000107a: int3     
0x1c000107b: int3     
0x1c000107c: int3     
0x1c000107d: int3     
0x1c000107e: int3     
0x1c000107f: int3     
0x1c0001080: jmp      qword ptr [rip + 0x4011]  ; -> KsiPropertyDefaultClockGetTime
0x1c0001087: int3     
0x1c0001088: int3     
0x1c0001089: int3     
0x1c000108a: int3     
0x1c000108b: int3     
0x1c000108c: int3     
0x1c000108d: int3     
0x1c000108e: int3     
0x1c000108f: int3     
0x1c0001090: int3     
0x1c0001091: int3     
0x1c0001092: int3     
0x1c0001093: int3     
0x1c0001094: int3     
0x1c0001095: int3     
0x1c0001096: int3     
0x1c0001097: int3     
0x1c0001098: int3     
0x1c0001099: int3     
0x1c000109a: int3     
0x1c000109b: int3     
0x1c000109c: int3     
0x1c000109d: int3     
0x1c000109e: int3     
0x1c000109f: int3     
0x1c00010a0: jmp      qword ptr [rip + 0x4021]  ; -> KsiPropertyDefaultClockGetResolution
0x1c00010a7: int3     
0x1c00010a8: int3     
0x1c00010a9: int3     
0x1c00010aa: int3     
0x1c00010ab: int3     
0x1c00010ac: int3     
0x1c00010ad: int3     
0x1c00010ae: int3     
0x1c00010af: int3     
0x1c00010b0: int3     
0x1c00010b1: int3     
0x1c00010b2: int3     
0x1c00010b3: int3     
0x1c00010b4: int3     
0x1c00010b5: int3     
0x1c00010b6: int3     
0x1c00010b7: int3     
0x1c00010b8: int3     
0x1c00010b9: int3     
0x1c00010ba: int3     
0x1c00010bb: int3     
0x1c00010bc: int3     
0x1c00010bd: int3     
0x1c00010be: int3     
0x1c00010bf: int3     
0x1c00010c0: jmp      qword ptr [rip + 0x4009]  ; -> KsiPropertyDefaultClockGetPhysicalTime
0x1c00010c7: int3     
0x1c00010c8: int3     
0x1c00010c9: int3     
0x1c00010ca: int3     
0x1c00010cb: int3     
0x1c00010cc: int3     
0x1c00010cd: int3     
0x1c00010ce: int3     
0x1c00010cf: int3     
0x1c00010d0: int3     
0x1c00010d1: int3     
0x1c00010d2: int3     
0x1c00010d3: int3     
0x1c00010d4: int3     
0x1c00010d5: int3     
0x1c00010d6: int3     
0x1c00010d7: int3     
0x1c00010d8: int3     
0x1c00010d9: int3     
0x1c00010da: int3     
0x1c00010db: int3     
0x1c00010dc: int3     
0x1c00010dd: int3     
0x1c00010de: int3     
0x1c00010df: int3     
0x1c00010e0: jmp      qword ptr [rip + 0x3ff1]  ; -> KsiPropertyDefaultClockGetState
0x1c00010e7: int3     
0x1c00010e8: int3     
0x1c00010e9: int3     
0x1c00010ea: int3     
0x1c00010eb: int3     
0x1c00010ec: int3     
0x1c00010ed: int3     
0x1c00010ee: int3     
0x1c00010ef: int3     
0x1c00010f0: int3     
0x1c00010f1: int3     
0x1c00010f2: int3     
0x1c00010f3: int3     
0x1c00010f4: int3     
0x1c00010f5: int3     
0x1c00010f6: int3     
0x1c00010f7: int3     
0x1c00010f8: int3     
0x1c00010f9: int3     
0x1c00010fa: int3     
0x1c00010fb: int3     
0x1c00010fc: int3     
0x1c00010fd: int3     
0x1c00010fe: int3     
0x1c00010ff: int3     
0x1c0001100: jmp      qword ptr [rip + 0x3f29]  ; -> KsiPropertyDefaultClockGetCorrelatedPhysicalTime
0x1c0001107: int3     
0x1c0001108: int3     
0x1c0001109: int3     
0x1c000110a: int3     
0x1c000110b: int3     
0x1c000110c: int3     
0x1c000110d: int3     
0x1c000110e: int3     
0x1c000110f: int3     
0x1c0001110: int3     
0x1c0001111: int3     
0x1c0001112: int3     
0x1c0001113: int3     
0x1c0001114: int3     
0x1c0001115: int3     
0x1c0001116: int3     
0x1c0001117: int3     
0x1c0001118: int3     
0x1c0001119: int3     
0x1c000111a: int3     
0x1c000111b: int3     
0x1c000111c: int3     
0x1c000111d: int3     
0x1c000111e: int3     
0x1c000111f: int3     
0x1c0001120: ret      0
0x1c0001123: int3     
0x1c0001124: int3     
0x1c0001125: int3     
0x1c0001126: int3     
0x1c0001127: int3     
0x1c0001128: int3     
0x1c0001129: int3     
0x1c000112a: int3     
0x1c000112b: int3     
0x1c000112c: int3     
0x1c000112d: int3     
0x1c000112e: int3     
0x1c000112f: int3     
0x1c0001130: int3     
0x1c0001131: int3     
0x1c0001132: int3     
0x1c0001133: int3     
0x1c0001134: int3     
0x1c0001135: int3     
0x1c0001136: nop      word ptr [rax + rax]
0x1c0001140: cmp      rcx, qword ptr [rip + 0x1eb9]
0x1c0001147: jne      0x1c0001159
0x1c0001149: rol      rcx, 0x10
0x1c000114d: test     cx, 0xffff
0x1c0001152: jne      0x1c0001155
0x1c0001154: ret      
0x1c0001155: ror      rcx, 0x10
0x1c0001159: jmp      0x1c0001010
0x1c000115e: int3     
0x1c000115f: int3     
0x1c0001160: int3     
0x1c0001161: int3     
0x1c0001162: int3     
0x1c0001163: int3     
0x1c0001164: int3     
0x1c0001165: int3     
0x1c0001166: nop      word ptr [rax + rax]
0x1c0001170: int3     
0x1c0001171: int3     
0x1c0001172: int3     
0x1c0001173: int3     
0x1c0001174: int3     
0x1c0001175: int3     
0x1c0001176: int3     
0x1c0001177: int3     
0x1c0001178: int3     
0x1c0001179: int3     
0x1c000117a: int3     
0x1c000117b: int3     
0x1c000117c: int3     
0x1c000117d: int3     
0x1c000117e: int3     
0x1c000117f: int3     
0x1c0001180: jmp      rax
0x1c0001182: int3     
0x1c0001183: int3     
0x1c0001184: int3     
0x1c0001185: int3     
0x1c0001186: int3     
0x1c0001187: int3     
0x1c0001188: int3     
0x1c0001189: int3     
0x1c000118a: int3     
0x1c000118b: int3     
0x1c000118c: int3     
0x1c000118d: int3     
0x1c000118e: int3     
0x1c000118f: int3     
0x1c0001190: int3     
0x1c0001191: int3     
0x1c0001192: int3     
0x1c0001193: int3     
0x1c0001194: int3     
0x1c0001195: int3     
0x1c0001196: nop      word ptr [rax + rax]
0x1c00011a0: int3     
0x1c00011a1: int3     
0x1c00011a2: int3     
0x1c00011a3: int3     
0x1c00011a4: int3     
0x1c00011a5: int3     
0x1c00011a6: int3     
0x1c00011a7: int3     
0x1c00011a8: int3     
0x1c00011a9: int3     
0x1c00011aa: int3     
0x1c00011ab: int3     
0x1c00011ac: int3     
0x1c00011ad: int3     
0x1c00011ae: int3     
0x1c00011af: int3     
0x1c00011b0: jmp      qword ptr [rip + 0x40f2]
0x1c00011b6: add      byte ptr [rax], al
0x1c00011b8: add      byte ptr [rax], al
0x1c00011ba: add      byte ptr [rax], al
0x1c00011bc: add      byte ptr [rax], al
0x1c00011be: add      byte ptr [rax], al
0x1c00011c0: add      byte ptr [rax], al
0x1c00011c2: add      byte ptr [rax], al
0x1c00011c4: add      byte ptr [rax], al
0x1c00011c6: add      byte ptr [rax], al
0x1c00011c8: add      byte ptr [rax], al
0x1c00011ca: add      byte ptr [rax], al
0x1c00011cc: add      byte ptr [rax], al
0x1c00011ce: add      byte ptr [rax], al
0x1c00011d0: add      byte ptr [rax], al
0x1c00011d2: add      byte ptr [rax], al
0x1c00011d4: add      byte ptr [rax], al
0x1c00011d6: add      byte ptr [rax], al
0x1c00011d8: add      byte ptr [rax], al
0x1c00011da: add      byte ptr [rax], al
0x1c00011dc: add      byte ptr [rax], al
0x1c00011de: add      byte ptr [rax], al
0x1c00011e0: add      byte ptr [rax], al
0x1c00011e2: add      byte ptr [rax], al
0x1c00011e4: add      byte ptr [rax], al
0x1c00011e6: add      byte ptr [rax], al
0x1c00011e8: add      byte ptr [rax], al
0x1c00011ea: add      byte ptr [rax], al
0x1c00011ec: add      byte ptr [rax], al
0x1c00011ee: add      byte ptr [rax], al
0x1c00011f0: add      byte ptr [rax], al
0x1c00011f2: add      byte ptr [rax], al
0x1c00011f4: add      byte ptr [rax], al
0x1c00011f6: add      byte ptr [rax], al
0x1c00011f8: add      byte ptr [rax], al
0x1c00011fa: add      byte ptr [rax], al
0x1c00011fc: add      byte ptr [rax], al
0x1c00011fe: add      byte ptr [rax], al
0x1c0001200: add      byte ptr [rax], al
0x1c0001202: add      byte ptr [rax], al
0x1c0001204: add      byte ptr [rax], al
0x1c0001206: add      byte ptr [rax], al
0x1c0001208: add      byte ptr [rax], al
0x1c000120a: add      byte ptr [rax], al
0x1c000120c: add      byte ptr [rax], al
0x1c000120e: add      byte ptr [rax], al
0x1c0001210: add      byte ptr [rax], al
0x1c0001212: add      byte ptr [rax], al
0x1c0001214: add      byte ptr [rax], al
0x1c0001216: add      byte ptr [rax], al
0x1c0001218: add      byte ptr [rax], al
0x1c000121a: add      byte ptr [rax], al
0x1c000121c: add      byte ptr [rax], al
0x1c000121e: add      byte ptr [rax], al
0x1c0001220: add      byte ptr [rax], al
0x1c0001222: add      byte ptr [rax], al
0x1c0001224: add      byte ptr [rax], al
0x1c0001226: add      byte ptr [rax], al
0x1c0001228: add      byte ptr [rax], al
0x1c000122a: add      byte ptr [rax], al
0x1c000122c: add      byte ptr [rax], al
0x1c000122e: add      byte ptr [rax], al
0x1c0001230: add      byte ptr [rax], al
0x1c0001232: add      byte ptr [rax], al
0x1c0001234: add      byte ptr [rax], al
0x1c0001236: add      byte ptr [rax], al
0x1c0001238: add      byte ptr [rax], al
0x1c000123a: add      byte ptr [rax], al
0x1c000123c: add      byte ptr [rax], al
0x1c000123e: add      byte ptr [rax], al
0x1c0001240: add      byte ptr [rax], al
0x1c0001242: add      byte ptr [rax], al
0x1c0001244: add      byte ptr [rax], al
0x1c0001246: add      byte ptr [rax], al
0x1c0001248: add      byte ptr [rax], al
0x1c000124a: add      byte ptr [rax], al
0x1c000124c: add      byte ptr [rax], al
0x1c000124e: add      byte ptr [rax], al
0x1c0001250: add      byte ptr [rax], al
0x1c0001252: add      byte ptr [rax], al
0x1c0001254: add      byte ptr [rax], al
0x1c0001256: add      byte ptr [rax], al
0x1c0001258: add      byte ptr [rax], al
0x1c000125a: add      byte ptr [rax], al
0x1c000125c: add      byte ptr [rax], al
0x1c000125e: add      byte ptr [rax], al
0x1c0001260: add      byte ptr [rax], al
0x1c0001262: add      byte ptr [rax], al
0x1c0001264: add      byte ptr [rax], al
0x1c0001266: add      byte ptr [rax], al
0x1c0001268: add      byte ptr [rax], al
0x1c000126a: add      byte ptr [rax], al
0x1c000126c: add      byte ptr [rax], al
0x1c000126e: add      byte ptr [rax], al
0x1c0001270: add      byte ptr [rax], al
0x1c0001272: add      byte ptr [rax], al
0x1c0001274: add      byte ptr [rax], al
0x1c0001276: add      byte ptr [rax], al
0x1c0001278: add      byte ptr [rax], al
0x1c000127a: add      byte ptr [rax], al
0x1c000127c: add      byte ptr [rax], al
0x1c000127e: add      byte ptr [rax], al
0x1c0001280: add      byte ptr [rax], al
0x1c0001282: add      byte ptr [rax], al
0x1c0001284: add      byte ptr [rax], al
0x1c0001286: add      byte ptr [rax], al
0x1c0001288: add      byte ptr [rax], al
0x1c000128a: add      byte ptr [rax], al
0x1c000128c: add      byte ptr [rax], al
0x1c000128e: add      byte ptr [rax], al
0x1c0001290: add      byte ptr [rax], al
0x1c0001292: add      byte ptr [rax], al
0x1c0001294: add      byte ptr [rax], al
0x1c0001296: add      byte ptr [rax], al
0x1c0001298: add      byte ptr [rax], al
0x1c000129a: add      byte ptr [rax], al
0x1c000129c: add      byte ptr [rax], al
0x1c000129e: add      byte ptr [rax], al
0x1c00012a0: add      byte ptr [rax], al
0x1c00012a2: add      byte ptr [rax], al
0x1c00012a4: add      byte ptr [rax], al
0x1c00012a6: add      byte ptr [rax], al
0x1c00012a8: add      byte ptr [rax], al
0x1c00012aa: add      byte ptr [rax], al
0x1c00012ac: add      byte ptr [rax], al
0x1c00012ae: add      byte ptr [rax], al
0x1c00012b0: add      byte ptr [rax], al
0x1c00012b2: add      byte ptr [rax], al
0x1c00012b4: add      byte ptr [rax], al
0x1c00012b6: add      byte ptr [rax], al
0x1c00012b8: add      byte ptr [rax], al
0x1c00012ba: add      byte ptr [rax], al
0x1c00012bc: add      byte ptr [rax], al
0x1c00012be: add      byte ptr [rax], al
0x1c00012c0: add      byte ptr [rax], al
0x1c00012c2: add      byte ptr [rax], al
0x1c00012c4: add      byte ptr [rax], al
0x1c00012c6: add      byte ptr [rax], al
0x1c00012c8: add      byte ptr [rax], al
0x1c00012ca: add      byte ptr [rax], al
0x1c00012cc: add      byte ptr [rax], al
0x1c00012ce: add      byte ptr [rax], al
0x1c00012d0: add      byte ptr [rax], al
0x1c00012d2: add      byte ptr [rax], al
0x1c00012d4: add      byte ptr [rax], al
0x1c00012d6: add      byte ptr [rax], al
0x1c00012d8: add      byte ptr [rax], al
0x1c00012da: add      byte ptr [rax], al
0x1c00012dc: add      byte ptr [rax], al
0x1c00012de: add      byte ptr [rax], al
0x1c00012e0: add      byte ptr [rax], al
0x1c00012e2: add      byte ptr [rax], al
0x1c00012e4: add      byte ptr [rax], al
0x1c00012e6: add      byte ptr [rax], al
0x1c00012e8: add      byte ptr [rax], al
0x1c00012ea: add      byte ptr [rax], al
0x1c00012ec: add      byte ptr [rax], al
0x1c00012ee: add      byte ptr [rax], al
0x1c00012f0: add      byte ptr [rax], al
0x1c00012f2: add      byte ptr [rax], al
0x1c00012f4: add      byte ptr [rax], al
0x1c00012f6: add      byte ptr [rax], al
0x1c00012f8: add      byte ptr [rax], al
0x1c00012fa: add      byte ptr [rax], al
0x1c00012fc: add      byte ptr [rax], al
0x1c00012fe: add      byte ptr [rax], al
0x1c0001300: add      byte ptr [rax], al
0x1c0001302: add      byte ptr [rax], al
0x1c0001304: add      byte ptr [rax], al
0x1c0001306: add      byte ptr [rax], al
0x1c0001308: add      byte ptr [rax], al
0x1c000130a: add      byte ptr [rax], al
0x1c000130c: add      byte ptr [rax], al
0x1c000130e: add      byte ptr [rax], al
0x1c0001310: add      byte ptr [rax], al
0x1c0001312: add      byte ptr [rax], al
0x1c0001314: add      byte ptr [rax], al
0x1c0001316: add      byte ptr [rax], al
0x1c0001318: add      byte ptr [rax], al
0x1c000131a: add      byte ptr [rax], al
0x1c000131c: add      byte ptr [rax], al
0x1c000131e: add      byte ptr [rax], al
0x1c0001320: add      byte ptr [rax], al
0x1c0001322: add      byte ptr [rax], al
0x1c0001324: add      byte ptr [rax], al
0x1c0001326: add      byte ptr [rax], al
0x1c0001328: add      byte ptr [rax], al
0x1c000132a: add      byte ptr [rax], al
0x1c000132c: add      byte ptr [rax], al
0x1c000132e: add      byte ptr [rax], al
0x1c0001330: add      byte ptr [rax], al
0x1c0001332: add      byte ptr [rax], al
0x1c0001334: add      byte ptr [rax], al
0x1c0001336: add      byte ptr [rax], al
0x1c0001338: add      byte ptr [rax], al
0x1c000133a: add      byte ptr [rax], al
0x1c000133c: add      byte ptr [rax], al
0x1c000133e: add      byte ptr [rax], al
0x1c0001340: add      byte ptr [rax], al
0x1c0001342: add      byte ptr [rax], al
0x1c0001344: add      byte ptr [rax], al
0x1c0001346: add      byte ptr [rax], al
0x1c0001348: add      byte ptr [rax], al
0x1c000134a: add      byte ptr [rax], al
0x1c000134c: add      byte ptr [rax], al
0x1c000134e: add      byte ptr [rax], al
0x1c0001350: add      byte ptr [rax], al
0x1c0001352: add      byte ptr [rax], al
0x1c0001354: add      byte ptr [rax], al
0x1c0001356: add      byte ptr [rax], al
0x1c0001358: add      byte ptr [rax], al
0x1c000135a: add      byte ptr [rax], al
0x1c000135c: add      byte ptr [rax], al
0x1c000135e: add      byte ptr [rax], al
0x1c0001360: add      byte ptr [rax], al
0x1c0001362: add      byte ptr [rax], al
0x1c0001364: add      byte ptr [rax], al
0x1c0001366: add      byte ptr [rax], al
0x1c0001368: add      byte ptr [rax], al
0x1c000136a: add      byte ptr [rax], al
0x1c000136c: add      byte ptr [rax], al
0x1c000136e: add      byte ptr [rax], al
0x1c0001370: add      byte ptr [rax], al
0x1c0001372: add      byte ptr [rax], al
0x1c0001374: add      byte ptr [rax], al
0x1c0001376: add      byte ptr [rax], al
0x1c0001378: add      byte ptr [rax], al
0x1c000137a: add      byte ptr [rax], al
0x1c000137c: add      byte ptr [rax], al
0x1c000137e: add      byte ptr [rax], al
0x1c0001380: add      byte ptr [rax], al
0x1c0001382: add      byte ptr [rax], al
0x1c0001384: add      byte ptr [rax], al
0x1c0001386: add      byte ptr [rax], al
0x1c0001388: add      byte ptr [rax], al
0x1c000138a: add      byte ptr [rax], al
0x1c000138c: add      byte ptr [rax], al
0x1c000138e: add      byte ptr [rax], al
0x1c0001390: add      byte ptr [rax], al
0x1c0001392: add      byte ptr [rax], al
0x1c0001394: add      byte ptr [rax], al
0x1c0001396: add      byte ptr [rax], al
0x1c0001398: add      byte ptr [rax], al
0x1c000139a: add      byte ptr [rax], al
0x1c000139c: add      byte ptr [rax], al
0x1c000139e: add      byte ptr [rax], al
0x1c00013a0: add      byte ptr [rax], al
0x1c00013a2: add      byte ptr [rax], al
0x1c00013a4: add      byte ptr [rax], al
0x1c00013a6: add      byte ptr [rax], al
0x1c00013a8: add      byte ptr [rax], al
0x1c00013aa: add      byte ptr [rax], al
0x1c00013ac: add      byte ptr [rax], al
0x1c00013ae: add      byte ptr [rax], al
0x1c00013b0: add      byte ptr [rax], al
0x1c00013b2: add      byte ptr [rax], al
0x1c00013b4: add      byte ptr [rax], al
0x1c00013b6: add      byte ptr [rax], al
0x1c00013b8: add      byte ptr [rax], al
0x1c00013ba: add      byte ptr [rax], al
0x1c00013bc: add      byte ptr [rax], al
0x1c00013be: add      byte ptr [rax], al
0x1c00013c0: add      byte ptr [rax], al
0x1c00013c2: add      byte ptr [rax], al
0x1c00013c4: add      byte ptr [rax], al
0x1c00013c6: add      byte ptr [rax], al
0x1c00013c8: add      byte ptr [rax], al
0x1c00013ca: add      byte ptr [rax], al
0x1c00013cc: add      byte ptr [rax], al
0x1c00013ce: add      byte ptr [rax], al
0x1c00013d0: add      byte ptr [rax], al
0x1c00013d2: add      byte ptr [rax], al
0x1c00013d4: add      byte ptr [rax], al
0x1c00013d6: add      byte ptr [rax], al
0x1c00013d8: add      byte ptr [rax], al
0x1c00013da: add      byte ptr [rax], al
0x1c00013dc: add      byte ptr [rax], al
0x1c00013de: add      byte ptr [rax], al
0x1c00013e0: add      byte ptr [rax], al
0x1c00013e2: add      byte ptr [rax], al
0x1c00013e4: add      byte ptr [rax], al
0x1c00013e6: add      byte ptr [rax], al
0x1c00013e8: add      byte ptr [rax], al
0x1c00013ea: add      byte ptr [rax], al
0x1c00013ec: add      byte ptr [rax], al
0x1c00013ee: add      byte ptr [rax], al
0x1c00013f0: add      byte ptr [rax], al
0x1c00013f2: add      byte ptr [rax], al
0x1c00013f4: add      byte ptr [rax], al
0x1c00013f6: add      byte ptr [rax], al
0x1c00013f8: add      byte ptr [rax], al
0x1c00013fa: add      byte ptr [rax], al
0x1c00013fc: add      byte ptr [rax], al
0x1c00013fe: add      byte ptr [rax], al
0x1c0001400: add      byte ptr [rax], al
0x1c0001402: add      byte ptr [rax], al
0x1c0001404: add      byte ptr [rax], al
0x1c0001406: add      byte ptr [rax], al
0x1c0001408: add      byte ptr [rax], al
0x1c000140a: add      byte ptr [rax], al
0x1c000140c: add      byte ptr [rax], al
0x1c000140e: add      byte ptr [rax], al
0x1c0001410: add      byte ptr [rax], al
0x1c0001412: add      byte ptr [rax], al
0x1c0001414: add      byte ptr [rax], al
0x1c0001416: add      byte ptr [rax], al
0x1c0001418: add      byte ptr [rax], al
0x1c000141a: add      byte ptr [rax], al
0x1c000141c: add      byte ptr [rax], al
0x1c000141e: add      byte ptr [rax], al
0x1c0001420: add      byte ptr [rax], al
0x1c0001422: add      byte ptr [rax], al
0x1c0001424: add      byte ptr [rax], al
0x1c0001426: add      byte ptr [rax], al
0x1c0001428: add      byte ptr [rax], al
0x1c000142a: add      byte ptr [rax], al
0x1c000142c: add      byte ptr [rax], al
0x1c000142e: add      byte ptr [rax], al
0x1c0001430: add      byte ptr [rax], al
0x1c0001432: add      byte ptr [rax], al
0x1c0001434: add      byte ptr [rax], al
0x1c0001436: add      byte ptr [rax], al
0x1c0001438: add      byte ptr [rax], al
0x1c000143a: add      byte ptr [rax], al
0x1c000143c: add      byte ptr [rax], al
0x1c000143e: add      byte ptr [rax], al
0x1c0001440: add      byte ptr [rax], al
0x1c0001442: add      byte ptr [rax], al
0x1c0001444: add      byte ptr [rax], al
0x1c0001446: add      byte ptr [rax], al
0x1c0001448: add      byte ptr [rax], al
0x1c000144a: add      byte ptr [rax], al
0x1c000144c: add      byte ptr [rax], al
0x1c000144e: add      byte ptr [rax], al
0x1c0001450: add      byte ptr [rax], al
0x1c0001452: add      byte ptr [rax], al
0x1c0001454: add      byte ptr [rax], al
0x1c0001456: add      byte ptr [rax], al
0x1c0001458: add      byte ptr [rax], al
0x1c000145a: add      byte ptr [rax], al
0x1c000145c: add      byte ptr [rax], al
0x1c000145e: add      byte ptr [rax], al
0x1c0001460: add      byte ptr [rax], al
0x1c0001462: add      byte ptr [rax], al
0x1c0001464: add      byte ptr [rax], al
0x1c0001466: add      byte ptr [rax], al
0x1c0001468: add      byte ptr [rax], al
0x1c000146a: add      byte ptr [rax], al
0x1c000146c: add      byte ptr [rax], al
0x1c000146e: add      byte ptr [rax], al
0x1c0001470: add      byte ptr [rax], al
0x1c0001472: add      byte ptr [rax], al
0x1c0001474: add      byte ptr [rax], al
0x1c0001476: add      byte ptr [rax], al
0x1c0001478: add      byte ptr [rax], al
0x1c000147a: add      byte ptr [rax], al
0x1c000147c: add      byte ptr [rax], al
0x1c000147e: add      byte ptr [rax], al
0x1c0001480: add      byte ptr [rax], al
0x1c0001482: add      byte ptr [rax], al
0x1c0001484: add      byte ptr [rax], al
0x1c0001486: add      byte ptr [rax], al
0x1c0001488: add      byte ptr [rax], al
0x1c000148a: add      byte ptr [rax], al
0x1c000148c: add      byte ptr [rax], al
0x1c000148e: add      byte ptr [rax], al
0x1c0001490: add      byte ptr [rax], al
0x1c0001492: add      byte ptr [rax], al
0x1c0001494: add      byte ptr [rax], al
0x1c0001496: add      byte ptr [rax], al
0x1c0001498: add      byte ptr [rax], al
0x1c000149a: add      byte ptr [rax], al
0x1c000149c: add      byte ptr [rax], al
0x1c000149e: add      byte ptr [rax], al
0x1c00014a0: add      byte ptr [rax], al
0x1c00014a2: add      byte ptr [rax], al
0x1c00014a4: add      byte ptr [rax], al
0x1c00014a6: add      byte ptr [rax], al
0x1c00014a8: add      byte ptr [rax], al
0x1c00014aa: add      byte ptr [rax], al
0x1c00014ac: add      byte ptr [rax], al
0x1c00014ae: add      byte ptr [rax], al
0x1c00014b0: add      byte ptr [rax], al
0x1c00014b2: add      byte ptr [rax], al
0x1c00014b4: add      byte ptr [rax], al
0x1c00014b6: add      byte ptr [rax], al
0x1c00014b8: add      byte ptr [rax], al
0x1c00014ba: add      byte ptr [rax], al
0x1c00014bc: add      byte ptr [rax], al
0x1c00014be: add      byte ptr [rax], al
0x1c00014c0: add      byte ptr [rax], al
0x1c00014c2: add      byte ptr [rax], al
0x1c00014c4: add      byte ptr [rax], al
0x1c00014c6: add      byte ptr [rax], al
0x1c00014c8: add      byte ptr [rax], al
0x1c00014ca: add      byte ptr [rax], al
0x1c00014cc: add      byte ptr [rax], al
0x1c00014ce: add      byte ptr [rax], al
0x1c00014d0: add      byte ptr [rax], al
0x1c00014d2: add      byte ptr [rax], al
0x1c00014d4: add      byte ptr [rax], al
0x1c00014d6: add      byte ptr [rax], al
0x1c00014d8: add      byte ptr [rax], al
0x1c00014da: add      byte ptr [rax], al
0x1c00014dc: add      byte ptr [rax], al
0x1c00014de: add      byte ptr [rax], al
0x1c00014e0: add      byte ptr [rax], al
0x1c00014e2: add      byte ptr [rax], al
0x1c00014e4: add      byte ptr [rax], al
0x1c00014e6: add      byte ptr [rax], al
0x1c00014e8: add      byte ptr [rax], al
0x1c00014ea: add      byte ptr [rax], al
0x1c00014ec: add      byte ptr [rax], al
0x1c00014ee: add      byte ptr [rax], al
0x1c00014f0: add      byte ptr [rax], al
0x1c00014f2: add      byte ptr [rax], al
0x1c00014f4: add      byte ptr [rax], al
0x1c00014f6: add      byte ptr [rax], al
0x1c00014f8: add      byte ptr [rax], al
0x1c00014fa: add      byte ptr [rax], al
0x1c00014fc: add      byte ptr [rax], al
0x1c00014fe: add      byte ptr [rax], al
0x1c0001500: add      byte ptr [rax], al
0x1c0001502: add      byte ptr [rax], al
0x1c0001504: add      byte ptr [rax], al
0x1c0001506: add      byte ptr [rax], al
0x1c0001508: add      byte ptr [rax], al
0x1c000150a: add      byte ptr [rax], al
0x1c000150c: add      byte ptr [rax], al
0x1c000150e: add      byte ptr [rax], al
0x1c0001510: add      byte ptr [rax], al
0x1c0001512: add      byte ptr [rax], al
0x1c0001514: add      byte ptr [rax], al
0x1c0001516: add      byte ptr [rax], al
0x1c0001518: add      byte ptr [rax], al
0x1c000151a: add      byte ptr [rax], al
0x1c000151c: add      byte ptr [rax], al
0x1c000151e: add      byte ptr [rax], al
0x1c0001520: add      byte ptr [rax], al
0x1c0001522: add      byte ptr [rax], al
0x1c0001524: add      byte ptr [rax], al
0x1c0001526: add      byte ptr [rax], al
0x1c0001528: add      byte ptr [rax], al
0x1c000152a: add      byte ptr [rax], al
0x1c000152c: add      byte ptr [rax], al
0x1c000152e: add      byte ptr [rax], al
0x1c0001530: add      byte ptr [rax], al
0x1c0001532: add      byte ptr [rax], al
0x1c0001534: add      byte ptr [rax], al
0x1c0001536: add      byte ptr [rax], al
0x1c0001538: add      byte ptr [rax], al
0x1c000153a: add      byte ptr [rax], al
0x1c000153c: add      byte ptr [rax], al
0x1c000153e: add      byte ptr [rax], al
0x1c0001540: add      byte ptr [rax], al
0x1c0001542: add      byte ptr [rax], al
0x1c0001544: add      byte ptr [rax], al
0x1c0001546: add      byte ptr [rax], al
0x1c0001548: add      byte ptr [rax], al
0x1c000154a: add      byte ptr [rax], al
0x1c000154c: add      byte ptr [rax], al
0x1c000154e: add      byte ptr [rax], al
0x1c0001550: add      byte ptr [rax], al
0x1c0001552: add      byte ptr [rax], al
0x1c0001554: add      byte ptr [rax], al
0x1c0001556: add      byte ptr [rax], al
0x1c0001558: add      byte ptr [rax], al
0x1c000155a: add      byte ptr [rax], al
0x1c000155c: add      byte ptr [rax], al
0x1c000155e: add      byte ptr [rax], al
0x1c0001560: add      byte ptr [rax], al
0x1c0001562: add      byte ptr [rax], al
0x1c0001564: add      byte ptr [rax], al
0x1c0001566: add      byte ptr [rax], al
0x1c0001568: add      byte ptr [rax], al
0x1c000156a: add      byte ptr [rax], al
0x1c000156c: add      byte ptr [rax], al
0x1c000156e: add      byte ptr [rax], al
0x1c0001570: add      byte ptr [rax], al
0x1c0001572: add      byte ptr [rax], al
0x1c0001574: add      byte ptr [rax], al
0x1c0001576: add      byte ptr [rax], al
0x1c0001578: add      byte ptr [rax], al
0x1c000157a: add      byte ptr [rax], al
0x1c000157c: add      byte ptr [rax], al
0x1c000157e: add      byte ptr [rax], al
0x1c0001580: add      byte ptr [rax], al
0x1c0001582: add      byte ptr [rax], al
0x1c0001584: add      byte ptr [rax], al
0x1c0001586: add      byte ptr [rax], al
0x1c0001588: add      byte ptr [rax], al
0x1c000158a: add      byte ptr [rax], al
0x1c000158c: add      byte ptr [rax], al
0x1c000158e: add      byte ptr [rax], al
0x1c0001590: add      byte ptr [rax], al
0x1c0001592: add      byte ptr [rax], al
0x1c0001594: add      byte ptr [rax], al
0x1c0001596: add      byte ptr [rax], al
0x1c0001598: add      byte ptr [rax], al
0x1c000159a: add      byte ptr [rax], al
0x1c000159c: add      byte ptr [rax], al
0x1c000159e: add      byte ptr [rax], al
0x1c00015a0: add      byte ptr [rax], al
0x1c00015a2: add      byte ptr [rax], al
0x1c00015a4: add      byte ptr [rax], al
0x1c00015a6: add      byte ptr [rax], al
0x1c00015a8: add      byte ptr [rax], al
0x1c00015aa: add      byte ptr [rax], al
0x1c00015ac: add      byte ptr [rax], al
0x1c00015ae: add      byte ptr [rax], al
0x1c00015b0: add      byte ptr [rax], al
0x1c00015b2: add      byte ptr [rax], al
0x1c00015b4: add      byte ptr [rax], al
0x1c00015b6: add      byte ptr [rax], al
0x1c00015b8: add      byte ptr [rax], al
0x1c00015ba: add      byte ptr [rax], al
0x1c00015bc: add      byte ptr [rax], al
0x1c00015be: add      byte ptr [rax], al
0x1c00015c0: add      byte ptr [rax], al
0x1c00015c2: add      byte ptr [rax], al
0x1c00015c4: add      byte ptr [rax], al
0x1c00015c6: add      byte ptr [rax], al
0x1c00015c8: add      byte ptr [rax], al
0x1c00015ca: add      byte ptr [rax], al
0x1c00015cc: add      byte ptr [rax], al
0x1c00015ce: add      byte ptr [rax], al
0x1c00015d0: add      byte ptr [rax], al
0x1c00015d2: add      byte ptr [rax], al
0x1c00015d4: add      byte ptr [rax], al
0x1c00015d6: add      byte ptr [rax], al
0x1c00015d8: add      byte ptr [rax], al
0x1c00015da: add      byte ptr [rax], al
0x1c00015dc: add      byte ptr [rax], al
0x1c00015de: add      byte ptr [rax], al
0x1c00015e0: add      byte ptr [rax], al
0x1c00015e2: add      byte ptr [rax], al
0x1c00015e4: add      byte ptr [rax], al
0x1c00015e6: add      byte ptr [rax], al
0x1c00015e8: add      byte ptr [rax], al
0x1c00015ea: add      byte ptr [rax], al
0x1c00015ec: add      byte ptr [rax], al
0x1c00015ee: add      byte ptr [rax], al
0x1c00015f0: add      byte ptr [rax], al
0x1c00015f2: add      byte ptr [rax], al
0x1c00015f4: add      byte ptr [rax], al
0x1c00015f6: add      byte ptr [rax], al
0x1c00015f8: add      byte ptr [rax], al
0x1c00015fa: add      byte ptr [rax], al
0x1c00015fc: add      byte ptr [rax], al
0x1c00015fe: add      byte ptr [rax], al
0x1c0001600: add      byte ptr [rax], al
0x1c0001602: add      byte ptr [rax], al
0x1c0001604: add      byte ptr [rax], al
0x1c0001606: add      byte ptr [rax], al
0x1c0001608: add      byte ptr [rax], al
0x1c000160a: add      byte ptr [rax], al
0x1c000160c: add      byte ptr [rax], al
0x1c000160e: add      byte ptr [rax], al
0x1c0001610: add      byte ptr [rax], al
0x1c0001612: add      byte ptr [rax], al
0x1c0001614: add      byte ptr [rax], al
0x1c0001616: add      byte ptr [rax], al
0x1c0001618: add      byte ptr [rax], al
0x1c000161a: add      byte ptr [rax], al
0x1c000161c: add      byte ptr [rax], al
0x1c000161e: add      byte ptr [rax], al
0x1c0001620: add      byte ptr [rax], al
0x1c0001622: add      byte ptr [rax], al
0x1c0001624: add      byte ptr [rax], al
0x1c0001626: add      byte ptr [rax], al
0x1c0001628: add      byte ptr [rax], al
0x1c000162a: add      byte ptr [rax], al
0x1c000162c: add      byte ptr [rax], al
0x1c000162e: add      byte ptr [rax], al
0x1c0001630: add      byte ptr [rax], al
0x1c0001632: add      byte ptr [rax], al
0x1c0001634: add      byte ptr [rax], al
0x1c0001636: add      byte ptr [rax], al
0x1c0001638: add      byte ptr [rax], al
0x1c000163a: add      byte ptr [rax], al
0x1c000163c: add      byte ptr [rax], al
0x1c000163e: add      byte ptr [rax], al
0x1c0001640: add      byte ptr [rax], al
0x1c0001642: add      byte ptr [rax], al
0x1c0001644: add      byte ptr [rax], al
0x1c0001646: add      byte ptr [rax], al
0x1c0001648: add      byte ptr [rax], al
0x1c000164a: add      byte ptr [rax], al
0x1c000164c: add      byte ptr [rax], al
0x1c000164e: add      byte ptr [rax], al
0x1c0001650: add      byte ptr [rax], al
0x1c0001652: add      byte ptr [rax], al
0x1c0001654: add      byte ptr [rax], al
0x1c0001656: add      byte ptr [rax], al
0x1c0001658: add      byte ptr [rax], al
0x1c000165a: add      byte ptr [rax], al
0x1c000165c: add      byte ptr [rax], al
0x1c000165e: add      byte ptr [rax], al
0x1c0001660: add      byte ptr [rax], al
0x1c0001662: add      byte ptr [rax], al
0x1c0001664: add      byte ptr [rax], al
0x1c0001666: add      byte ptr [rax], al
0x1c0001668: add      byte ptr [rax], al
0x1c000166a: add      byte ptr [rax], al
0x1c000166c: add      byte ptr [rax], al
0x1c000166e: add      byte ptr [rax], al
0x1c0001670: add      byte ptr [rax], al
0x1c0001672: add      byte ptr [rax], al
0x1c0001674: add      byte ptr [rax], al
0x1c0001676: add      byte ptr [rax], al
0x1c0001678: add      byte ptr [rax], al
0x1c000167a: add      byte ptr [rax], al
0x1c000167c: add      byte ptr [rax], al
0x1c000167e: add      byte ptr [rax], al
0x1c0001680: add      byte ptr [rax], al
0x1c0001682: add      byte ptr [rax], al
0x1c0001684: add      byte ptr [rax], al
0x1c0001686: add      byte ptr [rax], al
0x1c0001688: add      byte ptr [rax], al
0x1c000168a: add      byte ptr [rax], al
0x1c000168c: add      byte ptr [rax], al
0x1c000168e: add      byte ptr [rax], al
0x1c0001690: add      byte ptr [rax], al
0x1c0001692: add      byte ptr [rax], al
0x1c0001694: add      byte ptr [rax], al
0x1c0001696: add      byte ptr [rax], al
0x1c0001698: add      byte ptr [rax], al
0x1c000169a: add      byte ptr [rax], al
0x1c000169c: add      byte ptr [rax], al
0x1c000169e: add      byte ptr [rax], al
0x1c00016a0: add      byte ptr [rax], al
0x1c00016a2: add      byte ptr [rax], al
0x1c00016a4: add      byte ptr [rax], al
0x1c00016a6: add      byte ptr [rax], al
0x1c00016a8: add      byte ptr [rax], al
0x1c00016aa: add      byte ptr [rax], al
0x1c00016ac: add      byte ptr [rax], al
0x1c00016ae: add      byte ptr [rax], al
0x1c00016b0: add      byte ptr [rax], al
0x1c00016b2: add      byte ptr [rax], al
0x1c00016b4: add      byte ptr [rax], al
0x1c00016b6: add      byte ptr [rax], al
0x1c00016b8: add      byte ptr [rax], al
0x1c00016ba: add      byte ptr [rax], al
0x1c00016bc: add      byte ptr [rax], al
0x1c00016be: add      byte ptr [rax], al
0x1c00016c0: add      byte ptr [rax], al
0x1c00016c2: add      byte ptr [rax], al
0x1c00016c4: add      byte ptr [rax], al
0x1c00016c6: add      byte ptr [rax], al
0x1c00016c8: add      byte ptr [rax], al
0x1c00016ca: add      byte ptr [rax], al
0x1c00016cc: add      byte ptr [rax], al
0x1c00016ce: add      byte ptr [rax], al
0x1c00016d0: add      byte ptr [rax], al
0x1c00016d2: add      byte ptr [rax], al
0x1c00016d4: add      byte ptr [rax], al
0x1c00016d6: add      byte ptr [rax], al
0x1c00016d8: add      byte ptr [rax], al
0x1c00016da: add      byte ptr [rax], al
0x1c00016dc: add      byte ptr [rax], al
0x1c00016de: add      byte ptr [rax], al
0x1c00016e0: add      byte ptr [rax], al
0x1c00016e2: add      byte ptr [rax], al
0x1c00016e4: add      byte ptr [rax], al
0x1c00016e6: add      byte ptr [rax], al
0x1c00016e8: add      byte ptr [rax], al
0x1c00016ea: add      byte ptr [rax], al
0x1c00016ec: add      byte ptr [rax], al
0x1c00016ee: add      byte ptr [rax], al
0x1c00016f0: add      byte ptr [rax], al
0x1c00016f2: add      byte ptr [rax], al
0x1c00016f4: add      byte ptr [rax], al
0x1c00016f6: add      byte ptr [rax], al
0x1c00016f8: add      byte ptr [rax], al
0x1c00016fa: add      byte ptr [rax], al
0x1c00016fc: add      byte ptr [rax], al
0x1c00016fe: add      byte ptr [rax], al
0x1c0001700: add      byte ptr [rax], al
0x1c0001702: add      byte ptr [rax], al
0x1c0001704: add      byte ptr [rax], al
0x1c0001706: add      byte ptr [rax], al
0x1c0001708: add      byte ptr [rax], al
0x1c000170a: add      byte ptr [rax], al
0x1c000170c: add      byte ptr [rax], al
0x1c000170e: add      byte ptr [rax], al
0x1c0001710: add      byte ptr [rax], al
0x1c0001712: add      byte ptr [rax], al
0x1c0001714: add      byte ptr [rax], al
0x1c0001716: add      byte ptr [rax], al
0x1c0001718: add      byte ptr [rax], al
0x1c000171a: add      byte ptr [rax], al
0x1c000171c: add      byte ptr [rax], al
0x1c000171e: add      byte ptr [rax], al
0x1c0001720: add      byte ptr [rax], al
0x1c0001722: add      byte ptr [rax], al
0x1c0001724: add      byte ptr [rax], al
0x1c0001726: add      byte ptr [rax], al
0x1c0001728: add      byte ptr [rax], al
0x1c000172a: add      byte ptr [rax], al
0x1c000172c: add      byte ptr [rax], al
0x1c000172e: add      byte ptr [rax], al
0x1c0001730: add      byte ptr [rax], al
0x1c0001732: add      byte ptr [rax], al
0x1c0001734: add      byte ptr [rax], al
0x1c0001736: add      byte ptr [rax], al
0x1c0001738: add      byte ptr [rax], al
0x1c000173a: add      byte ptr [rax], al
0x1c000173c: add      byte ptr [rax], al
0x1c000173e: add      byte ptr [rax], al
0x1c0001740: add      byte ptr [rax], al
0x1c0001742: add      byte ptr [rax], al
0x1c0001744: add      byte ptr [rax], al
0x1c0001746: add      byte ptr [rax], al
0x1c0001748: add      byte ptr [rax], al
0x1c000174a: add      byte ptr [rax], al
0x1c000174c: add      byte ptr [rax], al
0x1c000174e: add      byte ptr [rax], al
0x1c0001750: add      byte ptr [rax], al
0x1c0001752: add      byte ptr [rax], al
0x1c0001754: add      byte ptr [rax], al
0x1c0001756: add      byte ptr [rax], al
0x1c0001758: add      byte ptr [rax], al
0x1c000175a: add      byte ptr [rax], al
0x1c000175c: add      byte ptr [rax], al
0x1c000175e: add      byte ptr [rax], al
0x1c0001760: add      byte ptr [rax], al
0x1c0001762: add      byte ptr [rax], al
0x1c0001764: add      byte ptr [rax], al
0x1c0001766: add      byte ptr [rax], al
0x1c0001768: add      byte ptr [rax], al
0x1c000176a: add      byte ptr [rax], al
0x1c000176c: add      byte ptr [rax], al
0x1c000176e: add      byte ptr [rax], al
0x1c0001770: add      byte ptr [rax], al
0x1c0001772: add      byte ptr [rax], al
0x1c0001774: add      byte ptr [rax], al
0x1c0001776: add      byte ptr [rax], al
0x1c0001778: add      byte ptr [rax], al
0x1c000177a: add      byte ptr [rax], al
0x1c000177c: add      byte ptr [rax], al
0x1c000177e: add      byte ptr [rax], al
0x1c0001780: add      byte ptr [rax], al
0x1c0001782: add      byte ptr [rax], al
0x1c0001784: add      byte ptr [rax], al
0x1c0001786: add      byte ptr [rax], al
0x1c0001788: add      byte ptr [rax], al
0x1c000178a: add      byte ptr [rax], al
0x1c000178c: add      byte ptr [rax], al
0x1c000178e: add      byte ptr [rax], al
0x1c0001790: add      byte ptr [rax], al
0x1c0001792: add      byte ptr [rax], al
0x1c0001794: add      byte ptr [rax], al
0x1c0001796: add      byte ptr [rax], al
0x1c0001798: add      byte ptr [rax], al
0x1c000179a: add      byte ptr [rax], al
0x1c000179c: add      byte ptr [rax], al
0x1c000179e: add      byte ptr [rax], al
0x1c00017a0: add      byte ptr [rax], al
0x1c00017a2: add      byte ptr [rax], al
0x1c00017a4: add      byte ptr [rax], al
0x1c00017a6: add      byte ptr [rax], al
0x1c00017a8: add      byte ptr [rax], al
0x1c00017aa: add      byte ptr [rax], al
0x1c00017ac: add      byte ptr [rax], al
0x1c00017ae: add      byte ptr [rax], al
0x1c00017b0: add      byte ptr [rax], al
0x1c00017b2: add      byte ptr [rax], al
0x1c00017b4: add      byte ptr [rax], al
0x1c00017b6: add      byte ptr [rax], al
0x1c00017b8: add      byte ptr [rax], al
0x1c00017ba: add      byte ptr [rax], al
0x1c00017bc: add      byte ptr [rax], al
0x1c00017be: add      byte ptr [rax], al
0x1c00017c0: add      byte ptr [rax], al
0x1c00017c2: add      byte ptr [rax], al
0x1c00017c4: add      byte ptr [rax], al
0x1c00017c6: add      byte ptr [rax], al
0x1c00017c8: add      byte ptr [rax], al
0x1c00017ca: add      byte ptr [rax], al
0x1c00017cc: add      byte ptr [rax], al
0x1c00017ce: add      byte ptr [rax], al
0x1c00017d0: add      byte ptr [rax], al
0x1c00017d2: add      byte ptr [rax], al
0x1c00017d4: add      byte ptr [rax], al
0x1c00017d6: add      byte ptr [rax], al
0x1c00017d8: add      byte ptr [rax], al
0x1c00017da: add      byte ptr [rax], al
0x1c00017dc: add      byte ptr [rax], al
0x1c00017de: add      byte ptr [rax], al
0x1c00017e0: add      byte ptr [rax], al
0x1c00017e2: add      byte ptr [rax], al
0x1c00017e4: add      byte ptr [rax], al
0x1c00017e6: add      byte ptr [rax], al
0x1c00017e8: add      byte ptr [rax], al
0x1c00017ea: add      byte ptr [rax], al
0x1c00017ec: add      byte ptr [rax], al
0x1c00017ee: add      byte ptr [rax], al
0x1c00017f0: add      byte ptr [rax], al
0x1c00017f2: add      byte ptr [rax], al
0x1c00017f4: add      byte ptr [rax], al
0x1c00017f6: add      byte ptr [rax], al
0x1c00017f8: add      byte ptr [rax], al
0x1c00017fa: add      byte ptr [rax], al
0x1c00017fc: add      byte ptr [rax], al
0x1c00017fe: add      byte ptr [rax], al
0x1c0001800: add      byte ptr [rax], al
0x1c0001802: add      byte ptr [rax], al
0x1c0001804: add      byte ptr [rax], al
0x1c0001806: add      byte ptr [rax], al
0x1c0001808: add      byte ptr [rax], al
0x1c000180a: add      byte ptr [rax], al
0x1c000180c: add      byte ptr [rax], al
0x1c000180e: add      byte ptr [rax], al
0x1c0001810: add      byte ptr [rax], al
0x1c0001812: add      byte ptr [rax], al
0x1c0001814: add      byte ptr [rax], al
0x1c0001816: add      byte ptr [rax], al
0x1c0001818: add      byte ptr [rax], al
0x1c000181a: add      byte ptr [rax], al
0x1c000181c: add      byte ptr [rax], al
0x1c000181e: add      byte ptr [rax], al
0x1c0001820: add      byte ptr [rax], al
0x1c0001822: add      byte ptr [rax], al
0x1c0001824: add      byte ptr [rax], al
0x1c0001826: add      byte ptr [rax], al
0x1c0001828: add      byte ptr [rax], al
0x1c000182a: add      byte ptr [rax], al
0x1c000182c: add      byte ptr [rax], al
0x1c000182e: add      byte ptr [rax], al
0x1c0001830: add      byte ptr [rax], al
0x1c0001832: add      byte ptr [rax], al
0x1c0001834: add      byte ptr [rax], al
0x1c0001836: add      byte ptr [rax], al
0x1c0001838: add      byte ptr [rax], al
0x1c000183a: add      byte ptr [rax], al
0x1c000183c: add      byte ptr [rax], al
0x1c000183e: add      byte ptr [rax], al
0x1c0001840: add      byte ptr [rax], al
0x1c0001842: add      byte ptr [rax], al
0x1c0001844: add      byte ptr [rax], al
0x1c0001846: add      byte ptr [rax], al
0x1c0001848: add      byte ptr [rax], al
0x1c000184a: add      byte ptr [rax], al
0x1c000184c: add      byte ptr [rax], al
0x1c000184e: add      byte ptr [rax], al
0x1c0001850: add      byte ptr [rax], al
0x1c0001852: add      byte ptr [rax], al
0x1c0001854: add      byte ptr [rax], al
0x1c0001856: add      byte ptr [rax], al
0x1c0001858: add      byte ptr [rax], al
0x1c000185a: add      byte ptr [rax], al
0x1c000185c: add      byte ptr [rax], al
0x1c000185e: add      byte ptr [rax], al
0x1c0001860: add      byte ptr [rax], al
0x1c0001862: add      byte ptr [rax], al
0x1c0001864: add      byte ptr [rax], al
0x1c0001866: add      byte ptr [rax], al
0x1c0001868: add      byte ptr [rax], al
0x1c000186a: add      byte ptr [rax], al
0x1c000186c: add      byte ptr [rax], al
0x1c000186e: add      byte ptr [rax], al
0x1c0001870: add      byte ptr [rax], al
0x1c0001872: add      byte ptr [rax], al
0x1c0001874: add      byte ptr [rax], al
0x1c0001876: add      byte ptr [rax], al
0x1c0001878: add      byte ptr [rax], al
0x1c000187a: add      byte ptr [rax], al
0x1c000187c: add      byte ptr [rax], al
0x1c000187e: add      byte ptr [rax], al
0x1c0001880: add      byte ptr [rax], al
0x1c0001882: add      byte ptr [rax], al
0x1c0001884: add      byte ptr [rax], al
0x1c0001886: add      byte ptr [rax], al
0x1c0001888: add      byte ptr [rax], al
0x1c000188a: add      byte ptr [rax], al
0x1c000188c: add      byte ptr [rax], al
0x1c000188e: add      byte ptr [rax], al
0x1c0001890: add      byte ptr [rax], al
0x1c0001892: add      byte ptr [rax], al
0x1c0001894: add      byte ptr [rax], al
0x1c0001896: add      byte ptr [rax], al
0x1c0001898: add      byte ptr [rax], al
0x1c000189a: add      byte ptr [rax], al
0x1c000189c: add      byte ptr [rax], al
0x1c000189e: add      byte ptr [rax], al
0x1c00018a0: add      byte ptr [rax], al
0x1c00018a2: add      byte ptr [rax], al
0x1c00018a4: add      byte ptr [rax], al
0x1c00018a6: add      byte ptr [rax], al
0x1c00018a8: add      byte ptr [rax], al
0x1c00018aa: add      byte ptr [rax], al
0x1c00018ac: add      byte ptr [rax], al
0x1c00018ae: add      byte ptr [rax], al
0x1c00018b0: add      byte ptr [rax], al
0x1c00018b2: add      byte ptr [rax], al
0x1c00018b4: add      byte ptr [rax], al
0x1c00018b6: add      byte ptr [rax], al
0x1c00018b8: add      byte ptr [rax], al
0x1c00018ba: add      byte ptr [rax], al
0x1c00018bc: add      byte ptr [rax], al
0x1c00018be: add      byte ptr [rax], al
0x1c00018c0: add      byte ptr [rax], al
0x1c00018c2: add      byte ptr [rax], al
0x1c00018c4: add      byte ptr [rax], al
0x1c00018c6: add      byte ptr [rax], al
0x1c00018c8: add      byte ptr [rax], al
0x1c00018ca: add      byte ptr [rax], al
0x1c00018cc: add      byte ptr [rax], al
0x1c00018ce: add      byte ptr [rax], al
0x1c00018d0: add      byte ptr [rax], al
0x1c00018d2: add      byte ptr [rax], al
0x1c00018d4: add      byte ptr [rax], al
0x1c00018d6: add      byte ptr [rax], al
0x1c00018d8: add      byte ptr [rax], al
0x1c00018da: add      byte ptr [rax], al
0x1c00018dc: add      byte ptr [rax], al
0x1c00018de: add      byte ptr [rax], al
0x1c00018e0: add      byte ptr [rax], al
0x1c00018e2: add      byte ptr [rax], al
0x1c00018e4: add      byte ptr [rax], al
0x1c00018e6: add      byte ptr [rax], al
0x1c00018e8: add      byte ptr [rax], al
0x1c00018ea: add      byte ptr [rax], al
0x1c00018ec: add      byte ptr [rax], al
0x1c00018ee: add      byte ptr [rax], al
0x1c00018f0: add      byte ptr [rax], al
0x1c00018f2: add      byte ptr [rax], al
0x1c00018f4: add      byte ptr [rax], al
0x1c00018f6: add      byte ptr [rax], al
0x1c00018f8: add      byte ptr [rax], al
0x1c00018fa: add      byte ptr [rax], al
0x1c00018fc: add      byte ptr [rax], al
0x1c00018fe: add      byte ptr [rax], al
0x1c0001900: add      byte ptr [rax], al
0x1c0001902: add      byte ptr [rax], al
0x1c0001904: add      byte ptr [rax], al
0x1c0001906: add      byte ptr [rax], al
0x1c0001908: add      byte ptr [rax], al
0x1c000190a: add      byte ptr [rax], al
0x1c000190c: add      byte ptr [rax], al
0x1c000190e: add      byte ptr [rax], al
0x1c0001910: add      byte ptr [rax], al
0x1c0001912: add      byte ptr [rax], al
0x1c0001914: add      byte ptr [rax], al
0x1c0001916: add      byte ptr [rax], al
0x1c0001918: add      byte ptr [rax], al
0x1c000191a: add      byte ptr [rax], al
0x1c000191c: add      byte ptr [rax], al
0x1c000191e: add      byte ptr [rax], al
0x1c0001920: add      byte ptr [rax], al
0x1c0001922: add      byte ptr [rax], al
0x1c0001924: add      byte ptr [rax], al
0x1c0001926: add      byte ptr [rax], al
0x1c0001928: add      byte ptr [rax], al
0x1c000192a: add      byte ptr [rax], al
0x1c000192c: add      byte ptr [rax], al
0x1c000192e: add      byte ptr [rax], al
0x1c0001930: add      byte ptr [rax], al
0x1c0001932: add      byte ptr [rax], al
0x1c0001934: add      byte ptr [rax], al
0x1c0001936: add      byte ptr [rax], al
0x1c0001938: add      byte ptr [rax], al
0x1c000193a: add      byte ptr [rax], al
0x1c000193c: add      byte ptr [rax], al
0x1c000193e: add      byte ptr [rax], al
0x1c0001940: add      byte ptr [rax], al
0x1c0001942: add      byte ptr [rax], al
0x1c0001944: add      byte ptr [rax], al
0x1c0001946: add      byte ptr [rax], al
0x1c0001948: add      byte ptr [rax], al
0x1c000194a: add      byte ptr [rax], al
0x1c000194c: add      byte ptr [rax], al
0x1c000194e: add      byte ptr [rax], al
0x1c0001950: add      byte ptr [rax], al
0x1c0001952: add      byte ptr [rax], al
0x1c0001954: add      byte ptr [rax], al
0x1c0001956: add      byte ptr [rax], al
0x1c0001958: add      byte ptr [rax], al
0x1c000195a: add      byte ptr [rax], al
0x1c000195c: add      byte ptr [rax], al
0x1c000195e: add      byte ptr [rax], al
0x1c0001960: add      byte ptr [rax], al
0x1c0001962: add      byte ptr [rax], al
0x1c0001964: add      byte ptr [rax], al
0x1c0001966: add      byte ptr [rax], al
0x1c0001968: add      byte ptr [rax], al
0x1c000196a: add      byte ptr [rax], al
0x1c000196c: add      byte ptr [rax], al
0x1c000196e: add      byte ptr [rax], al
0x1c0001970: add      byte ptr [rax], al
0x1c0001972: add      byte ptr [rax], al
0x1c0001974: add      byte ptr [rax], al
0x1c0001976: add      byte ptr [rax], al
0x1c0001978: add      byte ptr [rax], al
0x1c000197a: add      byte ptr [rax], al
0x1c000197c: add      byte ptr [rax], al
0x1c000197e: add      byte ptr [rax], al
0x1c0001980: add      byte ptr [rax], al
0x1c0001982: add      byte ptr [rax], al
0x1c0001984: add      byte ptr [rax], al
0x1c0001986: add      byte ptr [rax], al
0x1c0001988: add      byte ptr [rax], al
0x1c000198a: add      byte ptr [rax], al
0x1c000198c: add      byte ptr [rax], al
0x1c000198e: add      byte ptr [rax], al
0x1c0001990: add      byte ptr [rax], al
0x1c0001992: add      byte ptr [rax], al
0x1c0001994: add      byte ptr [rax], al
0x1c0001996: add      byte ptr [rax], al
0x1c0001998: add      byte ptr [rax], al
0x1c000199a: add      byte ptr [rax], al
0x1c000199c: add      byte ptr [rax], al
0x1c000199e: add      byte ptr [rax], al
0x1c00019a0: add      byte ptr [rax], al
0x1c00019a2: add      byte ptr [rax], al
0x1c00019a4: add      byte ptr [rax], al
0x1c00019a6: add      byte ptr [rax], al
0x1c00019a8: add      byte ptr [rax], al
0x1c00019aa: add      byte ptr [rax], al
0x1c00019ac: add      byte ptr [rax], al
0x1c00019ae: add      byte ptr [rax], al
0x1c00019b0: add      byte ptr [rax], al
0x1c00019b2: add      byte ptr [rax], al
0x1c00019b4: add      byte ptr [rax], al
0x1c00019b6: add      byte ptr [rax], al
0x1c00019b8: add      byte ptr [rax], al
0x1c00019ba: add      byte ptr [rax], al
0x1c00019bc: add      byte ptr [rax], al
0x1c00019be: add      byte ptr [rax], al
0x1c00019c0: add      byte ptr [rax], al
0x1c00019c2: add      byte ptr [rax], al
0x1c00019c4: add      byte ptr [rax], al
0x1c00019c6: add      byte ptr [rax], al
0x1c00019c8: add      byte ptr [rax], al
0x1c00019ca: add      byte ptr [rax], al
0x1c00019cc: add      byte ptr [rax], al
0x1c00019ce: add      byte ptr [rax], al
0x1c00019d0: add      byte ptr [rax], al
0x1c00019d2: add      byte ptr [rax], al
0x1c00019d4: add      byte ptr [rax], al
0x1c00019d6: add      byte ptr [rax], al
0x1c00019d8: add      byte ptr [rax], al
0x1c00019da: add      byte ptr [rax], al
0x1c00019dc: add      byte ptr [rax], al
0x1c00019de: add      byte ptr [rax], al
0x1c00019e0: add      byte ptr [rax], al
0x1c00019e2: add      byte ptr [rax], al
0x1c00019e4: add      byte ptr [rax], al
0x1c00019e6: add      byte ptr [rax], al
0x1c00019e8: add      byte ptr [rax], al
0x1c00019ea: add      byte ptr [rax], al
0x1c00019ec: add      byte ptr [rax], al
0x1c00019ee: add      byte ptr [rax], al
0x1c00019f0: add      byte ptr [rax], al
0x1c00019f2: add      byte ptr [rax], al
0x1c00019f4: add      byte ptr [rax], al
0x1c00019f6: add      byte ptr [rax], al
0x1c00019f8: add      byte ptr [rax], al
0x1c00019fa: add      byte ptr [rax], al
0x1c00019fc: add      byte ptr [rax], al
0x1c00019fe: add      byte ptr [rax], al
0x1c0001a00: add      byte ptr [rax], al
0x1c0001a02: add      byte ptr [rax], al
0x1c0001a04: add      byte ptr [rax], al
0x1c0001a06: add      byte ptr [rax], al
0x1c0001a08: add      byte ptr [rax], al
0x1c0001a0a: add      byte ptr [rax], al
0x1c0001a0c: add      byte ptr [rax], al
0x1c0001a0e: add      byte ptr [rax], al
0x1c0001a10: add      byte ptr [rax], al
0x1c0001a12: add      byte ptr [rax], al
0x1c0001a14: add      byte ptr [rax], al
0x1c0001a16: add      byte ptr [rax], al
0x1c0001a18: add      byte ptr [rax], al
0x1c0001a1a: add      byte ptr [rax], al
0x1c0001a1c: add      byte ptr [rax], al
0x1c0001a1e: add      byte ptr [rax], al
0x1c0001a20: add      byte ptr [rax], al
0x1c0001a22: add      byte ptr [rax], al
0x1c0001a24: add      byte ptr [rax], al
0x1c0001a26: add      byte ptr [rax], al
0x1c0001a28: add      byte ptr [rax], al
0x1c0001a2a: add      byte ptr [rax], al
0x1c0001a2c: add      byte ptr [rax], al
0x1c0001a2e: add      byte ptr [rax], al
0x1c0001a30: add      byte ptr [rax], al
0x1c0001a32: add      byte ptr [rax], al
0x1c0001a34: add      byte ptr [rax], al
0x1c0001a36: add      byte ptr [rax], al
0x1c0001a38: add      byte ptr [rax], al
0x1c0001a3a: add      byte ptr [rax], al
0x1c0001a3c: add      byte ptr [rax], al
0x1c0001a3e: add      byte ptr [rax], al
0x1c0001a40: add      byte ptr [rax], al
0x1c0001a42: add      byte ptr [rax], al
0x1c0001a44: add      byte ptr [rax], al
0x1c0001a46: add      byte ptr [rax], al
0x1c0001a48: add      byte ptr [rax], al
0x1c0001a4a: add      byte ptr [rax], al
0x1c0001a4c: add      byte ptr [rax], al
0x1c0001a4e: add      byte ptr [rax], al
0x1c0001a50: add      byte ptr [rax], al
0x1c0001a52: add      byte ptr [rax], al
0x1c0001a54: add      byte ptr [rax], al
0x1c0001a56: add      byte ptr [rax], al
0x1c0001a58: add      byte ptr [rax], al
0x1c0001a5a: add      byte ptr [rax], al
0x1c0001a5c: add      byte ptr [rax], al
0x1c0001a5e: add      byte ptr [rax], al
0x1c0001a60: add      byte ptr [rax], al
0x1c0001a62: add      byte ptr [rax], al
0x1c0001a64: add      byte ptr [rax], al
0x1c0001a66: add      byte ptr [rax], al
0x1c0001a68: add      byte ptr [rax], al
0x1c0001a6a: add      byte ptr [rax], al
0x1c0001a6c: add      byte ptr [rax], al
0x1c0001a6e: add      byte ptr [rax], al
0x1c0001a70: add      byte ptr [rax], al
0x1c0001a72: add      byte ptr [rax], al
0x1c0001a74: add      byte ptr [rax], al
0x1c0001a76: add      byte ptr [rax], al
0x1c0001a78: add      byte ptr [rax], al
0x1c0001a7a: add      byte ptr [rax], al
0x1c0001a7c: add      byte ptr [rax], al
0x1c0001a7e: add      byte ptr [rax], al
0x1c0001a80: add      byte ptr [rax], al
0x1c0001a82: add      byte ptr [rax], al
0x1c0001a84: add      byte ptr [rax], al
0x1c0001a86: add      byte ptr [rax], al
0x1c0001a88: add      byte ptr [rax], al
0x1c0001a8a: add      byte ptr [rax], al
0x1c0001a8c: add      byte ptr [rax], al
0x1c0001a8e: add      byte ptr [rax], al
0x1c0001a90: add      byte ptr [rax], al
0x1c0001a92: add      byte ptr [rax], al
0x1c0001a94: add      byte ptr [rax], al
0x1c0001a96: add      byte ptr [rax], al
0x1c0001a98: add      byte ptr [rax], al
0x1c0001a9a: add      byte ptr [rax], al
0x1c0001a9c: add      byte ptr [rax], al
0x1c0001a9e: add      byte ptr [rax], al
0x1c0001aa0: add      byte ptr [rax], al
0x1c0001aa2: add      byte ptr [rax], al
0x1c0001aa4: add      byte ptr [rax], al
0x1c0001aa6: add      byte ptr [rax], al
0x1c0001aa8: add      byte ptr [rax], al
0x1c0001aaa: add      byte ptr [rax], al
0x1c0001aac: add      byte ptr [rax], al
0x1c0001aae: add      byte ptr [rax], al
0x1c0001ab0: add      byte ptr [rax], al
0x1c0001ab2: add      byte ptr [rax], al
0x1c0001ab4: add      byte ptr [rax], al
0x1c0001ab6: add      byte ptr [rax], al
0x1c0001ab8: add      byte ptr [rax], al
0x1c0001aba: add      byte ptr [rax], al
0x1c0001abc: add      byte ptr [rax], al
0x1c0001abe: add      byte ptr [rax], al
0x1c0001ac0: add      byte ptr [rax], al
0x1c0001ac2: add      byte ptr [rax], al
0x1c0001ac4: add      byte ptr [rax], al
0x1c0001ac6: add      byte ptr [rax], al
0x1c0001ac8: add      byte ptr [rax], al
0x1c0001aca: add      byte ptr [rax], al
0x1c0001acc: add      byte ptr [rax], al
0x1c0001ace: add      byte ptr [rax], al
0x1c0001ad0: add      byte ptr [rax], al
0x1c0001ad2: add      byte ptr [rax], al
0x1c0001ad4: add      byte ptr [rax], al
0x1c0001ad6: add      byte ptr [rax], al
0x1c0001ad8: add      byte ptr [rax], al
0x1c0001ada: add      byte ptr [rax], al
0x1c0001adc: add      byte ptr [rax], al
0x1c0001ade: add      byte ptr [rax], al
0x1c0001ae0: add      byte ptr [rax], al
0x1c0001ae2: add      byte ptr [rax], al
0x1c0001ae4: add      byte ptr [rax], al
0x1c0001ae6: add      byte ptr [rax], al
0x1c0001ae8: add      byte ptr [rax], al
0x1c0001aea: add      byte ptr [rax], al
0x1c0001aec: add      byte ptr [rax], al
0x1c0001aee: add      byte ptr [rax], al
0x1c0001af0: add      byte ptr [rax], al
0x1c0001af2: add      byte ptr [rax], al
0x1c0001af4: add      byte ptr [rax], al
0x1c0001af6: add      byte ptr [rax], al
0x1c0001af8: add      byte ptr [rax], al
0x1c0001afa: add      byte ptr [rax], al
0x1c0001afc: add      byte ptr [rax], al
0x1c0001afe: add      byte ptr [rax], al
0x1c0001b00: add      byte ptr [rax], al
0x1c0001b02: add      byte ptr [rax], al
0x1c0001b04: add      byte ptr [rax], al
0x1c0001b06: add      byte ptr [rax], al
0x1c0001b08: add      byte ptr [rax], al
0x1c0001b0a: add      byte ptr [rax], al
0x1c0001b0c: add      byte ptr [rax], al
0x1c0001b0e: add      byte ptr [rax], al
0x1c0001b10: add      byte ptr [rax], al
0x1c0001b12: add      byte ptr [rax], al
0x1c0001b14: add      byte ptr [rax], al
0x1c0001b16: add      byte ptr [rax], al
0x1c0001b18: add      byte ptr [rax], al
0x1c0001b1a: add      byte ptr [rax], al
0x1c0001b1c: add      byte ptr [rax], al
0x1c0001b1e: add      byte ptr [rax], al
0x1c0001b20: add      byte ptr [rax], al
0x1c0001b22: add      byte ptr [rax], al
0x1c0001b24: add      byte ptr [rax], al
0x1c0001b26: add      byte ptr [rax], al
0x1c0001b28: add      byte ptr [rax], al
0x1c0001b2a: add      byte ptr [rax], al
0x1c0001b2c: add      byte ptr [rax], al
0x1c0001b2e: add      byte ptr [rax], al
0x1c0001b30: add      byte ptr [rax], al
0x1c0001b32: add      byte ptr [rax], al
0x1c0001b34: add      byte ptr [rax], al
0x1c0001b36: add      byte ptr [rax], al
0x1c0001b38: add      byte ptr [rax], al
0x1c0001b3a: add      byte ptr [rax], al
0x1c0001b3c: add      byte ptr [rax], al
0x1c0001b3e: add      byte ptr [rax], al
0x1c0001b40: add      byte ptr [rax], al
0x1c0001b42: add      byte ptr [rax], al
0x1c0001b44: add      byte ptr [rax], al
0x1c0001b46: add      byte ptr [rax], al
0x1c0001b48: add      byte ptr [rax], al
0x1c0001b4a: add      byte ptr [rax], al
0x1c0001b4c: add      byte ptr [rax], al
0x1c0001b4e: add      byte ptr [rax], al
0x1c0001b50: add      byte ptr [rax], al
0x1c0001b52: add      byte ptr [rax], al
0x1c0001b54: add      byte ptr [rax], al
0x1c0001b56: add      byte ptr [rax], al
0x1c0001b58: add      byte ptr [rax], al
0x1c0001b5a: add      byte ptr [rax], al
0x1c0001b5c: add      byte ptr [rax], al
0x1c0001b5e: add      byte ptr [rax], al
0x1c0001b60: add      byte ptr [rax], al
0x1c0001b62: add      byte ptr [rax], al
0x1c0001b64: add      byte ptr [rax], al
0x1c0001b66: add      byte ptr [rax], al
0x1c0001b68: add      byte ptr [rax], al
0x1c0001b6a: add      byte ptr [rax], al
0x1c0001b6c: add      byte ptr [rax], al
0x1c0001b6e: add      byte ptr [rax], al
0x1c0001b70: add      byte ptr [rax], al
0x1c0001b72: add      byte ptr [rax], al
0x1c0001b74: add      byte ptr [rax], al
0x1c0001b76: add      byte ptr [rax], al
0x1c0001b78: add      byte ptr [rax], al
0x1c0001b7a: add      byte ptr [rax], al
0x1c0001b7c: add      byte ptr [rax], al
0x1c0001b7e: add      byte ptr [rax], al
0x1c0001b80: add      byte ptr [rax], al
0x1c0001b82: add      byte ptr [rax], al
0x1c0001b84: add      byte ptr [rax], al
0x1c0001b86: add      byte ptr [rax], al
0x1c0001b88: add      byte ptr [rax], al
0x1c0001b8a: add      byte ptr [rax], al
0x1c0001b8c: add      byte ptr [rax], al
0x1c0001b8e: add      byte ptr [rax], al
0x1c0001b90: add      byte ptr [rax], al
0x1c0001b92: add      byte ptr [rax], al
0x1c0001b94: add      byte ptr [rax], al
0x1c0001b96: add      byte ptr [rax], al
0x1c0001b98: add      byte ptr [rax], al
0x1c0001b9a: add      byte ptr [rax], al
0x1c0001b9c: add      byte ptr [rax], al
0x1c0001b9e: add      byte ptr [rax], al
0x1c0001ba0: add      byte ptr [rax], al
0x1c0001ba2: add      byte ptr [rax], al
0x1c0001ba4: add      byte ptr [rax], al
0x1c0001ba6: add      byte ptr [rax], al
0x1c0001ba8: add      byte ptr [rax], al
0x1c0001baa: add      byte ptr [rax], al
0x1c0001bac: add      byte ptr [rax], al
0x1c0001bae: add      byte ptr [rax], al
0x1c0001bb0: add      byte ptr [rax], al
0x1c0001bb2: add      byte ptr [rax], al
0x1c0001bb4: add      byte ptr [rax], al
0x1c0001bb6: add      byte ptr [rax], al
0x1c0001bb8: add      byte ptr [rax], al
0x1c0001bba: add      byte ptr [rax], al
0x1c0001bbc: add      byte ptr [rax], al
0x1c0001bbe: add      byte ptr [rax], al
0x1c0001bc0: add      byte ptr [rax], al
0x1c0001bc2: add      byte ptr [rax], al
0x1c0001bc4: add      byte ptr [rax], al
0x1c0001bc6: add      byte ptr [rax], al
0x1c0001bc8: add      byte ptr [rax], al
0x1c0001bca: add      byte ptr [rax], al
0x1c0001bcc: add      byte ptr [rax], al
0x1c0001bce: add      byte ptr [rax], al
0x1c0001bd0: add      byte ptr [rax], al
0x1c0001bd2: add      byte ptr [rax], al
0x1c0001bd4: add      byte ptr [rax], al
0x1c0001bd6: add      byte ptr [rax], al
0x1c0001bd8: add      byte ptr [rax], al
0x1c0001bda: add      byte ptr [rax], al
0x1c0001bdc: add      byte ptr [rax], al
0x1c0001bde: add      byte ptr [rax], al
0x1c0001be0: add      byte ptr [rax], al
0x1c0001be2: add      byte ptr [rax], al
0x1c0001be4: add      byte ptr [rax], al
0x1c0001be6: add      byte ptr [rax], al
0x1c0001be8: add      byte ptr [rax], al
0x1c0001bea: add      byte ptr [rax], al
0x1c0001bec: add      byte ptr [rax], al
0x1c0001bee: add      byte ptr [rax], al
0x1c0001bf0: add      byte ptr [rax], al
0x1c0001bf2: add      byte ptr [rax], al
0x1c0001bf4: add      byte ptr [rax], al
0x1c0001bf6: add      byte ptr [rax], al
0x1c0001bf8: add      byte ptr [rax], al
0x1c0001bfa: add      byte ptr [rax], al
0x1c0001bfc: add      byte ptr [rax], al
0x1c0001bfe: add      byte ptr [rax], al
0x1c0001c00: add      byte ptr [rax], al
0x1c0001c02: add      byte ptr [rax], al
0x1c0001c04: add      byte ptr [rax], al
0x1c0001c06: add      byte ptr [rax], al
0x1c0001c08: add      byte ptr [rax], al
0x1c0001c0a: add      byte ptr [rax], al
0x1c0001c0c: add      byte ptr [rax], al
0x1c0001c0e: add      byte ptr [rax], al
0x1c0001c10: add      byte ptr [rax], al
0x1c0001c12: add      byte ptr [rax], al
0x1c0001c14: add      byte ptr [rax], al
0x1c0001c16: add      byte ptr [rax], al
0x1c0001c18: add      byte ptr [rax], al
0x1c0001c1a: add      byte ptr [rax], al
0x1c0001c1c: add      byte ptr [rax], al
0x1c0001c1e: add      byte ptr [rax], al
0x1c0001c20: add      byte ptr [rax], al
0x1c0001c22: add      byte ptr [rax], al
0x1c0001c24: add      byte ptr [rax], al
0x1c0001c26: add      byte ptr [rax], al
0x1c0001c28: add      byte ptr [rax], al
0x1c0001c2a: add      byte ptr [rax], al
0x1c0001c2c: add      byte ptr [rax], al
0x1c0001c2e: add      byte ptr [rax], al
0x1c0001c30: add      byte ptr [rax], al
0x1c0001c32: add      byte ptr [rax], al
0x1c0001c34: add      byte ptr [rax], al
0x1c0001c36: add      byte ptr [rax], al
0x1c0001c38: add      byte ptr [rax], al
0x1c0001c3a: add      byte ptr [rax], al
0x1c0001c3c: add      byte ptr [rax], al
0x1c0001c3e: add      byte ptr [rax], al
0x1c0001c40: add      byte ptr [rax], al
0x1c0001c42: add      byte ptr [rax], al
0x1c0001c44: add      byte ptr [rax], al
0x1c0001c46: add      byte ptr [rax], al
0x1c0001c48: add      byte ptr [rax], al
0x1c0001c4a: add      byte ptr [rax], al
0x1c0001c4c: add      byte ptr [rax], al
0x1c0001c4e: add      byte ptr [rax], al
0x1c0001c50: add      byte ptr [rax], al
0x1c0001c52: add      byte ptr [rax], al
0x1c0001c54: add      byte ptr [rax], al
0x1c0001c56: add      byte ptr [rax], al
0x1c0001c58: add      byte ptr [rax], al
0x1c0001c5a: add      byte ptr [rax], al
0x1c0001c5c: add      byte ptr [rax], al
0x1c0001c5e: add      byte ptr [rax], al
0x1c0001c60: add      byte ptr [rax], al
0x1c0001c62: add      byte ptr [rax], al
0x1c0001c64: add      byte ptr [rax], al
0x1c0001c66: add      byte ptr [rax], al
0x1c0001c68: add      byte ptr [rax], al
0x1c0001c6a: add      byte ptr [rax], al
0x1c0001c6c: add      byte ptr [rax], al
0x1c0001c6e: add      byte ptr [rax], al
0x1c0001c70: add      byte ptr [rax], al
0x1c0001c72: add      byte ptr [rax], al
0x1c0001c74: add      byte ptr [rax], al
0x1c0001c76: add      byte ptr [rax], al
0x1c0001c78: add      byte ptr [rax], al
0x1c0001c7a: add      byte ptr [rax], al
0x1c0001c7c: add      byte ptr [rax], al
0x1c0001c7e: add      byte ptr [rax], al
0x1c0001c80: add      byte ptr [rax], al
0x1c0001c82: add      byte ptr [rax], al
0x1c0001c84: add      byte ptr [rax], al
0x1c0001c86: add      byte ptr [rax], al
0x1c0001c88: add      byte ptr [rax], al
0x1c0001c8a: add      byte ptr [rax], al
0x1c0001c8c: add      byte ptr [rax], al
0x1c0001c8e: add      byte ptr [rax], al
0x1c0001c90: add      byte ptr [rax], al
0x1c0001c92: add      byte ptr [rax], al
0x1c0001c94: add      byte ptr [rax], al
0x1c0001c96: add      byte ptr [rax], al
0x1c0001c98: add      byte ptr [rax], al
0x1c0001c9a: add      byte ptr [rax], al
0x1c0001c9c: add      byte ptr [rax], al
0x1c0001c9e: add      byte ptr [rax], al
0x1c0001ca0: add      byte ptr [rax], al
0x1c0001ca2: add      byte ptr [rax], al
0x1c0001ca4: add      byte ptr [rax], al
0x1c0001ca6: add      byte ptr [rax], al
0x1c0001ca8: add      byte ptr [rax], al
0x1c0001caa: add      byte ptr [rax], al
0x1c0001cac: add      byte ptr [rax], al
0x1c0001cae: add      byte ptr [rax], al
0x1c0001cb0: add      byte ptr [rax], al
0x1c0001cb2: add      byte ptr [rax], al
0x1c0001cb4: add      byte ptr [rax], al
0x1c0001cb6: add      byte ptr [rax], al
0x1c0001cb8: add      byte ptr [rax], al
0x1c0001cba: add      byte ptr [rax], al
0x1c0001cbc: add      byte ptr [rax], al
0x1c0001cbe: add      byte ptr [rax], al
0x1c0001cc0: add      byte ptr [rax], al
0x1c0001cc2: add      byte ptr [rax], al
0x1c0001cc4: add      byte ptr [rax], al
0x1c0001cc6: add      byte ptr [rax], al
0x1c0001cc8: add      byte ptr [rax], al
0x1c0001cca: add      byte ptr [rax], al
0x1c0001ccc: add      byte ptr [rax], al
0x1c0001cce: add      byte ptr [rax], al
0x1c0001cd0: add      byte ptr [rax], al
0x1c0001cd2: add      byte ptr [rax], al
0x1c0001cd4: add      byte ptr [rax], al
0x1c0001cd6: add      byte ptr [rax], al
0x1c0001cd8: add      byte ptr [rax], al
0x1c0001cda: add      byte ptr [rax], al
0x1c0001cdc: add      byte ptr [rax], al
0x1c0001cde: add      byte ptr [rax], al
0x1c0001ce0: add      byte ptr [rax], al
0x1c0001ce2: add      byte ptr [rax], al
0x1c0001ce4: add      byte ptr [rax], al
0x1c0001ce6: add      byte ptr [rax], al
0x1c0001ce8: add      byte ptr [rax], al
0x1c0001cea: add      byte ptr [rax], al
0x1c0001cec: add      byte ptr [rax], al
0x1c0001cee: add      byte ptr [rax], al
0x1c0001cf0: add      byte ptr [rax], al
0x1c0001cf2: add      byte ptr [rax], al
0x1c0001cf4: add      byte ptr [rax], al
0x1c0001cf6: add      byte ptr [rax], al
0x1c0001cf8: add      byte ptr [rax], al
0x1c0001cfa: add      byte ptr [rax], al
0x1c0001cfc: add      byte ptr [rax], al
0x1c0001cfe: add      byte ptr [rax], al
0x1c0001d00: add      byte ptr [rax], al
0x1c0001d02: add      byte ptr [rax], al
0x1c0001d04: add      byte ptr [rax], al
0x1c0001d06: add      byte ptr [rax], al
0x1c0001d08: add      byte ptr [rax], al
0x1c0001d0a: add      byte ptr [rax], al
0x1c0001d0c: add      byte ptr [rax], al
0x1c0001d0e: add      byte ptr [rax], al
0x1c0001d10: add      byte ptr [rax], al
0x1c0001d12: add      byte ptr [rax], al
0x1c0001d14: add      byte ptr [rax], al
0x1c0001d16: add      byte ptr [rax], al
0x1c0001d18: add      byte ptr [rax], al
0x1c0001d1a: add      byte ptr [rax], al
0x1c0001d1c: add      byte ptr [rax], al
0x1c0001d1e: add      byte ptr [rax], al
0x1c0001d20: add      byte ptr [rax], al
0x1c0001d22: add      byte ptr [rax], al
0x1c0001d24: add      byte ptr [rax], al
0x1c0001d26: add      byte ptr [rax], al
0x1c0001d28: add      byte ptr [rax], al
0x1c0001d2a: add      byte ptr [rax], al
0x1c0001d2c: add      byte ptr [rax], al
0x1c0001d2e: add      byte ptr [rax], al
0x1c0001d30: add      byte ptr [rax], al
0x1c0001d32: add      byte ptr [rax], al
0x1c0001d34: add      byte ptr [rax], al
0x1c0001d36: add      byte ptr [rax], al
0x1c0001d38: add      byte ptr [rax], al
0x1c0001d3a: add      byte ptr [rax], al
0x1c0001d3c: add      byte ptr [rax], al
0x1c0001d3e: add      byte ptr [rax], al
0x1c0001d40: add      byte ptr [rax], al
0x1c0001d42: add      byte ptr [rax], al
0x1c0001d44: add      byte ptr [rax], al
0x1c0001d46: add      byte ptr [rax], al
0x1c0001d48: add      byte ptr [rax], al
0x1c0001d4a: add      byte ptr [rax], al
0x1c0001d4c: add      byte ptr [rax], al
0x1c0001d4e: add      byte ptr [rax], al
0x1c0001d50: add      byte ptr [rax], al
0x1c0001d52: add      byte ptr [rax], al
0x1c0001d54: add      byte ptr [rax], al
0x1c0001d56: add      byte ptr [rax], al
0x1c0001d58: add      byte ptr [rax], al
0x1c0001d5a: add      byte ptr [rax], al
0x1c0001d5c: add      byte ptr [rax], al
0x1c0001d5e: add      byte ptr [rax], al
0x1c0001d60: add      byte ptr [rax], al
0x1c0001d62: add      byte ptr [rax], al
0x1c0001d64: add      byte ptr [rax], al
0x1c0001d66: add      byte ptr [rax], al
0x1c0001d68: add      byte ptr [rax], al
0x1c0001d6a: add      byte ptr [rax], al
0x1c0001d6c: add      byte ptr [rax], al
0x1c0001d6e: add      byte ptr [rax], al
0x1c0001d70: add      byte ptr [rax], al
0x1c0001d72: add      byte ptr [rax], al
0x1c0001d74: add      byte ptr [rax], al
0x1c0001d76: add      byte ptr [rax], al
0x1c0001d78: add      byte ptr [rax], al
0x1c0001d7a: add      byte ptr [rax], al
0x1c0001d7c: add      byte ptr [rax], al
0x1c0001d7e: add      byte ptr [rax], al
0x1c0001d80: add      byte ptr [rax], al
0x1c0001d82: add      byte ptr [rax], al
0x1c0001d84: add      byte ptr [rax], al
0x1c0001d86: add      byte ptr [rax], al
0x1c0001d88: add      byte ptr [rax], al
0x1c0001d8a: add      byte ptr [rax], al
0x1c0001d8c: add      byte ptr [rax], al
0x1c0001d8e: add      byte ptr [rax], al
0x1c0001d90: add      byte ptr [rax], al
0x1c0001d92: add      byte ptr [rax], al
0x1c0001d94: add      byte ptr [rax], al
0x1c0001d96: add      byte ptr [rax], al
0x1c0001d98: add      byte ptr [rax], al
0x1c0001d9a: add      byte ptr [rax], al
0x1c0001d9c: add      byte ptr [rax], al
0x1c0001d9e: add      byte ptr [rax], al
0x1c0001da0: add      byte ptr [rax], al
0x1c0001da2: add      byte ptr [rax], al
0x1c0001da4: add      byte ptr [rax], al
0x1c0001da6: add      byte ptr [rax], al
0x1c0001da8: add      byte ptr [rax], al
0x1c0001daa: add      byte ptr [rax], al
0x1c0001dac: add      byte ptr [rax], al
0x1c0001dae: add      byte ptr [rax], al
0x1c0001db0: add      byte ptr [rax], al
0x1c0001db2: add      byte ptr [rax], al
0x1c0001db4: add      byte ptr [rax], al
0x1c0001db6: add      byte ptr [rax], al
0x1c0001db8: add      byte ptr [rax], al
0x1c0001dba: add      byte ptr [rax], al
0x1c0001dbc: add      byte ptr [rax], al
0x1c0001dbe: add      byte ptr [rax], al
0x1c0001dc0: add      byte ptr [rax], al
0x1c0001dc2: add      byte ptr [rax], al
0x1c0001dc4: add      byte ptr [rax], al
0x1c0001dc6: add      byte ptr [rax], al
0x1c0001dc8: add      byte ptr [rax], al
0x1c0001dca: add      byte ptr [rax], al
0x1c0001dcc: add      byte ptr [rax], al
0x1c0001dce: add      byte ptr [rax], al
0x1c0001dd0: add      byte ptr [rax], al
0x1c0001dd2: add      byte ptr [rax], al
0x1c0001dd4: add      byte ptr [rax], al
0x1c0001dd6: add      byte ptr [rax], al
0x1c0001dd8: add      byte ptr [rax], al
0x1c0001dda: add      byte ptr [rax], al
0x1c0001ddc: add      byte ptr [rax], al
0x1c0001dde: add      byte ptr [rax], al
0x1c0001de0: add      byte ptr [rax], al
0x1c0001de2: add      byte ptr [rax], al
0x1c0001de4: add      byte ptr [rax], al
0x1c0001de6: add      byte ptr [rax], al
0x1c0001de8: add      byte ptr [rax], al
0x1c0001dea: add      byte ptr [rax], al
0x1c0001dec: add      byte ptr [rax], al
0x1c0001dee: add      byte ptr [rax], al
0x1c0001df0: add      byte ptr [rax], al
0x1c0001df2: add      byte ptr [rax], al
0x1c0001df4: add      byte ptr [rax], al
0x1c0001df6: add      byte ptr [rax], al
0x1c0001df8: add      byte ptr [rax], al
0x1c0001dfa: add      byte ptr [rax], al
0x1c0001dfc: add      byte ptr [rax], al
0x1c0001dfe: add      byte ptr [rax], al
0x1c0001e00: add      byte ptr [rax], al
0x1c0001e02: add      byte ptr [rax], al
0x1c0001e04: add      byte ptr [rax], al
0x1c0001e06: add      byte ptr [rax], al
0x1c0001e08: add      byte ptr [rax], al
0x1c0001e0a: add      byte ptr [rax], al
0x1c0001e0c: add      byte ptr [rax], al
0x1c0001e0e: add      byte ptr [rax], al
0x1c0001e10: add      byte ptr [rax], al
0x1c0001e12: add      byte ptr [rax], al
0x1c0001e14: add      byte ptr [rax], al
0x1c0001e16: add      byte ptr [rax], al
0x1c0001e18: add      byte ptr [rax], al
0x1c0001e1a: add      byte ptr [rax], al
0x1c0001e1c: add      byte ptr [rax], al
0x1c0001e1e: add      byte ptr [rax], al
0x1c0001e20: add      byte ptr [rax], al
0x1c0001e22: add      byte ptr [rax], al
0x1c0001e24: add      byte ptr [rax], al
0x1c0001e26: add      byte ptr [rax], al
0x1c0001e28: add      byte ptr [rax], al
0x1c0001e2a: add      byte ptr [rax], al
0x1c0001e2c: add      byte ptr [rax], al
0x1c0001e2e: add      byte ptr [rax], al
0x1c0001e30: add      byte ptr [rax], al
0x1c0001e32: add      byte ptr [rax], al
0x1c0001e34: add      byte ptr [rax], al
0x1c0001e36: add      byte ptr [rax], al
0x1c0001e38: add      byte ptr [rax], al
0x1c0001e3a: add      byte ptr [rax], al
0x1c0001e3c: add      byte ptr [rax], al
0x1c0001e3e: add      byte ptr [rax], al
0x1c0001e40: add      byte ptr [rax], al
0x1c0001e42: add      byte ptr [rax], al
0x1c0001e44: add      byte ptr [rax], al
0x1c0001e46: add      byte ptr [rax], al
0x1c0001e48: add      byte ptr [rax], al
0x1c0001e4a: add      byte ptr [rax], al
0x1c0001e4c: add      byte ptr [rax], al
0x1c0001e4e: add      byte ptr [rax], al
0x1c0001e50: add      byte ptr [rax], al
0x1c0001e52: add      byte ptr [rax], al
0x1c0001e54: add      byte ptr [rax], al
0x1c0001e56: add      byte ptr [rax], al
0x1c0001e58: add      byte ptr [rax], al
0x1c0001e5a: add      byte ptr [rax], al
0x1c0001e5c: add      byte ptr [rax], al
0x1c0001e5e: add      byte ptr [rax], al
0x1c0001e60: add      byte ptr [rax], al
0x1c0001e62: add      byte ptr [rax], al
0x1c0001e64: add      byte ptr [rax], al
0x1c0001e66: add      byte ptr [rax], al
0x1c0001e68: add      byte ptr [rax], al
0x1c0001e6a: add      byte ptr [rax], al
0x1c0001e6c: add      byte ptr [rax], al
0x1c0001e6e: add      byte ptr [rax], al
0x1c0001e70: add      byte ptr [rax], al
0x1c0001e72: add      byte ptr [rax], al
0x1c0001e74: add      byte ptr [rax], al
0x1c0001e76: add      byte ptr [rax], al
0x1c0001e78: add      byte ptr [rax], al
0x1c0001e7a: add      byte ptr [rax], al
0x1c0001e7c: add      byte ptr [rax], al
0x1c0001e7e: add      byte ptr [rax], al
0x1c0001e80: add      byte ptr [rax], al
0x1c0001e82: add      byte ptr [rax], al
0x1c0001e84: add      byte ptr [rax], al
0x1c0001e86: add      byte ptr [rax], al
0x1c0001e88: add      byte ptr [rax], al
0x1c0001e8a: add      byte ptr [rax], al
0x1c0001e8c: add      byte ptr [rax], al
0x1c0001e8e: add      byte ptr [rax], al
0x1c0001e90: add      byte ptr [rax], al
0x1c0001e92: add      byte ptr [rax], al
0x1c0001e94: add      byte ptr [rax], al
0x1c0001e96: add      byte ptr [rax], al
0x1c0001e98: add      byte ptr [rax], al
0x1c0001e9a: add      byte ptr [rax], al
0x1c0001e9c: add      byte ptr [rax], al
0x1c0001e9e: add      byte ptr [rax], al
0x1c0001ea0: add      byte ptr [rax], al
0x1c0001ea2: add      byte ptr [rax], al
0x1c0001ea4: add      byte ptr [rax], al
0x1c0001ea6: add      byte ptr [rax], al
0x1c0001ea8: add      byte ptr [rax], al
0x1c0001eaa: add      byte ptr [rax], al
0x1c0001eac: add      byte ptr [rax], al
0x1c0001eae: add      byte ptr [rax], al
0x1c0001eb0: add      byte ptr [rax], al
0x1c0001eb2: add      byte ptr [rax], al
0x1c0001eb4: add      byte ptr [rax], al
0x1c0001eb6: add      byte ptr [rax], al
0x1c0001eb8: add      byte ptr [rax], al
0x1c0001eba: add      byte ptr [rax], al
0x1c0001ebc: add      byte ptr [rax], al
0x1c0001ebe: add      byte ptr [rax], al
0x1c0001ec0: add      byte ptr [rax], al
0x1c0001ec2: add      byte ptr [rax], al
0x1c0001ec4: add      byte ptr [rax], al
0x1c0001ec6: add      byte ptr [rax], al
0x1c0001ec8: add      byte ptr [rax], al
0x1c0001eca: add      byte ptr [rax], al
0x1c0001ecc: add      byte ptr [rax], al
0x1c0001ece: add      byte ptr [rax], al
0x1c0001ed0: add      byte ptr [rax], al
0x1c0001ed2: add      byte ptr [rax], al
0x1c0001ed4: add      byte ptr [rax], al
0x1c0001ed6: add      byte ptr [rax], al
0x1c0001ed8: add      byte ptr [rax], al
0x1c0001eda: add      byte ptr [rax], al
0x1c0001edc: add      byte ptr [rax], al
0x1c0001ede: add      byte ptr [rax], al
0x1c0001ee0: add      byte ptr [rax], al
0x1c0001ee2: add      byte ptr [rax], al
0x1c0001ee4: add      byte ptr [rax], al
0x1c0001ee6: add      byte ptr [rax], al
0x1c0001ee8: add      byte ptr [rax], al
0x1c0001eea: add      byte ptr [rax], al
0x1c0001eec: add      byte ptr [rax], al
0x1c0001eee: add      byte ptr [rax], al
0x1c0001ef0: add      byte ptr [rax], al
0x1c0001ef2: add      byte ptr [rax], al
0x1c0001ef4: add      byte ptr [rax], al
0x1c0001ef6: add      byte ptr [rax], al
0x1c0001ef8: add      byte ptr [rax], al
0x1c0001efa: add      byte ptr [rax], al
0x1c0001efc: add      byte ptr [rax], al
0x1c0001efe: add      byte ptr [rax], al
0x1c0001f00: add      byte ptr [rax], al
0x1c0001f02: add      byte ptr [rax], al
0x1c0001f04: add      byte ptr [rax], al
0x1c0001f06: add      byte ptr [rax], al
0x1c0001f08: add      byte ptr [rax], al
0x1c0001f0a: add      byte ptr [rax], al
0x1c0001f0c: add      byte ptr [rax], al
0x1c0001f0e: add      byte ptr [rax], al
0x1c0001f10: add      byte ptr [rax], al
0x1c0001f12: add      byte ptr [rax], al
0x1c0001f14: add      byte ptr [rax], al
0x1c0001f16: add      byte ptr [rax], al
0x1c0001f18: add      byte ptr [rax], al
0x1c0001f1a: add      byte ptr [rax], al
0x1c0001f1c: add      byte ptr [rax], al
0x1c0001f1e: add      byte ptr [rax], al
0x1c0001f20: add      byte ptr [rax], al
0x1c0001f22: add      byte ptr [rax], al
0x1c0001f24: add      byte ptr [rax], al
0x1c0001f26: add      byte ptr [rax], al
0x1c0001f28: add      byte ptr [rax], al
0x1c0001f2a: add      byte ptr [rax], al
0x1c0001f2c: add      byte ptr [rax], al
0x1c0001f2e: add      byte ptr [rax], al
0x1c0001f30: add      byte ptr [rax], al
0x1c0001f32: add      byte ptr [rax], al
0x1c0001f34: add      byte ptr [rax], al
0x1c0001f36: add      byte ptr [rax], al
0x1c0001f38: add      byte ptr [rax], al
0x1c0001f3a: add      byte ptr [rax], al
0x1c0001f3c: add      byte ptr [rax], al
0x1c0001f3e: add      byte ptr [rax], al
0x1c0001f40: add      byte ptr [rax], al
0x1c0001f42: add      byte ptr [rax], al
0x1c0001f44: add      byte ptr [rax], al
0x1c0001f46: add      byte ptr [rax], al
0x1c0001f48: add      byte ptr [rax], al
0x1c0001f4a: add      byte ptr [rax], al
0x1c0001f4c: add      byte ptr [rax], al
0x1c0001f4e: add      byte ptr [rax], al
0x1c0001f50: add      byte ptr [rax], al
0x1c0001f52: add      byte ptr [rax], al
0x1c0001f54: add      byte ptr [rax], al
0x1c0001f56: add      byte ptr [rax], al
0x1c0001f58: add      byte ptr [rax], al
0x1c0001f5a: add      byte ptr [rax], al
0x1c0001f5c: add      byte ptr [rax], al
0x1c0001f5e: add      byte ptr [rax], al
0x1c0001f60: add      byte ptr [rax], al
0x1c0001f62: add      byte ptr [rax], al
0x1c0001f64: add      byte ptr [rax], al
0x1c0001f66: add      byte ptr [rax], al
0x1c0001f68: add      byte ptr [rax], al
0x1c0001f6a: add      byte ptr [rax], al
0x1c0001f6c: add      byte ptr [rax], al
0x1c0001f6e: add      byte ptr [rax], al
0x1c0001f70: add      byte ptr [rax], al
0x1c0001f72: add      byte ptr [rax], al
0x1c0001f74: add      byte ptr [rax], al
0x1c0001f76: add      byte ptr [rax], al
0x1c0001f78: add      byte ptr [rax], al
0x1c0001f7a: add      byte ptr [rax], al
0x1c0001f7c: add      byte ptr [rax], al
0x1c0001f7e: add      byte ptr [rax], al
0x1c0001f80: add      byte ptr [rax], al
0x1c0001f82: add      byte ptr [rax], al
0x1c0001f84: add      byte ptr [rax], al
0x1c0001f86: add      byte ptr [rax], al
0x1c0001f88: add      byte ptr [rax], al
0x1c0001f8a: add      byte ptr [rax], al
0x1c0001f8c: add      byte ptr [rax], al
0x1c0001f8e: add      byte ptr [rax], al
0x1c0001f90: add      byte ptr [rax], al
0x1c0001f92: add      byte ptr [rax], al
0x1c0001f94: add      byte ptr [rax], al
0x1c0001f96: add      byte ptr [rax], al
0x1c0001f98: add      byte ptr [rax], al
0x1c0001f9a: add      byte ptr [rax], al
0x1c0001f9c: add      byte ptr [rax], al
0x1c0001f9e: add      byte ptr [rax], al
0x1c0001fa0: add      byte ptr [rax], al
0x1c0001fa2: add      byte ptr [rax], al
0x1c0001fa4: add      byte ptr [rax], al
0x1c0001fa6: add      byte ptr [rax], al
0x1c0001fa8: add      byte ptr [rax], al
0x1c0001faa: add      byte ptr [rax], al
0x1c0001fac: add      byte ptr [rax], al
0x1c0001fae: add      byte ptr [rax], al
0x1c0001fb0: add      byte ptr [rax], al
0x1c0001fb2: add      byte ptr [rax], al
0x1c0001fb4: add      byte ptr [rax], al
0x1c0001fb6: add      byte ptr [rax], al
0x1c0001fb8: add      byte ptr [rax], al
0x1c0001fba: add      byte ptr [rax], al
0x1c0001fbc: add      byte ptr [rax], al
0x1c0001fbe: add      byte ptr [rax], al
0x1c0001fc0: add      byte ptr [rax], al
0x1c0001fc2: add      byte ptr [rax], al
0x1c0001fc4: add      byte ptr [rax], al
0x1c0001fc6: add      byte ptr [rax], al
0x1c0001fc8: add      byte ptr [rax], al
0x1c0001fca: add      byte ptr [rax], al
0x1c0001fcc: add      byte ptr [rax], al
0x1c0001fce: add      byte ptr [rax], al
0x1c0001fd0: add      byte ptr [rax], al
0x1c0001fd2: add      byte ptr [rax], al
0x1c0001fd4: add      byte ptr [rax], al
0x1c0001fd6: add      byte ptr [rax], al
0x1c0001fd8: add      byte ptr [rax], al
0x1c0001fda: add      byte ptr [rax], al
0x1c0001fdc: add      byte ptr [rax], al
0x1c0001fde: add      byte ptr [rax], al
0x1c0001fe0: add      byte ptr [rax], al
0x1c0001fe2: add      byte ptr [rax], al
0x1c0001fe4: add      byte ptr [rax], al
0x1c0001fe6: add      byte ptr [rax], al
0x1c0001fe8: add      byte ptr [rax], al
0x1c0001fea: add      byte ptr [rax], al
0x1c0001fec: add      byte ptr [rax], al
0x1c0001fee: add      byte ptr [rax], al
0x1c0001ff0: add      byte ptr [rax], al
0x1c0001ff2: add      byte ptr [rax], al
0x1c0001ff4: add      byte ptr [rax], al
0x1c0001ff6: add      byte ptr [rax], al
0x1c0001ff8: add      byte ptr [rax], al
0x1c0001ffa: add      byte ptr [rax], al
0x1c0001ffc: add      byte ptr [rax], al
0x1c0001ffe: add      byte ptr [rax], al
```

### Section: PAGE (VA=0x1c0007000, 1796 instructions)
```asm
0x1c0007000: int3     
0x1c0007001: int3     
0x1c0007002: int3     
0x1c0007003: int3     
0x1c0007004: int3     
0x1c0007005: int3     
0x1c0007006: int3     
0x1c0007007: int3     
0x1c0007008: int3     
0x1c0007009: int3     
0x1c000700a: int3     
0x1c000700b: int3     
0x1c000700c: int3     
0x1c000700d: int3     
0x1c000700e: int3     
0x1c000700f: int3     
0x1c0007010: mov      qword ptr [rsp + 8], rbx
0x1c0007015: mov      qword ptr [rsp + 0x10], rsi
0x1c000701a: push     rdi
0x1c000701b: sub      rsp, 0x20
0x1c000701f: mov      rax, qword ptr [rdx + 0xb8]
0x1c0007026: mov      rsi, rdx
0x1c0007029: mov      rdi, rcx
0x1c000702c: mov      r8d, 1
0x1c0007032: mov      rcx, qword ptr [rax + 0x30]
0x1c0007036: mov      rbx, qword ptr [rcx + 0x18]
0x1c000703a: mov      rdx, qword ptr [rbx + 8]
0x1c000703e: lea      r9, [rdx + 0x38]
0x1c0007042: add      rdx, 0x28
0x1c0007046: call     qword ptr [rip - 0x1f95]  ; -> KsFreeEventList
0x1c000704d: nop      dword ptr [rax + rax]
0x1c0007052: mov      rcx, qword ptr [rbx + 8]
0x1c0007056: call     qword ptr [rip - 0x2015]  ; -> KsFreeDefaultClock
0x1c000705d: nop      dword ptr [rax + rax]
0x1c0007062: mov      rcx, qword ptr [rbx]
0x1c0007065: call     qword ptr [rip - 0x202c]  ; -> KsFreeObjectHeader
0x1c000706c: nop      dword ptr [rax + rax]
0x1c0007071: mov      rcx, rbx
0x1c0007074: call     qword ptr [rip - 0x1f5b]  ; -> ExFreePool
0x1c000707b: nop      dword ptr [rax + rax]
0x1c0007080: mov      rcx, qword ptr [rdi + 0x40]
0x1c0007084: mov      rcx, qword ptr [rcx]
0x1c0007087: call     qword ptr [rip - 0x201e]  ; -> KsDereferenceSoftwareBusObject
0x1c000708e: nop      dword ptr [rax + rax]
0x1c0007093: and      dword ptr [rsi + 0x30], 0
0x1c0007097: xor      edx, edx
0x1c0007099: mov      rcx, rsi
0x1c000709c: call     qword ptr [rip - 0x1fa3]  ; -> IofCompleteRequest
0x1c00070a3: nop      dword ptr [rax + rax]
0x1c00070a8: mov      rbx, qword ptr [rsp + 0x30]
0x1c00070ad: xor      eax, eax
0x1c00070af: mov      rsi, qword ptr [rsp + 0x38]
0x1c00070b4: add      rsp, 0x20
0x1c00070b8: pop      rdi
0x1c00070b9: ret      
0x1c00070ba: int3     
0x1c00070bb: int3     
0x1c00070bc: int3     
0x1c00070bd: int3     
0x1c00070be: int3     
0x1c00070bf: int3     
0x1c00070c0: int3     
0x1c00070c1: int3     
0x1c00070c2: int3     
0x1c00070c3: int3     
0x1c00070c4: int3     
0x1c00070c5: int3     
0x1c00070c6: int3     
0x1c00070c7: int3     
0x1c00070c8: int3     
0x1c00070c9: int3     
0x1c00070ca: int3     
0x1c00070cb: int3     
0x1c00070cc: int3     
0x1c00070cd: int3     
0x1c00070ce: int3     
0x1c00070cf: int3     
0x1c00070d0: mov      qword ptr [rsp + 8], rbx
0x1c00070d5: mov      qword ptr [rsp + 0x10], rbp
0x1c00070da: mov      qword ptr [rsp + 0x18], rsi
0x1c00070df: push     rdi
0x1c00070e0: sub      rsp, 0x30
0x1c00070e4: mov      rbp, rcx
0x1c00070e7: mov      rsi, rdx
0x1c00070ea: mov      rcx, qword ptr [rcx + 0x40]
0x1c00070ee: mov      rcx, qword ptr [rcx]
0x1c00070f1: call     qword ptr [rip - 0x2050]  ; -> KsReferenceSoftwareBusObject
0x1c00070f8: nop      dword ptr [rax + rax]
0x1c00070fd: mov      ebx, eax
0x1c00070ff: test     eax, eax
0x1c0007101: js       0x1c00071c1
0x1c0007107: mov      edx, 0x50
0x1c000710c: mov      ecx, 0x600
0x1c0007111: mov      r8d, 0x4946734b
0x1c0007117: call     qword ptr [rip - 0x2036]  ; -> ExAllocatePoolWithTag
0x1c000711e: nop      dword ptr [rax + rax]
0x1c0007123: mov      rdi, rax
0x1c0007126: test     rax, rax
0x1c0007129: je       0x1c00071a9
0x1c000712b: lea      rcx, [rax + 8]
0x1c000712f: call     qword ptr [rip - 0x20de]  ; -> KsAllocateDefaultClock
0x1c0007136: nop      dword ptr [rax + rax]
0x1c000713b: mov      ebx, eax
0x1c000713d: mov      rcx, rdi
0x1c0007140: test     eax, eax
0x1c0007142: js       0x1c000719b
0x1c0007144: lea      rax, [rip - 0x514b]
0x1c000714b: mov      r9, rsi
0x1c000714e: xor      r8d, r8d
0x1c0007151: mov      qword ptr [rsp + 0x20], rax
0x1c0007156: xor      edx, edx
0x1c0007158: call     qword ptr [rip - 0x210f]  ; -> KsAllocateObjectHeader
0x1c000715f: nop      dword ptr [rax + rax]
0x1c0007164: and      qword ptr [rdi + 0x20], 0
0x1c0007169: lea      rcx, [rdi + 0x30]
0x1c000716d: and      dword ptr [rdi + 0x28], 0
0x1c0007171: mov      edx, 1
0x1c0007176: xor      r8d, r8d
0x1c0007179: mov      dword ptr [rdi + 0x18], edx
0x1c000717c: call     qword ptr [rip - 0x207b]  ; -> KeInitializeEvent
0x1c0007183: nop      dword ptr [rax + rax]
0x1c0007188: mov      rax, qword ptr [rsi + 0xb8]
0x1c000718f: xor      ebx, ebx
0x1c0007191: mov      rcx, qword ptr [rax + 0x30]
0x1c0007195: mov      qword ptr [rcx + 0x18], rdi
0x1c0007199: jmp      0x1c00071c1
0x1c000719b: call     qword ptr [rip - 0x2082]  ; -> ExFreePool
0x1c00071a2: nop      dword ptr [rax + rax]
0x1c00071a7: jmp      0x1c00071ae
0x1c00071a9: mov      ebx, 0xc000009a
0x1c00071ae: mov      rcx, qword ptr [rbp + 0x40]
0x1c00071b2: mov      rcx, qword ptr [rcx]
0x1c00071b5: call     qword ptr [rip - 0x214c]  ; -> KsDereferenceSoftwareBusObject
0x1c00071bc: nop      dword ptr [rax + rax]
0x1c00071c1: xor      edx, edx
0x1c00071c3: mov      dword ptr [rsi + 0x30], ebx
0x1c00071c6: mov      rcx, rsi
0x1c00071c9: call     qword ptr [rip - 0x20d0]  ; -> IofCompleteRequest
0x1c00071d0: nop      dword ptr [rax + rax]
0x1c00071d5: mov      rbp, qword ptr [rsp + 0x48]
0x1c00071da: mov      eax, ebx
0x1c00071dc: mov      rbx, qword ptr [rsp + 0x40]
0x1c00071e1: mov      rsi, qword ptr [rsp + 0x50]
0x1c00071e6: add      rsp, 0x30
0x1c00071ea: pop      rdi
0x1c00071eb: ret      
0x1c00071ec: int3     
0x1c00071ed: int3     
0x1c00071ee: int3     
0x1c00071ef: int3     
0x1c00071f0: int3     
0x1c00071f1: int3     
0x1c00071f2: int3     
0x1c00071f3: int3     
0x1c00071f4: int3     
0x1c00071f5: int3     
0x1c00071f6: int3     
0x1c00071f7: int3     
0x1c00071f8: int3     
0x1c00071f9: int3     
0x1c00071fa: int3     
0x1c00071fb: int3     
0x1c00071fc: int3     
0x1c00071fd: int3     
0x1c00071fe: int3     
0x1c00071ff: int3     
0x1c0007200: mov      qword ptr [rsp + 8], rbx
0x1c0007205: push     rdi
0x1c0007206: sub      rsp, 0x30
0x1c000720a: mov      rbx, rdx
0x1c000720d: mov      rdx, qword ptr [rdx + 0xb8]
0x1c0007214: mov      ecx, dword ptr [rdx + 0x18]
0x1c0007217: sub      ecx, 0x2f0003
0x1c000721d: je       0x1c0007285
0x1c000721f: sub      ecx, 4
0x1c0007222: je       0x1c000725b
0x1c0007224: cmp      ecx, 4
0x1c0007227: je       0x1c0007230
0x1c0007229: mov      edi, 0xc0000010
0x1c000722e: jmp      0x1c00072a2
0x1c0007230: mov      rax, qword ptr [rdx + 0x30]
0x1c0007234: mov      r8d, 1
0x1c000723a: mov      rcx, qword ptr [rax + 0x18]
0x1c000723e: mov      rdx, qword ptr [rcx + 8]
0x1c0007242: mov      rcx, rbx
0x1c0007245: lea      r9, [rdx + 0x38]
0x1c0007249: add      rdx, 0x28
0x1c000724d: call     qword ptr [rip - 0x21a4]  ; -> KsDisableEvent
0x1c0007254: nop      dword ptr [rax + rax]
0x1c0007259: jmp      0x1c00072a0
0x1c000725b: and      qword ptr [rsp + 0x28], 0
0x1c0007261: lea      r8, [rip - 0x4f98]
0x1c0007268: and      dword ptr [rsp + 0x20], 0
0x1c000726d: xor      r9d, r9d
0x1c0007270: mov      rcx, rbx
0x1c0007273: lea      edx, [r9 + 1]
0x1c0007277: call     qword ptr [rip - 0x2216]  ; -> KsEnableEvent
0x1c000727e: nop      dword ptr [rax + rax]
0x1c0007283: jmp      0x1c00072a0
0x1c0007285: lea      r8, [rip - 0x4fa4]
0x1c000728c: mov      edx, 1
0x1c0007291: mov      rcx, rbx
0x1c0007294: call     qword ptr [rip - 0x21fb]  ; -> KsPropertyHandler
0x1c000729b: nop      dword ptr [rax + rax]
0x1c00072a0: mov      edi, eax
0x1c00072a2: xor      edx, edx
0x1c00072a4: mov      dword ptr [rbx + 0x30], edi
0x1c00072a7: mov      rcx, rbx
0x1c00072aa: call     qword ptr [rip - 0x21b1]  ; -> IofCompleteRequest
0x1c00072b1: nop      dword ptr [rax + rax]
0x1c00072b6: mov      rbx, qword ptr [rsp + 0x40]
0x1c00072bb: mov      eax, edi
0x1c00072bd: add      rsp, 0x30
0x1c00072c1: pop      rdi
0x1c00072c2: ret      
0x1c00072c3: int3     
0x1c00072c4: int3     
0x1c00072c5: int3     
0x1c00072c6: int3     
0x1c00072c7: int3     
0x1c00072c8: int3     
0x1c00072c9: int3     
0x1c00072ca: int3     
0x1c00072cb: int3     
0x1c00072cc: int3     
0x1c00072cd: int3     
0x1c00072ce: int3     
0x1c00072cf: int3     
0x1c00072d0: mov      r11, rsp
0x1c00072d3: mov      qword ptr [r11 + 8], rbx
0x1c00072d7: mov      qword ptr [r11 + 0x10], rsi
0x1c00072db: push     rdi
0x1c00072dc: sub      rsp, 0x40
0x1c00072e0: and      qword ptr [r11 + 0x18], 0
0x1c00072e5: lea      rax, [r11 + 0x18]
0x1c00072e9: mov      qword ptr [r11 - 0x18], rax
0x1c00072ed: mov      r9d, 0x2f
0x1c00072f3: mov      rsi, rdx
0x1c00072f6: mov      byte ptr [rsp + 0x28], 0
0x1c00072fb: and      dword ptr [rsp + 0x20], 0
0x1c0007300: xor      r8d, r8d
0x1c0007303: lea      edx, [r9 - 0x27]
0x1c0007307: call     qword ptr [rip - 0x21fe]  ; -> IoCreateDevice
0x1c000730e: nop      dword ptr [rax + rax]
0x1c0007313: test     eax, eax
0x1c0007315: js       0x1c00073b6
0x1c000731b: mov      rax, qword ptr [rsp + 0x60]
0x1c0007320: lea      r8, [rip - 0x52d7]
0x1c0007327: mov      edx, 1
0x1c000732c: mov      rbx, qword ptr [rax + 0x40]
0x1c0007330: mov      rcx, rbx
0x1c0007333: call     qword ptr [rip - 0x22c2]  ; -> KsAllocateDeviceHeader
0x1c000733a: nop      dword ptr [rax + rax]
0x1c000733f: mov      edi, eax
0x1c0007341: test     eax, eax
0x1c0007343: js       0x1c0007399
0x1c0007345: mov      rcx, qword ptr [rsp + 0x60]
0x1c000734a: mov      rdx, rsi
0x1c000734d: call     qword ptr [rip - 0x222c]  ; -> IoAttachDeviceToDeviceStack
0x1c0007354: nop      dword ptr [rax + rax]
0x1c0007359: mov      rcx, qword ptr [rbx]
0x1c000735c: test     rax, rax
0x1c000735f: je       0x1c000738d
0x1c0007361: mov      r8, qword ptr [rsp + 0x60]
0x1c0007366: mov      rdx, rax
0x1c0007369: call     qword ptr [rip - 0x2370]  ; -> KsSetDevicePnpAndBaseObject
0x1c0007370: nop      dword ptr [rax + rax]
0x1c0007375: mov      rax, qword ptr [rsp + 0x60]
0x1c000737a: bts      dword ptr [rax + 0x30], 0xd
0x1c000737f: mov      rax, qword ptr [rsp + 0x60]
0x1c0007384: btr      dword ptr [rax + 0x30], 7
0x1c0007389: xor      eax, eax
0x1c000738b: jmp      0x1c00073b6
0x1c000738d: call     qword ptr [rip - 0x235c]  ; -> KsFreeDeviceHeader
0x1c0007394: nop      dword ptr [rax + rax]
0x1c0007399: mov      rax, qword ptr [rsp + 0x60]
0x1c000739e: btr      dword ptr [rax + 0x30], 7
0x1c00073a3: mov      rcx, qword ptr [rsp + 0x60]
0x1c00073a8: call     qword ptr [rip - 0x227f]  ; -> IoDeleteDevice
0x1c00073af: nop      dword ptr [rax + rax]
0x1c00073b4: mov      eax, edi
0x1c00073b6: mov      rbx, qword ptr [rsp + 0x50]
0x1c00073bb: mov      rsi, qword ptr [rsp + 0x58]
0x1c00073c0: add      rsp, 0x40
0x1c00073c4: pop      rdi
0x1c00073c5: ret      
0x1c00073c6: int3     
0x1c00073c7: int3     
0x1c00073c8: int3     
0x1c00073c9: int3     
0x1c00073ca: int3     
0x1c00073cb: int3     
0x1c00073cc: int3     
0x1c00073cd: int3     
0x1c00073ce: int3     
0x1c00073cf: int3     
0x1c00073d0: mov      qword ptr [rsp + 8], rbx
0x1c00073d5: mov      qword ptr [rsp + 0x10], rsi
0x1c00073da: push     rdi
0x1c00073db: sub      rsp, 0x20
0x1c00073df: mov      rax, qword ptr [rcx + 0xb8]
0x1c00073e6: mov      rsi, r8
0x1c00073e9: mov      rcx, qword ptr [rax + 0x30]
0x1c00073ed: mov      rbx, qword ptr [rcx + 0x18]
0x1c00073f1: call     qword ptr [rip - 0x22c0]  ; -> KeEnterCriticalRegion
0x1c00073f8: nop      dword ptr [rax + rax]
0x1c00073fd: lea      rcx, [rbx + 0x18]
0x1c0007401: call     qword ptr [rip - 0x22f0]  ; -> ExAcquireFastMutexUnsafe
0x1c0007408: nop      dword ptr [rax + rax]
0x1c000740d: mov      edx, dword ptr [rsi]
0x1c000740f: mov      rcx, qword ptr [rbx + 8]
0x1c0007413: call     qword ptr [rip - 0x23ba]  ; -> KsSetDefaultClockState
0x1c000741a: nop      dword ptr [rax + rax]
0x1c000741f: lea      rcx, [rbx + 0x18]
0x1c0007423: call     qword ptr [rip - 0x2332]  ; -> ExReleaseFastMutexUnsafe
0x1c000742a: nop      dword ptr [rax + rax]
0x1c000742f: call     qword ptr [rip - 0x2346]  ; -> KeLeaveCriticalRegion
0x1c0007436: nop      dword ptr [rax + rax]
0x1c000743b: mov      rbx, qword ptr [rsp + 0x30]
0x1c0007440: xor      eax, eax
0x1c0007442: mov      rsi, qword ptr [rsp + 0x38]
0x1c0007447: add      rsp, 0x20
0x1c000744b: pop      rdi
0x1c000744c: ret      
0x1c000744d: int3     
0x1c000744e: int3     
0x1c000744f: int3     
0x1c0007450: int3     
0x1c0007451: int3     
0x1c0007452: int3     
0x1c0007453: int3     
0x1c0007454: int3     
0x1c0007455: int3     
0x1c0007456: int3     
0x1c0007457: int3     
0x1c0007458: int3     
0x1c0007459: int3     
0x1c000745a: int3     
0x1c000745b: int3     
0x1c000745c: int3     
0x1c000745d: int3     
0x1c000745e: int3     
0x1c000745f: int3     
0x1c0007460: mov      qword ptr [rsp + 8], rbx
0x1c0007465: mov      qword ptr [rsp + 0x10], rsi
0x1c000746a: push     rdi
0x1c000746b: sub      rsp, 0x20
0x1c000746f: mov      rax, qword ptr [rcx + 0xb8]
0x1c0007476: mov      rsi, r8
0x1c0007479: mov      rcx, qword ptr [rax + 0x30]
0x1c000747d: mov      rbx, qword ptr [rcx + 0x18]
0x1c0007481: call     qword ptr [rip - 0x2350]  ; -> KeEnterCriticalRegion
0x1c0007488: nop      dword ptr [rax + rax]
0x1c000748d: lea      rcx, [rbx + 0x18]
0x1c0007491: call     qword ptr [rip - 0x2380]  ; -> ExAcquireFastMutexUnsafe
0x1c0007498: nop      dword ptr [rax + rax]
0x1c000749d: mov      rdx, qword ptr [rsi]
0x1c00074a0: mov      rcx, qword ptr [rbx + 8]
0x1c00074a4: call     qword ptr [rip - 0x23eb]  ; -> KsSetDefaultClockTime
0x1c00074ab: nop      dword ptr [rax + rax]
0x1c00074b0: lea      rcx, [rbx + 0x18]
0x1c00074b4: call     qword ptr [rip - 0x23c3]  ; -> ExReleaseFastMutexUnsafe
0x1c00074bb: nop      dword ptr [rax + rax]
0x1c00074c0: call     qword ptr [rip - 0x23d7]  ; -> KeLeaveCriticalRegion
0x1c00074c7: nop      dword ptr [rax + rax]
0x1c00074cc: mov      rbx, qword ptr [rsp + 0x30]
0x1c00074d1: xor      eax, eax
0x1c00074d3: mov      rsi, qword ptr [rsp + 0x38]
0x1c00074d8: add      rsp, 0x20
0x1c00074dc: pop      rdi
0x1c00074dd: ret      
0x1c00074de: int3     
0x1c00074df: add      byte ptr [rax], al
0x1c00074e1: add      byte ptr [rax], al
0x1c00074e3: add      byte ptr [rax], al
0x1c00074e5: add      byte ptr [rax], al
0x1c00074e7: add      byte ptr [rax], al
0x1c00074e9: add      byte ptr [rax], al
0x1c00074eb: add      byte ptr [rax], al
0x1c00074ed: add      byte ptr [rax], al
0x1c00074ef: add      byte ptr [rax], al
0x1c00074f1: add      byte ptr [rax], al
0x1c00074f3: add      byte ptr [rax], al
0x1c00074f5: add      byte ptr [rax], al
0x1c00074f7: add      byte ptr [rax], al
0x1c00074f9: add      byte ptr [rax], al
0x1c00074fb: add      byte ptr [rax], al
0x1c00074fd: add      byte ptr [rax], al
0x1c00074ff: add      byte ptr [rax], al
0x1c0007501: add      byte ptr [rax], al
0x1c0007503: add      byte ptr [rax], al
0x1c0007505: add      byte ptr [rax], al
0x1c0007507: add      byte ptr [rax], al
0x1c0007509: add      byte ptr [rax], al
0x1c000750b: add      byte ptr [rax], al
0x1c000750d: add      byte ptr [rax], al
0x1c000750f: add      byte ptr [rax], al
0x1c0007511: add      byte ptr [rax], al
0x1c0007513: add      byte ptr [rax], al
0x1c0007515: add      byte ptr [rax], al
0x1c0007517: add      byte ptr [rax], al
0x1c0007519: add      byte ptr [rax], al
0x1c000751b: add      byte ptr [rax], al
0x1c000751d: add      byte ptr [rax], al
0x1c000751f: add      byte ptr [rax], al
0x1c0007521: add      byte ptr [rax], al
0x1c0007523: add      byte ptr [rax], al
0x1c0007525: add      byte ptr [rax], al
0x1c0007527: add      byte ptr [rax], al
0x1c0007529: add      byte ptr [rax], al
0x1c000752b: add      byte ptr [rax], al
0x1c000752d: add      byte ptr [rax], al
0x1c000752f: add      byte ptr [rax], al
0x1c0007531: add      byte ptr [rax], al
0x1c0007533: add      byte ptr [rax], al
0x1c0007535: add      byte ptr [rax], al
0x1c0007537: add      byte ptr [rax], al
0x1c0007539: add      byte ptr [rax], al
0x1c000753b: add      byte ptr [rax], al
0x1c000753d: add      byte ptr [rax], al
0x1c000753f: add      byte ptr [rax], al
0x1c0007541: add      byte ptr [rax], al
0x1c0007543: add      byte ptr [rax], al
0x1c0007545: add      byte ptr [rax], al
0x1c0007547: add      byte ptr [rax], al
0x1c0007549: add      byte ptr [rax], al
0x1c000754b: add      byte ptr [rax], al
0x1c000754d: add      byte ptr [rax], al
0x1c000754f: add      byte ptr [rax], al
0x1c0007551: add      byte ptr [rax], al
0x1c0007553: add      byte ptr [rax], al
0x1c0007555: add      byte ptr [rax], al
0x1c0007557: add      byte ptr [rax], al
0x1c0007559: add      byte ptr [rax], al
0x1c000755b: add      byte ptr [rax], al
0x1c000755d: add      byte ptr [rax], al
0x1c000755f: add      byte ptr [rax], al
0x1c0007561: add      byte ptr [rax], al
0x1c0007563: add      byte ptr [rax], al
0x1c0007565: add      byte ptr [rax], al
0x1c0007567: add      byte ptr [rax], al
0x1c0007569: add      byte ptr [rax], al
0x1c000756b: add      byte ptr [rax], al
0x1c000756d: add      byte ptr [rax], al
0x1c000756f: add      byte ptr [rax], al
0x1c0007571: add      byte ptr [rax], al
0x1c0007573: add      byte ptr [rax], al
0x1c0007575: add      byte ptr [rax], al
0x1c0007577: add      byte ptr [rax], al
0x1c0007579: add      byte ptr [rax], al
0x1c000757b: add      byte ptr [rax], al
0x1c000757d: add      byte ptr [rax], al
0x1c000757f: add      byte ptr [rax], al
0x1c0007581: add      byte ptr [rax], al
0x1c0007583: add      byte ptr [rax], al
0x1c0007585: add      byte ptr [rax], al
0x1c0007587: add      byte ptr [rax], al
0x1c0007589: add      byte ptr [rax], al
0x1c000758b: add      byte ptr [rax], al
0x1c000758d: add      byte ptr [rax], al
0x1c000758f: add      byte ptr [rax], al
0x1c0007591: add      byte ptr [rax], al
0x1c0007593: add      byte ptr [rax], al
0x1c0007595: add      byte ptr [rax], al
0x1c0007597: add      byte ptr [rax], al
0x1c0007599: add      byte ptr [rax], al
0x1c000759b: add      byte ptr [rax], al
0x1c000759d: add      byte ptr [rax], al
0x1c000759f: add      byte ptr [rax], al
0x1c00075a1: add      byte ptr [rax], al
0x1c00075a3: add      byte ptr [rax], al
0x1c00075a5: add      byte ptr [rax], al
0x1c00075a7: add      byte ptr [rax], al
0x1c00075a9: add      byte ptr [rax], al
0x1c00075ab: add      byte ptr [rax], al
0x1c00075ad: add      byte ptr [rax], al
0x1c00075af: add      byte ptr [rax], al
0x1c00075b1: add      byte ptr [rax], al
0x1c00075b3: add      byte ptr [rax], al
0x1c00075b5: add      byte ptr [rax], al
0x1c00075b7: add      byte ptr [rax], al
0x1c00075b9: add      byte ptr [rax], al
0x1c00075bb: add      byte ptr [rax], al
0x1c00075bd: add      byte ptr [rax], al
0x1c00075bf: add      byte ptr [rax], al
0x1c00075c1: add      byte ptr [rax], al
0x1c00075c3: add      byte ptr [rax], al
0x1c00075c5: add      byte ptr [rax], al
0x1c00075c7: add      byte ptr [rax], al
0x1c00075c9: add      byte ptr [rax], al
0x1c00075cb: add      byte ptr [rax], al
0x1c00075cd: add      byte ptr [rax], al
0x1c00075cf: add      byte ptr [rax], al
0x1c00075d1: add      byte ptr [rax], al
0x1c00075d3: add      byte ptr [rax], al
0x1c00075d5: add      byte ptr [rax], al
0x1c00075d7: add      byte ptr [rax], al
0x1c00075d9: add      byte ptr [rax], al
0x1c00075db: add      byte ptr [rax], al
0x1c00075dd: add      byte ptr [rax], al
0x1c00075df: add      byte ptr [rax], al
0x1c00075e1: add      byte ptr [rax], al
0x1c00075e3: add      byte ptr [rax], al
0x1c00075e5: add      byte ptr [rax], al
0x1c00075e7: add      byte ptr [rax], al
0x1c00075e9: add      byte ptr [rax], al
0x1c00075eb: add      byte ptr [rax], al
0x1c00075ed: add      byte ptr [rax], al
0x1c00075ef: add      byte ptr [rax], al
0x1c00075f1: add      byte ptr [rax], al
0x1c00075f3: add      byte ptr [rax], al
0x1c00075f5: add      byte ptr [rax], al
0x1c00075f7: add      byte ptr [rax], al
0x1c00075f9: add      byte ptr [rax], al
0x1c00075fb: add      byte ptr [rax], al
0x1c00075fd: add      byte ptr [rax], al
0x1c00075ff: add      byte ptr [rax], al
0x1c0007601: add      byte ptr [rax], al
0x1c0007603: add      byte ptr [rax], al
0x1c0007605: add      byte ptr [rax], al
0x1c0007607: add      byte ptr [rax], al
0x1c0007609: add      byte ptr [rax], al
0x1c000760b: add      byte ptr [rax], al
0x1c000760d: add      byte ptr [rax], al
0x1c000760f: add      byte ptr [rax], al
0x1c0007611: add      byte ptr [rax], al
0x1c0007613: add      byte ptr [rax], al
0x1c0007615: add      byte ptr [rax], al
0x1c0007617: add      byte ptr [rax], al
0x1c0007619: add      byte ptr [rax], al
0x1c000761b: add      byte ptr [rax], al
0x1c000761d: add      byte ptr [rax], al
0x1c000761f: add      byte ptr [rax], al
0x1c0007621: add      byte ptr [rax], al
0x1c0007623: add      byte ptr [rax], al
0x1c0007625: add      byte ptr [rax], al
0x1c0007627: add      byte ptr [rax], al
0x1c0007629: add      byte ptr [rax], al
0x1c000762b: add      byte ptr [rax], al
0x1c000762d: add      byte ptr [rax], al
0x1c000762f: add      byte ptr [rax], al
0x1c0007631: add      byte ptr [rax], al
0x1c0007633: add      byte ptr [rax], al
0x1c0007635: add      byte ptr [rax], al
0x1c0007637: add      byte ptr [rax], al
0x1c0007639: add      byte ptr [rax], al
0x1c000763b: add      byte ptr [rax], al
0x1c000763d: add      byte ptr [rax], al
0x1c000763f: add      byte ptr [rax], al
0x1c0007641: add      byte ptr [rax], al
0x1c0007643: add      byte ptr [rax], al
0x1c0007645: add      byte ptr [rax], al
0x1c0007647: add      byte ptr [rax], al
0x1c0007649: add      byte ptr [rax], al
0x1c000764b: add      byte ptr [rax], al
0x1c000764d: add      byte ptr [rax], al
0x1c000764f: add      byte ptr [rax], al
0x1c0007651: add      byte ptr [rax], al
0x1c0007653: add      byte ptr [rax], al
0x1c0007655: add      byte ptr [rax], al
0x1c0007657: add      byte ptr [rax], al
0x1c0007659: add      byte ptr [rax], al
0x1c000765b: add      byte ptr [rax], al
0x1c000765d: add      byte ptr [rax], al
0x1c000765f: add      byte ptr [rax], al
0x1c0007661: add      byte ptr [rax], al
0x1c0007663: add      byte ptr [rax], al
0x1c0007665: add      byte ptr [rax], al
0x1c0007667: add      byte ptr [rax], al
0x1c0007669: add      byte ptr [rax], al
0x1c000766b: add      byte ptr [rax], al
0x1c000766d: add      byte ptr [rax], al
0x1c000766f: add      byte ptr [rax], al
0x1c0007671: add      byte ptr [rax], al
0x1c0007673: add      byte ptr [rax], al
0x1c0007675: add      byte ptr [rax], al
0x1c0007677: add      byte ptr [rax], al
0x1c0007679: add      byte ptr [rax], al
0x1c000767b: add      byte ptr [rax], al
0x1c000767d: add      byte ptr [rax], al
0x1c000767f: add      byte ptr [rax], al
0x1c0007681: add      byte ptr [rax], al
0x1c0007683: add      byte ptr [rax], al
0x1c0007685: add      byte ptr [rax], al
0x1c0007687: add      byte ptr [rax], al
0x1c0007689: add      byte ptr [rax], al
0x1c000768b: add      byte ptr [rax], al
0x1c000768d: add      byte ptr [rax], al
0x1c000768f: add      byte ptr [rax], al
0x1c0007691: add      byte ptr [rax], al
0x1c0007693: add      byte ptr [rax], al
0x1c0007695: add      byte ptr [rax], al
0x1c0007697: add      byte ptr [rax], al
0x1c0007699: add      byte ptr [rax], al
0x1c000769b: add      byte ptr [rax], al
0x1c000769d: add      byte ptr [rax], al
0x1c000769f: add      byte ptr [rax], al
0x1c00076a1: add      byte ptr [rax], al
0x1c00076a3: add      byte ptr [rax], al
0x1c00076a5: add      byte ptr [rax], al
0x1c00076a7: add      byte ptr [rax], al
0x1c00076a9: add      byte ptr [rax], al
0x1c00076ab: add      byte ptr [rax], al
0x1c00076ad: add      byte ptr [rax], al
0x1c00076af: add      byte ptr [rax], al
0x1c00076b1: add      byte ptr [rax], al
0x1c00076b3: add      byte ptr [rax], al
0x1c00076b5: add      byte ptr [rax], al
0x1c00076b7: add      byte ptr [rax], al
0x1c00076b9: add      byte ptr [rax], al
0x1c00076bb: add      byte ptr [rax], al
0x1c00076bd: add      byte ptr [rax], al
0x1c00076bf: add      byte ptr [rax], al
0x1c00076c1: add      byte ptr [rax], al
0x1c00076c3: add      byte ptr [rax], al
0x1c00076c5: add      byte ptr [rax], al
0x1c00076c7: add      byte ptr [rax], al
0x1c00076c9: add      byte ptr [rax], al
0x1c00076cb: add      byte ptr [rax], al
0x1c00076cd: add      byte ptr [rax], al
0x1c00076cf: add      byte ptr [rax], al
0x1c00076d1: add      byte ptr [rax], al
0x1c00076d3: add      byte ptr [rax], al
0x1c00076d5: add      byte ptr [rax], al
0x1c00076d7: add      byte ptr [rax], al
0x1c00076d9: add      byte ptr [rax], al
0x1c00076db: add      byte ptr [rax], al
0x1c00076dd: add      byte ptr [rax], al
0x1c00076df: add      byte ptr [rax], al
0x1c00076e1: add      byte ptr [rax], al
0x1c00076e3: add      byte ptr [rax], al
0x1c00076e5: add      byte ptr [rax], al
0x1c00076e7: add      byte ptr [rax], al
0x1c00076e9: add      byte ptr [rax], al
0x1c00076eb: add      byte ptr [rax], al
0x1c00076ed: add      byte ptr [rax], al
0x1c00076ef: add      byte ptr [rax], al
0x1c00076f1: add      byte ptr [rax], al
0x1c00076f3: add      byte ptr [rax], al
0x1c00076f5: add      byte ptr [rax], al
0x1c00076f7: add      byte ptr [rax], al
0x1c00076f9: add      byte ptr [rax], al
0x1c00076fb: add      byte ptr [rax], al
0x1c00076fd: add      byte ptr [rax], al
0x1c00076ff: add      byte ptr [rax], al
0x1c0007701: add      byte ptr [rax], al
0x1c0007703: add      byte ptr [rax], al
0x1c0007705: add      byte ptr [rax], al
0x1c0007707: add      byte ptr [rax], al
0x1c0007709: add      byte ptr [rax], al
0x1c000770b: add      byte ptr [rax], al
0x1c000770d: add      byte ptr [rax], al
0x1c000770f: add      byte ptr [rax], al
0x1c0007711: add      byte ptr [rax], al
0x1c0007713: add      byte ptr [rax], al
0x1c0007715: add      byte ptr [rax], al
0x1c0007717: add      byte ptr [rax], al
0x1c0007719: add      byte ptr [rax], al
0x1c000771b: add      byte ptr [rax], al
0x1c000771d: add      byte ptr [rax], al
0x1c000771f: add      byte ptr [rax], al
0x1c0007721: add      byte ptr [rax], al
0x1c0007723: add      byte ptr [rax], al
0x1c0007725: add      byte ptr [rax], al
0x1c0007727: add      byte ptr [rax], al
0x1c0007729: add      byte ptr [rax], al
0x1c000772b: add      byte ptr [rax], al
0x1c000772d: add      byte ptr [rax], al
0x1c000772f: add      byte ptr [rax], al
0x1c0007731: add      byte ptr [rax], al
0x1c0007733: add      byte ptr [rax], al
0x1c0007735: add      byte ptr [rax], al
0x1c0007737: add      byte ptr [rax], al
0x1c0007739: add      byte ptr [rax], al
0x1c000773b: add      byte ptr [rax], al
0x1c000773d: add      byte ptr [rax], al
0x1c000773f: add      byte ptr [rax], al
0x1c0007741: add      byte ptr [rax], al
0x1c0007743: add      byte ptr [rax], al
0x1c0007745: add      byte ptr [rax], al
0x1c0007747: add      byte ptr [rax], al
0x1c0007749: add      byte ptr [rax], al
0x1c000774b: add      byte ptr [rax], al
0x1c000774d: add      byte ptr [rax], al
0x1c000774f: add      byte ptr [rax], al
0x1c0007751: add      byte ptr [rax], al
0x1c0007753: add      byte ptr [rax], al
0x1c0007755: add      byte ptr [rax], al
0x1c0007757: add      byte ptr [rax], al
0x1c0007759: add      byte ptr [rax], al
0x1c000775b: add      byte ptr [rax], al
0x1c000775d: add      byte ptr [rax], al
0x1c000775f: add      byte ptr [rax], al
0x1c0007761: add      byte ptr [rax], al
0x1c0007763: add      byte ptr [rax], al
0x1c0007765: add      byte ptr [rax], al
0x1c0007767: add      byte ptr [rax], al
0x1c0007769: add      byte ptr [rax], al
0x1c000776b: add      byte ptr [rax], al
0x1c000776d: add      byte ptr [rax], al
0x1c000776f: add      byte ptr [rax], al
0x1c0007771: add      byte ptr [rax], al
0x1c0007773: add      byte ptr [rax], al
0x1c0007775: add      byte ptr [rax], al
0x1c0007777: add      byte ptr [rax], al
0x1c0007779: add      byte ptr [rax], al
0x1c000777b: add      byte ptr [rax], al
0x1c000777d: add      byte ptr [rax], al
0x1c000777f: add      byte ptr [rax], al
0x1c0007781: add      byte ptr [rax], al
0x1c0007783: add      byte ptr [rax], al
0x1c0007785: add      byte ptr [rax], al
0x1c0007787: add      byte ptr [rax], al
0x1c0007789: add      byte ptr [rax], al
0x1c000778b: add      byte ptr [rax], al
0x1c000778d: add      byte ptr [rax], al
0x1c000778f: add      byte ptr [rax], al
0x1c0007791: add      byte ptr [rax], al
0x1c0007793: add      byte ptr [rax], al
0x1c0007795: add      byte ptr [rax], al
0x1c0007797: add      byte ptr [rax], al
0x1c0007799: add      byte ptr [rax], al
0x1c000779b: add      byte ptr [rax], al
0x1c000779d: add      byte ptr [rax], al
0x1c000779f: add      byte ptr [rax], al
0x1c00077a1: add      byte ptr [rax], al
0x1c00077a3: add      byte ptr [rax], al
0x1c00077a5: add      byte ptr [rax], al
0x1c00077a7: add      byte ptr [rax], al
0x1c00077a9: add      byte ptr [rax], al
0x1c00077ab: add      byte ptr [rax], al
0x1c00077ad: add      byte ptr [rax], al
0x1c00077af: add      byte ptr [rax], al
0x1c00077b1: add      byte ptr [rax], al
0x1c00077b3: add      byte ptr [rax], al
0x1c00077b5: add      byte ptr [rax], al
0x1c00077b7: add      byte ptr [rax], al
0x1c00077b9: add      byte ptr [rax], al
0x1c00077bb: add      byte ptr [rax], al
0x1c00077bd: add      byte ptr [rax], al
0x1c00077bf: add      byte ptr [rax], al
0x1c00077c1: add      byte ptr [rax], al
0x1c00077c3: add      byte ptr [rax], al
0x1c00077c5: add      byte ptr [rax], al
0x1c00077c7: add      byte ptr [rax], al
0x1c00077c9: add      byte ptr [rax], al
0x1c00077cb: add      byte ptr [rax], al
0x1c00077cd: add      byte ptr [rax], al
0x1c00077cf: add      byte ptr [rax], al
0x1c00077d1: add      byte ptr [rax], al
0x1c00077d3: add      byte ptr [rax], al
0x1c00077d5: add      byte ptr [rax], al
0x1c00077d7: add      byte ptr [rax], al
0x1c00077d9: add      byte ptr [rax], al
0x1c00077db: add      byte ptr [rax], al
0x1c00077dd: add      byte ptr [rax], al
0x1c00077df: add      byte ptr [rax], al
0x1c00077e1: add      byte ptr [rax], al
0x1c00077e3: add      byte ptr [rax], al
0x1c00077e5: add      byte ptr [rax], al
0x1c00077e7: add      byte ptr [rax], al
0x1c00077e9: add      byte ptr [rax], al
0x1c00077eb: add      byte ptr [rax], al
0x1c00077ed: add      byte ptr [rax], al
0x1c00077ef: add      byte ptr [rax], al
0x1c00077f1: add      byte ptr [rax], al
0x1c00077f3: add      byte ptr [rax], al
0x1c00077f5: add      byte ptr [rax], al
0x1c00077f7: add      byte ptr [rax], al
0x1c00077f9: add      byte ptr [rax], al
0x1c00077fb: add      byte ptr [rax], al
0x1c00077fd: add      byte ptr [rax], al
0x1c00077ff: add      byte ptr [rax], al
0x1c0007801: add      byte ptr [rax], al
0x1c0007803: add      byte ptr [rax], al
0x1c0007805: add      byte ptr [rax], al
0x1c0007807: add      byte ptr [rax], al
0x1c0007809: add      byte ptr [rax], al
0x1c000780b: add      byte ptr [rax], al
0x1c000780d: add      byte ptr [rax], al
0x1c000780f: add      byte ptr [rax], al
0x1c0007811: add      byte ptr [rax], al
0x1c0007813: add      byte ptr [rax], al
0x1c0007815: add      byte ptr [rax], al
0x1c0007817: add      byte ptr [rax], al
0x1c0007819: add      byte ptr [rax], al
0x1c000781b: add      byte ptr [rax], al
0x1c000781d: add      byte ptr [rax], al
0x1c000781f: add      byte ptr [rax], al
0x1c0007821: add      byte ptr [rax], al
0x1c0007823: add      byte ptr [rax], al
0x1c0007825: add      byte ptr [rax], al
0x1c0007827: add      byte ptr [rax], al
0x1c0007829: add      byte ptr [rax], al
0x1c000782b: add      byte ptr [rax], al
0x1c000782d: add      byte ptr [rax], al
0x1c000782f: add      byte ptr [rax], al
0x1c0007831: add      byte ptr [rax], al
0x1c0007833: add      byte ptr [rax], al
0x1c0007835: add      byte ptr [rax], al
0x1c0007837: add      byte ptr [rax], al
0x1c0007839: add      byte ptr [rax], al
0x1c000783b: add      byte ptr [rax], al
0x1c000783d: add      byte ptr [rax], al
0x1c000783f: add      byte ptr [rax], al
0x1c0007841: add      byte ptr [rax], al
0x1c0007843: add      byte ptr [rax], al
0x1c0007845: add      byte ptr [rax], al
0x1c0007847: add      byte ptr [rax], al
0x1c0007849: add      byte ptr [rax], al
0x1c000784b: add      byte ptr [rax], al
0x1c000784d: add      byte ptr [rax], al
0x1c000784f: add      byte ptr [rax], al
0x1c0007851: add      byte ptr [rax], al
0x1c0007853: add      byte ptr [rax], al
0x1c0007855: add      byte ptr [rax], al
0x1c0007857: add      byte ptr [rax], al
0x1c0007859: add      byte ptr [rax], al
0x1c000785b: add      byte ptr [rax], al
0x1c000785d: add      byte ptr [rax], al
0x1c000785f: add      byte ptr [rax], al
0x1c0007861: add      byte ptr [rax], al
0x1c0007863: add      byte ptr [rax], al
0x1c0007865: add      byte ptr [rax], al
0x1c0007867: add      byte ptr [rax], al
0x1c0007869: add      byte ptr [rax], al
0x1c000786b: add      byte ptr [rax], al
0x1c000786d: add      byte ptr [rax], al
0x1c000786f: add      byte ptr [rax], al
0x1c0007871: add      byte ptr [rax], al
0x1c0007873: add      byte ptr [rax], al
0x1c0007875: add      byte ptr [rax], al
0x1c0007877: add      byte ptr [rax], al
0x1c0007879: add      byte ptr [rax], al
0x1c000787b: add      byte ptr [rax], al
0x1c000787d: add      byte ptr [rax], al
0x1c000787f: add      byte ptr [rax], al
0x1c0007881: add      byte ptr [rax], al
0x1c0007883: add      byte ptr [rax], al
0x1c0007885: add      byte ptr [rax], al
0x1c0007887: add      byte ptr [rax], al
0x1c0007889: add      byte ptr [rax], al
0x1c000788b: add      byte ptr [rax], al
0x1c000788d: add      byte ptr [rax], al
0x1c000788f: add      byte ptr [rax], al
0x1c0007891: add      byte ptr [rax], al
0x1c0007893: add      byte ptr [rax], al
0x1c0007895: add      byte ptr [rax], al
0x1c0007897: add      byte ptr [rax], al
0x1c0007899: add      byte ptr [rax], al
0x1c000789b: add      byte ptr [rax], al
0x1c000789d: add      byte ptr [rax], al
0x1c000789f: add      byte ptr [rax], al
0x1c00078a1: add      byte ptr [rax], al
0x1c00078a3: add      byte ptr [rax], al
0x1c00078a5: add      byte ptr [rax], al
0x1c00078a7: add      byte ptr [rax], al
0x1c00078a9: add      byte ptr [rax], al
0x1c00078ab: add      byte ptr [rax], al
0x1c00078ad: add      byte ptr [rax], al
0x1c00078af: add      byte ptr [rax], al
0x1c00078b1: add      byte ptr [rax], al
0x1c00078b3: add      byte ptr [rax], al
0x1c00078b5: add      byte ptr [rax], al
0x1c00078b7: add      byte ptr [rax], al
0x1c00078b9: add      byte ptr [rax], al
0x1c00078bb: add      byte ptr [rax], al
0x1c00078bd: add      byte ptr [rax], al
0x1c00078bf: add      byte ptr [rax], al
0x1c00078c1: add      byte ptr [rax], al
0x1c00078c3: add      byte ptr [rax], al
0x1c00078c5: add      byte ptr [rax], al
0x1c00078c7: add      byte ptr [rax], al
0x1c00078c9: add      byte ptr [rax], al
0x1c00078cb: add      byte ptr [rax], al
0x1c00078cd: add      byte ptr [rax], al
0x1c00078cf: add      byte ptr [rax], al
0x1c00078d1: add      byte ptr [rax], al
0x1c00078d3: add      byte ptr [rax], al
0x1c00078d5: add      byte ptr [rax], al
0x1c00078d7: add      byte ptr [rax], al
0x1c00078d9: add      byte ptr [rax], al
0x1c00078db: add      byte ptr [rax], al
0x1c00078dd: add      byte ptr [rax], al
0x1c00078df: add      byte ptr [rax], al
0x1c00078e1: add      byte ptr [rax], al
0x1c00078e3: add      byte ptr [rax], al
0x1c00078e5: add      byte ptr [rax], al
0x1c00078e7: add      byte ptr [rax], al
0x1c00078e9: add      byte ptr [rax], al
0x1c00078eb: add      byte ptr [rax], al
0x1c00078ed: add      byte ptr [rax], al
0x1c00078ef: add      byte ptr [rax], al
0x1c00078f1: add      byte ptr [rax], al
0x1c00078f3: add      byte ptr [rax], al
0x1c00078f5: add      byte ptr [rax], al
0x1c00078f7: add      byte ptr [rax], al
0x1c00078f9: add      byte ptr [rax], al
0x1c00078fb: add      byte ptr [rax], al
0x1c00078fd: add      byte ptr [rax], al
0x1c00078ff: add      byte ptr [rax], al
0x1c0007901: add      byte ptr [rax], al
0x1c0007903: add      byte ptr [rax], al
0x1c0007905: add      byte ptr [rax], al
0x1c0007907: add      byte ptr [rax], al
0x1c0007909: add      byte ptr [rax], al
0x1c000790b: add      byte ptr [rax], al
0x1c000790d: add      byte ptr [rax], al
0x1c000790f: add      byte ptr [rax], al
0x1c0007911: add      byte ptr [rax], al
0x1c0007913: add      byte ptr [rax], al
0x1c0007915: add      byte ptr [rax], al
0x1c0007917: add      byte ptr [rax], al
0x1c0007919: add      byte ptr [rax], al
0x1c000791b: add      byte ptr [rax], al
0x1c000791d: add      byte ptr [rax], al
0x1c000791f: add      byte ptr [rax], al
0x1c0007921: add      byte ptr [rax], al
0x1c0007923: add      byte ptr [rax], al
0x1c0007925: add      byte ptr [rax], al
0x1c0007927: add      byte ptr [rax], al
0x1c0007929: add      byte ptr [rax], al
0x1c000792b: add      byte ptr [rax], al
0x1c000792d: add      byte ptr [rax], al
0x1c000792f: add      byte ptr [rax], al
0x1c0007931: add      byte ptr [rax], al
0x1c0007933: add      byte ptr [rax], al
0x1c0007935: add      byte ptr [rax], al
0x1c0007937: add      byte ptr [rax], al
0x1c0007939: add      byte ptr [rax], al
0x1c000793b: add      byte ptr [rax], al
0x1c000793d: add      byte ptr [rax], al
0x1c000793f: add      byte ptr [rax], al
0x1c0007941: add      byte ptr [rax], al
0x1c0007943: add      byte ptr [rax], al
0x1c0007945: add      byte ptr [rax], al
0x1c0007947: add      byte ptr [rax], al
0x1c0007949: add      byte ptr [rax], al
0x1c000794b: add      byte ptr [rax], al
0x1c000794d: add      byte ptr [rax], al
0x1c000794f: add      byte ptr [rax], al
0x1c0007951: add      byte ptr [rax], al
0x1c0007953: add      byte ptr [rax], al
0x1c0007955: add      byte ptr [rax], al
0x1c0007957: add      byte ptr [rax], al
0x1c0007959: add      byte ptr [rax], al
0x1c000795b: add      byte ptr [rax], al
0x1c000795d: add      byte ptr [rax], al
0x1c000795f: add      byte ptr [rax], al
0x1c0007961: add      byte ptr [rax], al
0x1c0007963: add      byte ptr [rax], al
0x1c0007965: add      byte ptr [rax], al
0x1c0007967: add      byte ptr [rax], al
0x1c0007969: add      byte ptr [rax], al
0x1c000796b: add      byte ptr [rax], al
0x1c000796d: add      byte ptr [rax], al
0x1c000796f: add      byte ptr [rax], al
0x1c0007971: add      byte ptr [rax], al
0x1c0007973: add      byte ptr [rax], al
0x1c0007975: add      byte ptr [rax], al
0x1c0007977: add      byte ptr [rax], al
0x1c0007979: add      byte ptr [rax], al
0x1c000797b: add      byte ptr [rax], al
0x1c000797d: add      byte ptr [rax], al
0x1c000797f: add      byte ptr [rax], al
0x1c0007981: add      byte ptr [rax], al
0x1c0007983: add      byte ptr [rax], al
0x1c0007985: add      byte ptr [rax], al
0x1c0007987: add      byte ptr [rax], al
0x1c0007989: add      byte ptr [rax], al
0x1c000798b: add      byte ptr [rax], al
0x1c000798d: add      byte ptr [rax], al
0x1c000798f: add      byte ptr [rax], al
0x1c0007991: add      byte ptr [rax], al
0x1c0007993: add      byte ptr [rax], al
0x1c0007995: add      byte ptr [rax], al
0x1c0007997: add      byte ptr [rax], al
0x1c0007999: add      byte ptr [rax], al
0x1c000799b: add      byte ptr [rax], al
0x1c000799d: add      byte ptr [rax], al
0x1c000799f: add      byte ptr [rax], al
0x1c00079a1: add      byte ptr [rax], al
0x1c00079a3: add      byte ptr [rax], al
0x1c00079a5: add      byte ptr [rax], al
0x1c00079a7: add      byte ptr [rax], al
0x1c00079a9: add      byte ptr [rax], al
0x1c00079ab: add      byte ptr [rax], al
0x1c00079ad: add      byte ptr [rax], al
0x1c00079af: add      byte ptr [rax], al
0x1c00079b1: add      byte ptr [rax], al
0x1c00079b3: add      byte ptr [rax], al
0x1c00079b5: add      byte ptr [rax], al
0x1c00079b7: add      byte ptr [rax], al
0x1c00079b9: add      byte ptr [rax], al
0x1c00079bb: add      byte ptr [rax], al
0x1c00079bd: add      byte ptr [rax], al
0x1c00079bf: add      byte ptr [rax], al
0x1c00079c1: add      byte ptr [rax], al
0x1c00079c3: add      byte ptr [rax], al
0x1c00079c5: add      byte ptr [rax], al
0x1c00079c7: add      byte ptr [rax], al
0x1c00079c9: add      byte ptr [rax], al
0x1c00079cb: add      byte ptr [rax], al
0x1c00079cd: add      byte ptr [rax], al
0x1c00079cf: add      byte ptr [rax], al
0x1c00079d1: add      byte ptr [rax], al
0x1c00079d3: add      byte ptr [rax], al
0x1c00079d5: add      byte ptr [rax], al
0x1c00079d7: add      byte ptr [rax], al
0x1c00079d9: add      byte ptr [rax], al
0x1c00079db: add      byte ptr [rax], al
0x1c00079dd: add      byte ptr [rax], al
0x1c00079df: add      byte ptr [rax], al
0x1c00079e1: add      byte ptr [rax], al
0x1c00079e3: add      byte ptr [rax], al
0x1c00079e5: add      byte ptr [rax], al
0x1c00079e7: add      byte ptr [rax], al
0x1c00079e9: add      byte ptr [rax], al
0x1c00079eb: add      byte ptr [rax], al
0x1c00079ed: add      byte ptr [rax], al
0x1c00079ef: add      byte ptr [rax], al
0x1c00079f1: add      byte ptr [rax], al
0x1c00079f3: add      byte ptr [rax], al
0x1c00079f5: add      byte ptr [rax], al
0x1c00079f7: add      byte ptr [rax], al
0x1c00079f9: add      byte ptr [rax], al
0x1c00079fb: add      byte ptr [rax], al
0x1c00079fd: add      byte ptr [rax], al
0x1c00079ff: add      byte ptr [rax], al
0x1c0007a01: add      byte ptr [rax], al
0x1c0007a03: add      byte ptr [rax], al
0x1c0007a05: add      byte ptr [rax], al
0x1c0007a07: add      byte ptr [rax], al
0x1c0007a09: add      byte ptr [rax], al
0x1c0007a0b: add      byte ptr [rax], al
0x1c0007a0d: add      byte ptr [rax], al
0x1c0007a0f: add      byte ptr [rax], al
0x1c0007a11: add      byte ptr [rax], al
0x1c0007a13: add      byte ptr [rax], al
0x1c0007a15: add      byte ptr [rax], al
0x1c0007a17: add      byte ptr [rax], al
0x1c0007a19: add      byte ptr [rax], al
0x1c0007a1b: add      byte ptr [rax], al
0x1c0007a1d: add      byte ptr [rax], al
0x1c0007a1f: add      byte ptr [rax], al
0x1c0007a21: add      byte ptr [rax], al
0x1c0007a23: add      byte ptr [rax], al
0x1c0007a25: add      byte ptr [rax], al
0x1c0007a27: add      byte ptr [rax], al
0x1c0007a29: add      byte ptr [rax], al
0x1c0007a2b: add      byte ptr [rax], al
0x1c0007a2d: add      byte ptr [rax], al
0x1c0007a2f: add      byte ptr [rax], al
0x1c0007a31: add      byte ptr [rax], al
0x1c0007a33: add      byte ptr [rax], al
0x1c0007a35: add      byte ptr [rax], al
0x1c0007a37: add      byte ptr [rax], al
0x1c0007a39: add      byte ptr [rax], al
0x1c0007a3b: add      byte ptr [rax], al
0x1c0007a3d: add      byte ptr [rax], al
0x1c0007a3f: add      byte ptr [rax], al
0x1c0007a41: add      byte ptr [rax], al
0x1c0007a43: add      byte ptr [rax], al
0x1c0007a45: add      byte ptr [rax], al
0x1c0007a47: add      byte ptr [rax], al
0x1c0007a49: add      byte ptr [rax], al
0x1c0007a4b: add      byte ptr [rax], al
0x1c0007a4d: add      byte ptr [rax], al
0x1c0007a4f: add      byte ptr [rax], al
0x1c0007a51: add      byte ptr [rax], al
0x1c0007a53: add      byte ptr [rax], al
0x1c0007a55: add      byte ptr [rax], al
0x1c0007a57: add      byte ptr [rax], al
0x1c0007a59: add      byte ptr [rax], al
0x1c0007a5b: add      byte ptr [rax], al
0x1c0007a5d: add      byte ptr [rax], al
0x1c0007a5f: add      byte ptr [rax], al
0x1c0007a61: add      byte ptr [rax], al
0x1c0007a63: add      byte ptr [rax], al
0x1c0007a65: add      byte ptr [rax], al
0x1c0007a67: add      byte ptr [rax], al
0x1c0007a69: add      byte ptr [rax], al
0x1c0007a6b: add      byte ptr [rax], al
0x1c0007a6d: add      byte ptr [rax], al
0x1c0007a6f: add      byte ptr [rax], al
0x1c0007a71: add      byte ptr [rax], al
0x1c0007a73: add      byte ptr [rax], al
0x1c0007a75: add      byte ptr [rax], al
0x1c0007a77: add      byte ptr [rax], al
0x1c0007a79: add      byte ptr [rax], al
0x1c0007a7b: add      byte ptr [rax], al
0x1c0007a7d: add      byte ptr [rax], al
0x1c0007a7f: add      byte ptr [rax], al
0x1c0007a81: add      byte ptr [rax], al
0x1c0007a83: add      byte ptr [rax], al
0x1c0007a85: add      byte ptr [rax], al
0x1c0007a87: add      byte ptr [rax], al
0x1c0007a89: add      byte ptr [rax], al
0x1c0007a8b: add      byte ptr [rax], al
0x1c0007a8d: add      byte ptr [rax], al
0x1c0007a8f: add      byte ptr [rax], al
0x1c0007a91: add      byte ptr [rax], al
0x1c0007a93: add      byte ptr [rax], al
0x1c0007a95: add      byte ptr [rax], al
0x1c0007a97: add      byte ptr [rax], al
0x1c0007a99: add      byte ptr [rax], al
0x1c0007a9b: add      byte ptr [rax], al
0x1c0007a9d: add      byte ptr [rax], al
0x1c0007a9f: add      byte ptr [rax], al
0x1c0007aa1: add      byte ptr [rax], al
0x1c0007aa3: add      byte ptr [rax], al
0x1c0007aa5: add      byte ptr [rax], al
0x1c0007aa7: add      byte ptr [rax], al
0x1c0007aa9: add      byte ptr [rax], al
0x1c0007aab: add      byte ptr [rax], al
0x1c0007aad: add      byte ptr [rax], al
0x1c0007aaf: add      byte ptr [rax], al
0x1c0007ab1: add      byte ptr [rax], al
0x1c0007ab3: add      byte ptr [rax], al
0x1c0007ab5: add      byte ptr [rax], al
0x1c0007ab7: add      byte ptr [rax], al
0x1c0007ab9: add      byte ptr [rax], al
0x1c0007abb: add      byte ptr [rax], al
0x1c0007abd: add      byte ptr [rax], al
0x1c0007abf: add      byte ptr [rax], al
0x1c0007ac1: add      byte ptr [rax], al
0x1c0007ac3: add      byte ptr [rax], al
0x1c0007ac5: add      byte ptr [rax], al
0x1c0007ac7: add      byte ptr [rax], al
0x1c0007ac9: add      byte ptr [rax], al
0x1c0007acb: add      byte ptr [rax], al
0x1c0007acd: add      byte ptr [rax], al
0x1c0007acf: add      byte ptr [rax], al
0x1c0007ad1: add      byte ptr [rax], al
0x1c0007ad3: add      byte ptr [rax], al
0x1c0007ad5: add      byte ptr [rax], al
0x1c0007ad7: add      byte ptr [rax], al
0x1c0007ad9: add      byte ptr [rax], al
0x1c0007adb: add      byte ptr [rax], al
0x1c0007add: add      byte ptr [rax], al
0x1c0007adf: add      byte ptr [rax], al
0x1c0007ae1: add      byte ptr [rax], al
0x1c0007ae3: add      byte ptr [rax], al
0x1c0007ae5: add      byte ptr [rax], al
0x1c0007ae7: add      byte ptr [rax], al
0x1c0007ae9: add      byte ptr [rax], al
0x1c0007aeb: add      byte ptr [rax], al
0x1c0007aed: add      byte ptr [rax], al
0x1c0007aef: add      byte ptr [rax], al
0x1c0007af1: add      byte ptr [rax], al
0x1c0007af3: add      byte ptr [rax], al
0x1c0007af5: add      byte ptr [rax], al
0x1c0007af7: add      byte ptr [rax], al
0x1c0007af9: add      byte ptr [rax], al
0x1c0007afb: add      byte ptr [rax], al
0x1c0007afd: add      byte ptr [rax], al
0x1c0007aff: add      byte ptr [rax], al
0x1c0007b01: add      byte ptr [rax], al
0x1c0007b03: add      byte ptr [rax], al
0x1c0007b05: add      byte ptr [rax], al
0x1c0007b07: add      byte ptr [rax], al
0x1c0007b09: add      byte ptr [rax], al
0x1c0007b0b: add      byte ptr [rax], al
0x1c0007b0d: add      byte ptr [rax], al
0x1c0007b0f: add      byte ptr [rax], al
0x1c0007b11: add      byte ptr [rax], al
0x1c0007b13: add      byte ptr [rax], al
0x1c0007b15: add      byte ptr [rax], al
0x1c0007b17: add      byte ptr [rax], al
0x1c0007b19: add      byte ptr [rax], al
0x1c0007b1b: add      byte ptr [rax], al
0x1c0007b1d: add      byte ptr [rax], al
0x1c0007b1f: add      byte ptr [rax], al
0x1c0007b21: add      byte ptr [rax], al
0x1c0007b23: add      byte ptr [rax], al
0x1c0007b25: add      byte ptr [rax], al
0x1c0007b27: add      byte ptr [rax], al
0x1c0007b29: add      byte ptr [rax], al
0x1c0007b2b: add      byte ptr [rax], al
0x1c0007b2d: add      byte ptr [rax], al
0x1c0007b2f: add      byte ptr [rax], al
0x1c0007b31: add      byte ptr [rax], al
0x1c0007b33: add      byte ptr [rax], al
0x1c0007b35: add      byte ptr [rax], al
0x1c0007b37: add      byte ptr [rax], al
0x1c0007b39: add      byte ptr [rax], al
0x1c0007b3b: add      byte ptr [rax], al
0x1c0007b3d: add      byte ptr [rax], al
0x1c0007b3f: add      byte ptr [rax], al
0x1c0007b41: add      byte ptr [rax], al
0x1c0007b43: add      byte ptr [rax], al
0x1c0007b45: add      byte ptr [rax], al
0x1c0007b47: add      byte ptr [rax], al
0x1c0007b49: add      byte ptr [rax], al
0x1c0007b4b: add      byte ptr [rax], al
0x1c0007b4d: add      byte ptr [rax], al
0x1c0007b4f: add      byte ptr [rax], al
0x1c0007b51: add      byte ptr [rax], al
0x1c0007b53: add      byte ptr [rax], al
0x1c0007b55: add      byte ptr [rax], al
0x1c0007b57: add      byte ptr [rax], al
0x1c0007b59: add      byte ptr [rax], al
0x1c0007b5b: add      byte ptr [rax], al
0x1c0007b5d: add      byte ptr [rax], al
0x1c0007b5f: add      byte ptr [rax], al
0x1c0007b61: add      byte ptr [rax], al
0x1c0007b63: add      byte ptr [rax], al
0x1c0007b65: add      byte ptr [rax], al
0x1c0007b67: add      byte ptr [rax], al
0x1c0007b69: add      byte ptr [rax], al
0x1c0007b6b: add      byte ptr [rax], al
0x1c0007b6d: add      byte ptr [rax], al
0x1c0007b6f: add      byte ptr [rax], al
0x1c0007b71: add      byte ptr [rax], al
0x1c0007b73: add      byte ptr [rax], al
0x1c0007b75: add      byte ptr [rax], al
0x1c0007b77: add      byte ptr [rax], al
0x1c0007b79: add      byte ptr [rax], al
0x1c0007b7b: add      byte ptr [rax], al
0x1c0007b7d: add      byte ptr [rax], al
0x1c0007b7f: add      byte ptr [rax], al
0x1c0007b81: add      byte ptr [rax], al
0x1c0007b83: add      byte ptr [rax], al
0x1c0007b85: add      byte ptr [rax], al
0x1c0007b87: add      byte ptr [rax], al
0x1c0007b89: add      byte ptr [rax], al
0x1c0007b8b: add      byte ptr [rax], al
0x1c0007b8d: add      byte ptr [rax], al
0x1c0007b8f: add      byte ptr [rax], al
0x1c0007b91: add      byte ptr [rax], al
0x1c0007b93: add      byte ptr [rax], al
0x1c0007b95: add      byte ptr [rax], al
0x1c0007b97: add      byte ptr [rax], al
0x1c0007b99: add      byte ptr [rax], al
0x1c0007b9b: add      byte ptr [rax], al
0x1c0007b9d: add      byte ptr [rax], al
0x1c0007b9f: add      byte ptr [rax], al
0x1c0007ba1: add      byte ptr [rax], al
0x1c0007ba3: add      byte ptr [rax], al
0x1c0007ba5: add      byte ptr [rax], al
0x1c0007ba7: add      byte ptr [rax], al
0x1c0007ba9: add      byte ptr [rax], al
0x1c0007bab: add      byte ptr [rax], al
0x1c0007bad: add      byte ptr [rax], al
0x1c0007baf: add      byte ptr [rax], al
0x1c0007bb1: add      byte ptr [rax], al
0x1c0007bb3: add      byte ptr [rax], al
0x1c0007bb5: add      byte ptr [rax], al
0x1c0007bb7: add      byte ptr [rax], al
0x1c0007bb9: add      byte ptr [rax], al
0x1c0007bbb: add      byte ptr [rax], al
0x1c0007bbd: add      byte ptr [rax], al
0x1c0007bbf: add      byte ptr [rax], al
0x1c0007bc1: add      byte ptr [rax], al
0x1c0007bc3: add      byte ptr [rax], al
0x1c0007bc5: add      byte ptr [rax], al
0x1c0007bc7: add      byte ptr [rax], al
0x1c0007bc9: add      byte ptr [rax], al
0x1c0007bcb: add      byte ptr [rax], al
0x1c0007bcd: add      byte ptr [rax], al
0x1c0007bcf: add      byte ptr [rax], al
0x1c0007bd1: add      byte ptr [rax], al
0x1c0007bd3: add      byte ptr [rax], al
0x1c0007bd5: add      byte ptr [rax], al
0x1c0007bd7: add      byte ptr [rax], al
0x1c0007bd9: add      byte ptr [rax], al
0x1c0007bdb: add      byte ptr [rax], al
0x1c0007bdd: add      byte ptr [rax], al
0x1c0007bdf: add      byte ptr [rax], al
0x1c0007be1: add      byte ptr [rax], al
0x1c0007be3: add      byte ptr [rax], al
0x1c0007be5: add      byte ptr [rax], al
0x1c0007be7: add      byte ptr [rax], al
0x1c0007be9: add      byte ptr [rax], al
0x1c0007beb: add      byte ptr [rax], al
0x1c0007bed: add      byte ptr [rax], al
0x1c0007bef: add      byte ptr [rax], al
0x1c0007bf1: add      byte ptr [rax], al
0x1c0007bf3: add      byte ptr [rax], al
0x1c0007bf5: add      byte ptr [rax], al
0x1c0007bf7: add      byte ptr [rax], al
0x1c0007bf9: add      byte ptr [rax], al
0x1c0007bfb: add      byte ptr [rax], al
0x1c0007bfd: add      byte ptr [rax], al
0x1c0007bff: add      byte ptr [rax], al
0x1c0007c01: add      byte ptr [rax], al
0x1c0007c03: add      byte ptr [rax], al
0x1c0007c05: add      byte ptr [rax], al
0x1c0007c07: add      byte ptr [rax], al
0x1c0007c09: add      byte ptr [rax], al
0x1c0007c0b: add      byte ptr [rax], al
0x1c0007c0d: add      byte ptr [rax], al
0x1c0007c0f: add      byte ptr [rax], al
0x1c0007c11: add      byte ptr [rax], al
0x1c0007c13: add      byte ptr [rax], al
0x1c0007c15: add      byte ptr [rax], al
0x1c0007c17: add      byte ptr [rax], al
0x1c0007c19: add      byte ptr [rax], al
0x1c0007c1b: add      byte ptr [rax], al
0x1c0007c1d: add      byte ptr [rax], al
0x1c0007c1f: add      byte ptr [rax], al
0x1c0007c21: add      byte ptr [rax], al
0x1c0007c23: add      byte ptr [rax], al
0x1c0007c25: add      byte ptr [rax], al
0x1c0007c27: add      byte ptr [rax], al
0x1c0007c29: add      byte ptr [rax], al
0x1c0007c2b: add      byte ptr [rax], al
0x1c0007c2d: add      byte ptr [rax], al
0x1c0007c2f: add      byte ptr [rax], al
0x1c0007c31: add      byte ptr [rax], al
0x1c0007c33: add      byte ptr [rax], al
0x1c0007c35: add      byte ptr [rax], al
0x1c0007c37: add      byte ptr [rax], al
0x1c0007c39: add      byte ptr [rax], al
0x1c0007c3b: add      byte ptr [rax], al
0x1c0007c3d: add      byte ptr [rax], al
0x1c0007c3f: add      byte ptr [rax], al
0x1c0007c41: add      byte ptr [rax], al
0x1c0007c43: add      byte ptr [rax], al
0x1c0007c45: add      byte ptr [rax], al
0x1c0007c47: add      byte ptr [rax], al
0x1c0007c49: add      byte ptr [rax], al
0x1c0007c4b: add      byte ptr [rax], al
0x1c0007c4d: add      byte ptr [rax], al
0x1c0007c4f: add      byte ptr [rax], al
0x1c0007c51: add      byte ptr [rax], al
0x1c0007c53: add      byte ptr [rax], al
0x1c0007c55: add      byte ptr [rax], al
0x1c0007c57: add      byte ptr [rax], al
0x1c0007c59: add      byte ptr [rax], al
0x1c0007c5b: add      byte ptr [rax], al
0x1c0007c5d: add      byte ptr [rax], al
0x1c0007c5f: add      byte ptr [rax], al
0x1c0007c61: add      byte ptr [rax], al
0x1c0007c63: add      byte ptr [rax], al
0x1c0007c65: add      byte ptr [rax], al
0x1c0007c67: add      byte ptr [rax], al
0x1c0007c69: add      byte ptr [rax], al
0x1c0007c6b: add      byte ptr [rax], al
0x1c0007c6d: add      byte ptr [rax], al
0x1c0007c6f: add      byte ptr [rax], al
0x1c0007c71: add      byte ptr [rax], al
0x1c0007c73: add      byte ptr [rax], al
0x1c0007c75: add      byte ptr [rax], al
0x1c0007c77: add      byte ptr [rax], al
0x1c0007c79: add      byte ptr [rax], al
0x1c0007c7b: add      byte ptr [rax], al
0x1c0007c7d: add      byte ptr [rax], al
0x1c0007c7f: add      byte ptr [rax], al
0x1c0007c81: add      byte ptr [rax], al
0x1c0007c83: add      byte ptr [rax], al
0x1c0007c85: add      byte ptr [rax], al
0x1c0007c87: add      byte ptr [rax], al
0x1c0007c89: add      byte ptr [rax], al
0x1c0007c8b: add      byte ptr [rax], al
0x1c0007c8d: add      byte ptr [rax], al
0x1c0007c8f: add      byte ptr [rax], al
0x1c0007c91: add      byte ptr [rax], al
0x1c0007c93: add      byte ptr [rax], al
0x1c0007c95: add      byte ptr [rax], al
0x1c0007c97: add      byte ptr [rax], al
0x1c0007c99: add      byte ptr [rax], al
0x1c0007c9b: add      byte ptr [rax], al
0x1c0007c9d: add      byte ptr [rax], al
0x1c0007c9f: add      byte ptr [rax], al
0x1c0007ca1: add      byte ptr [rax], al
0x1c0007ca3: add      byte ptr [rax], al
0x1c0007ca5: add      byte ptr [rax], al
0x1c0007ca7: add      byte ptr [rax], al
0x1c0007ca9: add      byte ptr [rax], al
0x1c0007cab: add      byte ptr [rax], al
0x1c0007cad: add      byte ptr [rax], al
0x1c0007caf: add      byte ptr [rax], al
0x1c0007cb1: add      byte ptr [rax], al
0x1c0007cb3: add      byte ptr [rax], al
0x1c0007cb5: add      byte ptr [rax], al
0x1c0007cb7: add      byte ptr [rax], al
0x1c0007cb9: add      byte ptr [rax], al
0x1c0007cbb: add      byte ptr [rax], al
0x1c0007cbd: add      byte ptr [rax], al
0x1c0007cbf: add      byte ptr [rax], al
0x1c0007cc1: add      byte ptr [rax], al
0x1c0007cc3: add      byte ptr [rax], al
0x1c0007cc5: add      byte ptr [rax], al
0x1c0007cc7: add      byte ptr [rax], al
0x1c0007cc9: add      byte ptr [rax], al
0x1c0007ccb: add      byte ptr [rax], al
0x1c0007ccd: add      byte ptr [rax], al
0x1c0007ccf: add      byte ptr [rax], al
0x1c0007cd1: add      byte ptr [rax], al
0x1c0007cd3: add      byte ptr [rax], al
0x1c0007cd5: add      byte ptr [rax], al
0x1c0007cd7: add      byte ptr [rax], al
0x1c0007cd9: add      byte ptr [rax], al
0x1c0007cdb: add      byte ptr [rax], al
0x1c0007cdd: add      byte ptr [rax], al
0x1c0007cdf: add      byte ptr [rax], al
0x1c0007ce1: add      byte ptr [rax], al
0x1c0007ce3: add      byte ptr [rax], al
0x1c0007ce5: add      byte ptr [rax], al
0x1c0007ce7: add      byte ptr [rax], al
0x1c0007ce9: add      byte ptr [rax], al
0x1c0007ceb: add      byte ptr [rax], al
0x1c0007ced: add      byte ptr [rax], al
0x1c0007cef: add      byte ptr [rax], al
0x1c0007cf1: add      byte ptr [rax], al
0x1c0007cf3: add      byte ptr [rax], al
0x1c0007cf5: add      byte ptr [rax], al
0x1c0007cf7: add      byte ptr [rax], al
0x1c0007cf9: add      byte ptr [rax], al
0x1c0007cfb: add      byte ptr [rax], al
0x1c0007cfd: add      byte ptr [rax], al
0x1c0007cff: add      byte ptr [rax], al
0x1c0007d01: add      byte ptr [rax], al
0x1c0007d03: add      byte ptr [rax], al
0x1c0007d05: add      byte ptr [rax], al
0x1c0007d07: add      byte ptr [rax], al
0x1c0007d09: add      byte ptr [rax], al
0x1c0007d0b: add      byte ptr [rax], al
0x1c0007d0d: add      byte ptr [rax], al
0x1c0007d0f: add      byte ptr [rax], al
0x1c0007d11: add      byte ptr [rax], al
0x1c0007d13: add      byte ptr [rax], al
0x1c0007d15: add      byte ptr [rax], al
0x1c0007d17: add      byte ptr [rax], al
0x1c0007d19: add      byte ptr [rax], al
0x1c0007d1b: add      byte ptr [rax], al
0x1c0007d1d: add      byte ptr [rax], al
0x1c0007d1f: add      byte ptr [rax], al
0x1c0007d21: add      byte ptr [rax], al
0x1c0007d23: add      byte ptr [rax], al
0x1c0007d25: add      byte ptr [rax], al
0x1c0007d27: add      byte ptr [rax], al
0x1c0007d29: add      byte ptr [rax], al
0x1c0007d2b: add      byte ptr [rax], al
0x1c0007d2d: add      byte ptr [rax], al
0x1c0007d2f: add      byte ptr [rax], al
0x1c0007d31: add      byte ptr [rax], al
0x1c0007d33: add      byte ptr [rax], al
0x1c0007d35: add      byte ptr [rax], al
0x1c0007d37: add      byte ptr [rax], al
0x1c0007d39: add      byte ptr [rax], al
0x1c0007d3b: add      byte ptr [rax], al
0x1c0007d3d: add      byte ptr [rax], al
0x1c0007d3f: add      byte ptr [rax], al
0x1c0007d41: add      byte ptr [rax], al
0x1c0007d43: add      byte ptr [rax], al
0x1c0007d45: add      byte ptr [rax], al
0x1c0007d47: add      byte ptr [rax], al
0x1c0007d49: add      byte ptr [rax], al
0x1c0007d4b: add      byte ptr [rax], al
0x1c0007d4d: add      byte ptr [rax], al
0x1c0007d4f: add      byte ptr [rax], al
0x1c0007d51: add      byte ptr [rax], al
0x1c0007d53: add      byte ptr [rax], al
0x1c0007d55: add      byte ptr [rax], al
0x1c0007d57: add      byte ptr [rax], al
0x1c0007d59: add      byte ptr [rax], al
0x1c0007d5b: add      byte ptr [rax], al
0x1c0007d5d: add      byte ptr [rax], al
0x1c0007d5f: add      byte ptr [rax], al
0x1c0007d61: add      byte ptr [rax], al
0x1c0007d63: add      byte ptr [rax], al
0x1c0007d65: add      byte ptr [rax], al
0x1c0007d67: add      byte ptr [rax], al
0x1c0007d69: add      byte ptr [rax], al
0x1c0007d6b: add      byte ptr [rax], al
0x1c0007d6d: add      byte ptr [rax], al
0x1c0007d6f: add      byte ptr [rax], al
0x1c0007d71: add      byte ptr [rax], al
0x1c0007d73: add      byte ptr [rax], al
0x1c0007d75: add      byte ptr [rax], al
0x1c0007d77: add      byte ptr [rax], al
0x1c0007d79: add      byte ptr [rax], al
0x1c0007d7b: add      byte ptr [rax], al
0x1c0007d7d: add      byte ptr [rax], al
0x1c0007d7f: add      byte ptr [rax], al
0x1c0007d81: add      byte ptr [rax], al
0x1c0007d83: add      byte ptr [rax], al
0x1c0007d85: add      byte ptr [rax], al
0x1c0007d87: add      byte ptr [rax], al
0x1c0007d89: add      byte ptr [rax], al
0x1c0007d8b: add      byte ptr [rax], al
0x1c0007d8d: add      byte ptr [rax], al
0x1c0007d8f: add      byte ptr [rax], al
0x1c0007d91: add      byte ptr [rax], al
0x1c0007d93: add      byte ptr [rax], al
0x1c0007d95: add      byte ptr [rax], al
0x1c0007d97: add      byte ptr [rax], al
0x1c0007d99: add      byte ptr [rax], al
0x1c0007d9b: add      byte ptr [rax], al
0x1c0007d9d: add      byte ptr [rax], al
0x1c0007d9f: add      byte ptr [rax], al
0x1c0007da1: add      byte ptr [rax], al
0x1c0007da3: add      byte ptr [rax], al
0x1c0007da5: add      byte ptr [rax], al
0x1c0007da7: add      byte ptr [rax], al
0x1c0007da9: add      byte ptr [rax], al
0x1c0007dab: add      byte ptr [rax], al
0x1c0007dad: add      byte ptr [rax], al
0x1c0007daf: add      byte ptr [rax], al
0x1c0007db1: add      byte ptr [rax], al
0x1c0007db3: add      byte ptr [rax], al
0x1c0007db5: add      byte ptr [rax], al
0x1c0007db7: add      byte ptr [rax], al
0x1c0007db9: add      byte ptr [rax], al
0x1c0007dbb: add      byte ptr [rax], al
0x1c0007dbd: add      byte ptr [rax], al
0x1c0007dbf: add      byte ptr [rax], al
0x1c0007dc1: add      byte ptr [rax], al
0x1c0007dc3: add      byte ptr [rax], al
0x1c0007dc5: add      byte ptr [rax], al
0x1c0007dc7: add      byte ptr [rax], al
0x1c0007dc9: add      byte ptr [rax], al
0x1c0007dcb: add      byte ptr [rax], al
0x1c0007dcd: add      byte ptr [rax], al
0x1c0007dcf: add      byte ptr [rax], al
0x1c0007dd1: add      byte ptr [rax], al
0x1c0007dd3: add      byte ptr [rax], al
0x1c0007dd5: add      byte ptr [rax], al
0x1c0007dd7: add      byte ptr [rax], al
0x1c0007dd9: add      byte ptr [rax], al
0x1c0007ddb: add      byte ptr [rax], al
0x1c0007ddd: add      byte ptr [rax], al
0x1c0007ddf: add      byte ptr [rax], al
0x1c0007de1: add      byte ptr [rax], al
0x1c0007de3: add      byte ptr [rax], al
0x1c0007de5: add      byte ptr [rax], al
0x1c0007de7: add      byte ptr [rax], al
0x1c0007de9: add      byte ptr [rax], al
0x1c0007deb: add      byte ptr [rax], al
0x1c0007ded: add      byte ptr [rax], al
0x1c0007def: add      byte ptr [rax], al
0x1c0007df1: add      byte ptr [rax], al
0x1c0007df3: add      byte ptr [rax], al
0x1c0007df5: add      byte ptr [rax], al
0x1c0007df7: add      byte ptr [rax], al
0x1c0007df9: add      byte ptr [rax], al
0x1c0007dfb: add      byte ptr [rax], al
0x1c0007dfd: add      byte ptr [rax], al
0x1c0007dff: add      byte ptr [rax], al
0x1c0007e01: add      byte ptr [rax], al
0x1c0007e03: add      byte ptr [rax], al
0x1c0007e05: add      byte ptr [rax], al
0x1c0007e07: add      byte ptr [rax], al
0x1c0007e09: add      byte ptr [rax], al
0x1c0007e0b: add      byte ptr [rax], al
0x1c0007e0d: add      byte ptr [rax], al
0x1c0007e0f: add      byte ptr [rax], al
0x1c0007e11: add      byte ptr [rax], al
0x1c0007e13: add      byte ptr [rax], al
0x1c0007e15: add      byte ptr [rax], al
0x1c0007e17: add      byte ptr [rax], al
0x1c0007e19: add      byte ptr [rax], al
0x1c0007e1b: add      byte ptr [rax], al
0x1c0007e1d: add      byte ptr [rax], al
0x1c0007e1f: add      byte ptr [rax], al
0x1c0007e21: add      byte ptr [rax], al
0x1c0007e23: add      byte ptr [rax], al
0x1c0007e25: add      byte ptr [rax], al
0x1c0007e27: add      byte ptr [rax], al
0x1c0007e29: add      byte ptr [rax], al
0x1c0007e2b: add      byte ptr [rax], al
0x1c0007e2d: add      byte ptr [rax], al
0x1c0007e2f: add      byte ptr [rax], al
0x1c0007e31: add      byte ptr [rax], al
0x1c0007e33: add      byte ptr [rax], al
0x1c0007e35: add      byte ptr [rax], al
0x1c0007e37: add      byte ptr [rax], al
0x1c0007e39: add      byte ptr [rax], al
0x1c0007e3b: add      byte ptr [rax], al
0x1c0007e3d: add      byte ptr [rax], al
0x1c0007e3f: add      byte ptr [rax], al
0x1c0007e41: add      byte ptr [rax], al
0x1c0007e43: add      byte ptr [rax], al
0x1c0007e45: add      byte ptr [rax], al
0x1c0007e47: add      byte ptr [rax], al
0x1c0007e49: add      byte ptr [rax], al
0x1c0007e4b: add      byte ptr [rax], al
0x1c0007e4d: add      byte ptr [rax], al
0x1c0007e4f: add      byte ptr [rax], al
0x1c0007e51: add      byte ptr [rax], al
0x1c0007e53: add      byte ptr [rax], al
0x1c0007e55: add      byte ptr [rax], al
0x1c0007e57: add      byte ptr [rax], al
0x1c0007e59: add      byte ptr [rax], al
0x1c0007e5b: add      byte ptr [rax], al
0x1c0007e5d: add      byte ptr [rax], al
0x1c0007e5f: add      byte ptr [rax], al
0x1c0007e61: add      byte ptr [rax], al
0x1c0007e63: add      byte ptr [rax], al
0x1c0007e65: add      byte ptr [rax], al
0x1c0007e67: add      byte ptr [rax], al
0x1c0007e69: add      byte ptr [rax], al
0x1c0007e6b: add      byte ptr [rax], al
0x1c0007e6d: add      byte ptr [rax], al
0x1c0007e6f: add      byte ptr [rax], al
0x1c0007e71: add      byte ptr [rax], al
0x1c0007e73: add      byte ptr [rax], al
0x1c0007e75: add      byte ptr [rax], al
0x1c0007e77: add      byte ptr [rax], al
0x1c0007e79: add      byte ptr [rax], al
0x1c0007e7b: add      byte ptr [rax], al
0x1c0007e7d: add      byte ptr [rax], al
0x1c0007e7f: add      byte ptr [rax], al
0x1c0007e81: add      byte ptr [rax], al
0x1c0007e83: add      byte ptr [rax], al
0x1c0007e85: add      byte ptr [rax], al
0x1c0007e87: add      byte ptr [rax], al
0x1c0007e89: add      byte ptr [rax], al
0x1c0007e8b: add      byte ptr [rax], al
0x1c0007e8d: add      byte ptr [rax], al
0x1c0007e8f: add      byte ptr [rax], al
0x1c0007e91: add      byte ptr [rax], al
0x1c0007e93: add      byte ptr [rax], al
0x1c0007e95: add      byte ptr [rax], al
0x1c0007e97: add      byte ptr [rax], al
0x1c0007e99: add      byte ptr [rax], al
0x1c0007e9b: add      byte ptr [rax], al
0x1c0007e9d: add      byte ptr [rax], al
0x1c0007e9f: add      byte ptr [rax], al
0x1c0007ea1: add      byte ptr [rax], al
0x1c0007ea3: add      byte ptr [rax], al
0x1c0007ea5: add      byte ptr [rax], al
0x1c0007ea7: add      byte ptr [rax], al
0x1c0007ea9: add      byte ptr [rax], al
0x1c0007eab: add      byte ptr [rax], al
0x1c0007ead: add      byte ptr [rax], al
0x1c0007eaf: add      byte ptr [rax], al
0x1c0007eb1: add      byte ptr [rax], al
0x1c0007eb3: add      byte ptr [rax], al
0x1c0007eb5: add      byte ptr [rax], al
0x1c0007eb7: add      byte ptr [rax], al
0x1c0007eb9: add      byte ptr [rax], al
0x1c0007ebb: add      byte ptr [rax], al
0x1c0007ebd: add      byte ptr [rax], al
0x1c0007ebf: add      byte ptr [rax], al
0x1c0007ec1: add      byte ptr [rax], al
0x1c0007ec3: add      byte ptr [rax], al
0x1c0007ec5: add      byte ptr [rax], al
0x1c0007ec7: add      byte ptr [rax], al
0x1c0007ec9: add      byte ptr [rax], al
0x1c0007ecb: add      byte ptr [rax], al
0x1c0007ecd: add      byte ptr [rax], al
0x1c0007ecf: add      byte ptr [rax], al
0x1c0007ed1: add      byte ptr [rax], al
0x1c0007ed3: add      byte ptr [rax], al
0x1c0007ed5: add      byte ptr [rax], al
0x1c0007ed7: add      byte ptr [rax], al
0x1c0007ed9: add      byte ptr [rax], al
0x1c0007edb: add      byte ptr [rax], al
0x1c0007edd: add      byte ptr [rax], al
0x1c0007edf: add      byte ptr [rax], al
0x1c0007ee1: add      byte ptr [rax], al
0x1c0007ee3: add      byte ptr [rax], al
0x1c0007ee5: add      byte ptr [rax], al
0x1c0007ee7: add      byte ptr [rax], al
0x1c0007ee9: add      byte ptr [rax], al
0x1c0007eeb: add      byte ptr [rax], al
0x1c0007eed: add      byte ptr [rax], al
0x1c0007eef: add      byte ptr [rax], al
0x1c0007ef1: add      byte ptr [rax], al
0x1c0007ef3: add      byte ptr [rax], al
0x1c0007ef5: add      byte ptr [rax], al
0x1c0007ef7: add      byte ptr [rax], al
0x1c0007ef9: add      byte ptr [rax], al
0x1c0007efb: add      byte ptr [rax], al
0x1c0007efd: add      byte ptr [rax], al
0x1c0007eff: add      byte ptr [rax], al
0x1c0007f01: add      byte ptr [rax], al
0x1c0007f03: add      byte ptr [rax], al
0x1c0007f05: add      byte ptr [rax], al
0x1c0007f07: add      byte ptr [rax], al
0x1c0007f09: add      byte ptr [rax], al
0x1c0007f0b: add      byte ptr [rax], al
0x1c0007f0d: add      byte ptr [rax], al
0x1c0007f0f: add      byte ptr [rax], al
0x1c0007f11: add      byte ptr [rax], al
0x1c0007f13: add      byte ptr [rax], al
0x1c0007f15: add      byte ptr [rax], al
0x1c0007f17: add      byte ptr [rax], al
0x1c0007f19: add      byte ptr [rax], al
0x1c0007f1b: add      byte ptr [rax], al
0x1c0007f1d: add      byte ptr [rax], al
0x1c0007f1f: add      byte ptr [rax], al
0x1c0007f21: add      byte ptr [rax], al
0x1c0007f23: add      byte ptr [rax], al
0x1c0007f25: add      byte ptr [rax], al
0x1c0007f27: add      byte ptr [rax], al
0x1c0007f29: add      byte ptr [rax], al
0x1c0007f2b: add      byte ptr [rax], al
0x1c0007f2d: add      byte ptr [rax], al
0x1c0007f2f: add      byte ptr [rax], al
0x1c0007f31: add      byte ptr [rax], al
0x1c0007f33: add      byte ptr [rax], al
0x1c0007f35: add      byte ptr [rax], al
0x1c0007f37: add      byte ptr [rax], al
0x1c0007f39: add      byte ptr [rax], al
0x1c0007f3b: add      byte ptr [rax], al
0x1c0007f3d: add      byte ptr [rax], al
0x1c0007f3f: add      byte ptr [rax], al
0x1c0007f41: add      byte ptr [rax], al
0x1c0007f43: add      byte ptr [rax], al
0x1c0007f45: add      byte ptr [rax], al
0x1c0007f47: add      byte ptr [rax], al
0x1c0007f49: add      byte ptr [rax], al
0x1c0007f4b: add      byte ptr [rax], al
0x1c0007f4d: add      byte ptr [rax], al
0x1c0007f4f: add      byte ptr [rax], al
0x1c0007f51: add      byte ptr [rax], al
0x1c0007f53: add      byte ptr [rax], al
0x1c0007f55: add      byte ptr [rax], al
0x1c0007f57: add      byte ptr [rax], al
0x1c0007f59: add      byte ptr [rax], al
0x1c0007f5b: add      byte ptr [rax], al
0x1c0007f5d: add      byte ptr [rax], al
0x1c0007f5f: add      byte ptr [rax], al
0x1c0007f61: add      byte ptr [rax], al
0x1c0007f63: add      byte ptr [rax], al
0x1c0007f65: add      byte ptr [rax], al
0x1c0007f67: add      byte ptr [rax], al
0x1c0007f69: add      byte ptr [rax], al
0x1c0007f6b: add      byte ptr [rax], al
0x1c0007f6d: add      byte ptr [rax], al
0x1c0007f6f: add      byte ptr [rax], al
0x1c0007f71: add      byte ptr [rax], al
0x1c0007f73: add      byte ptr [rax], al
0x1c0007f75: add      byte ptr [rax], al
0x1c0007f77: add      byte ptr [rax], al
0x1c0007f79: add      byte ptr [rax], al
0x1c0007f7b: add      byte ptr [rax], al
0x1c0007f7d: add      byte ptr [rax], al
0x1c0007f7f: add      byte ptr [rax], al
0x1c0007f81: add      byte ptr [rax], al
0x1c0007f83: add      byte ptr [rax], al
0x1c0007f85: add      byte ptr [rax], al
0x1c0007f87: add      byte ptr [rax], al
0x1c0007f89: add      byte ptr [rax], al
0x1c0007f8b: add      byte ptr [rax], al
0x1c0007f8d: add      byte ptr [rax], al
0x1c0007f8f: add      byte ptr [rax], al
0x1c0007f91: add      byte ptr [rax], al
0x1c0007f93: add      byte ptr [rax], al
0x1c0007f95: add      byte ptr [rax], al
0x1c0007f97: add      byte ptr [rax], al
0x1c0007f99: add      byte ptr [rax], al
0x1c0007f9b: add      byte ptr [rax], al
0x1c0007f9d: add      byte ptr [rax], al
0x1c0007f9f: add      byte ptr [rax], al
0x1c0007fa1: add      byte ptr [rax], al
0x1c0007fa3: add      byte ptr [rax], al
0x1c0007fa5: add      byte ptr [rax], al
0x1c0007fa7: add      byte ptr [rax], al
0x1c0007fa9: add      byte ptr [rax], al
0x1c0007fab: add      byte ptr [rax], al
0x1c0007fad: add      byte ptr [rax], al
0x1c0007faf: add      byte ptr [rax], al
0x1c0007fb1: add      byte ptr [rax], al
0x1c0007fb3: add      byte ptr [rax], al
0x1c0007fb5: add      byte ptr [rax], al
0x1c0007fb7: add      byte ptr [rax], al
0x1c0007fb9: add      byte ptr [rax], al
0x1c0007fbb: add      byte ptr [rax], al
0x1c0007fbd: add      byte ptr [rax], al
0x1c0007fbf: add      byte ptr [rax], al
0x1c0007fc1: add      byte ptr [rax], al
0x1c0007fc3: add      byte ptr [rax], al
0x1c0007fc5: add      byte ptr [rax], al
0x1c0007fc7: add      byte ptr [rax], al
0x1c0007fc9: add      byte ptr [rax], al
0x1c0007fcb: add      byte ptr [rax], al
0x1c0007fcd: add      byte ptr [rax], al
0x1c0007fcf: add      byte ptr [rax], al
0x1c0007fd1: add      byte ptr [rax], al
0x1c0007fd3: add      byte ptr [rax], al
0x1c0007fd5: add      byte ptr [rax], al
0x1c0007fd7: add      byte ptr [rax], al
0x1c0007fd9: add      byte ptr [rax], al
0x1c0007fdb: add      byte ptr [rax], al
0x1c0007fdd: add      byte ptr [rax], al
0x1c0007fdf: add      byte ptr [rax], al
0x1c0007fe1: add      byte ptr [rax], al
0x1c0007fe3: add      byte ptr [rax], al
0x1c0007fe5: add      byte ptr [rax], al
0x1c0007fe7: add      byte ptr [rax], al
0x1c0007fe9: add      byte ptr [rax], al
0x1c0007feb: add      byte ptr [rax], al
0x1c0007fed: add      byte ptr [rax], al
0x1c0007fef: add      byte ptr [rax], al
0x1c0007ff1: add      byte ptr [rax], al
0x1c0007ff3: add      byte ptr [rax], al
0x1c0007ff5: add      byte ptr [rax], al
0x1c0007ff7: add      byte ptr [rax], al
0x1c0007ff9: add      byte ptr [rax], al
0x1c0007ffb: add      byte ptr [rax], al
0x1c0007ffd: add      byte ptr [rax], al
```

### Section: INIT (VA=0x1c0008000, 2003 instructions)
```asm
0x1c0008000: int3     
0x1c0008001: int3     
0x1c0008002: int3     
0x1c0008003: int3     
0x1c0008004: int3     
0x1c0008005: int3     
0x1c0008006: int3     
0x1c0008007: int3     
0x1c0008008: int3     
0x1c0008009: int3     
0x1c000800a: int3     
0x1c000800b: int3     
0x1c000800c: int3     
0x1c000800d: int3     
0x1c000800e: int3     
0x1c000800f: int3     
0x1c0008010: mov      qword ptr [rsp + 8], rbx
0x1c0008015: push     rdi
0x1c0008016: sub      rsp, 0x20
0x1c000801a: mov      rbx, rdx
0x1c000801d: mov      rdi, rcx
0x1c0008020: call     0x1c0008044
0x1c0008025: mov      rdx, rbx
0x1c0008028: mov      rcx, rdi
0x1c000802b: call     0x1c0008078
0x1c0008030: mov      rbx, qword ptr [rsp + 0x30]
0x1c0008035: add      rsp, 0x20
0x1c0008039: pop      rdi
0x1c000803a: ret      
0x1c000803b: int3     
0x1c000803c: int3     
0x1c000803d: int3     
0x1c000803e: int3     
0x1c000803f: int3     
0x1c0008040: int3     
0x1c0008041: int3     
0x1c0008042: int3     
0x1c0008043: int3     
0x1c0008044: mov      rax, qword ptr [rip - 0x504b]
0x1c000804b: test     rax, rax
0x1c000804e: je       0x1c000806b
0x1c0008050: movabs   rcx, 0x2b992ddfa232
0x1c000805a: cmp      rax, rcx
0x1c000805d: je       0x1c000806b
0x1c000805f: not      rax
0x1c0008062: mov      qword ptr [rip - 0x5061], rax
0x1c0008069: ret      
0x1c000806a: int3     
0x1c000806b: mov      ecx, 6
0x1c0008070: int      0x29
0x1c0008072: int3     
0x1c0008073: int3     
0x1c0008074: int3     
0x1c0008075: int3     
0x1c0008076: int3     
0x1c0008077: int3     
0x1c0008078: push     rbx
0x1c000807a: sub      rsp, 0x20
0x1c000807e: mov      rax, qword ptr [rip - 0x307d]  ; -> KsDefaultDispatchPnp
0x1c0008085: mov      rbx, rcx
0x1c0008088: mov      qword ptr [rcx + 0x148], rax
0x1c000808f: xor      edx, edx
0x1c0008091: mov      rax, qword ptr [rip - 0x3070]  ; -> KsDefaultDispatchPower
0x1c0008098: mov      qword ptr [rcx + 0x120], rax
0x1c000809f: mov      rax, qword ptr [rip - 0x3086]  ; -> KsDefaultForwardIrp
0x1c00080a6: mov      qword ptr [rcx + 0x128], rax
0x1c00080ad: mov      rax, qword ptr [rcx + 0x30]
0x1c00080b1: lea      rcx, [rip - 0xde8]
0x1c00080b8: mov      qword ptr [rax + 8], rcx
0x1c00080bc: mov      rcx, rbx
0x1c00080bf: mov      rax, qword ptr [rip - 0x30ae]  ; -> KsNullDriverUnload
0x1c00080c6: mov      qword ptr [rbx + 0x68], rax
0x1c00080ca: call     qword ptr [rip - 0x30c1]  ; -> KsSetMajorFunctionHandler
0x1c00080d1: nop      dword ptr [rax + rax]
0x1c00080d6: mov      edx, 2
0x1c00080db: mov      rcx, rbx
0x1c00080de: call     qword ptr [rip - 0x30d5]  ; -> KsSetMajorFunctionHandler
0x1c00080e5: nop      dword ptr [rax + rax]
0x1c00080ea: mov      edx, 0xe
0x1c00080ef: mov      rcx, rbx
0x1c00080f2: call     qword ptr [rip - 0x30e9]  ; -> KsSetMajorFunctionHandler
0x1c00080f9: nop      dword ptr [rax + rax]
0x1c00080fe: xor      eax, eax
0x1c0008100: add      rsp, 0x20
0x1c0008104: pop      rbx
0x1c0008105: ret      
0x1c0008106: int3     
0x1c0008107: add      byte ptr [rax], al
0x1c0008109: add      byte ptr [rax], al
0x1c000810b: add      byte ptr [rax], al
0x1c000810d: add      byte ptr [rax], al
0x1c000810f: add      byte ptr [rax], al
0x1c0008111: add      byte ptr [rax], al
0x1c0008113: add      byte ptr [rax], al
0x1c0008115: add      byte ptr [rax], al
0x1c0008117: add      byte ptr [rax], al
0x1c0008119: add      byte ptr [rax], al
0x1c000811b: add      byte ptr [rax], al
0x1c000811d: add      byte ptr [rax], al
0x1c000811f: add      byte ptr [rax], al
0x1c0008121: add      byte ptr [rax], al
0x1c0008123: add      byte ptr [rax], al
0x1c0008125: add      byte ptr [rax], al
0x1c0008127: add      byte ptr [rax], al
0x1c0008129: add      byte ptr [rax], al
0x1c000812b: add      byte ptr [rax], al
0x1c000812d: add      byte ptr [rax], al
0x1c000812f: add      byte ptr [rax], al
0x1c0008131: add      byte ptr [rax], al
0x1c0008133: add      byte ptr [rax], al
0x1c0008135: add      byte ptr [rax], al
0x1c0008137: add      byte ptr [rax], al
0x1c0008139: add      byte ptr [rax], al
0x1c000813b: add      byte ptr [rax], al
0x1c000813d: add      byte ptr [rax], al
0x1c000813f: add      byte ptr [rax], al
0x1c0008141: add      byte ptr [rax], al
0x1c0008143: add      byte ptr [rax], al
0x1c0008145: add      byte ptr [rax], al
0x1c0008147: add      byte ptr [rax], al
0x1c0008149: add      byte ptr [rax], al
0x1c000814b: add      byte ptr [rax], al
0x1c000814d: add      byte ptr [rax], al
0x1c000814f: add      byte ptr [rax], al
0x1c0008151: add      byte ptr [rax], al
0x1c0008153: add      byte ptr [rax], al
0x1c0008155: add      byte ptr [rax], al
0x1c0008157: add      byte ptr [rax], al
0x1c0008159: add      byte ptr [rax], al
0x1c000815b: add      byte ptr [rax], al
0x1c000815d: add      byte ptr [rax], al
0x1c000815f: add      byte ptr [rax], al
0x1c0008161: add      byte ptr [rax], al
0x1c0008163: add      byte ptr [rax], al
0x1c0008165: add      byte ptr [rax], al
0x1c0008167: add      byte ptr [rax], al
0x1c0008169: add      byte ptr [rax], al
0x1c000816b: add      byte ptr [rax], al
0x1c000816d: add      byte ptr [rax], al
0x1c000816f: add      byte ptr [rax], al
0x1c0008171: add      byte ptr [rax], al
0x1c0008173: add      byte ptr [rax], al
0x1c0008175: add      byte ptr [rax], al
0x1c0008177: add      byte ptr [rax], al
0x1c0008179: add      byte ptr [rax], al
0x1c000817b: add      byte ptr [rax], al
0x1c000817d: add      byte ptr [rax], al
0x1c000817f: add      byte ptr [rax], al
0x1c0008181: add      byte ptr [rax], al
0x1c0008183: add      byte ptr [rax], al
0x1c0008185: add      byte ptr [rax], al
0x1c0008187: add      byte ptr [rax], al
0x1c0008189: add      byte ptr [rax], al
0x1c000818b: add      byte ptr [rax], al
0x1c000818d: add      byte ptr [rax], al
0x1c000818f: add      byte ptr [rax], al
0x1c0008191: add      byte ptr [rax], al
0x1c0008193: add      byte ptr [rax], al
0x1c0008195: add      byte ptr [rax], al
0x1c0008197: add      byte ptr [rax], al
0x1c0008199: add      byte ptr [rax], al
0x1c000819b: add      byte ptr [rax], al
0x1c000819d: add      byte ptr [rax], al
0x1c000819f: add      byte ptr [rax], al
0x1c00081a1: add      byte ptr [rax], al
0x1c00081a3: add      byte ptr [rax], al
0x1c00081a5: add      byte ptr [rax], al
0x1c00081a7: add      byte ptr [rax], al
0x1c00081a9: add      byte ptr [rax], al
0x1c00081ab: add      byte ptr [rax], al
0x1c00081ad: add      byte ptr [rax], al
0x1c00081af: add      byte ptr [rax], al
0x1c00081b1: add      byte ptr [rax], al
0x1c00081b3: add      byte ptr [rax], al
0x1c00081b5: add      byte ptr [rax], al
0x1c00081b7: add      byte ptr [rax], al
0x1c00081b9: add      byte ptr [rax], al
0x1c00081bb: add      byte ptr [rax], al
0x1c00081bd: add      byte ptr [rax], al
0x1c00081bf: add      byte ptr [rax], al
0x1c00081c1: add      byte ptr [rax], al
0x1c00081c3: add      byte ptr [rax], al
0x1c00081c5: add      byte ptr [rax], al
0x1c00081c7: add      byte ptr [rax], al
0x1c00081c9: add      byte ptr [rax], al
0x1c00081cb: add      byte ptr [rax], al
0x1c00081cd: add      byte ptr [rax], al
0x1c00081cf: add      byte ptr [rax], al
0x1c00081d1: add      byte ptr [rax], al
0x1c00081d3: add      byte ptr [rax], al
0x1c00081d5: add      byte ptr [rax], al
0x1c00081d7: add      byte ptr [rax], al
0x1c00081d9: add      byte ptr [rax], al
0x1c00081db: add      byte ptr [rax], al
0x1c00081dd: add      byte ptr [rax], al
0x1c00081df: add      byte ptr [rax], al
0x1c00081e1: add      byte ptr [rax], al
0x1c00081e3: add      byte ptr [rax], al
0x1c00081e5: add      byte ptr [rax], al
0x1c00081e7: add      byte ptr [rax], al
0x1c00081e9: add      byte ptr [rax], al
0x1c00081eb: add      byte ptr [rax], al
0x1c00081ed: add      byte ptr [rax], al
0x1c00081ef: add      byte ptr [rax], al
0x1c00081f1: add      byte ptr [rax], al
0x1c00081f3: add      byte ptr [rax], al
0x1c00081f5: add      byte ptr [rax], al
0x1c00081f7: add      byte ptr [rax], al
0x1c00081f9: add      byte ptr [rax], al
0x1c00081fb: add      byte ptr [rax], al
0x1c00081fd: add      byte ptr [rax], al
0x1c00081ff: add      byte ptr [rax], al
0x1c0008201: add      byte ptr [rax], al
0x1c0008203: add      byte ptr [rax], al
0x1c0008205: add      byte ptr [rax], al
0x1c0008207: add      byte ptr [rax], al
0x1c0008209: add      byte ptr [rax], al
0x1c000820b: add      byte ptr [rax], al
0x1c000820d: add      byte ptr [rax], al
0x1c000820f: add      byte ptr [rax], al
0x1c0008211: add      byte ptr [rax], al
0x1c0008213: add      byte ptr [rax], al
0x1c0008215: add      byte ptr [rax], al
0x1c0008217: add      byte ptr [rax], al
0x1c0008219: add      byte ptr [rax], al
0x1c000821b: add      byte ptr [rax], al
0x1c000821d: add      byte ptr [rax], al
0x1c000821f: add      byte ptr [rax], al
0x1c0008221: add      byte ptr [rax], al
0x1c0008223: add      byte ptr [rax], al
0x1c0008225: add      byte ptr [rax], al
0x1c0008227: add      byte ptr [rax], al
0x1c0008229: add      byte ptr [rax], al
0x1c000822b: add      byte ptr [rax], al
0x1c000822d: add      byte ptr [rax], al
0x1c000822f: add      byte ptr [rax], al
0x1c0008231: add      byte ptr [rax], al
0x1c0008233: add      byte ptr [rax], al
0x1c0008235: add      byte ptr [rax], al
0x1c0008237: add      byte ptr [rax], al
0x1c0008239: add      byte ptr [rax], al
0x1c000823b: add      byte ptr [rax], al
0x1c000823d: add      byte ptr [rax], al
0x1c000823f: add      byte ptr [rax], al
0x1c0008241: add      byte ptr [rax], al
0x1c0008243: add      byte ptr [rax], al
0x1c0008245: add      byte ptr [rax], al
0x1c0008247: add      byte ptr [rax], al
0x1c0008249: add      byte ptr [rax], al
0x1c000824b: add      byte ptr [rax], al
0x1c000824d: add      byte ptr [rax], al
0x1c000824f: add      byte ptr [rax], al
0x1c0008251: add      byte ptr [rax], al
0x1c0008253: add      byte ptr [rax], al
0x1c0008255: add      byte ptr [rax], al
0x1c0008257: add      byte ptr [rax], al
0x1c0008259: add      byte ptr [rax], al
0x1c000825b: add      byte ptr [rax], al
0x1c000825d: add      byte ptr [rax], al
0x1c000825f: add      byte ptr [rax], al
0x1c0008261: add      byte ptr [rax], al
0x1c0008263: add      byte ptr [rax], al
0x1c0008265: add      byte ptr [rax], al
0x1c0008267: add      byte ptr [rax], al
0x1c0008269: add      byte ptr [rax], al
0x1c000826b: add      byte ptr [rax], al
0x1c000826d: add      byte ptr [rax], al
0x1c000826f: add      byte ptr [rax], al
0x1c0008271: add      byte ptr [rax], al
0x1c0008273: add      byte ptr [rax], al
0x1c0008275: add      byte ptr [rax], al
0x1c0008277: add      byte ptr [rax], al
0x1c0008279: add      byte ptr [rax], al
0x1c000827b: add      byte ptr [rax], al
0x1c000827d: add      byte ptr [rax], al
0x1c000827f: add      byte ptr [rax], al
0x1c0008281: add      byte ptr [rax], al
0x1c0008283: add      byte ptr [rax], al
0x1c0008285: add      byte ptr [rax], al
0x1c0008287: add      byte ptr [rax], al
0x1c0008289: add      byte ptr [rax], al
0x1c000828b: add      byte ptr [rax], al
0x1c000828d: add      byte ptr [rax], al
0x1c000828f: add      byte ptr [rax], al
0x1c0008291: add      byte ptr [rax], al
0x1c0008293: add      byte ptr [rax], al
0x1c0008295: add      byte ptr [rax], al
0x1c0008297: add      byte ptr [rax], al
0x1c0008299: add      byte ptr [rax], al
0x1c000829b: add      byte ptr [rax], al
0x1c000829d: add      byte ptr [rax], al
0x1c000829f: add      byte ptr [rax], al
0x1c00082a1: add      byte ptr [rax], al
0x1c00082a3: add      byte ptr [rax], al
0x1c00082a5: add      byte ptr [rax], al
0x1c00082a7: add      byte ptr [rax], al
0x1c00082a9: add      byte ptr [rax], al
0x1c00082ab: add      byte ptr [rax], al
0x1c00082ad: add      byte ptr [rax], al
0x1c00082af: add      byte ptr [rax], al
0x1c00082b1: add      byte ptr [rax], al
0x1c00082b3: add      byte ptr [rax], al
0x1c00082b5: add      byte ptr [rax], al
0x1c00082b7: add      byte ptr [rax], al
0x1c00082b9: add      byte ptr [rax], al
0x1c00082bb: add      byte ptr [rax], al
0x1c00082bd: add      byte ptr [rax], al
0x1c00082bf: add      byte ptr [rax], al
0x1c00082c1: add      byte ptr [rax], al
0x1c00082c3: add      byte ptr [rax], al
0x1c00082c5: add      byte ptr [rax], al
0x1c00082c7: add      byte ptr [rax], al
0x1c00082c9: add      byte ptr [rax], al
0x1c00082cb: add      byte ptr [rax], al
0x1c00082cd: add      byte ptr [rax], al
0x1c00082cf: add      byte ptr [rax], al
0x1c00082d1: add      byte ptr [rax], al
0x1c00082d3: add      byte ptr [rax], al
0x1c00082d5: add      byte ptr [rax], al
0x1c00082d7: add      byte ptr [rax], al
0x1c00082d9: add      byte ptr [rax], al
0x1c00082db: add      byte ptr [rax], al
0x1c00082dd: add      byte ptr [rax], al
0x1c00082df: add      byte ptr [rax], al
0x1c00082e1: add      byte ptr [rax], al
0x1c00082e3: add      byte ptr [rax], al
0x1c00082e5: add      byte ptr [rax], al
0x1c00082e7: add      byte ptr [rax], al
0x1c00082e9: add      byte ptr [rax], al
0x1c00082eb: add      byte ptr [rax], al
0x1c00082ed: add      byte ptr [rax], al
0x1c00082ef: add      byte ptr [rax], al
0x1c00082f1: add      byte ptr [rax], al
0x1c00082f3: add      byte ptr [rax], al
0x1c00082f5: add      byte ptr [rax], al
0x1c00082f7: add      byte ptr [rax], al
0x1c00082f9: add      byte ptr [rax], al
0x1c00082fb: add      byte ptr [rax], al
0x1c00082fd: add      byte ptr [rax], al
0x1c00082ff: add      byte ptr [rax], al
0x1c0008301: add      byte ptr [rax], al
0x1c0008303: add      byte ptr [rax], al
0x1c0008305: add      byte ptr [rax], al
0x1c0008307: add      byte ptr [rax], al
0x1c0008309: add      byte ptr [rax], al
0x1c000830b: add      byte ptr [rax], al
0x1c000830d: add      byte ptr [rax], al
0x1c000830f: add      byte ptr [rax], al
0x1c0008311: add      byte ptr [rax], al
0x1c0008313: add      byte ptr [rax], al
0x1c0008315: add      byte ptr [rax], al
0x1c0008317: add      byte ptr [rax], al
0x1c0008319: add      byte ptr [rax], al
0x1c000831b: add      byte ptr [rax], al
0x1c000831d: add      byte ptr [rax], al
0x1c000831f: add      byte ptr [rax], al
0x1c0008321: add      byte ptr [rax], al
0x1c0008323: add      byte ptr [rax], al
0x1c0008325: add      byte ptr [rax], al
0x1c0008327: add      byte ptr [rax], al
0x1c0008329: add      byte ptr [rax], al
0x1c000832b: add      byte ptr [rax], al
0x1c000832d: add      byte ptr [rax], al
0x1c000832f: add      byte ptr [rax], al
0x1c0008331: add      byte ptr [rax], al
0x1c0008333: add      byte ptr [rax], al
0x1c0008335: add      byte ptr [rax], al
0x1c0008337: add      byte ptr [rax], al
0x1c0008339: add      byte ptr [rax], al
0x1c000833b: add      byte ptr [rax], al
0x1c000833d: add      byte ptr [rax], al
0x1c000833f: add      byte ptr [rax], al
0x1c0008341: add      byte ptr [rax], al
0x1c0008343: add      byte ptr [rax], al
0x1c0008345: add      byte ptr [rax], al
0x1c0008347: add      byte ptr [rax], al
0x1c0008349: add      byte ptr [rax], al
0x1c000834b: add      byte ptr [rax], al
0x1c000834d: add      byte ptr [rax], al
0x1c000834f: add      byte ptr [rax], al
0x1c0008351: add      byte ptr [rax], al
0x1c0008353: add      byte ptr [rax], al
0x1c0008355: add      byte ptr [rax], al
0x1c0008357: add      byte ptr [rax], al
0x1c0008359: add      byte ptr [rax], al
0x1c000835b: add      byte ptr [rax], al
0x1c000835d: add      byte ptr [rax], al
0x1c000835f: add      byte ptr [rax], al
0x1c0008361: add      byte ptr [rax], al
0x1c0008363: add      byte ptr [rax], al
0x1c0008365: add      byte ptr [rax], al
0x1c0008367: add      byte ptr [rax], al
0x1c0008369: add      byte ptr [rax], al
0x1c000836b: add      byte ptr [rax], al
0x1c000836d: add      byte ptr [rax], al
0x1c000836f: add      byte ptr [rax], al
0x1c0008371: add      byte ptr [rax], al
0x1c0008373: add      byte ptr [rax], al
0x1c0008375: add      byte ptr [rax], al
0x1c0008377: add      byte ptr [rax], al
0x1c0008379: add      byte ptr [rax], al
0x1c000837b: add      byte ptr [rax], al
0x1c000837d: add      byte ptr [rax], al
0x1c000837f: add      byte ptr [rax], al
0x1c0008381: add      byte ptr [rax], al
0x1c0008383: add      byte ptr [rax], al
0x1c0008385: add      byte ptr [rax], al
0x1c0008387: add      byte ptr [rax], al
0x1c0008389: add      byte ptr [rax], al
0x1c000838b: add      byte ptr [rax], al
0x1c000838d: add      byte ptr [rax], al
0x1c000838f: add      byte ptr [rax], al
0x1c0008391: add      byte ptr [rax], al
0x1c0008393: add      byte ptr [rax], al
0x1c0008395: add      byte ptr [rax], al
0x1c0008397: add      byte ptr [rax], al
0x1c0008399: add      byte ptr [rax], al
0x1c000839b: add      byte ptr [rax], al
0x1c000839d: add      byte ptr [rax], al
0x1c000839f: add      byte ptr [rax], al
0x1c00083a1: add      byte ptr [rax], al
0x1c00083a3: add      byte ptr [rax], al
0x1c00083a5: add      byte ptr [rax], al
0x1c00083a7: add      byte ptr [rax], al
0x1c00083a9: add      byte ptr [rax], al
0x1c00083ab: add      byte ptr [rax], al
0x1c00083ad: add      byte ptr [rax], al
0x1c00083af: add      byte ptr [rax], al
0x1c00083b1: add      byte ptr [rax], al
0x1c00083b3: add      byte ptr [rax], al
0x1c00083b5: add      byte ptr [rax], al
0x1c00083b7: add      byte ptr [rax], al
0x1c00083b9: add      byte ptr [rax], al
0x1c00083bb: add      byte ptr [rax], al
0x1c00083bd: add      byte ptr [rax], al
0x1c00083bf: add      byte ptr [rax], al
0x1c00083c1: add      byte ptr [rax], al
0x1c00083c3: add      byte ptr [rax], al
0x1c00083c5: add      byte ptr [rax], al
0x1c00083c7: add      byte ptr [rax], al
0x1c00083c9: add      byte ptr [rax], al
0x1c00083cb: add      byte ptr [rax], al
0x1c00083cd: add      byte ptr [rax], al
0x1c00083cf: add      byte ptr [rax], al
0x1c00083d1: add      byte ptr [rax], al
0x1c00083d3: add      byte ptr [rax], al
0x1c00083d5: add      byte ptr [rax], al
0x1c00083d7: add      byte ptr [rax], al
0x1c00083d9: add      byte ptr [rax], al
0x1c00083db: add      byte ptr [rax], al
0x1c00083dd: add      byte ptr [rax], al
0x1c00083df: add      byte ptr [rax], al
0x1c00083e1: add      byte ptr [rax], al
0x1c00083e3: add      byte ptr [rax], al
0x1c00083e5: add      byte ptr [rax], al
0x1c00083e7: add      byte ptr [rax], al
0x1c00083e9: add      byte ptr [rax], al
0x1c00083eb: add      byte ptr [rax], al
0x1c00083ed: add      byte ptr [rax], al
0x1c00083ef: add      byte ptr [rax], al
0x1c00083f1: add      byte ptr [rax], al
0x1c00083f3: add      byte ptr [rax], al
0x1c00083f5: add      byte ptr [rax], al
0x1c00083f7: add      byte ptr [rax], al
0x1c00083f9: add      byte ptr [rax], al
0x1c00083fb: add      byte ptr [rax], al
0x1c00083fd: add      byte ptr [rax], al
0x1c00083ff: add      byte ptr [rax], al
0x1c0008401: add      byte ptr [rax], al
0x1c0008403: add      byte ptr [rax], al
0x1c0008405: add      byte ptr [rax], al
0x1c0008407: add      byte ptr [rax], al
0x1c0008409: add      byte ptr [rax], al
0x1c000840b: add      byte ptr [rax], al
0x1c000840d: add      byte ptr [rax], al
0x1c000840f: add      byte ptr [rax], al
0x1c0008411: add      byte ptr [rax], al
0x1c0008413: add      byte ptr [rax], al
0x1c0008415: add      byte ptr [rax], al
0x1c0008417: add      byte ptr [rax], al
0x1c0008419: add      byte ptr [rax], al
0x1c000841b: add      byte ptr [rax], al
0x1c000841d: add      byte ptr [rax], al
0x1c000841f: add      byte ptr [rax], al
0x1c0008421: add      byte ptr [rax], al
0x1c0008423: add      byte ptr [rax], al
0x1c0008425: add      byte ptr [rax], al
0x1c0008427: add      byte ptr [rax], al
0x1c0008429: add      byte ptr [rax], al
0x1c000842b: add      byte ptr [rax], al
0x1c000842d: add      byte ptr [rax], al
0x1c000842f: add      byte ptr [rax], al
0x1c0008431: add      byte ptr [rax], al
0x1c0008433: add      byte ptr [rax], al
0x1c0008435: add      byte ptr [rax], al
0x1c0008437: add      byte ptr [rax], al
0x1c0008439: add      byte ptr [rax], al
0x1c000843b: add      byte ptr [rax], al
0x1c000843d: add      byte ptr [rax], al
0x1c000843f: add      byte ptr [rax], al
0x1c0008441: add      byte ptr [rax], al
0x1c0008443: add      byte ptr [rax], al
0x1c0008445: add      byte ptr [rax], al
0x1c0008447: add      byte ptr [rax], al
0x1c0008449: add      byte ptr [rax], al
0x1c000844b: add      byte ptr [rax], al
0x1c000844d: add      byte ptr [rax], al
0x1c000844f: add      byte ptr [rax], al
0x1c0008451: add      byte ptr [rax], al
0x1c0008453: add      byte ptr [rax], al
0x1c0008455: add      byte ptr [rax], al
0x1c0008457: add      byte ptr [rax], al
0x1c0008459: add      byte ptr [rax], al
0x1c000845b: add      byte ptr [rax], al
0x1c000845d: add      byte ptr [rax], al
0x1c000845f: add      byte ptr [rax], al
0x1c0008461: add      byte ptr [rax], al
0x1c0008463: add      byte ptr [rax], al
0x1c0008465: add      byte ptr [rax], al
0x1c0008467: add      byte ptr [rax], al
0x1c0008469: add      byte ptr [rax], al
0x1c000846b: add      byte ptr [rax], al
0x1c000846d: add      byte ptr [rax], al
0x1c000846f: add      byte ptr [rax], al
0x1c0008471: add      byte ptr [rax], al
0x1c0008473: add      byte ptr [rax], al
0x1c0008475: add      byte ptr [rax], al
0x1c0008477: add      byte ptr [rax], al
0x1c0008479: add      byte ptr [rax], al
0x1c000847b: add      byte ptr [rax], al
0x1c000847d: add      byte ptr [rax], al
0x1c000847f: add      byte ptr [rax], al
0x1c0008481: add      byte ptr [rax], al
0x1c0008483: add      byte ptr [rax], al
0x1c0008485: add      byte ptr [rax], al
0x1c0008487: add      byte ptr [rax], al
0x1c0008489: add      byte ptr [rax], al
0x1c000848b: add      byte ptr [rax], al
0x1c000848d: add      byte ptr [rax], al
0x1c000848f: add      byte ptr [rax], al
0x1c0008491: add      byte ptr [rax], al
0x1c0008493: add      byte ptr [rax], al
0x1c0008495: add      byte ptr [rax], al
0x1c0008497: add      byte ptr [rax], al
0x1c0008499: add      byte ptr [rax], al
0x1c000849b: add      byte ptr [rax], al
0x1c000849d: add      byte ptr [rax], al
0x1c000849f: add      byte ptr [rax], al
0x1c00084a1: add      byte ptr [rax], al
0x1c00084a3: add      byte ptr [rax], al
0x1c00084a5: add      byte ptr [rax], al
0x1c00084a7: add      byte ptr [rax], al
0x1c00084a9: add      byte ptr [rax], al
0x1c00084ab: add      byte ptr [rax], al
0x1c00084ad: add      byte ptr [rax], al
0x1c00084af: add      byte ptr [rax], al
0x1c00084b1: add      byte ptr [rax], al
0x1c00084b3: add      byte ptr [rax], al
0x1c00084b5: add      byte ptr [rax], al
0x1c00084b7: add      byte ptr [rax], al
0x1c00084b9: add      byte ptr [rax], al
0x1c00084bb: add      byte ptr [rax], al
0x1c00084bd: add      byte ptr [rax], al
0x1c00084bf: add      byte ptr [rax], al
0x1c00084c1: add      byte ptr [rax], al
0x1c00084c3: add      byte ptr [rax], al
0x1c00084c5: add      byte ptr [rax], al
0x1c00084c7: add      byte ptr [rax], al
0x1c00084c9: add      byte ptr [rax], al
0x1c00084cb: add      byte ptr [rax], al
0x1c00084cd: add      byte ptr [rax], al
0x1c00084cf: add      byte ptr [rax], al
0x1c00084d1: add      byte ptr [rax], al
0x1c00084d3: add      byte ptr [rax], al
0x1c00084d5: add      byte ptr [rax], al
0x1c00084d7: add      byte ptr [rax], al
0x1c00084d9: add      byte ptr [rax], al
0x1c00084db: add      byte ptr [rax], al
0x1c00084dd: add      byte ptr [rax], al
0x1c00084df: add      byte ptr [rax], al
0x1c00084e1: add      byte ptr [rax], al
0x1c00084e3: add      byte ptr [rax], al
0x1c00084e5: add      byte ptr [rax], al
0x1c00084e7: add      byte ptr [rax], al
0x1c00084e9: add      byte ptr [rax], al
0x1c00084eb: add      byte ptr [rax], al
0x1c00084ed: add      byte ptr [rax], al
0x1c00084ef: add      byte ptr [rax], al
0x1c00084f1: add      byte ptr [rax], al
0x1c00084f3: add      byte ptr [rax], al
0x1c00084f5: add      byte ptr [rax], al
0x1c00084f7: add      byte ptr [rax], al
0x1c00084f9: add      byte ptr [rax], al
0x1c00084fb: add      byte ptr [rax], al
0x1c00084fd: add      byte ptr [rax], al
0x1c00084ff: add      byte ptr [rax], al
0x1c0008501: add      byte ptr [rax], al
0x1c0008503: add      byte ptr [rax], al
0x1c0008505: add      byte ptr [rax], al
0x1c0008507: add      byte ptr [rax], al
0x1c0008509: add      byte ptr [rax], al
0x1c000850b: add      byte ptr [rax], al
0x1c000850d: add      byte ptr [rax], al
0x1c000850f: add      byte ptr [rax], al
0x1c0008511: add      byte ptr [rax], al
0x1c0008513: add      byte ptr [rax], al
0x1c0008515: add      byte ptr [rax], al
0x1c0008517: add      byte ptr [rax], al
0x1c0008519: add      byte ptr [rax], al
0x1c000851b: add      byte ptr [rax], al
0x1c000851d: add      byte ptr [rax], al
0x1c000851f: add      byte ptr [rax], al
0x1c0008521: add      byte ptr [rax], al
0x1c0008523: add      byte ptr [rax], al
0x1c0008525: add      byte ptr [rax], al
0x1c0008527: add      byte ptr [rax], al
0x1c0008529: add      byte ptr [rax], al
0x1c000852b: add      byte ptr [rax], al
0x1c000852d: add      byte ptr [rax], al
0x1c000852f: add      byte ptr [rax], al
0x1c0008531: add      byte ptr [rax], al
0x1c0008533: add      byte ptr [rax], al
0x1c0008535: add      byte ptr [rax], al
0x1c0008537: add      byte ptr [rax], al
0x1c0008539: add      byte ptr [rax], al
0x1c000853b: add      byte ptr [rax], al
0x1c000853d: add      byte ptr [rax], al
0x1c000853f: add      byte ptr [rax], al
0x1c0008541: add      byte ptr [rax], al
0x1c0008543: add      byte ptr [rax], al
0x1c0008545: add      byte ptr [rax], al
0x1c0008547: add      byte ptr [rax], al
0x1c0008549: add      byte ptr [rax], al
0x1c000854b: add      byte ptr [rax], al
0x1c000854d: add      byte ptr [rax], al
0x1c000854f: add      byte ptr [rax], al
0x1c0008551: add      byte ptr [rax], al
0x1c0008553: add      byte ptr [rax], al
0x1c0008555: add      byte ptr [rax], al
0x1c0008557: add      byte ptr [rax], al
0x1c0008559: add      byte ptr [rax], al
0x1c000855b: add      byte ptr [rax], al
0x1c000855d: add      byte ptr [rax], al
0x1c000855f: add      byte ptr [rax], al
0x1c0008561: add      byte ptr [rax], al
0x1c0008563: add      byte ptr [rax], al
0x1c0008565: add      byte ptr [rax], al
0x1c0008567: add      byte ptr [rax], al
0x1c0008569: add      byte ptr [rax], al
0x1c000856b: add      byte ptr [rax], al
0x1c000856d: add      byte ptr [rax], al
0x1c000856f: add      byte ptr [rax], al
0x1c0008571: add      byte ptr [rax], al
0x1c0008573: add      byte ptr [rax], al
0x1c0008575: add      byte ptr [rax], al
0x1c0008577: add      byte ptr [rax], al
0x1c0008579: add      byte ptr [rax], al
0x1c000857b: add      byte ptr [rax], al
0x1c000857d: add      byte ptr [rax], al
0x1c000857f: add      byte ptr [rax], al
0x1c0008581: add      byte ptr [rax], al
0x1c0008583: add      byte ptr [rax], al
0x1c0008585: add      byte ptr [rax], al
0x1c0008587: add      byte ptr [rax], al
0x1c0008589: add      byte ptr [rax], al
0x1c000858b: add      byte ptr [rax], al
0x1c000858d: add      byte ptr [rax], al
0x1c000858f: add      byte ptr [rax], al
0x1c0008591: add      byte ptr [rax], al
0x1c0008593: add      byte ptr [rax], al
0x1c0008595: add      byte ptr [rax], al
0x1c0008597: add      byte ptr [rax], al
0x1c0008599: add      byte ptr [rax], al
0x1c000859b: add      byte ptr [rax], al
0x1c000859d: add      byte ptr [rax], al
0x1c000859f: add      byte ptr [rax], al
0x1c00085a1: add      byte ptr [rax], al
0x1c00085a3: add      byte ptr [rax], al
0x1c00085a5: add      byte ptr [rax], al
0x1c00085a7: add      byte ptr [rax], al
0x1c00085a9: add      byte ptr [rax], al
0x1c00085ab: add      byte ptr [rax], al
0x1c00085ad: add      byte ptr [rax], al
0x1c00085af: add      byte ptr [rax], al
0x1c00085b1: add      byte ptr [rax], al
0x1c00085b3: add      byte ptr [rax], al
0x1c00085b5: add      byte ptr [rax], al
0x1c00085b7: add      byte ptr [rax], al
0x1c00085b9: add      byte ptr [rax], al
0x1c00085bb: add      byte ptr [rax], al
0x1c00085bd: add      byte ptr [rax], al
0x1c00085bf: add      byte ptr [rax], al
0x1c00085c1: add      byte ptr [rax], al
0x1c00085c3: add      byte ptr [rax], al
0x1c00085c5: add      byte ptr [rax], al
0x1c00085c7: add      byte ptr [rax], al
0x1c00085c9: add      byte ptr [rax], al
0x1c00085cb: add      byte ptr [rax], al
0x1c00085cd: add      byte ptr [rax], al
0x1c00085cf: add      byte ptr [rax], al
0x1c00085d1: add      byte ptr [rax], al
0x1c00085d3: add      byte ptr [rax], al
0x1c00085d5: add      byte ptr [rax], al
0x1c00085d7: add      byte ptr [rax], al
0x1c00085d9: add      byte ptr [rax], al
0x1c00085db: add      byte ptr [rax], al
0x1c00085dd: add      byte ptr [rax], al
0x1c00085df: add      byte ptr [rax], al
0x1c00085e1: add      byte ptr [rax], al
0x1c00085e3: add      byte ptr [rax], al
0x1c00085e5: add      byte ptr [rax], al
0x1c00085e7: add      byte ptr [rax], al
0x1c00085e9: add      byte ptr [rax], al
0x1c00085eb: add      byte ptr [rax], al
0x1c00085ed: add      byte ptr [rax], al
0x1c00085ef: add      byte ptr [rax], al
0x1c00085f1: add      byte ptr [rax], al
0x1c00085f3: add      byte ptr [rax], al
0x1c00085f5: add      byte ptr [rax], al
0x1c00085f7: add      byte ptr [rax], al
0x1c00085f9: add      byte ptr [rax], al
0x1c00085fb: add      byte ptr [rax], al
0x1c00085fd: add      byte ptr [rax], al
0x1c00085ff: add      byte ptr [rax], al
0x1c0008601: add      byte ptr [rax], al
0x1c0008603: add      byte ptr [rax], al
0x1c0008605: add      byte ptr [rax], al
0x1c0008607: add      byte ptr [rax], al
0x1c0008609: add      byte ptr [rax], al
0x1c000860b: add      byte ptr [rax], al
0x1c000860d: add      byte ptr [rax], al
0x1c000860f: add      byte ptr [rax], al
0x1c0008611: add      byte ptr [rax], al
0x1c0008613: add      byte ptr [rax], al
0x1c0008615: add      byte ptr [rax], al
0x1c0008617: add      byte ptr [rax], al
0x1c0008619: add      byte ptr [rax], al
0x1c000861b: add      byte ptr [rax], al
0x1c000861d: add      byte ptr [rax], al
0x1c000861f: add      byte ptr [rax], al
0x1c0008621: add      byte ptr [rax], al
0x1c0008623: add      byte ptr [rax], al
0x1c0008625: add      byte ptr [rax], al
0x1c0008627: add      byte ptr [rax], al
0x1c0008629: add      byte ptr [rax], al
0x1c000862b: add      byte ptr [rax], al
0x1c000862d: add      byte ptr [rax], al
0x1c000862f: add      byte ptr [rax], al
0x1c0008631: add      byte ptr [rax], al
0x1c0008633: add      byte ptr [rax], al
0x1c0008635: add      byte ptr [rax], al
0x1c0008637: add      byte ptr [rax], al
0x1c0008639: add      byte ptr [rax], al
0x1c000863b: add      byte ptr [rax], al
0x1c000863d: add      byte ptr [rax], al
0x1c000863f: add      byte ptr [rax], al
0x1c0008641: add      byte ptr [rax], al
0x1c0008643: add      byte ptr [rax], al
0x1c0008645: add      byte ptr [rax], al
0x1c0008647: add      byte ptr [rax], al
0x1c0008649: add      byte ptr [rax], al
0x1c000864b: add      byte ptr [rax], al
0x1c000864d: add      byte ptr [rax], al
0x1c000864f: add      byte ptr [rax], al
0x1c0008651: add      byte ptr [rax], al
0x1c0008653: add      byte ptr [rax], al
0x1c0008655: add      byte ptr [rax], al
0x1c0008657: add      byte ptr [rax], al
0x1c0008659: add      byte ptr [rax], al
0x1c000865b: add      byte ptr [rax], al
0x1c000865d: add      byte ptr [rax], al
0x1c000865f: add      byte ptr [rax], al
0x1c0008661: add      byte ptr [rax], al
0x1c0008663: add      byte ptr [rax], al
0x1c0008665: add      byte ptr [rax], al
0x1c0008667: add      byte ptr [rax], al
0x1c0008669: add      byte ptr [rax], al
0x1c000866b: add      byte ptr [rax], al
0x1c000866d: add      byte ptr [rax], al
0x1c000866f: add      byte ptr [rax], al
0x1c0008671: add      byte ptr [rax], al
0x1c0008673: add      byte ptr [rax], al
0x1c0008675: add      byte ptr [rax], al
0x1c0008677: add      byte ptr [rax], al
0x1c0008679: add      byte ptr [rax], al
0x1c000867b: add      byte ptr [rax], al
0x1c000867d: add      byte ptr [rax], al
0x1c000867f: add      byte ptr [rax], al
0x1c0008681: add      byte ptr [rax], al
0x1c0008683: add      byte ptr [rax], al
0x1c0008685: add      byte ptr [rax], al
0x1c0008687: add      byte ptr [rax], al
0x1c0008689: add      byte ptr [rax], al
0x1c000868b: add      byte ptr [rax], al
0x1c000868d: add      byte ptr [rax], al
0x1c000868f: add      byte ptr [rax], al
0x1c0008691: add      byte ptr [rax], al
0x1c0008693: add      byte ptr [rax], al
0x1c0008695: add      byte ptr [rax], al
0x1c0008697: add      byte ptr [rax], al
0x1c0008699: add      byte ptr [rax], al
0x1c000869b: add      byte ptr [rax], al
0x1c000869d: add      byte ptr [rax], al
0x1c000869f: add      byte ptr [rax], al
0x1c00086a1: add      byte ptr [rax], al
0x1c00086a3: add      byte ptr [rax], al
0x1c00086a5: add      byte ptr [rax], al
0x1c00086a7: add      byte ptr [rax], al
0x1c00086a9: add      byte ptr [rax], al
0x1c00086ab: add      byte ptr [rax], al
0x1c00086ad: add      byte ptr [rax], al
0x1c00086af: add      byte ptr [rax], al
0x1c00086b1: add      byte ptr [rax], al
0x1c00086b3: add      byte ptr [rax], al
0x1c00086b5: add      byte ptr [rax], al
0x1c00086b7: add      byte ptr [rax], al
0x1c00086b9: add      byte ptr [rax], al
0x1c00086bb: add      byte ptr [rax], al
0x1c00086bd: add      byte ptr [rax], al
0x1c00086bf: add      byte ptr [rax], al
0x1c00086c1: add      byte ptr [rax], al
0x1c00086c3: add      byte ptr [rax], al
0x1c00086c5: add      byte ptr [rax], al
0x1c00086c7: add      byte ptr [rax], al
0x1c00086c9: add      byte ptr [rax], al
0x1c00086cb: add      byte ptr [rax], al
0x1c00086cd: add      byte ptr [rax], al
0x1c00086cf: add      byte ptr [rax], al
0x1c00086d1: add      byte ptr [rax], al
0x1c00086d3: add      byte ptr [rax], al
0x1c00086d5: add      byte ptr [rax], al
0x1c00086d7: add      byte ptr [rax], al
0x1c00086d9: add      byte ptr [rax], al
0x1c00086db: add      byte ptr [rax], al
0x1c00086dd: add      byte ptr [rax], al
0x1c00086df: add      byte ptr [rax], al
0x1c00086e1: add      byte ptr [rax], al
0x1c00086e3: add      byte ptr [rax], al
0x1c00086e5: add      byte ptr [rax], al
0x1c00086e7: add      byte ptr [rax], al
0x1c00086e9: add      byte ptr [rax], al
0x1c00086eb: add      byte ptr [rax], al
0x1c00086ed: add      byte ptr [rax], al
0x1c00086ef: add      byte ptr [rax], al
0x1c00086f1: add      byte ptr [rax], al
0x1c00086f3: add      byte ptr [rax], al
0x1c00086f5: add      byte ptr [rax], al
0x1c00086f7: add      byte ptr [rax], al
0x1c00086f9: add      byte ptr [rax], al
0x1c00086fb: add      byte ptr [rax], al
0x1c00086fd: add      byte ptr [rax], al
0x1c00086ff: add      byte ptr [rax], al
0x1c0008701: add      byte ptr [rax], al
0x1c0008703: add      byte ptr [rax], al
0x1c0008705: add      byte ptr [rax], al
0x1c0008707: add      byte ptr [rax], al
0x1c0008709: add      byte ptr [rax], al
0x1c000870b: add      byte ptr [rax], al
0x1c000870d: add      byte ptr [rax], al
0x1c000870f: add      byte ptr [rax], al
0x1c0008711: add      byte ptr [rax], al
0x1c0008713: add      byte ptr [rax], al
0x1c0008715: add      byte ptr [rax], al
0x1c0008717: add      byte ptr [rax], al
0x1c0008719: add      byte ptr [rax], al
0x1c000871b: add      byte ptr [rax], al
0x1c000871d: add      byte ptr [rax], al
0x1c000871f: add      byte ptr [rax], al
0x1c0008721: add      byte ptr [rax], al
0x1c0008723: add      byte ptr [rax], al
0x1c0008725: add      byte ptr [rax], al
0x1c0008727: add      byte ptr [rax], al
0x1c0008729: add      byte ptr [rax], al
0x1c000872b: add      byte ptr [rax], al
0x1c000872d: add      byte ptr [rax], al
0x1c000872f: add      byte ptr [rax], al
0x1c0008731: add      byte ptr [rax], al
0x1c0008733: add      byte ptr [rax], al
0x1c0008735: add      byte ptr [rax], al
0x1c0008737: add      byte ptr [rax], al
0x1c0008739: add      byte ptr [rax], al
0x1c000873b: add      byte ptr [rax], al
0x1c000873d: add      byte ptr [rax], al
0x1c000873f: add      byte ptr [rax], al
0x1c0008741: add      byte ptr [rax], al
0x1c0008743: add      byte ptr [rax], al
0x1c0008745: add      byte ptr [rax], al
0x1c0008747: add      byte ptr [rax], al
0x1c0008749: add      byte ptr [rax], al
0x1c000874b: add      byte ptr [rax], al
0x1c000874d: add      byte ptr [rax], al
0x1c000874f: add      byte ptr [rax], al
0x1c0008751: add      byte ptr [rax], al
0x1c0008753: add      byte ptr [rax], al
0x1c0008755: add      byte ptr [rax], al
0x1c0008757: add      byte ptr [rax], al
0x1c0008759: add      byte ptr [rax], al
0x1c000875b: add      byte ptr [rax], al
0x1c000875d: add      byte ptr [rax], al
0x1c000875f: add      byte ptr [rax], al
0x1c0008761: add      byte ptr [rax], al
0x1c0008763: add      byte ptr [rax], al
0x1c0008765: add      byte ptr [rax], al
0x1c0008767: add      byte ptr [rax], al
0x1c0008769: add      byte ptr [rax], al
0x1c000876b: add      byte ptr [rax], al
0x1c000876d: add      byte ptr [rax], al
0x1c000876f: add      byte ptr [rax], al
0x1c0008771: add      byte ptr [rax], al
0x1c0008773: add      byte ptr [rax], al
0x1c0008775: add      byte ptr [rax], al
0x1c0008777: add      byte ptr [rax], al
0x1c0008779: add      byte ptr [rax], al
0x1c000877b: add      byte ptr [rax], al
0x1c000877d: add      byte ptr [rax], al
0x1c000877f: add      byte ptr [rax], al
0x1c0008781: add      byte ptr [rax], al
0x1c0008783: add      byte ptr [rax], al
0x1c0008785: add      byte ptr [rax], al
0x1c0008787: add      byte ptr [rax], al
0x1c0008789: add      byte ptr [rax], al
0x1c000878b: add      byte ptr [rax], al
0x1c000878d: add      byte ptr [rax], al
0x1c000878f: add      byte ptr [rax], al
0x1c0008791: add      byte ptr [rax], al
0x1c0008793: add      byte ptr [rax], al
0x1c0008795: add      byte ptr [rax], al
0x1c0008797: add      byte ptr [rax], al
0x1c0008799: add      byte ptr [rax], al
0x1c000879b: add      byte ptr [rax], al
0x1c000879d: add      byte ptr [rax], al
0x1c000879f: add      byte ptr [rax], al
0x1c00087a1: add      byte ptr [rax], al
0x1c00087a3: add      byte ptr [rax], al
0x1c00087a5: add      byte ptr [rax], al
0x1c00087a7: add      byte ptr [rax], al
0x1c00087a9: add      byte ptr [rax], al
0x1c00087ab: add      byte ptr [rax], al
0x1c00087ad: add      byte ptr [rax], al
0x1c00087af: add      byte ptr [rax], al
0x1c00087b1: add      byte ptr [rax], al
0x1c00087b3: add      byte ptr [rax], al
0x1c00087b5: add      byte ptr [rax], al
0x1c00087b7: add      byte ptr [rax], al
0x1c00087b9: add      byte ptr [rax], al
0x1c00087bb: add      byte ptr [rax], al
0x1c00087bd: add      byte ptr [rax], al
0x1c00087bf: add      byte ptr [rax], al
0x1c00087c1: add      byte ptr [rax], al
0x1c00087c3: add      byte ptr [rax], al
0x1c00087c5: add      byte ptr [rax], al
0x1c00087c7: add      byte ptr [rax], al
0x1c00087c9: add      byte ptr [rax], al
0x1c00087cb: add      byte ptr [rax], al
0x1c00087cd: add      byte ptr [rax], al
0x1c00087cf: add      byte ptr [rax], al
0x1c00087d1: add      byte ptr [rax], al
0x1c00087d3: add      byte ptr [rax], al
0x1c00087d5: add      byte ptr [rax], al
0x1c00087d7: add      byte ptr [rax], al
0x1c00087d9: add      byte ptr [rax], al
0x1c00087db: add      byte ptr [rax], al
0x1c00087dd: add      byte ptr [rax], al
0x1c00087df: add      byte ptr [rax], al
0x1c00087e1: add      byte ptr [rax], al
0x1c00087e3: add      byte ptr [rax], al
0x1c00087e5: add      byte ptr [rax], al
0x1c00087e7: add      byte ptr [rax], al
0x1c00087e9: add      byte ptr [rax], al
0x1c00087eb: add      byte ptr [rax], al
0x1c00087ed: add      byte ptr [rax], al
0x1c00087ef: add      byte ptr [rax], al
0x1c00087f1: add      byte ptr [rax], al
0x1c00087f3: add      byte ptr [rax], al
0x1c00087f5: add      byte ptr [rax], al
0x1c00087f7: add      byte ptr [rax], al
0x1c00087f9: add      byte ptr [rax], al
0x1c00087fb: add      byte ptr [rax], al
0x1c00087fd: add      byte ptr [rax], al
0x1c00087ff: add      byte ptr [rax], al
0x1c0008801: add      byte ptr [rax], al
0x1c0008803: add      byte ptr [rax], al
0x1c0008805: add      byte ptr [rax], al
0x1c0008807: add      byte ptr [rax], al
0x1c0008809: add      byte ptr [rax], al
0x1c000880b: add      byte ptr [rax], al
0x1c000880d: add      byte ptr [rax], al
0x1c000880f: add      byte ptr [rax], al
0x1c0008811: add      byte ptr [rax], al
0x1c0008813: add      byte ptr [rax], al
0x1c0008815: add      byte ptr [rax], al
0x1c0008817: add      byte ptr [rax], al
0x1c0008819: add      byte ptr [rax], al
0x1c000881b: add      byte ptr [rax], al
0x1c000881d: add      byte ptr [rax], al
0x1c000881f: add      byte ptr [rax], al
0x1c0008821: add      byte ptr [rax], al
0x1c0008823: add      byte ptr [rax], al
0x1c0008825: add      byte ptr [rax], al
0x1c0008827: add      byte ptr [rax], al
0x1c0008829: add      byte ptr [rax], al
0x1c000882b: add      byte ptr [rax], al
0x1c000882d: add      byte ptr [rax], al
0x1c000882f: add      byte ptr [rax], al
0x1c0008831: add      byte ptr [rax], al
0x1c0008833: add      byte ptr [rax], al
0x1c0008835: add      byte ptr [rax], al
0x1c0008837: add      byte ptr [rax], al
0x1c0008839: add      byte ptr [rax], al
0x1c000883b: add      byte ptr [rax], al
0x1c000883d: add      byte ptr [rax], al
0x1c000883f: add      byte ptr [rax], al
0x1c0008841: add      byte ptr [rax], al
0x1c0008843: add      byte ptr [rax], al
0x1c0008845: add      byte ptr [rax], al
0x1c0008847: add      byte ptr [rax], al
0x1c0008849: add      byte ptr [rax], al
0x1c000884b: add      byte ptr [rax], al
0x1c000884d: add      byte ptr [rax], al
0x1c000884f: add      byte ptr [rax], al
0x1c0008851: add      byte ptr [rax], al
0x1c0008853: add      byte ptr [rax], al
0x1c0008855: add      byte ptr [rax], al
0x1c0008857: add      byte ptr [rax], al
0x1c0008859: add      byte ptr [rax], al
0x1c000885b: add      byte ptr [rax], al
0x1c000885d: add      byte ptr [rax], al
0x1c000885f: add      byte ptr [rax], al
0x1c0008861: add      byte ptr [rax], al
0x1c0008863: add      byte ptr [rax], al
0x1c0008865: add      byte ptr [rax], al
0x1c0008867: add      byte ptr [rax], al
0x1c0008869: add      byte ptr [rax], al
0x1c000886b: add      byte ptr [rax], al
0x1c000886d: add      byte ptr [rax], al
0x1c000886f: add      byte ptr [rax], al
0x1c0008871: add      byte ptr [rax], al
0x1c0008873: add      byte ptr [rax], al
0x1c0008875: add      byte ptr [rax], al
0x1c0008877: add      byte ptr [rax], al
0x1c0008879: add      byte ptr [rax], al
0x1c000887b: add      byte ptr [rax], al
0x1c000887d: add      byte ptr [rax], al
0x1c000887f: add      byte ptr [rax], al
0x1c0008881: add      byte ptr [rax], al
0x1c0008883: add      byte ptr [rax], al
0x1c0008885: add      byte ptr [rax], al
0x1c0008887: add      byte ptr [rax], al
0x1c0008889: add      byte ptr [rax], al
0x1c000888b: add      byte ptr [rax], al
0x1c000888d: add      byte ptr [rax], al
0x1c000888f: add      byte ptr [rax], al
0x1c0008891: add      byte ptr [rax], al
0x1c0008893: add      byte ptr [rax], al
0x1c0008895: add      byte ptr [rax], al
0x1c0008897: add      byte ptr [rax], al
0x1c0008899: add      byte ptr [rax], al
0x1c000889b: add      byte ptr [rax], al
0x1c000889d: add      byte ptr [rax], al
0x1c000889f: add      byte ptr [rax], al
0x1c00088a1: add      byte ptr [rax], al
0x1c00088a3: add      byte ptr [rax], al
0x1c00088a5: add      byte ptr [rax], al
0x1c00088a7: add      byte ptr [rax], al
0x1c00088a9: add      byte ptr [rax], al
0x1c00088ab: add      byte ptr [rax], al
0x1c00088ad: add      byte ptr [rax], al
0x1c00088af: add      byte ptr [rax], al
0x1c00088b1: add      byte ptr [rax], al
0x1c00088b3: add      byte ptr [rax], al
0x1c00088b5: add      byte ptr [rax], al
0x1c00088b7: add      byte ptr [rax], al
0x1c00088b9: add      byte ptr [rax], al
0x1c00088bb: add      byte ptr [rax], al
0x1c00088bd: add      byte ptr [rax], al
0x1c00088bf: add      byte ptr [rax], al
0x1c00088c1: add      byte ptr [rax], al
0x1c00088c3: add      byte ptr [rax], al
0x1c00088c5: add      byte ptr [rax], al
0x1c00088c7: add      byte ptr [rax], al
0x1c00088c9: add      byte ptr [rax], al
0x1c00088cb: add      byte ptr [rax], al
0x1c00088cd: add      byte ptr [rax], al
0x1c00088cf: add      byte ptr [rax], al
0x1c00088d1: add      byte ptr [rax], al
0x1c00088d3: add      byte ptr [rax], al
0x1c00088d5: add      byte ptr [rax], al
0x1c00088d7: add      byte ptr [rax], al
0x1c00088d9: add      byte ptr [rax], al
0x1c00088db: add      byte ptr [rax], al
0x1c00088dd: add      byte ptr [rax], al
0x1c00088df: add      byte ptr [rax], al
0x1c00088e1: add      byte ptr [rax], al
0x1c00088e3: add      byte ptr [rax], al
0x1c00088e5: add      byte ptr [rax], al
0x1c00088e7: add      byte ptr [rax], al
0x1c00088e9: add      byte ptr [rax], al
0x1c00088eb: add      byte ptr [rax], al
0x1c00088ed: add      byte ptr [rax], al
0x1c00088ef: add      byte ptr [rax], al
0x1c00088f1: add      byte ptr [rax], al
0x1c00088f3: add      byte ptr [rax], al
0x1c00088f5: add      byte ptr [rax], al
0x1c00088f7: add      byte ptr [rax], al
0x1c00088f9: add      byte ptr [rax], al
0x1c00088fb: add      byte ptr [rax], al
0x1c00088fd: add      byte ptr [rax], al
0x1c00088ff: add      byte ptr [rax], al
0x1c0008901: add      byte ptr [rax], al
0x1c0008903: add      byte ptr [rax], al
0x1c0008905: add      byte ptr [rax], al
0x1c0008907: add      byte ptr [rax], al
0x1c0008909: add      byte ptr [rax], al
0x1c000890b: add      byte ptr [rax], al
0x1c000890d: add      byte ptr [rax], al
0x1c000890f: add      byte ptr [rax], al
0x1c0008911: add      byte ptr [rax], al
0x1c0008913: add      byte ptr [rax], al
0x1c0008915: add      byte ptr [rax], al
0x1c0008917: add      byte ptr [rax], al
0x1c0008919: add      byte ptr [rax], al
0x1c000891b: add      byte ptr [rax], al
0x1c000891d: add      byte ptr [rax], al
0x1c000891f: add      byte ptr [rax], al
0x1c0008921: add      byte ptr [rax], al
0x1c0008923: add      byte ptr [rax], al
0x1c0008925: add      byte ptr [rax], al
0x1c0008927: add      byte ptr [rax], al
0x1c0008929: add      byte ptr [rax], al
0x1c000892b: add      byte ptr [rax], al
0x1c000892d: add      byte ptr [rax], al
0x1c000892f: add      byte ptr [rax], al
0x1c0008931: add      byte ptr [rax], al
0x1c0008933: add      byte ptr [rax], al
0x1c0008935: add      byte ptr [rax], al
0x1c0008937: add      byte ptr [rax], al
0x1c0008939: add      byte ptr [rax], al
0x1c000893b: add      byte ptr [rax], al
0x1c000893d: add      byte ptr [rax], al
0x1c000893f: add      byte ptr [rax], al
0x1c0008941: add      byte ptr [rax], al
0x1c0008943: add      byte ptr [rax], al
0x1c0008945: add      byte ptr [rax], al
0x1c0008947: add      byte ptr [rax], al
0x1c0008949: add      byte ptr [rax], al
0x1c000894b: add      byte ptr [rax], al
0x1c000894d: add      byte ptr [rax], al
0x1c000894f: add      byte ptr [rax], al
0x1c0008951: add      byte ptr [rax], al
0x1c0008953: add      byte ptr [rax], al
0x1c0008955: add      byte ptr [rax], al
0x1c0008957: add      byte ptr [rax], al
0x1c0008959: add      byte ptr [rax], al
0x1c000895b: add      byte ptr [rax], al
0x1c000895d: add      byte ptr [rax], al
0x1c000895f: add      byte ptr [rax], al
0x1c0008961: add      byte ptr [rax], al
0x1c0008963: add      byte ptr [rax], al
0x1c0008965: add      byte ptr [rax], al
0x1c0008967: add      byte ptr [rax], al
0x1c0008969: add      byte ptr [rax], al
0x1c000896b: add      byte ptr [rax], al
0x1c000896d: add      byte ptr [rax], al
0x1c000896f: add      byte ptr [rax], al
0x1c0008971: add      byte ptr [rax], al
0x1c0008973: add      byte ptr [rax], al
0x1c0008975: add      byte ptr [rax], al
0x1c0008977: add      byte ptr [rax], al
0x1c0008979: add      byte ptr [rax], al
0x1c000897b: add      byte ptr [rax], al
0x1c000897d: add      byte ptr [rax], al
0x1c000897f: add      byte ptr [rax], al
0x1c0008981: add      byte ptr [rax], al
0x1c0008983: add      byte ptr [rax], al
0x1c0008985: add      byte ptr [rax], al
0x1c0008987: add      byte ptr [rax], al
0x1c0008989: add      byte ptr [rax], al
0x1c000898b: add      byte ptr [rax], al
0x1c000898d: add      byte ptr [rax], al
0x1c000898f: add      byte ptr [rax], al
0x1c0008991: add      byte ptr [rax], al
0x1c0008993: add      byte ptr [rax], al
0x1c0008995: add      byte ptr [rax], al
0x1c0008997: add      byte ptr [rax], al
0x1c0008999: add      byte ptr [rax], al
0x1c000899b: add      byte ptr [rax], al
0x1c000899d: add      byte ptr [rax], al
0x1c000899f: add      byte ptr [rax], al
0x1c00089a1: add      byte ptr [rax], al
0x1c00089a3: add      byte ptr [rax], al
0x1c00089a5: add      byte ptr [rax], al
0x1c00089a7: add      byte ptr [rax], al
0x1c00089a9: add      byte ptr [rax], al
0x1c00089ab: add      byte ptr [rax], al
0x1c00089ad: add      byte ptr [rax], al
0x1c00089af: add      byte ptr [rax], al
0x1c00089b1: add      byte ptr [rax], al
0x1c00089b3: add      byte ptr [rax], al
0x1c00089b5: add      byte ptr [rax], al
0x1c00089b7: add      byte ptr [rax], al
0x1c00089b9: add      byte ptr [rax], al
0x1c00089bb: add      byte ptr [rax], al
0x1c00089bd: add      byte ptr [rax], al
0x1c00089bf: add      byte ptr [rax], al
0x1c00089c1: add      byte ptr [rax], al
0x1c00089c3: add      byte ptr [rax], al
0x1c00089c5: add      byte ptr [rax], al
0x1c00089c7: add      byte ptr [rax], al
0x1c00089c9: add      byte ptr [rax], al
0x1c00089cb: add      byte ptr [rax], al
0x1c00089cd: add      byte ptr [rax], al
0x1c00089cf: add      byte ptr [rax], al
0x1c00089d1: add      byte ptr [rax], al
0x1c00089d3: add      byte ptr [rax], al
0x1c00089d5: add      byte ptr [rax], al
0x1c00089d7: add      byte ptr [rax], al
0x1c00089d9: add      byte ptr [rax], al
0x1c00089db: add      byte ptr [rax], al
0x1c00089dd: add      byte ptr [rax], al
0x1c00089df: add      byte ptr [rax], al
0x1c00089e1: add      byte ptr [rax], al
0x1c00089e3: add      byte ptr [rax], al
0x1c00089e5: add      byte ptr [rax], al
0x1c00089e7: add      byte ptr [rax], al
0x1c00089e9: add      byte ptr [rax], al
0x1c00089eb: add      byte ptr [rax], al
0x1c00089ed: add      byte ptr [rax], al
0x1c00089ef: add      byte ptr [rax], al
0x1c00089f1: add      byte ptr [rax], al
0x1c00089f3: add      byte ptr [rax], al
0x1c00089f5: add      byte ptr [rax], al
0x1c00089f7: add      byte ptr [rax], al
0x1c00089f9: add      byte ptr [rax], al
0x1c00089fb: add      byte ptr [rax], al
0x1c00089fd: add      byte ptr [rax], al
0x1c00089ff: add      byte ptr [rax], al
0x1c0008a01: add      byte ptr [rax], al
0x1c0008a03: add      byte ptr [rax], al
0x1c0008a05: add      byte ptr [rax], al
0x1c0008a07: add      byte ptr [rax], al
0x1c0008a09: add      byte ptr [rax], al
0x1c0008a0b: add      byte ptr [rax], al
0x1c0008a0d: add      byte ptr [rax], al
0x1c0008a0f: add      byte ptr [rax], al
0x1c0008a11: add      byte ptr [rax], al
0x1c0008a13: add      byte ptr [rax], al
0x1c0008a15: add      byte ptr [rax], al
0x1c0008a17: add      byte ptr [rax], al
0x1c0008a19: add      byte ptr [rax], al
0x1c0008a1b: add      byte ptr [rax], al
0x1c0008a1d: add      byte ptr [rax], al
0x1c0008a1f: add      byte ptr [rax], al
0x1c0008a21: add      byte ptr [rax], al
0x1c0008a23: add      byte ptr [rax], al
0x1c0008a25: add      byte ptr [rax], al
0x1c0008a27: add      byte ptr [rax], al
0x1c0008a29: add      byte ptr [rax], al
0x1c0008a2b: add      byte ptr [rax], al
0x1c0008a2d: add      byte ptr [rax], al
0x1c0008a2f: add      byte ptr [rax], al
0x1c0008a31: add      byte ptr [rax], al
0x1c0008a33: add      byte ptr [rax], al
0x1c0008a35: add      byte ptr [rax], al
0x1c0008a37: add      byte ptr [rax], al
0x1c0008a39: add      byte ptr [rax], al
0x1c0008a3b: add      byte ptr [rax], al
0x1c0008a3d: add      byte ptr [rax], al
0x1c0008a3f: add      byte ptr [rax], al
0x1c0008a41: add      byte ptr [rax], al
0x1c0008a43: add      byte ptr [rax], al
0x1c0008a45: add      byte ptr [rax], al
0x1c0008a47: add      byte ptr [rax], al
0x1c0008a49: add      byte ptr [rax], al
0x1c0008a4b: add      byte ptr [rax], al
0x1c0008a4d: add      byte ptr [rax], al
0x1c0008a4f: add      byte ptr [rax], al
0x1c0008a51: add      byte ptr [rax], al
0x1c0008a53: add      byte ptr [rax], al
0x1c0008a55: add      byte ptr [rax], al
0x1c0008a57: add      byte ptr [rax], al
0x1c0008a59: add      byte ptr [rax], al
0x1c0008a5b: add      byte ptr [rax], al
0x1c0008a5d: add      byte ptr [rax], al
0x1c0008a5f: add      byte ptr [rax], al
0x1c0008a61: add      byte ptr [rax], al
0x1c0008a63: add      byte ptr [rax], al
0x1c0008a65: add      byte ptr [rax], al
0x1c0008a67: add      byte ptr [rax], al
0x1c0008a69: add      byte ptr [rax], al
0x1c0008a6b: add      byte ptr [rax], al
0x1c0008a6d: add      byte ptr [rax], al
0x1c0008a6f: add      byte ptr [rax], al
0x1c0008a71: add      byte ptr [rax], al
0x1c0008a73: add      byte ptr [rax], al
0x1c0008a75: add      byte ptr [rax], al
0x1c0008a77: add      byte ptr [rax], al
0x1c0008a79: add      byte ptr [rax], al
0x1c0008a7b: add      byte ptr [rax], al
0x1c0008a7d: add      byte ptr [rax], al
0x1c0008a7f: add      byte ptr [rax], al
0x1c0008a81: add      byte ptr [rax], al
0x1c0008a83: add      byte ptr [rax], al
0x1c0008a85: add      byte ptr [rax], al
0x1c0008a87: add      byte ptr [rax], al
0x1c0008a89: add      byte ptr [rax], al
0x1c0008a8b: add      byte ptr [rax], al
0x1c0008a8d: add      byte ptr [rax], al
0x1c0008a8f: add      byte ptr [rax], al
0x1c0008a91: add      byte ptr [rax], al
0x1c0008a93: add      byte ptr [rax], al
0x1c0008a95: add      byte ptr [rax], al
0x1c0008a97: add      byte ptr [rax], al
0x1c0008a99: add      byte ptr [rax], al
0x1c0008a9b: add      byte ptr [rax], al
0x1c0008a9d: add      byte ptr [rax], al
0x1c0008a9f: add      byte ptr [rax], al
0x1c0008aa1: add      byte ptr [rax], al
0x1c0008aa3: add      byte ptr [rax], al
0x1c0008aa5: add      byte ptr [rax], al
0x1c0008aa7: add      byte ptr [rax], al
0x1c0008aa9: add      byte ptr [rax], al
0x1c0008aab: add      byte ptr [rax], al
0x1c0008aad: add      byte ptr [rax], al
0x1c0008aaf: add      byte ptr [rax], al
0x1c0008ab1: add      byte ptr [rax], al
0x1c0008ab3: add      byte ptr [rax], al
0x1c0008ab5: add      byte ptr [rax], al
0x1c0008ab7: add      byte ptr [rax], al
0x1c0008ab9: add      byte ptr [rax], al
0x1c0008abb: add      byte ptr [rax], al
0x1c0008abd: add      byte ptr [rax], al
0x1c0008abf: add      byte ptr [rax], al
0x1c0008ac1: add      byte ptr [rax], al
0x1c0008ac3: add      byte ptr [rax], al
0x1c0008ac5: add      byte ptr [rax], al
0x1c0008ac7: add      byte ptr [rax], al
0x1c0008ac9: add      byte ptr [rax], al
0x1c0008acb: add      byte ptr [rax], al
0x1c0008acd: add      byte ptr [rax], al
0x1c0008acf: add      byte ptr [rax], al
0x1c0008ad1: add      byte ptr [rax], al
0x1c0008ad3: add      byte ptr [rax], al
0x1c0008ad5: add      byte ptr [rax], al
0x1c0008ad7: add      byte ptr [rax], al
0x1c0008ad9: add      byte ptr [rax], al
0x1c0008adb: add      byte ptr [rax], al
0x1c0008add: add      byte ptr [rax], al
0x1c0008adf: add      byte ptr [rax], al
0x1c0008ae1: add      byte ptr [rax], al
0x1c0008ae3: add      byte ptr [rax], al
0x1c0008ae5: add      byte ptr [rax], al
0x1c0008ae7: add      byte ptr [rax], al
0x1c0008ae9: add      byte ptr [rax], al
0x1c0008aeb: add      byte ptr [rax], al
0x1c0008aed: add      byte ptr [rax], al
0x1c0008aef: add      byte ptr [rax], al
0x1c0008af1: add      byte ptr [rax], al
0x1c0008af3: add      byte ptr [rax], al
0x1c0008af5: add      byte ptr [rax], al
0x1c0008af7: add      byte ptr [rax], al
0x1c0008af9: add      byte ptr [rax], al
0x1c0008afb: add      byte ptr [rax], al
0x1c0008afd: add      byte ptr [rax], al
0x1c0008aff: add      byte ptr [rax], al
0x1c0008b01: add      byte ptr [rax], al
0x1c0008b03: add      byte ptr [rax], al
0x1c0008b05: add      byte ptr [rax], al
0x1c0008b07: add      byte ptr [rax], al
0x1c0008b09: add      byte ptr [rax], al
0x1c0008b0b: add      byte ptr [rax], al
0x1c0008b0d: add      byte ptr [rax], al
0x1c0008b0f: add      byte ptr [rax], al
0x1c0008b11: add      byte ptr [rax], al
0x1c0008b13: add      byte ptr [rax], al
0x1c0008b15: add      byte ptr [rax], al
0x1c0008b17: add      byte ptr [rax], al
0x1c0008b19: add      byte ptr [rax], al
0x1c0008b1b: add      byte ptr [rax], al
0x1c0008b1d: add      byte ptr [rax], al
0x1c0008b1f: add      byte ptr [rax], al
0x1c0008b21: add      byte ptr [rax], al
0x1c0008b23: add      byte ptr [rax], al
0x1c0008b25: add      byte ptr [rax], al
0x1c0008b27: add      byte ptr [rax], al
0x1c0008b29: add      byte ptr [rax], al
0x1c0008b2b: add      byte ptr [rax], al
0x1c0008b2d: add      byte ptr [rax], al
0x1c0008b2f: add      byte ptr [rax], al
0x1c0008b31: add      byte ptr [rax], al
0x1c0008b33: add      byte ptr [rax], al
0x1c0008b35: add      byte ptr [rax], al
0x1c0008b37: add      byte ptr [rax], al
0x1c0008b39: add      byte ptr [rax], al
0x1c0008b3b: add      byte ptr [rax], al
0x1c0008b3d: add      byte ptr [rax], al
0x1c0008b3f: add      byte ptr [rax], al
0x1c0008b41: add      byte ptr [rax], al
0x1c0008b43: add      byte ptr [rax], al
0x1c0008b45: add      byte ptr [rax], al
0x1c0008b47: add      byte ptr [rax], al
0x1c0008b49: add      byte ptr [rax], al
0x1c0008b4b: add      byte ptr [rax], al
0x1c0008b4d: add      byte ptr [rax], al
0x1c0008b4f: add      byte ptr [rax], al
0x1c0008b51: add      byte ptr [rax], al
0x1c0008b53: add      byte ptr [rax], al
0x1c0008b55: add      byte ptr [rax], al
0x1c0008b57: add      byte ptr [rax], al
0x1c0008b59: add      byte ptr [rax], al
0x1c0008b5b: add      byte ptr [rax], al
0x1c0008b5d: add      byte ptr [rax], al
0x1c0008b5f: add      byte ptr [rax], al
0x1c0008b61: add      byte ptr [rax], al
0x1c0008b63: add      byte ptr [rax], al
0x1c0008b65: add      byte ptr [rax], al
0x1c0008b67: add      byte ptr [rax], al
0x1c0008b69: add      byte ptr [rax], al
0x1c0008b6b: add      byte ptr [rax], al
0x1c0008b6d: add      byte ptr [rax], al
0x1c0008b6f: add      byte ptr [rax], al
0x1c0008b71: add      byte ptr [rax], al
0x1c0008b73: add      byte ptr [rax], al
0x1c0008b75: add      byte ptr [rax], al
0x1c0008b77: add      byte ptr [rax], al
0x1c0008b79: add      byte ptr [rax], al
0x1c0008b7b: add      byte ptr [rax], al
0x1c0008b7d: add      byte ptr [rax], al
0x1c0008b7f: add      byte ptr [rax], al
0x1c0008b81: add      byte ptr [rax], al
0x1c0008b83: add      byte ptr [rax], al
0x1c0008b85: add      byte ptr [rax], al
0x1c0008b87: add      byte ptr [rax], al
0x1c0008b89: add      byte ptr [rax], al
0x1c0008b8b: add      byte ptr [rax], al
0x1c0008b8d: add      byte ptr [rax], al
0x1c0008b8f: add      byte ptr [rax], al
0x1c0008b91: add      byte ptr [rax], al
0x1c0008b93: add      byte ptr [rax], al
0x1c0008b95: add      byte ptr [rax], al
0x1c0008b97: add      byte ptr [rax], al
0x1c0008b99: add      byte ptr [rax], al
0x1c0008b9b: add      byte ptr [rax], al
0x1c0008b9d: add      byte ptr [rax], al
0x1c0008b9f: add      byte ptr [rax], al
0x1c0008ba1: add      byte ptr [rax], al
0x1c0008ba3: add      byte ptr [rax], al
0x1c0008ba5: add      byte ptr [rax], al
0x1c0008ba7: add      byte ptr [rax], al
0x1c0008ba9: add      byte ptr [rax], al
0x1c0008bab: add      byte ptr [rax], al
0x1c0008bad: add      byte ptr [rax], al
0x1c0008baf: add      byte ptr [rax], al
0x1c0008bb1: add      byte ptr [rax], al
0x1c0008bb3: add      byte ptr [rax], al
0x1c0008bb5: add      byte ptr [rax], al
0x1c0008bb7: add      byte ptr [rax], al
0x1c0008bb9: add      byte ptr [rax], al
0x1c0008bbb: add      byte ptr [rax], al
0x1c0008bbd: add      byte ptr [rax], al
0x1c0008bbf: add      byte ptr [rax], al
0x1c0008bc1: add      byte ptr [rax], al
0x1c0008bc3: add      byte ptr [rax], al
0x1c0008bc5: add      byte ptr [rax], al
0x1c0008bc7: add      byte ptr [rax], al
0x1c0008bc9: add      byte ptr [rax], al
0x1c0008bcb: add      byte ptr [rax], al
0x1c0008bcd: add      byte ptr [rax], al
0x1c0008bcf: add      byte ptr [rax], al
0x1c0008bd1: add      byte ptr [rax], al
0x1c0008bd3: add      byte ptr [rax], al
0x1c0008bd5: add      byte ptr [rax], al
0x1c0008bd7: add      byte ptr [rax], al
0x1c0008bd9: add      byte ptr [rax], al
0x1c0008bdb: add      byte ptr [rax], al
0x1c0008bdd: add      byte ptr [rax], al
0x1c0008bdf: add      byte ptr [rax], al
0x1c0008be1: add      byte ptr [rax], al
0x1c0008be3: add      byte ptr [rax], al
0x1c0008be5: add      byte ptr [rax], al
0x1c0008be7: add      byte ptr [rax], al
0x1c0008be9: add      byte ptr [rax], al
0x1c0008beb: add      byte ptr [rax], al
0x1c0008bed: add      byte ptr [rax], al
0x1c0008bef: add      byte ptr [rax], al
0x1c0008bf1: add      byte ptr [rax], al
0x1c0008bf3: add      byte ptr [rax], al
0x1c0008bf5: add      byte ptr [rax], al
0x1c0008bf7: add      byte ptr [rax], al
0x1c0008bf9: add      byte ptr [rax], al
0x1c0008bfb: add      byte ptr [rax], al
0x1c0008bfd: add      byte ptr [rax], al
0x1c0008bff: add      byte ptr [rax], al
0x1c0008c01: add      byte ptr [rax], al
0x1c0008c03: add      byte ptr [rax], al
0x1c0008c05: add      byte ptr [rax], al
0x1c0008c07: add      byte ptr [rax], al
0x1c0008c09: add      byte ptr [rax], al
0x1c0008c0b: add      byte ptr [rax], al
0x1c0008c0d: add      byte ptr [rax], al
0x1c0008c0f: add      byte ptr [rax], al
0x1c0008c11: add      byte ptr [rax], al
0x1c0008c13: add      byte ptr [rax], al
0x1c0008c15: add      byte ptr [rax], al
0x1c0008c17: add      byte ptr [rax], al
0x1c0008c19: add      byte ptr [rax], al
0x1c0008c1b: add      byte ptr [rax], al
0x1c0008c1d: add      byte ptr [rax], al
0x1c0008c1f: add      byte ptr [rax], al
0x1c0008c21: add      byte ptr [rax], al
0x1c0008c23: add      byte ptr [rax], al
0x1c0008c25: add      byte ptr [rax], al
0x1c0008c27: add      byte ptr [rax], al
0x1c0008c29: add      byte ptr [rax], al
0x1c0008c2b: add      byte ptr [rax], al
0x1c0008c2d: add      byte ptr [rax], al
0x1c0008c2f: add      byte ptr [rax], al
0x1c0008c31: add      byte ptr [rax], al
0x1c0008c33: add      byte ptr [rax], al
0x1c0008c35: add      byte ptr [rax], al
0x1c0008c37: add      byte ptr [rax], al
0x1c0008c39: add      byte ptr [rax], al
0x1c0008c3b: add      byte ptr [rax], al
0x1c0008c3d: add      byte ptr [rax], al
0x1c0008c3f: add      byte ptr [rax], al
0x1c0008c41: add      byte ptr [rax], al
0x1c0008c43: add      byte ptr [rax], al
0x1c0008c45: add      byte ptr [rax], al
0x1c0008c47: add      byte ptr [rax], al
0x1c0008c49: add      byte ptr [rax], al
0x1c0008c4b: add      byte ptr [rax], al
0x1c0008c4d: add      byte ptr [rax], al
0x1c0008c4f: add      byte ptr [rax], al
0x1c0008c51: add      byte ptr [rax], al
0x1c0008c53: add      byte ptr [rax], al
0x1c0008c55: add      byte ptr [rax], al
0x1c0008c57: add      byte ptr [rax], al
0x1c0008c59: add      byte ptr [rax], al
0x1c0008c5b: add      byte ptr [rax], al
0x1c0008c5d: add      byte ptr [rax], al
0x1c0008c5f: add      byte ptr [rax], al
0x1c0008c61: add      byte ptr [rax], al
0x1c0008c63: add      byte ptr [rax], al
0x1c0008c65: add      byte ptr [rax], al
0x1c0008c67: add      byte ptr [rax], al
0x1c0008c69: add      byte ptr [rax], al
0x1c0008c6b: add      byte ptr [rax], al
0x1c0008c6d: add      byte ptr [rax], al
0x1c0008c6f: add      byte ptr [rax], al
0x1c0008c71: add      byte ptr [rax], al
0x1c0008c73: add      byte ptr [rax], al
0x1c0008c75: add      byte ptr [rax], al
0x1c0008c77: add      byte ptr [rax], al
0x1c0008c79: add      byte ptr [rax], al
0x1c0008c7b: add      byte ptr [rax], al
0x1c0008c7d: add      byte ptr [rax], al
0x1c0008c7f: add      byte ptr [rax], al
0x1c0008c81: add      byte ptr [rax], al
0x1c0008c83: add      byte ptr [rax], al
0x1c0008c85: add      byte ptr [rax], al
0x1c0008c87: add      byte ptr [rax], al
0x1c0008c89: add      byte ptr [rax], al
0x1c0008c8b: add      byte ptr [rax], al
0x1c0008c8d: add      byte ptr [rax], al
0x1c0008c8f: add      byte ptr [rax], al
0x1c0008c91: add      byte ptr [rax], al
0x1c0008c93: add      byte ptr [rax], al
0x1c0008c95: add      byte ptr [rax], al
0x1c0008c97: add      byte ptr [rax], al
0x1c0008c99: add      byte ptr [rax], al
0x1c0008c9b: add      byte ptr [rax], al
0x1c0008c9d: add      byte ptr [rax], al
0x1c0008c9f: add      byte ptr [rax], al
0x1c0008ca1: add      byte ptr [rax], al
0x1c0008ca3: add      byte ptr [rax], al
0x1c0008ca5: add      byte ptr [rax], al
0x1c0008ca7: add      byte ptr [rax], al
0x1c0008ca9: add      byte ptr [rax], al
0x1c0008cab: add      byte ptr [rax], al
0x1c0008cad: add      byte ptr [rax], al
0x1c0008caf: add      byte ptr [rax], al
0x1c0008cb1: add      byte ptr [rax], al
0x1c0008cb3: add      byte ptr [rax], al
0x1c0008cb5: add      byte ptr [rax], al
0x1c0008cb7: add      byte ptr [rax], al
0x1c0008cb9: add      byte ptr [rax], al
0x1c0008cbb: add      byte ptr [rax], al
0x1c0008cbd: add      byte ptr [rax], al
0x1c0008cbf: add      byte ptr [rax], al
0x1c0008cc1: add      byte ptr [rax], al
0x1c0008cc3: add      byte ptr [rax], al
0x1c0008cc5: add      byte ptr [rax], al
0x1c0008cc7: add      byte ptr [rax], al
0x1c0008cc9: add      byte ptr [rax], al
0x1c0008ccb: add      byte ptr [rax], al
0x1c0008ccd: add      byte ptr [rax], al
0x1c0008ccf: add      byte ptr [rax], al
0x1c0008cd1: add      byte ptr [rax], al
0x1c0008cd3: add      byte ptr [rax], al
0x1c0008cd5: add      byte ptr [rax], al
0x1c0008cd7: add      byte ptr [rax], al
0x1c0008cd9: add      byte ptr [rax], al
0x1c0008cdb: add      byte ptr [rax], al
0x1c0008cdd: add      byte ptr [rax], al
0x1c0008cdf: add      byte ptr [rax], al
0x1c0008ce1: add      byte ptr [rax], al
0x1c0008ce3: add      byte ptr [rax], al
0x1c0008ce5: add      byte ptr [rax], al
0x1c0008ce7: add      byte ptr [rax], al
0x1c0008ce9: add      byte ptr [rax], al
0x1c0008ceb: add      byte ptr [rax], al
0x1c0008ced: add      byte ptr [rax], al
0x1c0008cef: add      byte ptr [rax], al
0x1c0008cf1: add      byte ptr [rax], al
0x1c0008cf3: add      byte ptr [rax], al
0x1c0008cf5: add      byte ptr [rax], al
0x1c0008cf7: add      byte ptr [rax], al
0x1c0008cf9: add      byte ptr [rax], al
0x1c0008cfb: add      byte ptr [rax], al
0x1c0008cfd: add      byte ptr [rax], al
0x1c0008cff: add      byte ptr [rax], al
0x1c0008d01: add      byte ptr [rax], al
0x1c0008d03: add      byte ptr [rax], al
0x1c0008d05: add      byte ptr [rax], al
0x1c0008d07: add      byte ptr [rax], al
0x1c0008d09: add      byte ptr [rax], al
0x1c0008d0b: add      byte ptr [rax], al
0x1c0008d0d: add      byte ptr [rax], al
0x1c0008d0f: add      byte ptr [rax], al
0x1c0008d11: add      byte ptr [rax], al
0x1c0008d13: add      byte ptr [rax], al
0x1c0008d15: add      byte ptr [rax], al
0x1c0008d17: add      byte ptr [rax], al
0x1c0008d19: add      byte ptr [rax], al
0x1c0008d1b: add      byte ptr [rax], al
0x1c0008d1d: add      byte ptr [rax], al
0x1c0008d1f: add      byte ptr [rax], al
0x1c0008d21: add      byte ptr [rax], al
0x1c0008d23: add      byte ptr [rax], al
0x1c0008d25: add      byte ptr [rax], al
0x1c0008d27: add      byte ptr [rax], al
0x1c0008d29: add      byte ptr [rax], al
0x1c0008d2b: add      byte ptr [rax], al
0x1c0008d2d: add      byte ptr [rax], al
0x1c0008d2f: add      byte ptr [rax], al
0x1c0008d31: add      byte ptr [rax], al
0x1c0008d33: add      byte ptr [rax], al
0x1c0008d35: add      byte ptr [rax], al
0x1c0008d37: add      byte ptr [rax], al
0x1c0008d39: add      byte ptr [rax], al
0x1c0008d3b: add      byte ptr [rax], al
0x1c0008d3d: add      byte ptr [rax], al
0x1c0008d3f: add      byte ptr [rax], al
0x1c0008d41: add      byte ptr [rax], al
0x1c0008d43: add      byte ptr [rax], al
0x1c0008d45: add      byte ptr [rax], al
0x1c0008d47: add      byte ptr [rax], al
0x1c0008d49: add      byte ptr [rax], al
0x1c0008d4b: add      byte ptr [rax], al
0x1c0008d4d: add      byte ptr [rax], al
0x1c0008d4f: add      byte ptr [rax], al
0x1c0008d51: add      byte ptr [rax], al
0x1c0008d53: add      byte ptr [rax], al
0x1c0008d55: add      byte ptr [rax], al
0x1c0008d57: add      byte ptr [rax], al
0x1c0008d59: add      byte ptr [rax], al
0x1c0008d5b: add      byte ptr [rax], al
0x1c0008d5d: add      byte ptr [rax], al
0x1c0008d5f: add      byte ptr [rax], al
0x1c0008d61: add      byte ptr [rax], al
0x1c0008d63: add      byte ptr [rax], al
0x1c0008d65: add      byte ptr [rax], al
0x1c0008d67: add      byte ptr [rax], al
0x1c0008d69: add      byte ptr [rax], al
0x1c0008d6b: add      byte ptr [rax], al
0x1c0008d6d: add      byte ptr [rax], al
0x1c0008d6f: add      byte ptr [rax], al
0x1c0008d71: add      byte ptr [rax], al
0x1c0008d73: add      byte ptr [rax], al
0x1c0008d75: add      byte ptr [rax], al
0x1c0008d77: add      byte ptr [rax], al
0x1c0008d79: add      byte ptr [rax], al
0x1c0008d7b: add      byte ptr [rax], al
0x1c0008d7d: add      byte ptr [rax], al
0x1c0008d7f: add      byte ptr [rax], al
0x1c0008d81: add      byte ptr [rax], al
0x1c0008d83: add      byte ptr [rax], al
0x1c0008d85: add      byte ptr [rax], al
0x1c0008d87: add      byte ptr [rax], al
0x1c0008d89: add      byte ptr [rax], al
0x1c0008d8b: add      byte ptr [rax], al
0x1c0008d8d: add      byte ptr [rax], al
0x1c0008d8f: add      byte ptr [rax], al
0x1c0008d91: add      byte ptr [rax], al
0x1c0008d93: add      byte ptr [rax], al
0x1c0008d95: add      byte ptr [rax], al
0x1c0008d97: add      byte ptr [rax], al
0x1c0008d99: add      byte ptr [rax], al
0x1c0008d9b: add      byte ptr [rax], al
0x1c0008d9d: add      byte ptr [rax], al
0x1c0008d9f: add      byte ptr [rax], al
0x1c0008da1: add      byte ptr [rax], al
0x1c0008da3: add      byte ptr [rax], al
0x1c0008da5: add      byte ptr [rax], al
0x1c0008da7: add      byte ptr [rax], al
0x1c0008da9: add      byte ptr [rax], al
0x1c0008dab: add      byte ptr [rax], al
0x1c0008dad: add      byte ptr [rax], al
0x1c0008daf: add      byte ptr [rax], al
0x1c0008db1: add      byte ptr [rax], al
0x1c0008db3: add      byte ptr [rax], al
0x1c0008db5: add      byte ptr [rax], al
0x1c0008db7: add      byte ptr [rax], al
0x1c0008db9: add      byte ptr [rax], al
0x1c0008dbb: add      byte ptr [rax], al
0x1c0008dbd: add      byte ptr [rax], al
0x1c0008dbf: add      byte ptr [rax], al
0x1c0008dc1: add      byte ptr [rax], al
0x1c0008dc3: add      byte ptr [rax], al
0x1c0008dc5: add      byte ptr [rax], al
0x1c0008dc7: add      byte ptr [rax], al
0x1c0008dc9: add      byte ptr [rax], al
0x1c0008dcb: add      byte ptr [rax], al
0x1c0008dcd: add      byte ptr [rax], al
0x1c0008dcf: add      byte ptr [rax], al
0x1c0008dd1: add      byte ptr [rax], al
0x1c0008dd3: add      byte ptr [rax], al
0x1c0008dd5: add      byte ptr [rax], al
0x1c0008dd7: add      byte ptr [rax], al
0x1c0008dd9: add      byte ptr [rax], al
0x1c0008ddb: add      byte ptr [rax], al
0x1c0008ddd: add      byte ptr [rax], al
0x1c0008ddf: add      byte ptr [rax], al
0x1c0008de1: add      byte ptr [rax], al
0x1c0008de3: add      byte ptr [rax], al
0x1c0008de5: add      byte ptr [rax], al
0x1c0008de7: add      byte ptr [rax], al
0x1c0008de9: add      byte ptr [rax], al
0x1c0008deb: add      byte ptr [rax], al
0x1c0008ded: add      byte ptr [rax], al
0x1c0008def: add      byte ptr [rax], al
0x1c0008df1: add      byte ptr [rax], al
0x1c0008df3: add      byte ptr [rax], al
0x1c0008df5: add      byte ptr [rax], al
0x1c0008df7: add      byte ptr [rax], al
0x1c0008df9: add      byte ptr [rax], al
0x1c0008dfb: add      byte ptr [rax], al
0x1c0008dfd: add      byte ptr [rax], al
0x1c0008dff: add      byte ptr [rax], al
0x1c0008e01: add      byte ptr [rax], al
0x1c0008e03: add      byte ptr [rax], al
0x1c0008e05: add      byte ptr [rax], al
0x1c0008e07: add      byte ptr [rax], al
0x1c0008e09: add      byte ptr [rax], al
0x1c0008e0b: add      byte ptr [rax], al
0x1c0008e0d: add      byte ptr [rax], al
0x1c0008e0f: add      byte ptr [rax], al
0x1c0008e11: add      byte ptr [rax], al
0x1c0008e13: add      byte ptr [rax], al
0x1c0008e15: add      byte ptr [rax], al
0x1c0008e17: add      byte ptr [rax], al
0x1c0008e19: add      byte ptr [rax], al
0x1c0008e1b: add      byte ptr [rax], al
0x1c0008e1d: add      byte ptr [rax], al
0x1c0008e1f: add      byte ptr [rax], al
0x1c0008e21: add      byte ptr [rax], al
0x1c0008e23: add      byte ptr [rax], al
0x1c0008e25: add      byte ptr [rax], al
0x1c0008e27: add      byte ptr [rax], al
0x1c0008e29: add      byte ptr [rax], al
0x1c0008e2b: add      byte ptr [rax], al
0x1c0008e2d: add      byte ptr [rax], al
0x1c0008e2f: add      byte ptr [rax], al
0x1c0008e31: add      byte ptr [rax], al
0x1c0008e33: add      byte ptr [rax], al
0x1c0008e35: add      byte ptr [rax], al
0x1c0008e37: add      byte ptr [rax], al
0x1c0008e39: add      byte ptr [rax], al
0x1c0008e3b: add      byte ptr [rax], al
0x1c0008e3d: add      byte ptr [rax], al
0x1c0008e3f: add      byte ptr [rax], al
0x1c0008e41: add      byte ptr [rax], al
0x1c0008e43: add      byte ptr [rax], al
0x1c0008e45: add      byte ptr [rax], al
0x1c0008e47: add      byte ptr [rax], al
0x1c0008e49: add      byte ptr [rax], al
0x1c0008e4b: add      byte ptr [rax], al
0x1c0008e4d: add      byte ptr [rax], al
0x1c0008e4f: add      byte ptr [rax], al
0x1c0008e51: add      byte ptr [rax], al
0x1c0008e53: add      byte ptr [rax], al
0x1c0008e55: add      byte ptr [rax], al
0x1c0008e57: add      byte ptr [rax], al
0x1c0008e59: add      byte ptr [rax], al
0x1c0008e5b: add      byte ptr [rax], al
0x1c0008e5d: add      byte ptr [rax], al
0x1c0008e5f: add      byte ptr [rax], al
0x1c0008e61: add      byte ptr [rax], al
0x1c0008e63: add      byte ptr [rax], al
0x1c0008e65: add      byte ptr [rax], al
0x1c0008e67: add      byte ptr [rax], al
0x1c0008e69: add      byte ptr [rax], al
0x1c0008e6b: add      byte ptr [rax], al
0x1c0008e6d: add      byte ptr [rax], al
0x1c0008e6f: add      byte ptr [rax], al
0x1c0008e71: add      byte ptr [rax], al
0x1c0008e73: add      byte ptr [rax], al
0x1c0008e75: add      byte ptr [rax], al
0x1c0008e77: add      byte ptr [rax], al
0x1c0008e79: add      byte ptr [rax], al
0x1c0008e7b: add      byte ptr [rax], al
0x1c0008e7d: add      byte ptr [rax], al
0x1c0008e7f: add      byte ptr [rax], al
0x1c0008e81: add      byte ptr [rax], al
0x1c0008e83: add      byte ptr [rax], al
0x1c0008e85: add      byte ptr [rax], al
0x1c0008e87: add      byte ptr [rax], al
0x1c0008e89: add      byte ptr [rax], al
0x1c0008e8b: add      byte ptr [rax], al
0x1c0008e8d: add      byte ptr [rax], al
0x1c0008e8f: add      byte ptr [rax], al
0x1c0008e91: add      byte ptr [rax], al
0x1c0008e93: add      byte ptr [rax], al
0x1c0008e95: add      byte ptr [rax], al
0x1c0008e97: add      byte ptr [rax], al
0x1c0008e99: add      byte ptr [rax], al
0x1c0008e9b: add      byte ptr [rax], al
0x1c0008e9d: add      byte ptr [rax], al
0x1c0008e9f: add      byte ptr [rax], al
0x1c0008ea1: add      byte ptr [rax], al
0x1c0008ea3: add      byte ptr [rax], al
0x1c0008ea5: add      byte ptr [rax], al
0x1c0008ea7: add      byte ptr [rax], al
0x1c0008ea9: add      byte ptr [rax], al
0x1c0008eab: add      byte ptr [rax], al
0x1c0008ead: add      byte ptr [rax], al
0x1c0008eaf: add      byte ptr [rax], al
0x1c0008eb1: add      byte ptr [rax], al
0x1c0008eb3: add      byte ptr [rax], al
0x1c0008eb5: add      byte ptr [rax], al
0x1c0008eb7: add      byte ptr [rax], al
0x1c0008eb9: add      byte ptr [rax], al
0x1c0008ebb: add      byte ptr [rax], al
0x1c0008ebd: add      byte ptr [rax], al
0x1c0008ebf: add      byte ptr [rax], al
0x1c0008ec1: add      byte ptr [rax], al
0x1c0008ec3: add      byte ptr [rax], al
0x1c0008ec5: add      byte ptr [rax], al
0x1c0008ec7: add      byte ptr [rax], al
0x1c0008ec9: add      byte ptr [rax], al
0x1c0008ecb: add      byte ptr [rax], al
0x1c0008ecd: add      byte ptr [rax], al
0x1c0008ecf: add      byte ptr [rax], al
0x1c0008ed1: add      byte ptr [rax], al
0x1c0008ed3: add      byte ptr [rax], al
0x1c0008ed5: add      byte ptr [rax], al
0x1c0008ed7: add      byte ptr [rax], al
0x1c0008ed9: add      byte ptr [rax], al
0x1c0008edb: add      byte ptr [rax], al
0x1c0008edd: add      byte ptr [rax], al
0x1c0008edf: add      byte ptr [rax], al
0x1c0008ee1: add      byte ptr [rax], al
0x1c0008ee3: add      byte ptr [rax], al
0x1c0008ee5: add      byte ptr [rax], al
0x1c0008ee7: add      byte ptr [rax], al
0x1c0008ee9: add      byte ptr [rax], al
0x1c0008eeb: add      byte ptr [rax], al
0x1c0008eed: add      byte ptr [rax], al
0x1c0008eef: add      byte ptr [rax], al
0x1c0008ef1: add      byte ptr [rax], al
0x1c0008ef3: add      byte ptr [rax], al
0x1c0008ef5: add      byte ptr [rax], al
0x1c0008ef7: add      byte ptr [rax], al
0x1c0008ef9: add      byte ptr [rax], al
0x1c0008efb: add      byte ptr [rax], al
0x1c0008efd: add      byte ptr [rax], al
0x1c0008eff: add      byte ptr [rax], al
0x1c0008f01: add      byte ptr [rax], al
0x1c0008f03: add      byte ptr [rax], al
0x1c0008f05: add      byte ptr [rax], al
0x1c0008f07: add      byte ptr [rax], al
0x1c0008f09: add      byte ptr [rax], al
0x1c0008f0b: add      byte ptr [rax], al
0x1c0008f0d: add      byte ptr [rax], al
0x1c0008f0f: add      byte ptr [rax], al
0x1c0008f11: add      byte ptr [rax], al
0x1c0008f13: add      byte ptr [rax], al
0x1c0008f15: add      byte ptr [rax], al
0x1c0008f17: add      byte ptr [rax], al
0x1c0008f19: add      byte ptr [rax], al
0x1c0008f1b: add      byte ptr [rax], al
0x1c0008f1d: add      byte ptr [rax], al
0x1c0008f1f: add      byte ptr [rax], al
0x1c0008f21: add      byte ptr [rax], al
0x1c0008f23: add      byte ptr [rax], al
0x1c0008f25: add      byte ptr [rax], al
0x1c0008f27: add      byte ptr [rax], al
0x1c0008f29: add      byte ptr [rax], al
0x1c0008f2b: add      byte ptr [rax], al
0x1c0008f2d: add      byte ptr [rax], al
0x1c0008f2f: add      byte ptr [rax], al
0x1c0008f31: add      byte ptr [rax], al
0x1c0008f33: add      byte ptr [rax], al
0x1c0008f35: add      byte ptr [rax], al
0x1c0008f37: add      byte ptr [rax], al
0x1c0008f39: add      byte ptr [rax], al
0x1c0008f3b: add      byte ptr [rax], al
0x1c0008f3d: add      byte ptr [rax], al
0x1c0008f3f: add      byte ptr [rax], al
0x1c0008f41: add      byte ptr [rax], al
0x1c0008f43: add      byte ptr [rax], al
0x1c0008f45: add      byte ptr [rax], al
0x1c0008f47: add      byte ptr [rax], al
0x1c0008f49: add      byte ptr [rax], al
0x1c0008f4b: add      byte ptr [rax], al
0x1c0008f4d: add      byte ptr [rax], al
0x1c0008f4f: add      byte ptr [rax], al
0x1c0008f51: add      byte ptr [rax], al
0x1c0008f53: add      byte ptr [rax], al
0x1c0008f55: add      byte ptr [rax], al
0x1c0008f57: add      byte ptr [rax], al
0x1c0008f59: add      byte ptr [rax], al
0x1c0008f5b: add      byte ptr [rax], al
0x1c0008f5d: add      byte ptr [rax], al
0x1c0008f5f: add      byte ptr [rax], al
0x1c0008f61: add      byte ptr [rax], al
0x1c0008f63: add      byte ptr [rax], al
0x1c0008f65: add      byte ptr [rax], al
0x1c0008f67: add      byte ptr [rax], al
0x1c0008f69: add      byte ptr [rax], al
0x1c0008f6b: add      byte ptr [rax], al
0x1c0008f6d: add      byte ptr [rax], al
0x1c0008f6f: add      byte ptr [rax], al
0x1c0008f71: add      byte ptr [rax], al
0x1c0008f73: add      byte ptr [rax], al
0x1c0008f75: add      byte ptr [rax], al
0x1c0008f77: add      byte ptr [rax], al
0x1c0008f79: add      byte ptr [rax], al
0x1c0008f7b: add      byte ptr [rax], al
0x1c0008f7d: add      byte ptr [rax], al
0x1c0008f7f: add      byte ptr [rax], al
0x1c0008f81: add      byte ptr [rax], al
0x1c0008f83: add      byte ptr [rax], al
0x1c0008f85: add      byte ptr [rax], al
0x1c0008f87: add      byte ptr [rax], al
0x1c0008f89: add      byte ptr [rax], al
0x1c0008f8b: add      byte ptr [rax], al
0x1c0008f8d: add      byte ptr [rax], al
0x1c0008f8f: add      byte ptr [rax], al
0x1c0008f91: add      byte ptr [rax], al
0x1c0008f93: add      byte ptr [rax], al
0x1c0008f95: add      byte ptr [rax], al
0x1c0008f97: add      byte ptr [rax], al
0x1c0008f99: add      byte ptr [rax], al
0x1c0008f9b: add      byte ptr [rax], al
0x1c0008f9d: add      byte ptr [rax], al
0x1c0008f9f: add      byte ptr [rax], al
0x1c0008fa1: add      byte ptr [rax], al
0x1c0008fa3: add      byte ptr [rax], al
0x1c0008fa5: add      byte ptr [rax], al
0x1c0008fa7: add      byte ptr [rax], al
0x1c0008fa9: add      byte ptr [rax], al
0x1c0008fab: add      byte ptr [rax], al
0x1c0008fad: add      byte ptr [rax], al
0x1c0008faf: add      byte ptr [rax], al
0x1c0008fb1: add      byte ptr [rax], al
0x1c0008fb3: add      byte ptr [rax], al
0x1c0008fb5: add      byte ptr [rax], al
0x1c0008fb7: add      byte ptr [rax], al
0x1c0008fb9: add      byte ptr [rax], al
0x1c0008fbb: add      byte ptr [rax], al
0x1c0008fbd: add      byte ptr [rax], al
0x1c0008fbf: add      byte ptr [rax], al
0x1c0008fc1: add      byte ptr [rax], al
0x1c0008fc3: add      byte ptr [rax], al
0x1c0008fc5: add      byte ptr [rax], al
0x1c0008fc7: add      byte ptr [rax], al
0x1c0008fc9: add      byte ptr [rax], al
0x1c0008fcb: add      byte ptr [rax], al
0x1c0008fcd: add      byte ptr [rax], al
0x1c0008fcf: add      byte ptr [rax], al
0x1c0008fd1: add      byte ptr [rax], al
0x1c0008fd3: add      byte ptr [rax], al
0x1c0008fd5: add      byte ptr [rax], al
0x1c0008fd7: add      byte ptr [rax], al
0x1c0008fd9: add      byte ptr [rax], al
0x1c0008fdb: add      byte ptr [rax], al
0x1c0008fdd: add      byte ptr [rax], al
0x1c0008fdf: add      byte ptr [rax], al
0x1c0008fe1: add      byte ptr [rax], al
0x1c0008fe3: add      byte ptr [rax], al
0x1c0008fe5: add      byte ptr [rax], al
0x1c0008fe7: add      byte ptr [rax], al
0x1c0008fe9: add      byte ptr [rax], al
0x1c0008feb: add      byte ptr [rax], al
0x1c0008fed: add      byte ptr [rax], al
0x1c0008fef: add      byte ptr [rax], al
0x1c0008ff1: add      byte ptr [rax], al
0x1c0008ff3: add      byte ptr [rax], al
0x1c0008ff5: add      byte ptr [rax], al
0x1c0008ff7: add      byte ptr [rax], al
0x1c0008ff9: add      byte ptr [rax], al
0x1c0008ffb: add      byte ptr [rax], al
0x1c0008ffd: add      byte ptr [rax], al
```
