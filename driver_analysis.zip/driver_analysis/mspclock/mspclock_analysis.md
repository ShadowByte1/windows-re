# mspclock.sys — Static Analysis Report

## File Metadata
| Field | Value |
|---|---|
| File | mspclock.sys |
| Type | PE32+ native kernel driver (WDM) |
| Size | 48 KB |
| Architecture | x86-64 |
| Sections | 11 |
| Build Timestamp | Normalized/reproducible (future date indicates deterministic build) |
| Image Base | 0x1c0000000 |
| Image Size | ~0xc000 |
| Purpose | Kernel Streaming (KS) clock provider |

## Mitigation Summary (DllCharacteristics: 0x6160)
| Mitigation | Status |
|---|---|
| ASLR / DYNAMIC_BASE | PRESENT |
| NX / DEP | PRESENT |
| HIGH_ENTROPY_VA | PRESENT |
| WDM_DRIVER | PRESENT |
| FORCE_INTEGRITY | MISSING |
| GUARD_CF (PE DllChars flag) | MISSING (CFG table present despite flag absence) |

## Load Config / CFG
| Field | Value |
|---|---|
| SecurityCookie (/GS) | 0x1c0003000 (PRESENT) |
| GuardCFCheckFunction | 0x1c00052a0 (PRESENT) |
| GuardFlags | 0x51c500 |
| CF_INSTRUMENTED | YES |
| CF_FUNCTION_TABLE_PRESENT | YES |
| RF_INSTRUMENTED (return flow) | YES |
| RF_STRICT | YES |
| CF_EXPORT_SUPPRESSION | YES |
| CF_LONGJUMP_TABLE | YES |
| XFG | NO |

Better mitigation posture than mlx4_bus — return-flow guard is enabled.

## Section Map
| Section | VA | Raw Size | Entropy |
|---|---|---|---|
| .text | 0x1000 | 0x1000 | 0.639 |
| .rdata | 0x2000 | 0x1000 | 1.543 |
| .data | 0x3000 | 0x1000 | 0.045 |
| .pdata | 0x4000 | 0x1000 | 0.349 |
| .idata | 0x5000 | 0x1000 | 2.413 |
| .guids | 0x6000 | 0x1000 | 0.088 |
| PAGE | 0x7000 | 0x1000 | 2.341 |
| INIT | 0x8000 | 0x1000 | 0.601 |
| GFIDS | 0x9000 | 0x1000 | 0.092 |
| .rsrc | 0xa000 | 0x1000 | 1.071 |
| .reloc | 0xb000 | 0x1000 | 0.604 |

Very low entropy across all sections — small, sparse driver. The `.guids` section
is unusual and contains KS interface/category GUIDs.

## Imported DLLs
- ntoskrnl.exe — 11 imports
- ks.sys — 28 imports

## ntoskrnl.exe Imports
```
ExAllocatePoolWithTag     -- DEPRECATED (see Finding 1)
ExFreePool                -- DEPRECATED untagged free (see Finding 1)
KeLeaveCriticalRegion
ExReleaseFastMutexUnsafe
IofCompleteRequest
KeInitializeEvent
IoCreateDevice
ExAcquireFastMutexUnsafe
IoAttachDeviceToDeviceStack
IoDeleteDevice
KeEnterCriticalRegion
```

## ks.sys Imports (Kernel Streaming Interface)
```
KsSetDevicePnpAndBaseObject
KsDefaultDispatchPnp
KsSetMajorFunctionHandler       -- registers IRP dispatch handlers
KsNullDriverUnload
KsDefaultForwardIrp
KsDefaultDispatchPower
KsiPropertyDefaultClockGetCorrelatedPhysicalTime
KsFreeDeviceHeader
KsFreeObjectHeader
KsFreeDefaultClock
KsAllocateObjectHeader
KsAllocateDefaultClock
KsSetDefaultClockState
KsEnableEvent                   -- user-triggered event registration
KsDereferenceSoftwareBusObject
KsAllocateDeviceHeader
KsiPropertyDefaultClockGetFunctionTable
KsiPropertyDefaultClockGetCorrelatedTime
KsiDefaultClockAddMarkEvent
KsiPropertyDefaultClockGetTime
KsPropertyHandler               -- dispatches KSPROPERTY from user mode
KsReferenceSoftwareBusObject
KsDisableEvent                  -- user-triggered event disable
KsFreeEventList                 -- frees event list
KsSetDefaultClockTime
KsiPropertyDefaultClockGetResolution
KsiPropertyDefaultClockGetPhysicalTime
KsiPropertyDefaultClockGetState
```

---

## Attack Surface Overview

mspclock.sys is a KS (Kernel Streaming) clock driver. Its user-mode attack
surface is the KS property/event dispatch chain, reachable via DeviceIoControl
to the KS clock device object.

User-mode callers send KSPROPERTY requests which are dispatched through
`KsPropertyHandler`. The handler indexes into a property dispatch table
using `KSPROPERTY.Id`. The driver also handles events via `KsEnableEvent`
and `KsDisableEvent`.

---

## FINDING 1 — Mismatched Pool Allocation/Free (Tagged Alloc, Untagged Free)
**Severity:** Medium  
**APIs:** ExAllocatePoolWithTag + ExFreePool

### Detail
`ExAllocatePoolWithTag` allocates pool memory with a 4-byte tag for leak tracking
and pool corruption detection. `ExFreePool` is the untagged free variant.

When a block allocated with `ExAllocatePoolWithTag` is freed with `ExFreePool`,
Windows kernel pool verification (Driver Verifier, or internal pool checks on
checked builds) can flag the mismatch. More importantly:

- If pool corruption checking is active and walks the block's tag on free,
  a mismatched or corrupted tag field could cause incorrect behaviour in the
  corruption check path
- The correct paired free for `ExAllocatePoolWithTag` is `ExFreePoolWithTag`
- `ExAllocatePool2` (the modern replacement) should be used, paired with
  `ExFreePoolWithTag`

Given the small size of this driver, the allocation and free likely refer to
the same object. The risk is primarily that error paths may free the wrong
allocation, or that pool metadata is not validated consistently.

### Impact
- On Driver Verifier enabled systems: false pool corruption reports
- On systems with custom pool integrity checks: potential bypass
- Info-leak risk: ExAllocatePoolWithTag returns uninitialised memory;
  if the allocated buffer is larger than data written and later copied
  to user mode, previous kernel pool contents leak

### Fix
Replace with ExAllocatePool2 / ExFreePoolWithTag pair:
```c
// Old:
buf = ExAllocatePoolWithTag(NonPagedPool, size, 'kClk');
ExFreePool(buf);

// New:
buf = ExAllocatePool2(POOL_FLAG_NON_PAGED, size, 'kClk');
ExFreePoolWithTag(buf, 'kClk');
```

---

## FINDING 2 — KS Property Handler Attack Surface
**Severity:** Medium (requires further dynamic analysis to confirm exploitability)  
**Entry point:** KsPropertyHandler dispatch

### Detail
`KsPropertyHandler` receives IRPs from user mode via `DeviceIoControl` with
the KS IOCTL code. The input buffer contains a `KSPROPERTY` structure:

```c
typedef struct {
    GUID Set;       // property set GUID
    ULONG Id;       // property ID within the set
    ULONG Flags;    // KSPROPERTY_TYPE_GET / SET / etc.
} KSPROPERTY;
```

The handler uses `Id` to index into a static property dispatch table in `.rdata`.
If `Id` is not validated against the table bounds before indexing, an out-of-bounds
read from the table is possible.

For this driver, the property sets are KS clock properties:
- KSPROPERTY_CLOCK_TIME
- KSPROPERTY_CLOCK_PHYSICALTIME
- KSPROPERTY_CLOCK_CORRELATEDTIME
- KSPROPERTY_CLOCK_CORRELATEDPHYSICALTIME
- KSPROPERTY_CLOCK_RESOLUTION
- KSPROPERTY_CLOCK_STATE
- KSPROPERTY_CLOCK_FUNCTIONTABLE

These are all implemented via the Ksi* imports. The dispatch table is in
`.rdata` (read-only), so OOB read from a bad Id would read kernel .rdata
or adjacent memory — an information disclosure.

### Event Handling
`KsEnableEvent` and `KsDisableEvent` are also user-reachable.
`KsFreeEventList` frees a list of registered events. If an event object
is added to the list via `KsiDefaultClockAddMarkEvent` and then
`KsFreeEventList` is called concurrently, a race condition in the list
traversal could result in use-after-free. This requires dynamic analysis
to confirm.

---

## FINDING 3 — FORCE_INTEGRITY Missing
**Severity:** Informational  

`FORCE_INTEGRITY` in DllCharacteristics instructs the loader to verify the
driver's Authenticode signature at load time, even when kernel code signing
enforcement might otherwise be relaxed. Its absence means that on systems
where signing enforcement has been downgraded (test signing, boot-time bypass),
this driver provides no additional assurance of integrity.

---

## Recommended Mitigations
1. Replace ExAllocatePoolWithTag + ExFreePool with ExAllocatePool2 + ExFreePoolWithTag
2. Add explicit bounds check on KSPROPERTY.Id before table dispatch
3. Audit KsFreeEventList call sites for concurrent access without lock protection
4. Enable FORCE_INTEGRITY linker flag
5. Upgrade to XFG (eXtended Flow Guard) for type-safe indirect calls
