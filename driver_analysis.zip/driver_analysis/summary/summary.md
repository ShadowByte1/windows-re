# Driver Vulnerability Analysis — Executive Summary
Static analysis only. No dynamic execution performed.

## Scope
| Driver | Size | Purpose |
|---|---|---|
| mlx4_bus.sys | 1.1 MB | Mellanox ConnectX-4 RDMA/InfiniBand bus driver |
| mspclock.sys | 48 KB | Kernel Streaming (KS) clock provider |
| KNetPwrDepBroker.sys | 80 KB | Network Power Dependency Broker (IMS/LTE) |

---

## Mitigation Comparison
| Mitigation | mlx4_bus | mspclock | KNetPwrDepBroker |
|---|---|---|---|
| ASLR | YES | YES | YES |
| DEP/NX | YES | YES | YES |
| /GS stack cookies | YES | YES | YES |
| CFG (forward edge) | YES | YES | YES |
| Return-flow guard | NO | YES | YES |
| XFG | NO | NO | YES |
| FORCE_INTEGRITY | NO | NO | NO |
| Modern pool (ExAllocatePool2) | NO | NO | YES |

KNetPwrDepBroker is most hardened. mlx4_bus is weakest.
All three are missing FORCE_INTEGRITY.

---

## Findings Summary

### mlx4_bus.sys
| # | Title | Severity | Location |
|---|---|---|---|
| F1 | Integer overflow → MmMapIoSpaceEx (ICM page count, shl rcx,0xc) | HIGH | .text @ 0x140036d6c |
| F2 | Unprobed double-dereference before ProbeForWrite | MEDIUM-HIGH | .text @ 0x140028c0c |
| F3 | 32-bit shift overflow → MmMapIoSpaceEx (two sites) | MEDIUM | .text @ 0x140013f15, 0x140014417 |
| F4 | rand() usage in kernel driver | LOW-MEDIUM | IAT |
| F5 | Deprecated ExAllocatePoolWithTag/Priority | LOW | IAT |

### mspclock.sys
| # | Title | Severity | Location |
|---|---|---|---|
| F1 | ExAllocatePoolWithTag + ExFreePool mismatch | MEDIUM | IAT |
| F2 | KS property handler: KSPROPERTY.Id not validated before table dispatch | MEDIUM | KsPropertyHandler |
| F3 | FORCE_INTEGRITY missing | INFO | PE header |

### KNetPwrDepBroker.sys
| # | Title | Severity | Location |
|---|---|---|---|
| F1 | ExDeleteTimer race with callback context (potential UAF) | MEDIUM | PAGE section |
| F2 | NpdBrokerAcquireWithTimeout: timeout multiply overflow risk | LOW-MEDIUM | Export |
| F3 | DbgkWerCaptureLiveKernelDump reachable from exported API | INFO | IAT |
| F4 | FORCE_INTEGRITY missing | INFO | PE header |

---

## File Index
```
driver_analysis/
├── summary/
│   └── summary.md                        (this file)
├── mlx4_bus/
│   ├── mlx4_bus_analysis.md              (full analysis + annotated disassembly)
│   ├── mlx4_bus_disasm.md                (raw disassembly traces, all call sites)
│   ├── mlx4_bus_imports.md               (full IAT with addresses)
│   └── mlx4_bus_strings.txt              (all strings >= 6 chars)
├── mspclock/
│   ├── mspclock_analysis.md              (full analysis)
│   ├── mspclock_disasm.md                (full disassembly, all executable sections)
│   ├── mspclock_imports.md               (full IAT)
│   └── mspclock_strings.txt              (all strings)
└── KNetPwrDepBroker/
    ├── KNetPwrDepBroker_analysis.md      (full analysis)
    ├── KNetPwrDepBroker_disasm.md        (full disassembly, annotated with IAT targets)
    ├── KNetPwrDepBroker_imports.md       (full IAT + exports)
    └── KNetPwrDepBroker_strings.txt      (all strings)
```
