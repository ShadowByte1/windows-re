# KNetPwrDepBroker.sys — Disassembly Dump

## All Executable Sections

### Section: .text (VA=0x180001000, 5210 instructions)
```asm
0x180001000: int3     
0x180001001: int3     
0x180001002: int3     
0x180001003: int3     
0x180001004: int3     
0x180001005: int3     
0x180001006: int3     
0x180001007: int3     
0x180001008: push     rbp
0x18000100a: lea      rbp, [rsp - 0x37]
0x18000100f: sub      rsp, 0xa0
0x180001016: mov      rax, qword ptr [rip + 0x70e3]
0x18000101d: xor      rax, rsp
0x180001020: mov      qword ptr [rbp + 0x27], rax
0x180001024: mov      rax, qword ptr [rbp + 0x7f]
0x180001028: lea      rcx, [rip + 0x7019]
0x18000102f: mov      qword ptr [rbp + 0x17], rax
0x180001033: xor      r9d, r9d
0x180001036: mov      rax, qword ptr [rbp + 0x77]
0x18000103a: xor      r8d, r8d
0x18000103d: mov      qword ptr [rbp + 7], rax
0x180001041: mov      rax, qword ptr [rbp + 0x6f]
0x180001045: mov      qword ptr [rbp - 9], rax
0x180001049: mov      rax, qword ptr [rbp + 0x67]
0x18000104d: mov      qword ptr [rbp - 0x19], rax
0x180001051: lea      rax, [rbp - 0x39]
0x180001055: mov      qword ptr [rsp + 0x28], rax
0x18000105a: mov      dword ptr [rsp + 0x20], 6
0x180001062: mov      qword ptr [rbp + 0x1f], 8
0x18000106a: mov      qword ptr [rbp + 0xf], 4
0x180001072: mov      qword ptr [rbp - 1], 1
0x18000107a: mov      qword ptr [rbp - 0x11], 8
0x180001082: call     0x18000112c
0x180001087: mov      rcx, qword ptr [rbp + 0x27]
0x18000108b: xor      rcx, rsp
0x18000108e: call     0x1800041a0
0x180001093: add      rsp, 0xa0
0x18000109a: pop      rbp
0x18000109b: ret      
0x18000109c: int3     
0x18000109d: int3     
0x18000109e: int3     
0x18000109f: int3     
0x1800010a0: int3     
0x1800010a1: int3     
0x1800010a2: int3     
0x1800010a3: int3     
0x1800010a4: mov      r11, rsp
0x1800010a7: sub      rsp, 0x88
0x1800010ae: mov      rax, qword ptr [rip + 0x704b]
0x1800010b5: xor      rax, rsp
0x1800010b8: mov      qword ptr [rsp + 0x70], rax
0x1800010bd: mov      rax, qword ptr [rsp + 0xb8]
0x1800010c5: mov      ecx, 4
0x1800010ca: mov      qword ptr [r11 - 0x28], rax
0x1800010ce: xor      r9d, r9d
0x1800010d1: mov      rax, qword ptr [rsp + 0xb0]
0x1800010d9: xor      r8d, r8d
0x1800010dc: and      dword ptr [rsp + 0x6c], 0
0x1800010e1: mov      dword ptr [rsp + 0x68], ecx
0x1800010e5: mov      qword ptr [r11 - 0x38], rax
0x1800010e9: lea      rax, [r11 - 0x58]
0x1800010ed: and      dword ptr [rsp + 0x5c], 0
0x1800010f2: mov      qword ptr [r11 - 0x60], rax
0x1800010f6: mov      dword ptr [rsp + 0x20], ecx
0x1800010fa: lea      rcx, [rip + 0x6f47]
0x180001101: mov      dword ptr [rsp + 0x58], 8
0x180001109: call     0x18000112c
0x18000110e: mov      rcx, qword ptr [rsp + 0x70]
0x180001113: xor      rcx, rsp
0x180001116: call     0x1800041a0
0x18000111b: add      rsp, 0x88
0x180001122: ret      
0x180001123: int3     
0x180001124: int3     
0x180001125: int3     
0x180001126: int3     
0x180001127: int3     
0x180001128: int3     
0x180001129: int3     
0x18000112a: int3     
0x18000112b: int3     
0x18000112c: sub      rsp, 0x58
0x180001130: mov      rax, qword ptr [rip + 0x6fc9]
0x180001137: xor      rax, rsp
0x18000113a: mov      qword ptr [rsp + 0x48], rax
0x18000113f: movzx    eax, byte ptr [rdx]
0x180001142: mov      r11, rcx
0x180001145: mov      r10, qword ptr [rsp + 0x88]
0x18000114d: shl      eax, 0x18
0x180001150: mov      dword ptr [rsp + 0x38], eax
0x180001154: movzx    eax, word ptr [rdx + 1]
0x180001158: mov      dword ptr [rsp + 0x3c], eax
0x18000115c: mov      rax, qword ptr [rdx + 3]
0x180001160: add      rdx, 0xb
0x180001164: mov      qword ptr [rsp + 0x40], rax
0x180001169: mov      rax, qword ptr [rcx + 8]
0x18000116d: mov      qword ptr [r10], rax
0x180001170: mov      rax, qword ptr [rcx + 8]
0x180001174: mov      qword ptr [rsp + 0x28], r10
0x180001179: movzx    ecx, word ptr [rax]
0x18000117c: mov      dword ptr [r10 + 8], ecx
0x180001180: lea      rcx, [rip + 0x53f9]
0x180001187: mov      qword ptr [r10 + 0x10], rdx
0x18000118b: mov      dword ptr [r10 + 0xc], 2
0x180001193: movzx    eax, word ptr [rdx]
0x180001196: lea      rdx, [rsp + 0x38]
0x18000119b: mov      dword ptr [r10 + 0x18], eax
0x18000119f: lea      rax, [rip + 0x6057]
0x1800011a6: sub      eax, ecx
0x1800011a8: mov      dword ptr [r10 + 0x1c], 1
0x1800011b0: mov      dword ptr [rsp + 0x30], eax
0x1800011b4: mov      eax, dword ptr [rsp + 0x30]
0x1800011b8: mov      eax, dword ptr [rsp + 0x80]
0x1800011bf: mov      rcx, qword ptr [r11 + 0x20]
0x1800011c3: mov      dword ptr [rsp + 0x20], eax
0x1800011c7: call     qword ptr [rip + 0x8e7a]  ; -> EtwWriteTransfer
0x1800011ce: nop      dword ptr [rax + rax]
0x1800011d3: mov      rcx, qword ptr [rsp + 0x48]
0x1800011d8: xor      rcx, rsp
0x1800011db: call     0x1800041a0
0x1800011e0: add      rsp, 0x58
0x1800011e4: ret      
0x1800011e5: int3     
0x1800011e6: int3     
0x1800011e7: int3     
0x1800011e8: int3     
0x1800011e9: int3     
0x1800011ea: int3     
0x1800011eb: int3     
0x1800011ec: int3     
0x1800011ed: int3     
0x1800011ee: int3     
0x1800011ef: int3     
0x1800011f0: int3     
0x1800011f1: int3     
0x1800011f2: int3     
0x1800011f3: int3     
0x1800011f4: int3     
0x1800011f5: int3     
0x1800011f6: int3     
0x1800011f7: int3     
0x1800011f8: int3     
0x1800011f9: int3     
0x1800011fa: int3     
0x1800011fb: int3     
0x1800011fc: int3     
0x1800011fd: int3     
0x1800011fe: int3     
0x1800011ff: int3     
0x180001200: mov      ecx, 2
0x180001205: int      0x29
0x180001207: int3     
0x180001208: int3     
0x180001209: int3     
0x18000120a: int3     
0x18000120b: int3     
0x18000120c: int3     
0x18000120d: int3     
0x18000120e: int3     
0x18000120f: int3     
0x180001210: mov      qword ptr [rsp + 8], rbx
0x180001215: push     rdi
0x180001216: sub      rsp, 0x20
0x18000121a: mov      rbx, qword ptr [rcx]
0x18000121d: and      qword ptr [rcx], 0
0x180001221: test     rbx, rbx
0x180001224: je       0x180001265
0x180001226: mov      rdi, qword ptr [rbx]
0x180001229: test     rdi, rdi
0x18000122c: je       0x180001251
0x18000122e: mov      rcx, rdi
0x180001231: call     qword ptr [rip + 0x8dd8]  ; -> ExDeleteResourceLite
0x180001238: nop      dword ptr [rax + rax]
0x18000123d: mov      edx, 0x72424e50
0x180001242: mov      rcx, rdi
0x180001245: call     qword ptr [rip + 0x8e0c]  ; -> ExFreePoolWithTag
0x18000124c: nop      dword ptr [rax + rax]
0x180001251: mov      edx, 0x72424e50
0x180001256: mov      rcx, rbx
0x180001259: call     qword ptr [rip + 0x8df8]  ; -> ExFreePoolWithTag
0x180001260: nop      dword ptr [rax + rax]
0x180001265: mov      rbx, qword ptr [rsp + 0x30]
0x18000126a: add      rsp, 0x20
0x18000126e: pop      rdi
0x18000126f: ret      
0x180001270: int3     
0x180001271: int3     
0x180001272: int3     
0x180001273: int3     
0x180001274: int3     
0x180001275: int3     
0x180001276: int3     
0x180001277: int3     
0x180001278: mov      qword ptr [rsp + 0x18], rbx
0x18000127d: push     rdi
0x18000127e: sub      rsp, 0x30
0x180001282: mov      rax, qword ptr [rip + 0x6e77]
0x180001289: xor      rax, rsp
0x18000128c: mov      qword ptr [rsp + 0x28], rax
0x180001291: mov      rdi, rdx
0x180001294: mov      rbx, rcx
0x180001297: call     qword ptr [rip + 0x8d7a]  ; -> KeQueryTimeIncrement
0x18000129e: nop      dword ptr [rax + rax]
0x1800012a3: xor      r9d, r9d
0x1800012a6: lea      rcx, [rsp + 0x20]
0x1800012ab: mov      edx, eax
0x1800012ad: mov      qword ptr [rdi], r9
0x1800012b0: mov      qword ptr [rsp + 0x20], r9
0x1800012b5: call     0x18000133c
0x1800012ba: mov      r8, qword ptr [rbx]
0x1800012bd: mov      rcx, qword ptr [rsp + 0x20]
0x1800012c2: cmp      rcx, r8
0x1800012c5: jl       0x1800012cc
0x1800012c7: sub      rcx, r8
0x1800012ca: jmp      0x1800012dc
0x1800012cc: sub      rcx, r8
0x1800012cf: movabs   rax, 0x7fffffffffffffff
0x1800012d9: add      rcx, rax
0x1800012dc: mov      rax, rdx
0x1800012df: imul     rcx
0x1800012e2: mov      rcx, rax
0x1800012e5: test     rax, rax
0x1800012e8: jns      0x180001329
0x1800012ea: cmp      rdx, -1
0x1800012ee: jne      0x18000132e
0x1800012f0: movabs   rax, 0x346dc5d63886594b
0x1800012fa: imul     rcx
0x1800012fd: sar      rdx, 0xb
0x180001301: mov      rax, rdx
0x180001304: shr      rax, 0x3f
0x180001308: add      rdx, rax
0x18000130b: mov      qword ptr [rdi], rdx
0x18000130e: xor      eax, eax
0x180001310: mov      rcx, qword ptr [rsp + 0x28]
0x180001315: xor      rcx, rsp
0x180001318: call     0x1800041a0
0x18000131d: mov      rbx, qword ptr [rsp + 0x50]
0x180001322: add      rsp, 0x30
0x180001326: pop      rdi
0x180001327: ret      
0x180001328: int3     
0x180001329: test     rdx, rdx
0x18000132c: je       0x1800012f0
0x18000132e: mov      eax, 0xc0000095
0x180001333: jmp      0x180001310
0x180001335: int3     
0x180001336: int3     
0x180001337: int3     
0x180001338: int3     
0x180001339: int3     
0x18000133a: int3     
0x18000133b: int3     
0x18000133c: movabs   rax, qword ptr [0xfffff78000000320]
0x180001346: mov      qword ptr [rcx], rax
0x180001349: ret      
0x18000134a: int3     
0x18000134b: int3     
0x18000134c: int3     
0x18000134d: int3     
0x18000134e: int3     
0x18000134f: int3     
0x180001350: int3     
0x180001351: int3     
0x180001352: int3     
0x180001353: int3     
0x180001354: mov      rax, rsp
0x180001357: mov      qword ptr [rax + 8], rbx
0x18000135b: mov      qword ptr [rax + 0x10], rsi
0x18000135f: mov      qword ptr [rax + 0x18], rdi
0x180001363: push     rbp
0x180001364: lea      rbp, [rax - 0x5f]
0x180001368: sub      rsp, 0xf0
0x18000136f: mov      rax, qword ptr [rip + 0x6d8a]
0x180001376: xor      rax, rsp
0x180001379: mov      qword ptr [rbp + 0x47], rax
0x18000137d: xor      esi, esi
0x18000137f: cmp      word ptr [rip + 0x6e5e], si
0x180001386: mov      ebx, esi
0x180001388: mov      qword ptr [rbp - 0x61], rbx
0x18000138c: je       0x1800013a2
0x18000138e: lea      rdx, [rbp - 0x61]
0x180001392: lea      rcx, [rip + 0x6e4f]
0x180001399: call     0x180001278
0x18000139e: mov      rbx, qword ptr [rbp - 0x61]
0x1800013a2: mov      r8d, dword ptr [rip + 0x6e27]
0x1800013a9: mov      rdx, rsi
0x1800013ac: mov      qword ptr [rbp - 0x61], rdx
0x1800013b0: test     r8d, r8d
0x1800013b3: je       0x1800013d0
0x1800013b5: lea      rdx, [rbp - 0x61]
0x1800013b9: lea      rcx, [rip + 0x6e08]
0x1800013c0: call     0x180001278
0x1800013c5: mov      rdx, qword ptr [rbp - 0x61]
0x1800013c9: mov      r8d, dword ptr [rip + 0x6e00]
0x1800013d0: mov      edi, 0x800
0x1800013d5: test     rbx, rbx
0x1800013d8: jne      0x1800013e3
0x1800013da: test     rdx, rdx
0x1800013dd: je       0x1800014b3
0x1800013e3: cmp      dword ptr [rip + 0x6c5e], 3
0x1800013ea: jbe      0x1800014b3
0x1800013f0: movabs   r9, 0x400000000000
0x1800013fa: test     qword ptr [rip + 0x6c57], r9
0x180001401: je       0x1800014b3
0x180001407: mov      rax, qword ptr [rip + 0x6c52]
0x18000140e: and      rax, r9
0x180001411: cmp      rax, qword ptr [rip + 0x6c48]
0x180001418: jne      0x1800014b3
0x18000141e: movzx    eax, word ptr [rip + 0x6dbf]
0x180001425: lea      rcx, [rip + 0x6c1c]
0x18000142c: mov      word ptr [rbp - 0x69], ax
0x180001430: xor      r9d, r9d
0x180001433: lea      rax, [rbp - 0x51]
0x180001437: mov      qword ptr [rbp - 0x51], rdx
0x18000143b: mov      qword ptr [rbp + 0x37], rax
0x18000143f: lea      rdx, [rip + 0x5718]
0x180001446: lea      rax, [rbp - 0x59]
0x18000144a: mov      dword ptr [rbp - 0x59], r8d
0x18000144e: mov      qword ptr [rbp + 0x27], rax
0x180001452: xor      r8d, r8d
0x180001455: lea      rax, [rbp - 0x49]
0x180001459: mov      qword ptr [rbp - 0x49], rbx
0x18000145d: mov      qword ptr [rbp + 0x17], rax
0x180001461: lea      rax, [rbp - 0x69]
0x180001465: mov      qword ptr [rbp + 7], rax
0x180001469: lea      rax, [rbp - 0x41]
0x18000146d: mov      qword ptr [rbp - 9], rax
0x180001471: lea      rax, [rbp - 0x29]
0x180001475: mov      qword ptr [rsp + 0x28], rax
0x18000147a: mov      dword ptr [rsp + 0x20], 7
0x180001482: mov      qword ptr [rbp - 0x41], rdi
0x180001486: mov      qword ptr [rbp + 0x3f], 8
0x18000148e: mov      qword ptr [rbp + 0x2f], 4
0x180001496: mov      qword ptr [rbp + 0x1f], 8
0x18000149e: mov      qword ptr [rbp + 0xf], 2
0x1800014a6: mov      qword ptr [rbp - 1], 8
0x1800014ae: call     0x18000112c
0x1800014b3: mov      rcx, qword ptr [rip + 0x6d36]
0x1800014ba: test     rcx, rcx
0x1800014bd: je       0x1800014e2
0x1800014bf: mov      r8b, 1
0x1800014c2: xor      r9d, r9d
0x1800014c5: mov      dl, r8b
0x1800014c8: call     qword ptr [rip + 0x8b51]  ; -> ExDeleteTimer
0x1800014cf: nop      dword ptr [rax + rax]
0x1800014d4: mov      qword ptr [rip + 0x6d15], rsi
0x1800014db: mov      word ptr [rip + 0x6d02], si
0x1800014e2: mov      rbx, qword ptr [rip + 0x6cef]
0x1800014e9: test     rbx, rbx
0x1800014ec: je       0x1800015b0
0x1800014f2: cmp      qword ptr [rbx], rsi
0x1800014f5: je       0x180001575
0x1800014f7: mov      rcx, qword ptr [rbx + 8]
0x1800014fb: test     rcx, rcx
0x1800014fe: je       0x180001509
0x180001500: call     0x18000d4e4
0x180001505: mov      qword ptr [rbx + 8], rsi
0x180001509: mov      rcx, qword ptr [rbx]
0x18000150c: call     0x18000d8c8
0x180001511: mov      qword ptr [rbx], rsi
0x180001514: mov      edx, eax
0x180001516: test     eax, eax
0x180001518: jns      0x18000156e
0x18000151a: cmp      dword ptr [rip + 0x6b27], 2
0x180001521: jbe      0x18000156e
0x180001523: movabs   r8, 0x200000000000
0x18000152d: test     qword ptr [rip + 0x6b24], r8
0x180001534: je       0x18000156e
0x180001536: mov      rax, qword ptr [rip + 0x6b23]
0x18000153d: and      rax, r8
0x180001540: cmp      rax, qword ptr [rip + 0x6b19]
0x180001547: jne      0x18000156e
0x180001549: lea      rax, [rbp - 0x61]
0x18000154d: mov      dword ptr [rbp - 0x61], edx
0x180001550: mov      qword ptr [rsp + 0x28], rax
0x180001555: lea      rdx, [rip + 0x55c9]
0x18000155c: lea      rax, [rbp - 0x39]
0x180001560: mov      qword ptr [rbp - 0x39], rdi
0x180001564: mov      qword ptr [rsp + 0x20], rax
0x180001569: call     0x1800010a4
0x18000156e: mov      rbx, qword ptr [rip + 0x6c63]
0x180001575: test     rbx, rbx
0x180001578: je       0x1800015a9
0x18000157a: mov      rcx, qword ptr [rbx + 8]
0x18000157e: test     rcx, rcx
0x180001581: je       0x180001588
0x180001583: call     0x18000d4e4
0x180001588: mov      rcx, qword ptr [rbx]
0x18000158b: test     rcx, rcx
0x18000158e: je       0x180001595
0x180001590: call     0x18000d8c8
0x180001595: mov      edx, 0x72424e50
0x18000159a: mov      rcx, rbx
0x18000159d: call     qword ptr [rip + 0x8ab4]  ; -> ExFreePoolWithTag
0x1800015a4: nop      dword ptr [rax + rax]
0x1800015a9: mov      qword ptr [rip + 0x6c28], rsi
0x1800015b0: mov      rbx, qword ptr [rip + 0x6c41]
0x1800015b7: test     rbx, rbx
0x1800015ba: je       0x1800015fb
0x1800015bc: mov      rdi, qword ptr [rbx]
0x1800015bf: test     rdi, rdi
0x1800015c2: je       0x1800015e7
0x1800015c4: mov      rcx, rdi
0x1800015c7: call     qword ptr [rip + 0x8a42]  ; -> ExDeleteResourceLite
0x1800015ce: nop      dword ptr [rax + rax]
0x1800015d3: mov      edx, 0x72424e50
0x1800015d8: mov      rcx, rdi
0x1800015db: call     qword ptr [rip + 0x8a76]  ; -> ExFreePoolWithTag
0x1800015e2: nop      dword ptr [rax + rax]
0x1800015e7: mov      edx, 0x72424e50
0x1800015ec: mov      rcx, rbx
0x1800015ef: call     qword ptr [rip + 0x8a62]  ; -> ExFreePoolWithTag
0x1800015f6: nop      dword ptr [rax + rax]
0x1800015fb: mov      qword ptr [rip + 0x6bf6], rsi
0x180001602: mov      rcx, qword ptr [rbp + 0x47]
0x180001606: xor      rcx, rsp
0x180001609: call     0x1800041a0
0x18000160e: lea      r11, [rsp + 0xf0]
0x180001616: mov      rbx, qword ptr [r11 + 0x10]
0x18000161a: mov      rsi, qword ptr [r11 + 0x18]
0x18000161e: mov      rdi, qword ptr [r11 + 0x20]
0x180001622: mov      rsp, r11
0x180001625: pop      rbp
0x180001626: ret      
0x180001627: int3     
0x180001628: int3     
0x180001629: int3     
0x18000162a: int3     
0x18000162b: int3     
0x18000162c: int3     
0x18000162d: int3     
0x18000162e: int3     
0x18000162f: int3     
0x180001630: mov      qword ptr [rsp + 8], rbx
0x180001635: push     rdi
0x180001636: sub      rsp, 0x80
0x18000163d: mov      rax, qword ptr [rip + 0x6abc]
0x180001644: xor      rax, rsp
0x180001647: mov      qword ptr [rsp + 0x70], rax
0x18000164c: mov      rbx, qword ptr [rip + 0x6ba5]
0x180001653: mov      rdi, rdx
0x180001656: cmp      qword ptr [rbx], 0
0x18000165a: jne      0x180001661
0x18000165c: call     0x1800038ec
0x180001661: mov      rcx, qword ptr [rbx]
0x180001664: mov      dl, 1
0x180001666: call     qword ptr [rip + 0x899b]  ; -> ExAcquireResourceExclusiveLite
0x18000166d: nop      dword ptr [rax + rax]
0x180001672: mov      rcx, qword ptr [rip + 0x6b5f]
0x180001679: lea      r8, [rip + 0x4bd8]
0x180001680: mov      rbx, qword ptr [rbx]
0x180001683: lea      rdx, [rip + 0x4bf6]
0x18000168a: mov      r9d, 5
0x180001690: call     0x180001f1c
0x180001695: mov      r8d, eax
0x180001698: test     eax, eax
0x18000169a: js       0x180001728
0x1800016a0: cmp      dword ptr [rip + 0x69a1], 4
0x1800016a7: jbe      0x180001785
0x1800016ad: movabs   rdx, 0x200000000000
0x1800016b7: test     qword ptr [rip + 0x699a], rdx
0x1800016be: je       0x180001785
0x1800016c4: mov      rax, qword ptr [rip + 0x6995]
0x1800016cb: and      rax, rdx
0x1800016ce: cmp      rax, qword ptr [rip + 0x698b]
0x1800016d5: jne      0x180001785
0x1800016db: and      dword ptr [rsp + 0x6c], 0
0x1800016e0: lea      rax, [rsp + 0x30]
0x1800016e5: mov      qword ptr [rsp + 0x60], rax
0x1800016ea: lea      rdx, [rip + 0x53ff]
0x1800016f1: lea      rax, [rsp + 0x40]
0x1800016f6: mov      qword ptr [rsp + 0x30], 0x800
0x1800016ff: mov      qword ptr [rsp + 0x28], rax
0x180001704: lea      rcx, [rip + 0x693d]
0x18000170b: xor      r9d, r9d
0x18000170e: mov      dword ptr [rsp + 0x20], 3
0x180001716: xor      r8d, r8d
0x180001719: mov      dword ptr [rsp + 0x68], 8
0x180001721: call     0x18000112c
0x180001726: jmp      0x180001785
0x180001728: cmp      dword ptr [rip + 0x6919], 2
0x18000172f: jbe      0x180001785
0x180001731: movabs   rdx, 0x200000000000
0x18000173b: test     qword ptr [rip + 0x6916], rdx
0x180001742: je       0x180001785
0x180001744: mov      rax, qword ptr [rip + 0x6915]
0x18000174b: and      rax, rdx
0x18000174e: cmp      rax, qword ptr [rip + 0x690b]
0x180001755: jne      0x180001785
0x180001757: lea      rax, [rsp + 0x30]
0x18000175c: mov      dword ptr [rsp + 0x30], r8d
0x180001761: mov      qword ptr [rsp + 0x28], rax
0x180001766: lea      rdx, [rip + 0x5341]
0x18000176d: lea      rax, [rsp + 0x38]
0x180001772: mov      qword ptr [rsp + 0x38], 0x800
0x18000177b: mov      qword ptr [rsp + 0x20], rax
0x180001780: call     0x1800010a4
0x180001785: test     rdi, rdi
0x180001788: je       0x18000179e
0x18000178a: xor      r8d, r8d
0x18000178d: xor      edx, edx
0x18000178f: mov      rcx, rdi
0x180001792: call     qword ptr [rip + 0x888f]  ; -> KeSetEvent
0x180001799: nop      dword ptr [rax + rax]
0x18000179e: test     rbx, rbx
0x1800017a1: je       0x1800017b2
0x1800017a3: mov      rcx, rbx
0x1800017a6: call     qword ptr [rip + 0x8893]  ; -> ExReleaseResourceLite
0x1800017ad: nop      dword ptr [rax + rax]
0x1800017b2: mov      rcx, qword ptr [rsp + 0x70]
0x1800017b7: xor      rcx, rsp
0x1800017ba: call     0x1800041a0
0x1800017bf: mov      rbx, qword ptr [rsp + 0x90]
0x1800017c7: add      rsp, 0x80
0x1800017ce: pop      rdi
0x1800017cf: ret      
0x1800017d0: int3     
0x1800017d1: int3     
0x1800017d2: int3     
0x1800017d3: int3     
0x1800017d4: int3     
0x1800017d5: int3     
0x1800017d6: int3     
0x1800017d7: int3     
0x1800017d8: int3     
0x1800017d9: int3     
0x1800017da: int3     
0x1800017db: int3     
0x1800017dc: int3     
0x1800017dd: int3     
0x1800017de: int3     
0x1800017df: int3     
0x1800017e0: mov      qword ptr [rsp + 8], rbx
0x1800017e5: push     rdi
0x1800017e6: sub      rsp, 0x80
0x1800017ed: mov      rax, qword ptr [rip + 0x690c]
0x1800017f4: xor      rax, rsp
0x1800017f7: mov      qword ptr [rsp + 0x70], rax
0x1800017fc: mov      rbx, qword ptr [rip + 0x69f5]
0x180001803: mov      rdi, rdx
0x180001806: cmp      qword ptr [rbx], 0
0x18000180a: jne      0x180001811
0x18000180c: call     0x1800038ec
0x180001811: mov      rcx, qword ptr [rbx]
0x180001814: mov      dl, 1
0x180001816: call     qword ptr [rip + 0x87eb]  ; -> ExAcquireResourceExclusiveLite
0x18000181d: nop      dword ptr [rax + rax]
0x180001822: mov      rcx, qword ptr [rip + 0x69af]
0x180001829: lea      r8, [rip + 0x4a68]
0x180001830: mov      rbx, qword ptr [rbx]
0x180001833: lea      rdx, [rip + 0x4a46]
0x18000183a: mov      r9d, 5
0x180001840: call     0x180001f1c
0x180001845: mov      r8d, eax
0x180001848: test     eax, eax
0x18000184a: js       0x1800018d8
0x180001850: cmp      dword ptr [rip + 0x67f1], 4
0x180001857: jbe      0x180001935
0x18000185d: movabs   rdx, 0x200000000000
0x180001867: test     qword ptr [rip + 0x67ea], rdx
0x18000186e: je       0x180001935
0x180001874: mov      rax, qword ptr [rip + 0x67e5]
0x18000187b: and      rax, rdx
0x18000187e: cmp      rax, qword ptr [rip + 0x67db]
0x180001885: jne      0x180001935
0x18000188b: and      dword ptr [rsp + 0x6c], 0
0x180001890: lea      rax, [rsp + 0x30]
0x180001895: mov      qword ptr [rsp + 0x60], rax
0x18000189a: lea      rdx, [rip + 0x51d9]
0x1800018a1: lea      rax, [rsp + 0x40]
0x1800018a6: mov      qword ptr [rsp + 0x30], 0x800
0x1800018af: mov      qword ptr [rsp + 0x28], rax
0x1800018b4: lea      rcx, [rip + 0x678d]
0x1800018bb: xor      r9d, r9d
0x1800018be: mov      dword ptr [rsp + 0x20], 3
0x1800018c6: xor      r8d, r8d
0x1800018c9: mov      dword ptr [rsp + 0x68], 8
0x1800018d1: call     0x18000112c
0x1800018d6: jmp      0x180001935
0x1800018d8: cmp      dword ptr [rip + 0x6769], 2
0x1800018df: jbe      0x180001935
0x1800018e1: movabs   rdx, 0x200000000000
0x1800018eb: test     qword ptr [rip + 0x6766], rdx
0x1800018f2: je       0x180001935
0x1800018f4: mov      rax, qword ptr [rip + 0x6765]
0x1800018fb: and      rax, rdx
0x1800018fe: cmp      rax, qword ptr [rip + 0x675b]
0x180001905: jne      0x180001935
0x180001907: lea      rax, [rsp + 0x30]
0x18000190c: mov      dword ptr [rsp + 0x30], r8d
0x180001911: mov      qword ptr [rsp + 0x28], rax
0x180001916: lea      rdx, [rip + 0x511c]
0x18000191d: lea      rax, [rsp + 0x38]
0x180001922: mov      qword ptr [rsp + 0x38], 0x800
0x18000192b: mov      qword ptr [rsp + 0x20], rax
0x180001930: call     0x1800010a4
0x180001935: test     rdi, rdi
0x180001938: je       0x18000194e
0x18000193a: xor      r8d, r8d
0x18000193d: xor      edx, edx
0x18000193f: mov      rcx, rdi
0x180001942: call     qword ptr [rip + 0x86df]  ; -> KeSetEvent
0x180001949: nop      dword ptr [rax + rax]
0x18000194e: test     rbx, rbx
0x180001951: je       0x180001962
0x180001953: mov      rcx, rbx
0x180001956: call     qword ptr [rip + 0x86e3]  ; -> ExReleaseResourceLite
0x18000195d: nop      dword ptr [rax + rax]
0x180001962: mov      rcx, qword ptr [rsp + 0x70]
0x180001967: xor      rcx, rsp
0x18000196a: call     0x1800041a0
0x18000196f: mov      rbx, qword ptr [rsp + 0x90]
0x180001977: add      rsp, 0x80
0x18000197e: pop      rdi
0x18000197f: ret      
0x180001980: int3     
0x180001981: int3     
0x180001982: int3     
0x180001983: int3     
0x180001984: int3     
0x180001985: int3     
0x180001986: int3     
0x180001987: int3     
0x180001988: lea      eax, [rcx - 1]
0x18000198b: ret      
0x18000198c: int3     
0x18000198d: int3     
0x18000198e: int3     
0x18000198f: int3     
0x180001990: int3     
0x180001991: int3     
0x180001992: int3     
0x180001993: int3     
0x180001994: nop      
0x180001996: ret      
0x180001997: int3     
0x180001998: int3     
0x180001999: int3     
0x18000199a: int3     
0x18000199b: int3     
0x18000199c: int3     
0x18000199d: int3     
0x18000199e: int3     
0x18000199f: int3     
0x1800019a0: mov      qword ptr [rsp + 0x10], rbx
0x1800019a5: mov      qword ptr [rsp + 0x18], rsi
0x1800019aa: mov      qword ptr [rsp + 0x20], rdi
0x1800019af: push     r12
0x1800019b1: push     r14
0x1800019b3: push     r15
0x1800019b5: sub      rsp, 0x30
0x1800019b9: mov      rax, qword ptr [rip + 0x6740]
0x1800019c0: xor      rax, rsp
0x1800019c3: mov      qword ptr [rsp + 0x28], rax
0x1800019c8: mov      rbx, rcx
0x1800019cb: lea      r9, [rip + 0x662e]
0x1800019d2: lea      rcx, [rip + 0x47b7]
0x1800019d9: lea      r8, [rip + 0x6620]
0x1800019e0: call     0x180001df0
0x1800019e5: lea      rcx, [rip + 0x665c]
0x1800019ec: call     0x18000cfe4
0x1800019f1: mov      rcx, rbx
0x1800019f4: call     0x180003674
0x1800019f9: mov      edx, 8
0x1800019fe: mov      r14d, 0x72424e50
0x180001a04: mov      r8d, r14d
0x180001a07: lea      r15d, [rdx + 0x38]
0x180001a0b: mov      ecx, r15d
0x180001a0e: call     qword ptr [rip + 0x863b]  ; -> ExAllocatePool2
0x180001a15: nop      dword ptr [rax + rax]
0x180001a1a: lea      r12d, [r15 + 0x28]
0x180001a1e: mov      rdi, rax
0x180001a21: test     rax, rax
0x180001a24: je       0x180001af0
0x180001a2a: and      qword ptr [rax], 0
0x180001a2e: mov      r8d, r14d
0x180001a31: mov      edx, r12d
0x180001a34: mov      qword ptr [rsp + 0x20], rax
0x180001a39: mov      ecx, r15d
0x180001a3c: call     qword ptr [rip + 0x860d]  ; -> ExAllocatePool2
0x180001a43: nop      dword ptr [rax + rax]
0x180001a48: mov      rsi, rax
0x180001a4b: test     rax, rax
0x180001a4e: je       0x180001af6
0x180001a54: mov      rcx, rax
0x180001a57: call     qword ptr [rip + 0x85a2]  ; -> ExInitializeResourceLite
0x180001a5e: nop      dword ptr [rax + rax]
0x180001a63: mov      ebx, eax
0x180001a65: test     eax, eax
0x180001a67: js       0x180001adc
0x180001a69: mov      rbx, qword ptr [rdi]
0x180001a6c: test     rbx, rbx
0x180001a6f: je       0x180001a92
0x180001a71: mov      rcx, rbx
0x180001a74: call     qword ptr [rip + 0x8595]  ; -> ExDeleteResourceLite
0x180001a7b: nop      dword ptr [rax + rax]
0x180001a80: mov      edx, r14d
0x180001a83: mov      rcx, rbx
0x180001a86: call     qword ptr [rip + 0x85cb]  ; -> ExFreePoolWithTag
0x180001a8d: nop      dword ptr [rax + rax]
0x180001a92: mov      r8d, r14d
0x180001a95: mov      qword ptr [rdi], rsi
0x180001a98: mov      edx, 0x10
0x180001a9d: mov      rcx, r15
0x180001aa0: call     qword ptr [rip + 0x85a9]  ; -> ExAllocatePool2
0x180001aa7: nop      dword ptr [rax + rax]
0x180001aac: test     rax, rax
0x180001aaf: je       0x180001ad2
0x180001ab1: and      qword ptr [rax], 0
0x180001ab5: and      qword ptr [rax + 8], 0
0x180001aba: and      qword ptr [rsp + 0x20], 0
0x180001ac0: xor      ebx, ebx
0x180001ac2: mov      qword ptr [rip + 0x670f], rax
0x180001ac9: mov      qword ptr [rip + 0x6728], rdi
0x180001ad0: jmp      0x180001afb
0x180001ad2: and      qword ptr [rip + 0x66fe], 0
0x180001ada: jmp      0x180001af6
0x180001adc: mov      edx, r14d
0x180001adf: mov      rcx, rsi
0x180001ae2: call     qword ptr [rip + 0x856f]  ; -> ExFreePoolWithTag
0x180001ae9: nop      dword ptr [rax + rax]
0x180001aee: jmp      0x180001afb
0x180001af0: and      qword ptr [rsp + 0x20], 0
0x180001af6: mov      ebx, 0xc000009a
0x180001afb: lea      rcx, [rsp + 0x20]
0x180001b00: call     0x180001210
0x180001b05: test     ebx, ebx
0x180001b07: js       0x180001b6e
0x180001b09: call     0x180010008
0x180001b0e: mov      r8d, r14d
0x180001b11: mov      rdx, r12
0x180001b14: mov      rcx, r15
0x180001b17: call     qword ptr [rip + 0x8532]  ; -> ExAllocatePool2
0x180001b1e: nop      dword ptr [rax + rax]
0x180001b23: mov      r8d, r14d
0x180001b26: mov      rdx, r12
0x180001b29: mov      rcx, r15
0x180001b2c: mov      qword ptr [rip + 0x66d5], rax
0x180001b33: call     qword ptr [rip + 0x8516]  ; -> ExAllocatePool2
0x180001b3a: nop      dword ptr [rax + rax]
0x180001b3f: mov      rcx, qword ptr [rip + 0x66c2]
0x180001b46: mov      qword ptr [rip + 0x66b3], rax
0x180001b4d: call     qword ptr [rip + 0x84ac]  ; -> ExInitializeResourceLite
0x180001b54: nop      dword ptr [rax + rax]
0x180001b59: mov      rcx, qword ptr [rip + 0x66a0]
0x180001b60: call     qword ptr [rip + 0x8499]  ; -> ExInitializeResourceLite
0x180001b67: nop      dword ptr [rax + rax]
0x180001b6c: jmp      0x180001ba1
0x180001b6e: call     0x180003ed4
0x180001b73: mov      rcx, qword ptr [rip + 0x64ee]
0x180001b7a: and      qword ptr [rip + 0x64e6], 0
0x180001b82: and      dword ptr [rip + 0x64bf], 0
0x180001b89: call     qword ptr [rip + 0x84e0]  ; -> EtwUnregister
0x180001b90: nop      dword ptr [rax + rax]
0x180001b95: lea      rcx, [rip + 0x6464]
0x180001b9c: call     0x180001e1c
0x180001ba1: mov      eax, ebx
0x180001ba3: mov      rcx, qword ptr [rsp + 0x28]
0x180001ba8: xor      rcx, rsp
0x180001bab: call     0x1800041a0
0x180001bb0: mov      rbx, qword ptr [rsp + 0x58]
0x180001bb5: mov      rsi, qword ptr [rsp + 0x60]
0x180001bba: mov      rdi, qword ptr [rsp + 0x68]
0x180001bbf: add      rsp, 0x30
0x180001bc3: pop      r15
0x180001bc5: pop      r14
0x180001bc7: pop      r12
0x180001bc9: ret      
0x180001bca: int3     
0x180001bcb: int3     
0x180001bcc: int3     
0x180001bcd: int3     
0x180001bce: int3     
0x180001bcf: int3     
0x180001bd0: int3     
0x180001bd1: int3     
0x180001bd2: int3     
0x180001bd3: int3     
0x180001bd4: int3     
0x180001bd5: int3     
0x180001bd6: int3     
0x180001bd7: int3     
0x180001bd8: int3     
0x180001bd9: int3     
0x180001bda: int3     
0x180001bdb: int3     
0x180001bdc: int3     
0x180001bdd: int3     
0x180001bde: int3     
0x180001bdf: int3     
0x180001be0: sub      rsp, 0x28
0x180001be4: mov      rcx, qword ptr [rip + 0x661d]
0x180001beb: mov      dl, 1
0x180001bed: call     qword ptr [rip + 0x8414]  ; -> ExAcquireResourceExclusiveLite
0x180001bf4: nop      dword ptr [rax + rax]
0x180001bf9: jmp      0x180001c07
0x180001bfb: mov      rcx, rax
0x180001bfe: call     0x180002388
0x180001c03: test     eax, eax
0x180001c05: js       0x180001c13
0x180001c07: mov      rax, qword ptr [rip + 0x6602]
0x180001c0e: test     rax, rax
0x180001c11: jne      0x180001bfb
0x180001c13: mov      rcx, qword ptr [rip + 0x65ee]
0x180001c1a: call     qword ptr [rip + 0x841f]  ; -> ExReleaseResourceLite
0x180001c21: nop      dword ptr [rax + rax]
0x180001c26: mov      rcx, qword ptr [rip + 0x65d3]
0x180001c2d: call     qword ptr [rip + 0x83dc]  ; -> ExDeleteResourceLite
0x180001c34: nop      dword ptr [rax + rax]
0x180001c39: mov      rcx, qword ptr [rip + 0x65c8]
0x180001c40: call     qword ptr [rip + 0x83c9]  ; -> ExDeleteResourceLite
0x180001c47: nop      dword ptr [rax + rax]
0x180001c4c: mov      rcx, qword ptr [rip + 0x65ad]
0x180001c53: mov      edx, 0x72424e50
0x180001c58: call     qword ptr [rip + 0x83f9]  ; -> ExFreePoolWithTag
0x180001c5f: nop      dword ptr [rax + rax]
0x180001c64: mov      rcx, qword ptr [rip + 0x659d]
0x180001c6b: mov      edx, 0x72424e50
0x180001c70: call     qword ptr [rip + 0x83e1]  ; -> ExFreePoolWithTag
0x180001c77: nop      dword ptr [rax + rax]
0x180001c7c: and      qword ptr [rip + 0x657c], 0
0x180001c84: and      qword ptr [rip + 0x657c], 0
0x180001c8c: call     0x180001354
0x180001c91: call     0x180003ed4
0x180001c96: mov      rcx, qword ptr [rip + 0x63cb]
0x180001c9d: and      qword ptr [rip + 0x63c3], 0
0x180001ca5: and      dword ptr [rip + 0x639c], 0
0x180001cac: call     qword ptr [rip + 0x83bd]  ; -> EtwUnregister
0x180001cb3: nop      dword ptr [rax + rax]
0x180001cb8: lea      rcx, [rip + 0x6341]
0x180001cbf: call     0x180001e1c
0x180001cc4: xor      eax, eax
0x180001cc6: add      rsp, 0x28
0x180001cca: ret      
0x180001ccb: int3     
0x180001ccc: int3     
0x180001ccd: int3     
0x180001cce: int3     
0x180001ccf: int3     
0x180001cd0: int3     
0x180001cd1: int3     
0x180001cd2: int3     
0x180001cd3: int3     
0x180001cd4: int3     
0x180001cd5: int3     
0x180001cd6: int3     
0x180001cd7: int3     
0x180001cd8: int3     
0x180001cd9: int3     
0x180001cda: int3     
0x180001cdb: int3     
0x180001cdc: int3     
0x180001cdd: int3     
0x180001cde: int3     
0x180001cdf: int3     
0x180001ce0: push     rbx
0x180001ce2: sub      rsp, 0x20
0x180001ce6: mov      r10, qword ptr [rsp + 0x60]
0x180001ceb: xor      ebx, ebx
0x180001ced: test     r10, r10
0x180001cf0: je       0x180001de1
0x180001cf6: test     edx, edx
0x180001cf8: je       0x180001da8
0x180001cfe: cmp      edx, 1
0x180001d01: jne      0x180001de1
0x180001d07: mov      rax, qword ptr [rsp + 0x50]
0x180001d0c: mov      byte ptr [r10 + 0x28], r8b
0x180001d10: mov      r8d, ebx
0x180001d13: mov      qword ptr [r10 + 0x18], rax
0x180001d17: mov      qword ptr [r10 + 0x10], r9
0x180001d1b: mov      dword ptr [r10 + 0x24], edx
0x180001d1f: cmp      bx, word ptr [r10 + 0x2a]
0x180001d24: jae      0x180001de1
0x180001d2a: mov      rax, qword ptr [r10 + 0x38]
0x180001d2e: mov      r9b, byte ptr [r10 + 0x28]
0x180001d32: mov      ecx, r8d
0x180001d35: mov      rdx, qword ptr [rax + rcx*8]
0x180001d39: mov      rax, qword ptr [r10 + 0x40]
0x180001d3d: cmp      byte ptr [rcx + rax], r9b
0x180001d41: jbe      0x180001d48
0x180001d43: test     r9b, r9b
0x180001d46: jne      0x180001d62
0x180001d48: test     rdx, rdx
0x180001d4b: je       0x180001d67
0x180001d4d: test     qword ptr [r10 + 0x10], rdx
0x180001d51: je       0x180001d62
0x180001d53: mov      rcx, qword ptr [r10 + 0x18]
0x180001d57: mov      rax, rcx
0x180001d5a: and      rax, rdx
0x180001d5d: cmp      rax, rcx
0x180001d60: je       0x180001d67
0x180001d62: mov      r9b, bl
0x180001d65: jmp      0x180001d6a
0x180001d67: mov      r9b, 1
0x180001d6a: mov      rax, qword ptr [r10 + 0x30]
0x180001d6e: mov      ecx, r8d
0x180001d71: and      ecx, 0x1f
0x180001d74: mov      edx, 1
0x180001d79: shl      edx, cl
0x180001d7b: mov      ecx, r8d
0x180001d7e: shr      rcx, 5
0x180001d82: lea      r11, [rax + rcx*4]
0x180001d86: mov      eax, dword ptr [r11]
0x180001d89: test     r9b, r9b
0x180001d8c: je       0x180001d92
0x180001d8e: or       edx, eax
0x180001d90: jmp      0x180001d96
0x180001d92: not      edx
0x180001d94: and      edx, eax
0x180001d96: mov      dword ptr [r11], edx
0x180001d99: inc      r8d
0x180001d9c: movzx    eax, word ptr [r10 + 0x2a]
0x180001da1: cmp      r8d, eax
0x180001da4: jb       0x180001d2a
0x180001da6: jmp      0x180001de1
0x180001da8: movzx    eax, word ptr [r10 + 0x2a]
0x180001dad: mov      dword ptr [r10 + 0x24], ebx
0x180001db1: mov      byte ptr [r10 + 0x28], bl
0x180001db5: mov      qword ptr [r10 + 0x10], rbx
0x180001db9: mov      qword ptr [r10 + 0x18], rbx
0x180001dbd: test     ax, ax
0x180001dc0: je       0x180001de1
0x180001dc2: mov      rcx, qword ptr [r10 + 0x30]
0x180001dc6: dec      eax
0x180001dc8: cdq      
0x180001dc9: and      edx, 0x1f
0x180001dcc: add      eax, edx
0x180001dce: xor      edx, edx
0x180001dd0: sar      eax, 5
0x180001dd3: inc      eax
0x180001dd5: movsxd   r8, eax
0x180001dd8: shl      r8, 2
0x180001ddc: call     0x1800045c0
0x180001de1: add      rsp, 0x20
0x180001de5: pop      rbx
0x180001de6: ret      
0x180001de7: int3     
0x180001de8: int3     
0x180001de9: int3     
0x180001dea: int3     
0x180001deb: int3     
0x180001dec: int3     
0x180001ded: int3     
0x180001dee: int3     
0x180001def: int3     
0x180001df0: sub      rsp, 0x28
0x180001df4: xor      eax, eax
0x180001df6: cmp      qword ptr [r9], rax
0x180001df9: jne      0x180001e0e
0x180001dfb: lea      rdx, [rip - 0x122]
0x180001e02: call     qword ptr [rip + 0x8257]  ; -> EtwRegister
0x180001e09: nop      dword ptr [rax + rax]
0x180001e0e: add      rsp, 0x28
0x180001e12: ret      
0x180001e13: int3     
0x180001e14: int3     
0x180001e15: int3     
0x180001e16: int3     
0x180001e17: int3     
0x180001e18: int3     
0x180001e19: int3     
0x180001e1a: int3     
0x180001e1b: int3     
0x180001e1c: push     rbx
0x180001e1e: sub      rsp, 0x20
0x180001e22: mov      rbx, rcx
0x180001e25: mov      rcx, qword ptr [rcx]
0x180001e28: test     rcx, rcx
0x180001e2b: jne      0x180001e31
0x180001e2d: xor      eax, eax
0x180001e2f: jmp      0x180001e41
0x180001e31: call     qword ptr [rip + 0x8238]  ; -> EtwUnregister
0x180001e38: nop      dword ptr [rax + rax]
0x180001e3d: and      qword ptr [rbx], 0
0x180001e41: add      rsp, 0x20
0x180001e45: pop      rbx
0x180001e46: ret      
0x180001e47: int3     
0x180001e48: int3     
0x180001e49: int3     
0x180001e4a: int3     
0x180001e4b: int3     
0x180001e4c: int3     
0x180001e4d: int3     
0x180001e4e: int3     
0x180001e4f: int3     
0x180001e50: push     rbx
0x180001e52: sub      rsp, 0x30
0x180001e56: mov      r11, qword ptr [rcx + 8]
0x180001e5a: xor      eax, eax
0x180001e5c: mov      r10, qword ptr [rsp + 0x60]
0x180001e61: mov      ebx, r9d
0x180001e64: test     r11, r11
0x180001e67: jne      0x180001e71
0x180001e69: mov      qword ptr [r10], rax
0x180001e6c: mov      r9d, eax
0x180001e6f: jmp      0x180001e7d
0x180001e71: mov      qword ptr [r10], r11
0x180001e74: mov      eax, 2
0x180001e79: movzx    r9d, word ptr [r11]
0x180001e7d: mov      dword ptr [r10 + 8], r9d
0x180001e81: xor      r9d, r9d
0x180001e84: mov      dword ptr [r10 + 0xc], eax
0x180001e88: mov      rcx, qword ptr [rcx]
0x180001e8b: mov      qword ptr [rsp + 0x28], r10
0x180001e90: mov      dword ptr [rsp + 0x20], ebx
0x180001e94: call     qword ptr [rip + 0x81ad]  ; -> EtwWriteTransfer
0x180001e9b: nop      dword ptr [rax + rax]
0x180001ea0: add      rsp, 0x30
0x180001ea4: pop      rbx
0x180001ea5: ret      
0x180001ea6: int3     
0x180001ea7: int3     
0x180001ea8: int3     
0x180001ea9: int3     
0x180001eaa: int3     
0x180001eab: int3     
0x180001eac: int3     
0x180001ead: int3     
0x180001eae: int3     
0x180001eaf: int3     
0x180001eb0: mov      r11, rsp
0x180001eb3: mov      dword ptr [r11 + 0x20], r9d
0x180001eb7: sub      rsp, 0x68
0x180001ebb: mov      rax, qword ptr [rip + 0x623e]
0x180001ec2: xor      rax, rsp
0x180001ec5: mov      qword ptr [rsp + 0x50], rax
0x180001eca: lea      rax, [r11 + 0x20]
0x180001ece: mov      r9d, 2
0x180001ed4: mov      qword ptr [r11 - 0x28], rax
0x180001ed8: lea      r8, [rip + 0x42b1]
0x180001edf: and      dword ptr [rsp + 0x4c], 0
0x180001ee4: lea      rax, [r11 - 0x38]
0x180001ee8: lea      rcx, [rip + 0x6111]
0x180001eef: mov      qword ptr [r11 - 0x48], rax
0x180001ef3: mov      dword ptr [rsp + 0x48], 4
0x180001efb: call     0x180001e50
0x180001f00: mov      rcx, qword ptr [rsp + 0x50]
0x180001f05: xor      rcx, rsp
0x180001f08: call     0x1800041a0
0x180001f0d: add      rsp, 0x68
0x180001f11: ret      
0x180001f12: int3     
0x180001f13: int3     
0x180001f14: int3     
0x180001f15: int3     
0x180001f16: int3     
0x180001f17: int3     
0x180001f18: int3     
0x180001f19: int3     
0x180001f1a: int3     
0x180001f1b: int3     
0x180001f1c: push     rbp
0x180001f1e: push     rbx
0x180001f1f: push     rsi
0x180001f20: push     rdi
0x180001f21: push     r14
0x180001f23: lea      rbp, [rsp - 0x50]
0x180001f28: sub      rsp, 0x150
0x180001f2f: mov      rax, qword ptr [rip + 0x61ca]
0x180001f36: xor      rax, rsp
0x180001f39: mov      qword ptr [rbp + 0x40], rax
0x180001f3d: cmp      qword ptr [rcx], 0
0x180001f41: mov      r14d, r9d
0x180001f44: mov      rdi, r8
0x180001f47: mov      rsi, rdx
0x180001f4a: mov      rbx, rcx
0x180001f4d: jne      0x180001f7f
0x180001f4f: lea      rax, [rip + 0xfa]
0x180001f56: mov      qword ptr [rsp + 0x48], 1
0x180001f5f: mov      qword ptr [rsp + 0x50], rax
0x180001f64: lea      rdx, [rsp + 0x48]
0x180001f69: xor      eax, eax
0x180001f6b: mov      r8, rcx
0x180001f6e: and      qword ptr [rcx], rax
0x180001f71: mov      qword ptr [rsp + 0x58], rax
0x180001f76: call     0x18000d6cc
0x180001f7b: test     eax, eax
0x180001f7d: js       0x180001ff2
0x180001f7f: and      dword ptr [rsp + 0x40], 0
0x180001f84: lea      rcx, [rbp - 0x70]
0x180001f88: xor      edx, edx
0x180001f8a: mov      r8d, 0xa8
0x180001f90: call     0x1800045c0
0x180001f95: and      qword ptr [rsp + 0x68], 0
0x180001f9b: lea      rax, [rbp - 0x70]
0x180001f9f: mov      qword ptr [rsp + 0x70], rdi
0x180001fa4: lea      rdi, [rbx + 8]
0x180001fa8: mov      rcx, qword ptr [rdi]
0x180001fab: mov      qword ptr [rsp + 0x78], rax
0x180001fb0: xor      eax, eax
0x180001fb2: mov      dword ptr [rsp + 0x60], 1
0x180001fba: mov      dword ptr [rsp + 0x64], r14d
0x180001fbf: mov      qword ptr [rbp - 0x80], rax
0x180001fc3: test     rcx, rcx
0x180001fc6: je       0x180001fcd
0x180001fc8: call     0x18000d4e4
0x180001fcd: and      qword ptr [rdi], 0
0x180001fd1: lea      rax, [rsp + 0x40]
0x180001fd6: mov      rcx, qword ptr [rbx]
0x180001fd9: lea      rdx, [rsp + 0x60]
0x180001fde: mov      qword ptr [rsp + 0x38], rax
0x180001fe3: mov      qword ptr [rsp + 0x30], rdi
0x180001fe8: mov      qword ptr [rsp + 0x20], rsi
0x180001fed: call     0x18000d11c
0x180001ff2: mov      rcx, qword ptr [rbp + 0x40]
0x180001ff6: xor      rcx, rsp
0x180001ff9: call     0x1800041a0
0x180001ffe: add      rsp, 0x150
0x180002005: pop      r14
0x180002007: pop      rdi
0x180002008: pop      rsi
0x180002009: pop      rbx
0x18000200a: pop      rbp
0x18000200b: ret      
0x18000200c: int3     
0x18000200d: int3     
0x18000200e: int3     
0x18000200f: int3     
0x180002010: int3     
0x180002011: int3     
0x180002012: int3     
0x180002013: int3     
0x180002014: push     rbx
0x180002016: sub      rsp, 0x20
0x18000201a: mov      rbx, rcx
0x18000201d: mov      rcx, qword ptr [rcx + 8]
0x180002021: test     rcx, rcx
0x180002024: jne      0x18000202a
0x180002026: xor      eax, eax
0x180002028: jmp      0x180002034
0x18000202a: call     0x18000d4e4
0x18000202f: and      qword ptr [rbx + 8], 0
0x180002034: add      rsp, 0x20
0x180002038: pop      rbx
0x180002039: ret      
0x18000203a: int3     
0x18000203b: int3     
0x18000203c: int3     
0x18000203d: int3     
0x18000203e: int3     
0x18000203f: int3     
0x180002040: int3     
0x180002041: int3     
0x180002042: int3     
0x180002043: int3     
0x180002044: int3     
0x180002045: int3     
0x180002046: int3     
0x180002047: int3     
0x180002048: int3     
0x180002049: int3     
0x18000204a: int3     
0x18000204b: int3     
0x18000204c: int3     
0x18000204d: int3     
0x18000204e: int3     
0x18000204f: int3     
0x180002050: sub      rsp, 0x28
0x180002054: call     0x1800038ec
0x180002059: add      rsp, 0x28
0x18000205d: ret      
0x18000205e: int3     
0x18000205f: int3     
0x180002060: int3     
0x180002061: int3     
0x180002062: int3     
0x180002063: int3     
0x180002064: int3     
0x180002065: int3     
0x180002066: int3     
0x180002067: int3     
0x180002068: sub      rsp, 0x28
0x18000206c: mov      rcx, qword ptr [rip + 0x6195]
0x180002073: mov      dl, 1
0x180002075: call     qword ptr [rip + 0x7f8c]  ; -> ExAcquireResourceExclusiveLite
0x18000207c: nop      dword ptr [rax + rax]
0x180002081: add      rsp, 0x28
0x180002085: ret      
0x180002086: int3     
0x180002087: int3     
0x180002088: int3     
0x180002089: int3     
0x18000208a: int3     
0x18000208b: int3     
0x18000208c: int3     
0x18000208d: int3     
0x18000208e: int3     
0x18000208f: int3     
0x180002090: mov      qword ptr [rsp + 8], rbx
0x180002095: mov      qword ptr [rsp + 0x10], rsi
0x18000209a: push     rdi
0x18000209b: sub      rsp, 0x20
0x18000209f: mov      esi, edx
0x1800020a1: mov      rdi, rcx
0x1800020a4: mov      rcx, qword ptr [rip + 0x6155]
0x1800020ab: mov      dl, 1
0x1800020ad: call     qword ptr [rip + 0x7f54]  ; -> ExAcquireResourceExclusiveLite
0x1800020b4: nop      dword ptr [rax + rax]
0x1800020b9: xor      eax, eax
0x1800020bb: lock or  dword ptr [rsp], eax
0x1800020bf: cmp      qword ptr [rip + 0x614a], rax
0x1800020c6: jne      0x1800020d2
0x1800020c8: mov      ebx, 0xc000000d
0x1800020cd: jmp      0x180002175
0x1800020d2: cmp      byte ptr [rdi + 0x14], al
0x1800020d5: jne      0x180002130
0x1800020d7: test     byte ptr [rip + 0x60e2], 1
0x1800020de: je       0x1800020ec
0x1800020e0: lea      rdx, [rip + 0x4069]
0x1800020e7: call     0x180002794
0x1800020ec: mov      r9d, esi
0x1800020ef: lea      rdx, [rip + 0x41e2]
0x1800020f6: xor      r8d, r8d
0x1800020f9: mov      rcx, rdi
0x1800020fc: call     0x180001f1c
0x180002101: mov      ecx, eax
0x180002103: mov      ebx, eax
0x180002105: mov      eax, 0xc0000000
0x18000210a: and      ecx, eax
0x18000210c: cmp      ecx, eax
0x18000210e: jne      0x18000212a
0x180002110: test     byte ptr [rip + 0x60a9], 2
0x180002117: je       0x180002175
0x180002119: mov      r9d, ebx
0x18000211c: lea      rdx, [rip + 0x40ad]
0x180002123: call     0x180001eb0
0x180002128: jmp      0x180002175
0x18000212a: mov      byte ptr [rdi + 0x14], 1
0x18000212e: jmp      0x18000213d
0x180002130: mov      rcx, rdi
0x180002133: mov      ebx, 0x80
0x180002138: call     0x1800021a4
0x18000213d: test     byte ptr [rip + 0x607c], 1
0x180002144: je       0x180002155
0x180002146: mov      r9d, esi
0x180002149: lea      rdx, [rip + 0x40a0]
0x180002150: call     0x180001eb0
0x180002155: imul     eax, esi, 0xffffd8f0
0x18000215b: lea      r9, [rdi + 0x58]
0x18000215f: lea      rcx, [rdi + 0x18]
0x180002163: xor      r8d, r8d
0x180002166: movsxd   rdx, eax
0x180002169: call     qword ptr [rip + 0x7f28]  ; -> KeSetTimerEx
0x180002170: nop      dword ptr [rax + rax]
0x180002175: mov      rcx, qword ptr [rip + 0x6084]
0x18000217c: call     qword ptr [rip + 0x7ebd]  ; -> ExReleaseResourceLite
0x180002183: nop      dword ptr [rax + rax]
0x180002188: mov      rsi, qword ptr [rsp + 0x38]
0x18000218d: mov      eax, ebx
0x18000218f: mov      rbx, qword ptr [rsp + 0x30]
0x180002194: add      rsp, 0x20
0x180002198: pop      rdi
0x180002199: ret      
0x18000219a: int3     
0x18000219b: int3     
0x18000219c: int3     
0x18000219d: int3     
0x18000219e: int3     
0x18000219f: int3     
0x1800021a0: int3     
0x1800021a1: int3     
0x1800021a2: int3     
0x1800021a3: int3     
0x1800021a4: push     rbx
0x1800021a6: sub      rsp, 0x30
0x1800021aa: mov      rbx, rcx
0x1800021ad: add      rcx, 0x18
0x1800021b1: call     qword ptr [rip + 0x7ee8]  ; -> KeCancelTimer
0x1800021b8: nop      dword ptr [rax + rax]
0x1800021bd: test     al, al
0x1800021bf: jne      0x18000222e
0x1800021c1: test     byte ptr [rip + 0x5ff8], 1
0x1800021c8: je       0x1800021d6
0x1800021ca: lea      rdx, [rip + 0x3fdf]
0x1800021d1: call     0x180002794
0x1800021d6: mov      rcx, qword ptr [rip + 0x6023]
0x1800021dd: mov      byte ptr [rbx + 0x15], 1
0x1800021e1: call     qword ptr [rip + 0x7e58]  ; -> ExReleaseResourceLite
0x1800021e8: nop      dword ptr [rax + rax]
0x1800021ed: and      qword ptr [rsp + 0x20], 0
0x1800021f3: lea      rcx, [rbx + 0xb8]
0x1800021fa: xor      r9d, r9d
0x1800021fd: xor      r8d, r8d
0x180002200: xor      edx, edx
0x180002202: call     qword ptr [rip + 0x7e9f]  ; -> KeWaitForSingleObject
0x180002209: nop      dword ptr [rax + rax]
0x18000220e: mov      rcx, qword ptr [rip + 0x5feb]
0x180002215: mov      dl, 1
0x180002217: call     qword ptr [rip + 0x7dea]  ; -> ExAcquireResourceExclusiveLite
0x18000221e: nop      dword ptr [rax + rax]
0x180002223: lock or  dword ptr [rsp], 0
0x180002228: mov      byte ptr [rbx + 0x15], 0
0x18000222c: jmp      0x180002243
0x18000222e: test     byte ptr [rip + 0x5f8b], 1
0x180002235: je       0x180002243
0x180002237: lea      rdx, [rip + 0x3f32]
0x18000223e: call     0x180002794
0x180002243: add      rsp, 0x30
0x180002247: pop      rbx
0x180002248: ret      
0x180002249: int3     
0x18000224a: int3     
0x18000224b: int3     
0x18000224c: int3     
0x18000224d: int3     
0x18000224e: int3     
0x18000224f: int3     
0x180002250: mov      qword ptr [rsp + 8], rbx
0x180002255: mov      qword ptr [rsp + 0x10], rsi
0x18000225a: push     rdi
0x18000225b: sub      rsp, 0x20
0x18000225f: mov      rsi, rcx
0x180002262: xor      edi, edi
0x180002264: mov      rcx, qword ptr [rip + 0x5f95]
0x18000226b: mov      dl, 1
0x18000226d: call     qword ptr [rip + 0x7d94]  ; -> ExAcquireResourceExclusiveLite
0x180002274: nop      dword ptr [rax + rax]
0x180002279: lock or  dword ptr [rsp], edi
0x18000227d: test     rsi, rsi
0x180002280: jne      0x18000228c
0x180002282: mov      edi, 0xc0000008
0x180002287: jmp      0x180002354
0x18000228c: mov      rbx, qword ptr [rip + 0x5f7d]
0x180002293: test     rbx, rbx
0x180002296: jne      0x180002347
0x18000229c: test     byte ptr [rip + 0x5f1d], 1
0x1800022a3: je       0x1800022b1
0x1800022a5: lea      rdx, [rip + 0x3ef4]
0x1800022ac: call     0x180002794
0x1800022b1: mov      edx, 0xd0
0x1800022b6: mov      ecx, 0x40
0x1800022bb: mov      r8d, 0x72424e50
0x1800022c1: call     qword ptr [rip + 0x7d88]  ; -> ExAllocatePool2
0x1800022c8: nop      dword ptr [rax + rax]
0x1800022cd: mov      rbx, rax
0x1800022d0: test     rax, rax
0x1800022d3: je       0x18000237a
0x1800022d9: lea      rcx, [rax + 0x16]
0x1800022dd: xor      edx, edx
0x1800022df: mov      r8d, 0xba
0x1800022e5: call     0x1800045c0
0x1800022ea: and      qword ptr [rbx], rdi
0x1800022ed: mov      rcx, rbx
0x1800022f0: and      qword ptr [rbx + 8], rdi
0x1800022f4: and      dword ptr [rbx + 0x10], edi
0x1800022f7: mov      word ptr [rbx + 0x14], di
0x1800022fb: call     0x180002568
0x180002300: mov      ecx, eax
0x180002302: mov      edi, eax
0x180002304: mov      eax, 0xc0000000
0x180002309: and      ecx, eax
0x18000230b: cmp      ecx, eax
0x18000230d: jne      0x180002340
0x18000230f: mov      rcx, qword ptr [rbx + 8]
0x180002313: test     rcx, rcx
0x180002316: je       0x18000231d
0x180002318: call     0x18000d4e4
0x18000231d: mov      rcx, qword ptr [rbx]
0x180002320: test     rcx, rcx
0x180002323: je       0x18000232a
0x180002325: call     0x18000d8c8
0x18000232a: mov      edx, 0x72424e50
0x18000232f: mov      rcx, rbx
0x180002332: call     qword ptr [rip + 0x7d1f]  ; -> ExFreePoolWithTag
0x180002339: nop      dword ptr [rax + rax]
0x18000233e: jmp      0x180002354
0x180002340: mov      qword ptr [rip + 0x5ec9], rbx
0x180002347: inc      dword ptr [rbx + 0x10]
0x18000234a: mov      rax, qword ptr [rip + 0x5ebf]
0x180002351: mov      qword ptr [rsi], rax
0x180002354: mov      rcx, qword ptr [rip + 0x5ea5]
0x18000235b: call     qword ptr [rip + 0x7cde]  ; -> ExReleaseResourceLite
0x180002362: nop      dword ptr [rax + rax]
0x180002367: mov      rbx, qword ptr [rsp + 0x30]
0x18000236c: mov      eax, edi
0x18000236e: mov      rsi, qword ptr [rsp + 0x38]
0x180002373: add      rsp, 0x20
0x180002377: pop      rdi
0x180002378: ret      
0x180002379: int3     
0x18000237a: mov      edi, 0xc0000017
0x18000237f: jmp      0x180002354
0x180002381: int3     
0x180002382: int3     
0x180002383: int3     
0x180002384: int3     
0x180002385: int3     
0x180002386: int3     
0x180002387: int3     
0x180002388: mov      qword ptr [rsp + 8], rbx
0x18000238d: push     rdi
0x18000238e: sub      rsp, 0x20
0x180002392: mov      rbx, rcx
0x180002395: xor      edi, edi
0x180002397: mov      rcx, qword ptr [rip + 0x5e62]
0x18000239e: mov      dl, 1
0x1800023a0: call     qword ptr [rip + 0x7c61]  ; -> ExAcquireResourceExclusiveLite
0x1800023a7: nop      dword ptr [rax + rax]
0x1800023ac: lock or  dword ptr [rsp], edi
0x1800023b0: mov      rax, qword ptr [rip + 0x5e59]
0x1800023b7: test     rax, rax
0x1800023ba: je       0x180002426
0x1800023bc: dec      dword ptr [rax + 0x10]
0x1800023bf: mov      rax, qword ptr [rip + 0x5e4a]
0x1800023c6: cmp      dword ptr [rax + 0x10], edi
0x1800023c9: jne      0x180002426
0x1800023cb: test     byte ptr [rip + 0x5dee], 1
0x1800023d2: je       0x1800023e0
0x1800023d4: lea      rdx, [rip + 0x3e65]
0x1800023db: call     0x180002794
0x1800023e0: mov      rcx, rbx
0x1800023e3: call     0x1800026c0
0x1800023e8: mov      edi, eax
0x1800023ea: test     rbx, rbx
0x1800023ed: je       0x18000241e
0x1800023ef: mov      rcx, qword ptr [rbx + 8]
0x1800023f3: test     rcx, rcx
0x1800023f6: je       0x1800023fd
0x1800023f8: call     0x18000d4e4
0x1800023fd: mov      rcx, qword ptr [rbx]
0x180002400: test     rcx, rcx
0x180002403: je       0x18000240a
0x180002405: call     0x18000d8c8
0x18000240a: mov      edx, 0x72424e50
0x18000240f: mov      rcx, rbx
0x180002412: call     qword ptr [rip + 0x7c3f]  ; -> ExFreePoolWithTag
0x180002419: nop      dword ptr [rax + rax]
0x18000241e: and      qword ptr [rip + 0x5dea], 0
0x180002426: mov      rcx, qword ptr [rip + 0x5dd3]
0x18000242d: call     qword ptr [rip + 0x7c0c]  ; -> ExReleaseResourceLite
0x180002434: nop      dword ptr [rax + rax]
0x180002439: mov      rbx, qword ptr [rsp + 0x30]
0x18000243e: mov      eax, edi
0x180002440: add      rsp, 0x20
0x180002444: pop      rdi
0x180002445: ret      
0x180002446: int3     
0x180002447: int3     
0x180002448: int3     
0x180002449: int3     
0x18000244a: int3     
0x18000244b: int3     
0x18000244c: int3     
0x18000244d: int3     
0x18000244e: int3     
0x18000244f: int3     
0x180002450: xor      r8d, r8d
0x180002453: xor      eax, eax
0x180002455: lock cmpxchg qword ptr [rip + 0x5db2], r8
0x18000245e: test     rdx, rdx
0x180002461: je       0x180002472
0x180002463: test     rax, rax
0x180002466: je       0x180002472
0x180002468: cmp      rcx, rax
0x18000246b: jne      0x180002472
0x18000246d: mov      qword ptr [rdx], rax
0x180002470: jmp      0x180002478
0x180002472: mov      r8d, 0xc0000008
0x180002478: mov      eax, r8d
0x18000247b: ret      
0x18000247c: int3     
0x18000247d: int3     
0x18000247e: int3     
0x18000247f: int3     
0x180002480: int3     
0x180002481: int3     
0x180002482: int3     
0x180002483: int3     
0x180002484: mov      qword ptr [rsp + 8], rbx
0x180002489: push     rdi
0x18000248a: sub      rsp, 0x20
0x18000248e: mov      rdi, rcx
0x180002491: xor      ebx, ebx
0x180002493: mov      rcx, qword ptr [rip + 0x5d66]
0x18000249a: mov      dl, 1
0x18000249c: call     qword ptr [rip + 0x7b65]  ; -> ExAcquireResourceExclusiveLite
0x1800024a3: nop      dword ptr [rax + rax]
0x1800024a8: lock or  dword ptr [rsp], ebx
0x1800024ac: cmp      byte ptr [rdi + 0x14], 1
0x1800024b0: je       0x1800024b7
0x1800024b2: call     0x1800038ec
0x1800024b7: cmp      byte ptr [rdi + 0x15], bl
0x1800024ba: jne      0x180002511
0x1800024bc: test     byte ptr [rip + 0x5cfd], 1
0x1800024c3: je       0x1800024d1
0x1800024c5: lea      rdx, [rip + 0x3d14]
0x1800024cc: call     0x180002794
0x1800024d1: mov      rcx, qword ptr [rdi + 8]
0x1800024d5: test     rcx, rcx
0x1800024d8: je       0x18000250b
0x1800024da: call     0x18000d4e4
0x1800024df: and      qword ptr [rdi + 8], 0
0x1800024e4: mov      ecx, 0xc0000000
0x1800024e9: mov      ebx, eax
0x1800024eb: and      eax, ecx
0x1800024ed: cmp      eax, ecx
0x1800024ef: jne      0x18000250b
0x1800024f1: test     byte ptr [rip + 0x5cc8], 2
0x1800024f8: je       0x18000253e
0x1800024fa: mov      r9d, ebx
0x1800024fd: lea      rdx, [rip + 0x3ccc]
0x180002504: call     0x180001eb0
0x180002509: jmp      0x18000253e
0x18000250b: mov      byte ptr [rdi + 0x14], 0
0x18000250f: jmp      0x18000253e
0x180002511: test     byte ptr [rip + 0x5ca8], 1
0x180002518: je       0x180002526
0x18000251a: lea      rdx, [rip + 0x3c3f]
0x180002521: call     0x180002794
0x180002526: lea      rcx, [rdi + 0xb8]
0x18000252d: xor      r8d, r8d
0x180002530: xor      edx, edx
0x180002532: call     qword ptr [rip + 0x7aef]  ; -> KeSetEvent
0x180002539: nop      dword ptr [rax + rax]
0x18000253e: mov      rcx, qword ptr [rip + 0x5cbb]
0x180002545: call     qword ptr [rip + 0x7af4]  ; -> ExReleaseResourceLite
0x18000254c: nop      dword ptr [rax + rax]
0x180002551: mov      eax, ebx
0x180002553: mov      rbx, qword ptr [rsp + 0x30]
0x180002558: add      rsp, 0x20
0x18000255c: pop      rdi
0x18000255d: ret      
0x18000255e: int3     
0x18000255f: int3     
0x180002560: int3     
0x180002561: int3     
0x180002562: int3     
0x180002563: int3     
0x180002564: int3     
0x180002565: int3     
0x180002566: int3     
0x180002567: int3     
0x180002568: push     rbx
0x18000256a: sub      rsp, 0x40
0x18000256e: mov      rbx, rcx
0x180002571: mov      edx, 1
0x180002576: add      rcx, 0x18
0x18000257a: call     qword ptr [rip + 0x7af7]  ; -> KeInitializeTimerEx
0x180002581: nop      dword ptr [rax + rax]
0x180002586: lea      rcx, [rbx + 0x58]
0x18000258a: mov      r8, rbx
0x18000258d: lea      rdx, [rip + 0xbc]
0x180002594: call     qword ptr [rip + 0x7ae5]  ; -> KeInitializeDpc
0x18000259b: nop      dword ptr [rax + rax]
0x1800025a0: xor      r8d, r8d
0x1800025a3: lea      rcx, [rbx + 0xb8]
0x1800025aa: lea      edx, [r8 + 1]
0x1800025ae: call     qword ptr [rip + 0x7ad3]  ; -> KeInitializeEvent
0x1800025b5: nop      dword ptr [rax + rax]
0x1800025ba: xor      ecx, ecx
0x1800025bc: lea      rax, [rip + 0xbd]
0x1800025c3: mov      word ptr [rbx + 0x14], cx
0x1800025c7: mov      qword ptr [rbx + 0xa0], rcx
0x1800025ce: mov      qword ptr [rbx + 0xa8], rax
0x1800025d5: mov      qword ptr [rbx + 0xb0], rbx
0x1800025dc: mov      qword ptr [rbx + 0x98], rcx
0x1800025e3: cmp      qword ptr [rbx], rcx
0x1800025e6: jne      0x18000263d
0x1800025e8: lea      rax, [rip - 0x59f]
0x1800025ef: mov      qword ptr [rsp + 0x20], 1
0x1800025f8: mov      qword ptr [rsp + 0x28], rax
0x1800025fd: lea      rdx, [rsp + 0x20]
0x180002602: xor      eax, eax
0x180002604: mov      qword ptr [rbx], rcx
0x180002607: mov      r8, rbx
0x18000260a: mov      qword ptr [rsp + 0x30], rax
0x18000260f: call     0x18000d6cc
0x180002614: mov      edx, 0xc0000000
0x180002619: mov      ebx, eax
0x18000261b: mov      ecx, eax
0x18000261d: and      eax, edx
0x18000261f: cmp      eax, edx
0x180002621: jne      0x18000263d
0x180002623: test     byte ptr [rip + 0x5b96], 2
0x18000262a: je       0x18000263d
0x18000262c: mov      r9d, ecx
0x18000262f: lea      rdx, [rip + 0x3bca]
0x180002636: call     0x180001eb0
0x18000263b: mov      ecx, ebx
0x18000263d: mov      eax, ecx
0x18000263f: add      rsp, 0x40
0x180002643: pop      rbx
0x180002644: ret      
0x180002645: int3     
0x180002646: int3     
0x180002647: int3     
0x180002648: int3     
0x180002649: int3     
0x18000264a: int3     
0x18000264b: int3     
0x18000264c: int3     
0x18000264d: int3     
0x18000264e: int3     
0x18000264f: int3     
0x180002650: sub      rsp, 0x28
0x180002654: test     rdx, rdx
0x180002657: je       0x18000266e
0x180002659: lea      rcx, [rdx + 0x98]
0x180002660: xor      edx, edx
0x180002662: call     qword ptr [rip + 0x7a27]  ; -> ExQueueWorkItem
0x180002669: nop      dword ptr [rax + rax]
0x18000266e: add      rsp, 0x28
0x180002672: ret      
0x180002673: int3     
0x180002674: int3     
0x180002675: int3     
0x180002676: int3     
0x180002677: int3     
0x180002678: int3     
0x180002679: int3     
0x18000267a: int3     
0x18000267b: int3     
0x18000267c: int3     
0x18000267d: int3     
0x18000267e: int3     
0x18000267f: int3     
0x180002680: sub      rsp, 0x28
0x180002684: test     rcx, rcx
0x180002687: je       0x18000268e
0x180002689: call     0x180002484
0x18000268e: add      rsp, 0x28
0x180002692: ret      
0x180002693: int3     
0x180002694: int3     
0x180002695: int3     
0x180002696: int3     
0x180002697: int3     
0x180002698: int3     
0x180002699: int3     
0x18000269a: int3     
0x18000269b: int3     
0x18000269c: sub      rsp, 0x28
0x1800026a0: mov      rcx, qword ptr [rip + 0x5b61]
0x1800026a7: call     qword ptr [rip + 0x7992]  ; -> ExReleaseResourceLite
0x1800026ae: nop      dword ptr [rax + rax]
0x1800026b3: add      rsp, 0x28
0x1800026b7: ret      
0x1800026b8: int3     
0x1800026b9: int3     
0x1800026ba: int3     
0x1800026bb: int3     
0x1800026bc: int3     
0x1800026bd: int3     
0x1800026be: int3     
0x1800026bf: int3     
0x1800026c0: mov      qword ptr [rsp + 8], rbx
0x1800026c5: mov      qword ptr [rsp + 0x10], rbp
0x1800026ca: mov      qword ptr [rsp + 0x18], rsi
0x1800026cf: push     rdi
0x1800026d0: sub      rsp, 0x20
0x1800026d4: xor      ebx, ebx
0x1800026d6: mov      rdi, rcx
0x1800026d9: mov      ebp, 0xc0000000
0x1800026de: cmp      byte ptr [rcx + 0x14], bl
0x1800026e1: je       0x180002730
0x1800026e3: call     0x1800021a4
0x1800026e8: test     byte ptr [rip + 0x5ad1], 1
0x1800026ef: je       0x1800026fd
0x1800026f1: lea      rdx, [rip + 0x3ae8]
0x1800026f8: call     0x180002794
0x1800026fd: mov      rcx, qword ptr [rdi + 8]
0x180002701: test     rcx, rcx
0x180002704: je       0x18000272d
0x180002706: call     0x18000d4e4
0x18000270b: mov      r9d, eax
0x18000270e: mov      qword ptr [rdi + 8], rbx
0x180002712: and      eax, ebp
0x180002714: cmp      eax, ebp
0x180002716: jne      0x18000272d
0x180002718: test     byte ptr [rip + 0x5aa1], 2
0x18000271f: je       0x18000272d
0x180002721: lea      rdx, [rip + 0x3aa8]
0x180002728: call     0x180001eb0
0x18000272d: mov      byte ptr [rdi + 0x14], bl
0x180002730: cmp      qword ptr [rdi], rbx
0x180002733: je       0x180002774
0x180002735: mov      rcx, qword ptr [rdi + 8]
0x180002739: test     rcx, rcx
0x18000273c: je       0x180002747
0x18000273e: call     0x18000d4e4
0x180002743: mov      qword ptr [rdi + 8], rbx
0x180002747: mov      rcx, qword ptr [rdi]
0x18000274a: call     0x18000d8c8
0x18000274f: mov      qword ptr [rdi], rbx
0x180002752: mov      esi, eax
0x180002754: mov      ebx, eax
0x180002756: and      eax, ebp
0x180002758: cmp      eax, ebp
0x18000275a: jne      0x180002774
0x18000275c: test     byte ptr [rip + 0x5a5d], 2
0x180002763: je       0x180002774
0x180002765: mov      r9d, ebx
0x180002768: lea      rdx, [rip + 0x3ac1]
0x18000276f: call     0x180001eb0
0x180002774: mov      rbp, qword ptr [rsp + 0x38]
0x180002779: mov      eax, ebx
0x18000277b: mov      rbx, qword ptr [rsp + 0x30]
0x180002780: mov      rsi, qword ptr [rsp + 0x40]
0x180002785: add      rsp, 0x20
0x180002789: pop      rdi
0x18000278a: ret      
0x18000278b: int3     
0x18000278c: int3     
0x18000278d: int3     
0x18000278e: int3     
0x18000278f: int3     
0x180002790: int3     
0x180002791: int3     
0x180002792: int3     
0x180002793: int3     
0x180002794: sub      rsp, 0x58
0x180002798: mov      rax, qword ptr [rip + 0x5961]
0x18000279f: xor      rax, rsp
0x1800027a2: mov      qword ptr [rsp + 0x40], rax
0x1800027a7: lea      rax, [rsp + 0x30]
0x1800027ac: mov      r9d, 1
0x1800027b2: lea      r8, [rip + 0x39d7]
0x1800027b9: mov      qword ptr [rsp + 0x20], rax
0x1800027be: lea      rcx, [rip + 0x583b]
0x1800027c5: call     0x180001e50
0x1800027ca: mov      rcx, qword ptr [rsp + 0x40]
0x1800027cf: xor      rcx, rsp
0x1800027d2: call     0x1800041a0
0x1800027d7: add      rsp, 0x58
0x1800027db: ret      
0x1800027dc: int3     
0x1800027dd: int3     
0x1800027de: int3     
0x1800027df: int3     
0x1800027e0: int3     
0x1800027e1: int3     
0x1800027e2: int3     
0x1800027e3: int3     
0x1800027e4: xor      r8d, r8d
0x1800027e7: lea      r9, [rdx + 0x10]
0x1800027eb: mov      r10, rcx
0x1800027ee: sub      r10, rdx
0x1800027f1: mov      eax, r8d
0x1800027f4: cmp      rax, qword ptr [rcx]
0x1800027f7: jae      0x180002816
0x1800027f9: mov      rax, qword ptr [r10 + r9]
0x1800027fd: inc      r8d
0x180002800: mov      qword ptr [r9], rax
0x180002803: mov      rax, qword ptr [r10 + r9 - 8]
0x180002808: mov      qword ptr [r9 - 8], rax
0x18000280c: add      r9, 0x10
0x180002810: cmp      r8d, 0xa
0x180002814: jb       0x1800027f1
0x180002816: mov      dword ptr [rdx], r8d
0x180002819: ret      
0x18000281a: int3     
0x18000281b: int3     
0x18000281c: int3     
0x18000281d: int3     
0x18000281e: int3     
0x18000281f: int3     
0x180002820: int3     
0x180002821: int3     
0x180002822: int3     
0x180002823: int3     
0x180002824: mov      eax, 1
0x180002829: test     rcx, rcx
0x18000282c: je       0x180002848
0x18000282e: mov      edx, dword ptr [rcx]
0x180002830: cmp      edx, eax
0x180002832: je       0x18000284a
0x180002834: cmp      edx, 2
0x180002837: jne      0x180002848
0x180002839: mov      rcx, qword ptr [rcx + 0x20]
0x18000283d: test     rcx, rcx
0x180002840: je       0x18000284a
0x180002842: cmp      qword ptr [rcx], 8
0x180002846: jb       0x18000284a
0x180002848: xor      al, al
0x18000284a: ret      
0x18000284b: int3     
0x18000284c: int3     
0x18000284d: int3     
0x18000284e: int3     
0x18000284f: int3     
0x180002850: int3     
0x180002851: int3     
0x180002852: int3     
0x180002853: int3     
0x180002854: mov      qword ptr [rsp + 8], rbx
0x180002859: mov      qword ptr [rsp + 0x10], rsi
0x18000285e: push     rdi
0x18000285f: sub      rsp, 0x20
0x180002863: lea      rdi, [rcx + 8]
0x180002867: mov      rbx, rcx
0x18000286a: mov      rcx, rdi
0x18000286d: mov      rsi, rdx
0x180002870: call     qword ptr [rip + 0x7861]  ; -> ExAcquireRundownProtection
0x180002877: nop      dword ptr [rax + rax]
0x18000287c: test     al, al
0x18000287e: jne      0x180002887
0x180002880: mov      ebx, 0xc0000189
0x180002885: jmp      0x1800028b5
0x180002887: mov      dword ptr [rsi + 0x2c], 6
0x18000288e: mov      r8d, 0x320
0x180002894: mov      rax, qword ptr [rbx + 0x28]
0x180002898: mov      rdx, rsi
0x18000289b: mov      rcx, qword ptr [rbx + 0x18]
0x18000289f: call     0x1800041e0
0x1800028a4: mov      rcx, rdi
0x1800028a7: mov      ebx, eax
0x1800028a9: call     qword ptr [rip + 0x7830]  ; -> ExReleaseRundownProtection
0x1800028b0: nop      dword ptr [rax + rax]
0x1800028b5: mov      rsi, qword ptr [rsp + 0x38]
0x1800028ba: mov      eax, ebx
0x1800028bc: mov      rbx, qword ptr [rsp + 0x30]
0x1800028c1: add      rsp, 0x20
0x1800028c5: pop      rdi
0x1800028c6: ret      
0x1800028c7: int3     
0x1800028c8: int3     
0x1800028c9: int3     
0x1800028ca: int3     
0x1800028cb: int3     
0x1800028cc: int3     
0x1800028cd: int3     
0x1800028ce: int3     
0x1800028cf: int3     
0x1800028d0: sub      rsp, 0x28
0x1800028d4: call     qword ptr [rip + 0x781d]  ; -> KeResetEvent
0x1800028db: nop      dword ptr [rax + rax]
0x1800028e0: add      rsp, 0x28
0x1800028e4: ret      
0x1800028e5: int3     
0x1800028e6: int3     
0x1800028e7: int3     
0x1800028e8: int3     
0x1800028e9: int3     
0x1800028ea: int3     
0x1800028eb: int3     
0x1800028ec: mov      dword ptr [rsp + 0x20], r9d
0x1800028f1: mov      dword ptr [rsp + 0x18], r8d
0x1800028f6: push     rbp
0x1800028f7: lea      rbp, [rsp - 0x3f]
0x1800028fc: sub      rsp, 0xb0
0x180002903: mov      rax, qword ptr [rip + 0x57f6]
0x18000290a: xor      rax, rsp
0x18000290d: mov      qword ptr [rbp + 0x2f], rax
0x180002911: xor      r8d, r8d
0x180002914: mov      dword ptr [rbp - 0x41], 2
0x18000291b: lea      rax, [rbp + 0x5f]
0x18000291f: mov      qword ptr [rbp - 0x19], 4
0x180002927: mov      qword ptr [rbp - 0x21], rax
0x18000292b: lea      rcx, [rip + 0x574e]
0x180002932: lea      rax, [rbp + 0x67]
0x180002936: mov      qword ptr [rbp - 9], 4
0x18000293e: mov      qword ptr [rbp - 0x11], rax
0x180002942: lea      r9d, [r8 + 6]
0x180002946: lea      rax, [rbp - 0x41]
0x18000294a: mov      qword ptr [rbp + 7], 4
0x180002952: mov      qword ptr [rbp - 1], rax
0x180002956: lea      rax, [rbp + 0x77]
0x18000295a: mov      qword ptr [rbp + 0xf], rax
0x18000295e: mov      rax, qword ptr [rbp + 0x7f]
0x180002962: mov      qword ptr [rbp + 0x1f], rax
0x180002966: mov      eax, dword ptr [rbp + 0x77]
0x180002969: add      eax, eax
0x18000296b: mov      qword ptr [rbp + 0x17], 4
0x180002973: mov      dword ptr [rbp + 0x27], eax
0x180002976: lea      rax, [rbp - 0x31]
0x18000297a: mov      qword ptr [rsp + 0x20], rax
0x18000297f: mov      dword ptr [rbp + 0x2b], r8d
0x180002983: call     0x180001e50
0x180002988: mov      rcx, qword ptr [rbp + 0x2f]
0x18000298c: xor      rcx, rsp
0x18000298f: call     0x1800041a0
0x180002994: add      rsp, 0xb0
0x18000299b: pop      rbp
0x18000299c: ret      
0x18000299d: int3     
0x18000299e: int3     
0x18000299f: int3     
0x1800029a0: int3     
0x1800029a1: int3     
0x1800029a2: int3     
0x1800029a3: int3     
0x1800029a4: mov      dword ptr [rsp + 0x20], r9d
0x1800029a9: mov      dword ptr [rsp + 0x18], r8d
0x1800029ae: push     rbp
0x1800029af: lea      rbp, [rsp - 0x30]
0x1800029b4: sub      rsp, 0x130
0x1800029bb: mov      rax, qword ptr [rip + 0x573e]
0x1800029c2: xor      rax, rsp
0x1800029c5: mov      qword ptr [rbp + 0x20], rax
0x1800029c9: xor      edx, edx
0x1800029cb: mov      dword ptr [rsp + 0x30], 2
0x1800029d3: lea      rax, [rbp + 0x50]
0x1800029d7: mov      dword ptr [rsp + 0x7c], edx
0x1800029db: mov      qword ptr [rsp + 0x50], rax
0x1800029e0: lea      rcx, [rip + 0x5699]
0x1800029e7: lea      rax, [rbp + 0x58]
0x1800029eb: mov      dword ptr [rbp - 0x64], edx
0x1800029ee: mov      qword ptr [rsp + 0x60], rax
0x1800029f3: xor      r8d, r8d
0x1800029f6: mov      rax, qword ptr [rbp + 0x60]
0x1800029fa: mov      qword ptr [rsp + 0x70], rax
0x1800029ff: lea      eax, [r9 + r9]
0x180002a03: mov      dword ptr [rsp + 0x78], eax
0x180002a07: lea      r9d, [rdx + 0xe]
0x180002a0b: lea      rax, [rbp + 0x68]
0x180002a0f: mov      dword ptr [rbp + 0x1c], edx
0x180002a12: mov      qword ptr [rbp - 0x80], rax
0x180002a16: lea      rdx, [rip + 0x38db]
0x180002a1d: mov      rax, qword ptr [rbp + 0x70]
0x180002a21: mov      qword ptr [rbp - 0x70], rax
0x180002a25: mov      eax, dword ptr [rbp + 0x68]
0x180002a28: add      eax, eax
0x180002a2a: mov      qword ptr [rsp + 0x58], 4
0x180002a33: mov      dword ptr [rbp - 0x68], eax
0x180002a36: lea      rax, [rbp + 0x78]
0x180002a3a: mov      qword ptr [rbp - 0x60], rax
0x180002a3e: lea      rax, [rbp + 0x80]
0x180002a45: mov      qword ptr [rbp - 0x50], rax
0x180002a49: lea      rax, [rbp + 0x88]
0x180002a50: mov      qword ptr [rbp - 0x40], rax
0x180002a54: lea      rax, [rbp + 0x90]
0x180002a5b: mov      qword ptr [rbp - 0x30], rax
0x180002a5f: lea      rax, [rbp + 0x98]
0x180002a66: mov      qword ptr [rbp - 0x20], rax
0x180002a6a: lea      rax, [rsp + 0x30]
0x180002a6f: mov      qword ptr [rbp - 0x10], rax
0x180002a73: lea      rax, [rbp + 0xa8]
0x180002a7a: mov      qword ptr [rbp], rax
0x180002a7e: mov      rax, qword ptr [rbp + 0xb0]
0x180002a85: mov      qword ptr [rbp + 0x10], rax
0x180002a89: mov      eax, dword ptr [rbp + 0xa8]
0x180002a8f: add      eax, eax
0x180002a91: mov      qword ptr [rsp + 0x68], 4
0x180002a9a: mov      dword ptr [rbp + 0x18], eax
0x180002a9d: lea      rax, [rsp + 0x40]
0x180002aa2: mov      qword ptr [rsp + 0x20], rax
0x180002aa7: mov      qword ptr [rbp - 0x78], 4
0x180002aaf: mov      qword ptr [rbp - 0x58], 4
0x180002ab7: mov      qword ptr [rbp - 0x48], 4
0x180002abf: mov      qword ptr [rbp - 0x38], 4
0x180002ac7: mov      qword ptr [rbp - 0x28], 4
0x180002acf: mov      qword ptr [rbp - 0x18], 8
0x180002ad7: mov      qword ptr [rbp - 8], 4
0x180002adf: mov      qword ptr [rbp + 8], 4
0x180002ae7: call     0x180001e50
0x180002aec: mov      rcx, qword ptr [rbp + 0x20]
0x180002af0: xor      rcx, rsp
0x180002af3: call     0x1800041a0
0x180002af8: add      rsp, 0x130
0x180002aff: pop      rbp
0x180002b00: ret      
0x180002b01: int3     
0x180002b02: int3     
0x180002b03: int3     
0x180002b04: int3     
0x180002b05: int3     
0x180002b06: int3     
0x180002b07: int3     
0x180002b08: mov      dword ptr [rsp + 0x20], r9d
0x180002b0d: mov      dword ptr [rsp + 0x18], r8d
0x180002b12: push     rbp
0x180002b13: lea      rbp, [rsp - 0x60]
0x180002b18: sub      rsp, 0x160
0x180002b1f: mov      rax, qword ptr [rip + 0x55da]
0x180002b26: xor      rax, rsp
0x180002b29: mov      qword ptr [rbp + 0x50], rax
0x180002b2d: xor      edx, edx
0x180002b2f: mov      dword ptr [rsp + 0x30], 2
0x180002b37: lea      rax, [rbp + 0x80]
0x180002b3e: mov      dword ptr [rsp + 0x7c], edx
0x180002b42: mov      qword ptr [rsp + 0x50], rax
0x180002b47: lea      rcx, [rip + 0x5532]
0x180002b4e: lea      rax, [rbp + 0x88]
0x180002b55: mov      dword ptr [rbp - 0x64], edx
0x180002b58: mov      qword ptr [rsp + 0x60], rax
0x180002b5d: xor      r8d, r8d
0x180002b60: mov      rax, qword ptr [rbp + 0x90]
0x180002b67: mov      qword ptr [rsp + 0x70], rax
0x180002b6c: lea      eax, [r9 + r9]
0x180002b70: mov      dword ptr [rsp + 0x78], eax
0x180002b74: lea      r9d, [rdx + 0x11]
0x180002b78: lea      rax, [rbp + 0x98]
0x180002b7f: mov      dword ptr [rbp + 0x3c], edx
0x180002b82: mov      qword ptr [rbp - 0x80], rax
0x180002b86: lea      rdx, [rip + 0x378b]
0x180002b8d: mov      rax, qword ptr [rbp + 0xa0]
0x180002b94: mov      qword ptr [rbp - 0x70], rax
0x180002b98: mov      eax, dword ptr [rbp + 0x98]
0x180002b9e: add      eax, eax
0x180002ba0: mov      qword ptr [rsp + 0x58], 4
0x180002ba9: mov      dword ptr [rbp - 0x68], eax
0x180002bac: lea      rax, [rbp + 0xa8]
0x180002bb3: mov      qword ptr [rbp - 0x60], rax
0x180002bb7: lea      rax, [rbp + 0xb0]
0x180002bbe: mov      qword ptr [rbp - 0x50], rax
0x180002bc2: lea      rax, [rbp + 0xb8]
0x180002bc9: mov      qword ptr [rbp - 0x40], rax
0x180002bcd: lea      rax, [rbp + 0xc0]
0x180002bd4: mov      qword ptr [rbp - 0x30], rax
0x180002bd8: lea      rax, [rbp + 0xc8]
0x180002bdf: mov      qword ptr [rbp - 0x20], rax
0x180002be3: lea      rax, [rbp + 0xd0]
0x180002bea: mov      qword ptr [rbp - 0x10], rax
0x180002bee: lea      rax, [rbp + 0xd8]
0x180002bf5: mov      qword ptr [rbp], rax
0x180002bf9: lea      rax, [rsp + 0x30]
0x180002bfe: mov      qword ptr [rbp + 0x10], rax
0x180002c02: lea      rax, [rbp + 0xe8]
0x180002c09: mov      qword ptr [rbp + 0x20], rax
0x180002c0d: mov      rax, qword ptr [rbp + 0xf0]
0x180002c14: mov      qword ptr [rbp + 0x30], rax
0x180002c18: mov      eax, dword ptr [rbp + 0xe8]
0x180002c1e: add      eax, eax
0x180002c20: mov      qword ptr [rsp + 0x68], 4
0x180002c29: mov      dword ptr [rbp + 0x38], eax
0x180002c2c: lea      rax, [rbp + 0xf8]
0x180002c33: mov      qword ptr [rbp + 0x40], rax
0x180002c37: lea      rax, [rsp + 0x40]
0x180002c3c: mov      qword ptr [rsp + 0x20], rax
0x180002c41: mov      qword ptr [rbp - 0x78], 4
0x180002c49: mov      qword ptr [rbp - 0x58], 4
0x180002c51: mov      qword ptr [rbp - 0x48], 4
0x180002c59: mov      qword ptr [rbp - 0x38], 4
0x180002c61: mov      qword ptr [rbp - 0x28], 8
0x180002c69: mov      qword ptr [rbp - 0x18], 4
0x180002c71: mov      qword ptr [rbp - 8], 8
0x180002c79: mov      qword ptr [rbp + 8], 4
0x180002c81: mov      qword ptr [rbp + 0x18], 4
0x180002c89: mov      qword ptr [rbp + 0x28], 4
0x180002c91: mov      qword ptr [rbp + 0x48], 4
0x180002c99: call     0x180001e50
0x180002c9e: mov      rcx, qword ptr [rbp + 0x50]
0x180002ca2: xor      rcx, rsp
0x180002ca5: call     0x1800041a0
0x180002caa: add      rsp, 0x160
0x180002cb1: pop      rbp
0x180002cb2: ret      
0x180002cb3: int3     
0x180002cb4: int3     
0x180002cb5: int3     
0x180002cb6: int3     
0x180002cb7: int3     
0x180002cb8: int3     
0x180002cb9: int3     
0x180002cba: int3     
0x180002cbb: int3     
0x180002cbc: mov      dword ptr [rsp + 0x20], r9d
0x180002cc1: mov      dword ptr [rsp + 0x18], r8d
0x180002cc6: push     rbp
0x180002cc7: lea      rbp, [rsp - 0x40]
0x180002ccc: sub      rsp, 0x140
0x180002cd3: mov      rax, qword ptr [rip + 0x5426]
0x180002cda: xor      rax, rsp
0x180002cdd: mov      qword ptr [rbp + 0x30], rax
0x180002ce1: xor      edx, edx
0x180002ce3: mov      dword ptr [rsp + 0x30], 2
0x180002ceb: lea      rax, [rbp + 0x60]
0x180002cef: mov      dword ptr [rsp + 0x7c], edx
0x180002cf3: mov      qword ptr [rsp + 0x50], rax
0x180002cf8: lea      rcx, [rip + 0x5381]
0x180002cff: lea      rax, [rbp + 0x68]
0x180002d03: mov      dword ptr [rbp - 0x64], edx
0x180002d06: mov      qword ptr [rsp + 0x60], rax
0x180002d0b: xor      r8d, r8d
0x180002d0e: mov      rax, qword ptr [rbp + 0x70]
0x180002d12: mov      qword ptr [rsp + 0x70], rax
0x180002d17: lea      eax, [r9 + r9]
0x180002d1b: mov      dword ptr [rsp + 0x78], eax
0x180002d1f: lea      r9d, [rdx + 0xf]
0x180002d23: lea      rax, [rbp + 0x78]
0x180002d27: mov      dword ptr [rbp + 0x1c], edx
0x180002d2a: mov      qword ptr [rbp - 0x80], rax
0x180002d2e: lea      rdx, [rip + 0x3603]
0x180002d35: mov      rax, qword ptr [rbp + 0x80]
0x180002d3c: mov      qword ptr [rbp - 0x70], rax
0x180002d40: mov      eax, dword ptr [rbp + 0x78]
0x180002d43: add      eax, eax
0x180002d45: mov      qword ptr [rsp + 0x58], 4
0x180002d4e: mov      dword ptr [rbp - 0x68], eax
0x180002d51: lea      rax, [rbp + 0x88]
0x180002d58: mov      qword ptr [rbp - 0x60], rax
0x180002d5c: lea      rax, [rbp + 0x90]
0x180002d63: mov      qword ptr [rbp - 0x50], rax
0x180002d67: lea      rax, [rbp + 0x98]
0x180002d6e: mov      qword ptr [rbp - 0x40], rax
0x180002d72: lea      rax, [rbp + 0xa0]
0x180002d79: mov      qword ptr [rbp - 0x30], rax
0x180002d7d: lea      rax, [rbp + 0xa8]
0x180002d84: mov      qword ptr [rbp - 0x20], rax
0x180002d88: lea      rax, [rsp + 0x30]
0x180002d8d: mov      qword ptr [rbp - 0x10], rax
0x180002d91: lea      rax, [rbp + 0xb8]
0x180002d98: mov      qword ptr [rbp], rax
0x180002d9c: mov      rax, qword ptr [rbp + 0xc0]
0x180002da3: mov      qword ptr [rbp + 0x10], rax
0x180002da7: mov      eax, dword ptr [rbp + 0xb8]
0x180002dad: add      eax, eax
0x180002daf: mov      qword ptr [rsp + 0x68], 4
0x180002db8: mov      dword ptr [rbp + 0x18], eax
0x180002dbb: lea      rax, [rbp + 0xc8]
0x180002dc2: mov      qword ptr [rbp + 0x20], rax
0x180002dc6: lea      rax, [rsp + 0x40]
0x180002dcb: mov      qword ptr [rsp + 0x20], rax
0x180002dd0: mov      qword ptr [rbp - 0x78], 4
0x180002dd8: mov      qword ptr [rbp - 0x58], 4
0x180002de0: mov      qword ptr [rbp - 0x48], 4
0x180002de8: mov      qword ptr [rbp - 0x38], 8
0x180002df0: mov      qword ptr [rbp - 0x28], 4
0x180002df8: mov      qword ptr [rbp - 0x18], 8
0x180002e00: mov      qword ptr [rbp - 8], 4
0x180002e08: mov      qword ptr [rbp + 8], 4
0x180002e10: mov      qword ptr [rbp + 0x28], 4
0x180002e18: call     0x180001e50
0x180002e1d: mov      rcx, qword ptr [rbp + 0x30]
0x180002e21: xor      rcx, rsp
0x180002e24: call     0x1800041a0
0x180002e29: add      rsp, 0x140
0x180002e30: pop      rbp
0x180002e31: ret      
0x180002e32: int3     
0x180002e33: int3     
0x180002e34: int3     
0x180002e35: int3     
0x180002e36: int3     
0x180002e37: int3     
0x180002e38: int3     
0x180002e39: int3     
0x180002e3a: int3     
0x180002e3b: int3     
0x180002e3c: sub      rsp, 0x28
0x180002e40: mov      eax, 1
0x180002e45: lock xadd dword ptr [rip + 0x53cb], eax
0x180002e4d: inc      eax
0x180002e4f: cmp      eax, 1
0x180002e52: jne      0x180002e76
0x180002e54: lea      r8, [rip + 0x5225]
0x180002e5b: mov      r9, r8
0x180002e5e: lea      rcx, [rip + 0x34a3]
0x180002e65: call     0x180001df0
0x180002e6a: lea      rcx, [rip + 0x5257]
0x180002e71: call     0x18000cfe4
0x180002e76: add      rsp, 0x28
0x180002e7a: ret      
0x180002e7b: int3     
0x180002e7c: int3     
0x180002e7d: int3     
0x180002e7e: int3     
0x180002e7f: int3     
0x180002e80: int3     
0x180002e81: int3     
0x180002e82: int3     
0x180002e83: int3     
0x180002e84: sub      rsp, 0x28
0x180002e88: or       eax, 0xffffffff
0x180002e8b: lock xadd dword ptr [rip + 0x5385], eax
0x180002e93: cmp      eax, 1
0x180002e96: jne      0x180002ec6
0x180002e98: mov      rcx, qword ptr [rip + 0x5249]
0x180002e9f: and      qword ptr [rip + 0x5241], 0
0x180002ea7: and      dword ptr [rip + 0x521a], 0
0x180002eae: call     qword ptr [rip + 0x71bb]  ; -> EtwUnregister
0x180002eb5: nop      dword ptr [rax + rax]
0x180002eba: lea      rcx, [rip + 0x51bf]
0x180002ec1: call     0x180001e1c
0x180002ec6: add      rsp, 0x28
0x180002eca: ret      
0x180002ecb: int3     
0x180002ecc: int3     
0x180002ecd: int3     
0x180002ece: int3     
0x180002ecf: int3     
0x180002ed0: int3     
0x180002ed1: int3     
0x180002ed2: int3     
0x180002ed3: int3     
0x180002ed4: mov      qword ptr [rsp + 8], rbx
0x180002ed9: mov      qword ptr [rsp + 0x10], rbp
0x180002ede: mov      qword ptr [rsp + 0x18], rsi
0x180002ee3: push     rdi
0x180002ee4: push     r14
0x180002ee6: push     r15
0x180002ee8: sub      rsp, 0x80
0x180002eef: or       r11d, 0xffffffff
0x180002ef3: lea      r10, [rip + 0x3562]
0x180002efa: xor      r15d, r15d
0x180002efd: mov      r14d, r8d
0x180002f00: mov      ebp, r11d
0x180002f03: mov      r8d, r11d
0x180002f06: mov      esi, r11d
0x180002f09: mov      rbx, r10
0x180002f0c: mov      rdi, r10
0x180002f0f: test     rdx, rdx
0x180002f12: je       0x180002f29
0x180002f14: mov      r8d, dword ptr [rdx + 0x20]
0x180002f18: lea      r10, [rdx + 0x78]
0x180002f1c: mov      ebp, dword ptr [rdx + 0xf8]
0x180002f22: mov      r11d, dword ptr [rdx + 0xfc]
0x180002f29: test     rcx, rcx
0x180002f2c: je       0x180002f3c
0x180002f2e: mov      esi, dword ptr [rcx + 0x34]
0x180002f31: lea      rdi, [rcx + 0x48]
0x180002f35: lea      rbx, [rcx + 0x148]
0x180002f3c: test     byte ptr [rip + 0x5303], 0x40
0x180002f43: je       0x180002fa0
0x180002f45: or       r9, 0xffffffffffffffff
0x180002f49: mov      rdx, r9
0x180002f4c: inc      rdx
0x180002f4f: cmp      word ptr [r10 + rdx*2], r15w
0x180002f54: jne      0x180002f4c
0x180002f56: mov      rax, r9
0x180002f59: inc      rax
0x180002f5c: cmp      word ptr [rbx + rax*2], r15w
0x180002f61: jne      0x180002f59
0x180002f63: inc      r9
0x180002f66: cmp      word ptr [rdi + r9*2], r15w
0x180002f6b: jne      0x180002f63
0x180002f6d: mov      qword ptr [rsp + 0x70], r10
0x180002f72: mov      dword ptr [rsp + 0x68], edx
0x180002f76: mov      qword ptr [rsp + 0x58], rcx
0x180002f7b: mov      dword ptr [rsp + 0x50], r14d
0x180002f80: mov      dword ptr [rsp + 0x48], esi
0x180002f84: mov      dword ptr [rsp + 0x40], ebp
0x180002f88: mov      dword ptr [rsp + 0x38], r11d
0x180002f8d: mov      qword ptr [rsp + 0x30], rbx
0x180002f92: mov      dword ptr [rsp + 0x28], eax
0x180002f96: mov      qword ptr [rsp + 0x20], rdi
0x180002f9b: call     0x1800029a4
0x180002fa0: lea      r11, [rsp + 0x80]
0x180002fa8: mov      rbx, qword ptr [r11 + 0x20]
0x180002fac: mov      rbp, qword ptr [r11 + 0x28]
0x180002fb0: mov      rsi, qword ptr [r11 + 0x30]
0x180002fb4: mov      rsp, r11
0x180002fb7: pop      r15
0x180002fb9: pop      r14
0x180002fbb: pop      rdi
0x180002fbc: ret      
0x180002fbd: int3     
0x180002fbe: int3     
0x180002fbf: int3     
0x180002fc0: int3     
0x180002fc1: int3     
0x180002fc2: int3     
0x180002fc3: int3     
0x180002fc4: mov      qword ptr [rsp + 0x18], rbx
0x180002fc9: push     rbp
0x180002fca: push     rsi
0x180002fcb: push     rdi
0x180002fcc: push     r12
0x180002fce: push     r13
0x180002fd0: push     r14
0x180002fd2: push     r15
0x180002fd4: lea      rbp, [rsp - 0xa0]
0x180002fdc: sub      rsp, 0x1b0
0x180002fe3: mov      rax, qword ptr [rip + 0x5116]
0x180002fea: xor      rax, rsp
0x180002fed: mov      qword ptr [rbp + 0x90], rax
0x180002ff4: or       r12d, 0xffffffff
0x180002ff8: mov      dword ptr [rbp - 0x78], r8d
0x180002ffc: or       rbx, 0xffffffffffffffff
0x180003000: mov      dword ptr [rbp - 0x7c], r9d
0x180003004: xor      eax, eax
0x180003006: mov      qword ptr [rbp - 0x70], rbx
0x18000300a: mov      dword ptr [rbp - 0x74], r12d
0x18000300e: mov      r13, rcx
0x180003011: mov      dword ptr [rbp - 0x80], r12d
0x180003015: lea      rcx, [rip + 0x3440]
0x18000301c: mov      rdi, rcx
0x18000301f: mov      r14, rcx
0x180003022: mov      rsi, rcx
0x180003025: mov      r8, rbx
0x180003028: mov      r11d, r12d
0x18000302b: mov      r10d, eax
0x18000302e: mov      r15d, r12d
0x180003031: test     rdx, rdx
0x180003034: je       0x180003050
0x180003036: mov      r11d, dword ptr [rdx + 0xf8]
0x18000303d: lea      rdi, [rdx + 0x78]
0x180003041: mov      r15d, dword ptr [rdx + 0x20]
0x180003045: mov      r12d, dword ptr [rdx + 0xfc]
0x18000304c: mov      dword ptr [rbp - 0x74], r11d
0x180003050: test     r13, r13
0x180003053: je       0x18000309d
0x180003055: mov      eax, dword ptr [r13 + 0x40]
0x180003059: lea      rsi, [r13 + 0x48]
0x18000305d: mov      dword ptr [rbp - 0x80], eax
0x180003060: lea      r14, [r13 + 0x148]
0x180003067: movabs   rax, 0xfffff78000000320
0x180003071: movabs   rcx, 0xfffff78000000004
0x18000307b: mov      rax, qword ptr [rax]
0x18000307e: mov      ecx, dword ptr [rcx]
0x180003080: mov      r10d, dword ptr [r13 + 0x248]
0x180003087: shl      rax, 8
0x18000308b: shl      rcx, 0x20
0x18000308f: mul      rcx
0x180003092: mov      r8, rdx
0x180003095: sub      r8, qword ptr [r13 + 0x28]
0x180003099: mov      qword ptr [rbp - 0x70], r8
0x18000309d: test     byte ptr [rip + 0x51a2], 0x40
0x1800030a4: je       0x180003125
0x1800030a6: mov      rcx, rbx
0x1800030a9: xor      edx, edx
0x1800030ab: inc      rcx
0x1800030ae: cmp      word ptr [rdi + rcx*2], dx
0x1800030b2: jne      0x1800030ab
0x1800030b4: mov      rax, rbx
0x1800030b7: inc      rax
0x1800030ba: cmp      word ptr [r14 + rax*2], dx
0x1800030bf: jne      0x1800030b7
0x1800030c1: mov      r9, rbx
0x1800030c4: inc      r9
0x1800030c7: cmp      word ptr [rsi + r9*2], dx
0x1800030cc: jne      0x1800030c4
0x1800030ce: mov      dword ptr [rsp + 0x88], r10d
0x1800030d6: mov      qword ptr [rsp + 0x80], rdi
0x1800030de: mov      dword ptr [rsp + 0x78], ecx
0x1800030e2: mov      ecx, dword ptr [rbp - 0x80]
0x1800030e5: mov      dword ptr [rsp + 0x68], ecx
0x1800030e9: mov      ecx, dword ptr [rbp - 0x7c]
0x1800030ec: mov      qword ptr [rsp + 0x60], r13
0x1800030f1: mov      dword ptr [rsp + 0x58], ecx
0x1800030f5: mov      ecx, dword ptr [rbp - 0x78]
0x1800030f8: mov      qword ptr [rsp + 0x50], r8
0x1800030fd: mov      r8d, r15d
0x180003100: mov      dword ptr [rsp + 0x48], r11d
0x180003105: mov      dword ptr [rsp + 0x40], r12d
0x18000310a: mov      dword ptr [rsp + 0x38], ecx
0x18000310e: mov      qword ptr [rsp + 0x30], r14
0x180003113: mov      dword ptr [rsp + 0x28], eax
0x180003117: mov      qword ptr [rsp + 0x20], rsi
0x18000311c: call     0x180002b08
0x180003121: mov      r9d, dword ptr [rbp - 0x7c]
0x180003125: cmp      dword ptr [rip + 0x4f9c], 5
0x18000312c: jbe      0x1800032ae
0x180003132: xor      r8d, r8d
0x180003135: mov      dword ptr [rbp - 0x7c], r15d
0x180003139: mov      qword ptr [rbp - 0x28], 4
0x180003141: lea      rax, [rbp - 0x7c]
0x180003145: mov      qword ptr [rbp - 0x30], rax
0x180003149: lea      eax, [r8 + 2]
0x18000314d: test     rsi, rsi
0x180003150: je       0x180003168
0x180003152: mov      rcx, rbx
0x180003155: inc      rcx
0x180003158: cmp      word ptr [rsi + rcx*2], r8w
0x18000315d: jne      0x180003155
0x18000315f: lea      ecx, [rcx*2 + 2]
0x180003166: jmp      0x180003171
0x180003168: lea      rsi, [rip + 0x32ed]
0x18000316f: mov      ecx, eax
0x180003171: mov      qword ptr [rbp - 0x20], rsi
0x180003175: mov      dword ptr [rbp - 0x18], ecx
0x180003178: mov      dword ptr [rbp - 0x14], r8d
0x18000317c: test     r14, r14
0x18000317f: je       0x180003197
0x180003181: mov      rcx, rbx
0x180003184: inc      rcx
0x180003187: cmp      word ptr [r14 + rcx*2], r8w
0x18000318c: jne      0x180003184
0x18000318e: lea      ecx, [rcx*2 + 2]
0x180003195: jmp      0x1800031a0
0x180003197: lea      r14, [rip + 0x32be]
0x18000319e: mov      ecx, eax
0x1800031a0: mov      dword ptr [rbp - 8], ecx
0x1800031a3: mov      ecx, dword ptr [rbp - 0x78]
0x1800031a6: mov      dword ptr [rbp - 0x78], ecx
0x1800031a9: lea      rcx, [rbp - 0x78]
0x1800031ad: mov      qword ptr [rbp], rcx
0x1800031b1: lea      rcx, [rbp - 0x68]
0x1800031b5: mov      qword ptr [rbp + 0x10], rcx
0x1800031b9: mov      ecx, dword ptr [rbp - 0x74]
0x1800031bc: mov      dword ptr [rbp - 0x74], ecx
0x1800031bf: lea      rcx, [rbp - 0x74]
0x1800031c3: mov      qword ptr [rbp + 0x20], rcx
0x1800031c7: mov      ecx, dword ptr [rbp - 0x80]
0x1800031ca: mov      dword ptr [rbp - 0x80], ecx
0x1800031cd: lea      rcx, [rbp - 0x80]
0x1800031d1: mov      qword ptr [rbp + 0x30], rcx
0x1800031d5: mov      rcx, qword ptr [rbp - 0x70]
0x1800031d9: mov      qword ptr [rbp - 0x60], rcx
0x1800031dd: lea      rcx, [rbp - 0x60]
0x1800031e1: mov      qword ptr [rbp + 0x40], rcx
0x1800031e5: lea      rcx, [rbp - 0x58]
0x1800031e9: mov      qword ptr [rbp + 0x50], rcx
0x1800031ed: lea      rcx, [rbp - 0x64]
0x1800031f1: mov      qword ptr [rbp + 0x60], rcx
0x1800031f5: lea      rcx, [rbp - 0x70]
0x1800031f9: mov      qword ptr [rbp + 0x70], rcx
0x1800031fd: mov      qword ptr [rbp - 0x10], r14
0x180003201: mov      dword ptr [rbp - 4], r8d
0x180003205: mov      qword ptr [rbp + 8], 4
0x18000320d: mov      dword ptr [rbp - 0x68], r12d
0x180003211: mov      qword ptr [rbp + 0x18], 4
0x180003219: mov      qword ptr [rbp + 0x28], 4
0x180003221: mov      qword ptr [rbp + 0x38], 4
0x180003229: mov      qword ptr [rbp + 0x48], 8
0x180003231: mov      qword ptr [rbp - 0x58], r13
0x180003235: mov      qword ptr [rbp + 0x58], 8
0x18000323d: mov      dword ptr [rbp - 0x64], r9d
0x180003241: mov      qword ptr [rbp + 0x68], 4
0x180003249: mov      dword ptr [rbp - 0x70], eax
0x18000324c: mov      qword ptr [rbp + 0x78], 4
0x180003254: test     rdi, rdi
0x180003257: je       0x18000326c
0x180003259: inc      rbx
0x18000325c: cmp      word ptr [rdi + rbx*2], r8w
0x180003261: jne      0x180003259
0x180003263: lea      eax, [rbx*2 + 2]
0x18000326a: jmp      0x180003273
0x18000326c: lea      rdi, [rip + 0x31e9]
0x180003273: mov      dword ptr [rbp + 0x88], eax
0x180003279: lea      rdx, [rip + 0x3b71]
0x180003280: lea      rax, [rbp - 0x50]
0x180003284: mov      qword ptr [rbp + 0x80], rdi
0x18000328b: mov      qword ptr [rsp + 0x28], rax
0x180003290: lea      rcx, [rip + 0x4e31]
0x180003297: xor      r9d, r9d
0x18000329a: mov      dword ptr [rsp + 0x20], 0xe
0x1800032a2: mov      dword ptr [rbp + 0x8c], r8d
0x1800032a9: call     0x18000112c
0x1800032ae: mov      rcx, qword ptr [rbp + 0x90]
0x1800032b5: xor      rcx, rsp
0x1800032b8: call     0x1800041a0
0x1800032bd: mov      rbx, qword ptr [rsp + 0x200]
0x1800032c5: add      rsp, 0x1b0
0x1800032cc: pop      r15
0x1800032ce: pop      r14
0x1800032d0: pop      r13
0x1800032d2: pop      r12
0x1800032d4: pop      rdi
0x1800032d5: pop      rsi
0x1800032d6: pop      rbp
0x1800032d7: ret      
0x1800032d8: int3     
0x1800032d9: int3     
0x1800032da: int3     
0x1800032db: int3     
0x1800032dc: int3     
0x1800032dd: int3     
0x1800032de: int3     
0x1800032df: int3     
0x1800032e0: mov      qword ptr [rsp + 0x18], rbx
0x1800032e5: push     rbp
0x1800032e6: push     rsi
0x1800032e7: push     rdi
0x1800032e8: push     r12
0x1800032ea: push     r13
0x1800032ec: push     r14
0x1800032ee: push     r15
0x1800032f0: lea      rbp, [rsp - 0x80]
0x1800032f5: sub      rsp, 0x180
0x1800032fc: mov      rax, qword ptr [rip + 0x4dfd]
0x180003303: xor      rax, rsp
0x180003306: mov      qword ptr [rbp + 0x70], rax
0x18000330a: or       rbx, 0xffffffffffffffff
0x18000330e: mov      dword ptr [rbp - 0x80], r8d
0x180003312: xor      eax, eax
0x180003314: mov      r9d, r8d
0x180003317: or       r8d, 0xffffffff
0x18000331b: mov      r13, rcx
0x18000331e: mov      dword ptr [rbp - 0x7c], r8d
0x180003322: lea      rcx, [rip + 0x3133]
0x180003329: mov      dword ptr [rbp - 0x78], r8d
0x18000332d: mov      r12, rbx
0x180003330: mov      r11d, r8d
0x180003333: mov      r10d, eax
0x180003336: mov      r15d, r8d
0x180003339: mov      rdi, rcx
0x18000333c: mov      r14, rcx
0x18000333f: mov      rsi, rcx
0x180003342: test     rdx, rdx
0x180003345: je       0x180003365
0x180003347: mov      r11d, dword ptr [rdx + 0xf8]
0x18000334e: lea      rdi, [rdx + 0x78]
0x180003352: mov      r8d, dword ptr [rdx + 0xfc]
0x180003359: mov      r15d, dword ptr [rdx + 0x20]
0x18000335d: mov      dword ptr [rbp - 0x78], r11d
0x180003361: mov      dword ptr [rbp - 0x7c], r8d
0x180003365: test     r13, r13
0x180003368: je       0x1800033a7
0x18000336a: movabs   rax, 0xfffff78000000004
0x180003374: lea      rsi, [r13 + 0x48]
0x180003378: lea      r14, [r13 + 0x148]
0x18000337f: mov      ecx, dword ptr [rax]
0x180003381: movabs   rax, 0xfffff78000000320
0x18000338b: shl      rcx, 0x20
0x18000338f: mov      rax, qword ptr [rax]
0x180003392: mov      r10d, dword ptr [r13 + 0x248]
0x180003399: shl      rax, 8
0x18000339d: mul      rcx
0x1800033a0: mov      r12, rdx
0x1800033a3: sub      r12, qword ptr [r13 + 0x28]
0x1800033a7: test     byte ptr [rip + 0x4e98], 0x40
0x1800033ae: je       0x18000341b
0x1800033b0: mov      rcx, rbx
0x1800033b3: xor      edx, edx
0x1800033b5: inc      rcx
0x1800033b8: cmp      word ptr [rdi + rcx*2], dx
0x1800033bc: jne      0x1800033b5
0x1800033be: mov      rax, rbx
0x1800033c1: inc      rax
0x1800033c4: cmp      word ptr [r14 + rax*2], dx
0x1800033c9: jne      0x1800033c1
0x1800033cb: mov      r9, rbx
0x1800033ce: inc      r9
0x1800033d1: cmp      word ptr [rsi + r9*2], dx
0x1800033d6: jne      0x1800033ce
0x1800033d8: mov      dword ptr [rsp + 0x78], r10d
0x1800033dd: mov      qword ptr [rsp + 0x70], rdi
0x1800033e2: mov      dword ptr [rsp + 0x68], ecx
0x1800033e6: mov      ecx, dword ptr [rbp - 0x80]
0x1800033e9: mov      qword ptr [rsp + 0x58], r13
0x1800033ee: mov      dword ptr [rsp + 0x50], ecx
0x1800033f2: mov      qword ptr [rsp + 0x48], r12
0x1800033f7: mov      dword ptr [rsp + 0x40], r11d
0x1800033fc: mov      dword ptr [rsp + 0x38], r8d
0x180003401: mov      r8d, r15d
0x180003404: mov      qword ptr [rsp + 0x30], r14
0x180003409: mov      dword ptr [rsp + 0x28], eax
0x18000340d: mov      qword ptr [rsp + 0x20], rsi
0x180003412: call     0x180002cbc
0x180003417: mov      r9d, dword ptr [rbp - 0x80]
0x18000341b: cmp      r12, 0x3e8
0x180003422: jb       0x18000357a
0x180003428: cmp      dword ptr [rip + 0x4c99], 5
0x18000342f: jbe      0x18000357a
0x180003435: xor      r8d, r8d
0x180003438: mov      dword ptr [rbp - 0x80], r15d
0x18000343c: mov      qword ptr [rbp - 0x28], 4
0x180003444: lea      rax, [rbp - 0x80]
0x180003448: mov      qword ptr [rbp - 0x30], rax
0x18000344c: lea      eax, [r8 + 2]
0x180003450: test     rsi, rsi
0x180003453: je       0x18000346b
0x180003455: mov      rcx, rbx
0x180003458: inc      rcx
0x18000345b: cmp      word ptr [rsi + rcx*2], r8w
0x180003460: jne      0x180003458
0x180003462: lea      ecx, [rcx*2 + 2]
0x180003469: jmp      0x180003474
0x18000346b: lea      rsi, [rip + 0x2fea]
0x180003472: mov      ecx, eax
0x180003474: mov      qword ptr [rbp - 0x20], rsi
0x180003478: mov      dword ptr [rbp - 0x18], ecx
0x18000347b: mov      dword ptr [rbp - 0x14], r8d
0x18000347f: test     r14, r14
0x180003482: je       0x18000349a
0x180003484: mov      rcx, rbx
0x180003487: inc      rcx
0x18000348a: cmp      word ptr [r14 + rcx*2], r8w
0x18000348f: jne      0x180003487
0x180003491: lea      ecx, [rcx*2 + 2]
0x180003498: jmp      0x1800034a3
0x18000349a: lea      r14, [rip + 0x2fbb]
0x1800034a1: mov      ecx, eax
0x1800034a3: mov      dword ptr [rbp - 8], ecx
0x1800034a6: mov      ecx, dword ptr [rbp - 0x7c]
0x1800034a9: mov      dword ptr [rbp - 0x7c], ecx
0x1800034ac: lea      rcx, [rbp - 0x7c]
0x1800034b0: mov      qword ptr [rbp], rcx
0x1800034b4: mov      ecx, dword ptr [rbp - 0x78]
0x1800034b7: mov      dword ptr [rbp - 0x78], ecx
0x1800034ba: lea      rcx, [rbp - 0x78]
0x1800034be: mov      qword ptr [rbp + 0x10], rcx
0x1800034c2: lea      rcx, [rbp - 0x68]
0x1800034c6: mov      qword ptr [rbp + 0x20], rcx
0x1800034ca: lea      rcx, [rbp - 0x60]
0x1800034ce: mov      qword ptr [rbp + 0x30], rcx
0x1800034d2: lea      rcx, [rbp - 0x74]
0x1800034d6: mov      qword ptr [rbp + 0x40], rcx
0x1800034da: lea      rcx, [rbp - 0x70]
0x1800034de: mov      qword ptr [rbp + 0x50], rcx
0x1800034e2: mov      qword ptr [rbp - 0x10], r14
0x1800034e6: mov      dword ptr [rbp - 4], r8d
0x1800034ea: mov      qword ptr [rbp + 8], 4
0x1800034f2: mov      qword ptr [rbp + 0x18], 4
0x1800034fa: mov      qword ptr [rbp - 0x68], r12
0x1800034fe: mov      qword ptr [rbp + 0x28], 8
0x180003506: mov      qword ptr [rbp - 0x60], r13
0x18000350a: mov      qword ptr [rbp + 0x38], 8
0x180003512: mov      dword ptr [rbp - 0x74], r9d
0x180003516: mov      qword ptr [rbp + 0x48], 4
0x18000351e: mov      dword ptr [rbp - 0x70], eax
0x180003521: mov      qword ptr [rbp + 0x58], 4
0x180003529: test     rdi, rdi
0x18000352c: je       0x180003541
0x18000352e: inc      rbx
0x180003531: cmp      word ptr [rdi + rbx*2], r8w
0x180003536: jne      0x18000352e
0x180003538: lea      eax, [rbx*2 + 2]
0x18000353f: jmp      0x180003548
0x180003541: lea      rdi, [rip + 0x2f14]
0x180003548: mov      dword ptr [rbp + 0x68], eax
0x18000354b: lea      rdx, [rip + 0x37f8]
0x180003552: lea      rax, [rbp - 0x50]
0x180003556: mov      qword ptr [rbp + 0x60], rdi
0x18000355a: mov      qword ptr [rsp + 0x28], rax
0x18000355f: lea      rcx, [rip + 0x4b62]
0x180003566: xor      r9d, r9d
0x180003569: mov      dword ptr [rsp + 0x20], 0xc
0x180003571: mov      dword ptr [rbp + 0x6c], r8d
0x180003575: call     0x18000112c
0x18000357a: mov      rcx, qword ptr [rbp + 0x70]
0x18000357e: xor      rcx, rsp
0x180003581: call     0x1800041a0
0x180003586: mov      rbx, qword ptr [rsp + 0x1d0]
0x18000358e: add      rsp, 0x180
0x180003595: pop      r15
0x180003597: pop      r14
0x180003599: pop      r13
0x18000359b: pop      r12
0x18000359d: pop      rdi
0x18000359e: pop      rsi
0x18000359f: pop      rbp
0x1800035a0: ret      
0x1800035a1: int3     
0x1800035a2: int3     
0x1800035a3: int3     
0x1800035a4: int3     
0x1800035a5: int3     
0x1800035a6: int3     
0x1800035a7: int3     
0x1800035a8: sub      rsp, 0x48
0x1800035ac: or       r10d, 0xffffffff
0x1800035b0: lea      r8, [rip + 0x2ea5]
0x1800035b7: xor      r9d, r9d
0x1800035ba: test     rcx, rcx
0x1800035bd: je       0x1800035c7
0x1800035bf: mov      r10d, dword ptr [rcx + 0x20]
0x1800035c3: lea      r8, [rcx + 0x78]
0x1800035c7: test     byte ptr [rip + 0x4c78], 0x40
0x1800035ce: je       0x1800035f9
0x1800035d0: or       rax, 0xffffffffffffffff
0x1800035d4: inc      rax
0x1800035d7: cmp      word ptr [r8 + rax*2], r9w
0x1800035dc: jne      0x1800035d4
0x1800035de: mov      qword ptr [rsp + 0x30], r8
0x1800035e3: mov      r9d, edx
0x1800035e6: mov      r8d, r10d
0x1800035e9: mov      dword ptr [rsp + 0x28], eax
0x1800035ed: lea      rdx, [rip + 0x2d34]
0x1800035f4: call     0x1800028ec
0x1800035f9: add      rsp, 0x48
0x1800035fd: ret      
0x1800035fe: int3     
0x1800035ff: int3     
0x180003600: int3     
0x180003601: int3     
0x180003602: int3     
0x180003603: int3     
0x180003604: int3     
0x180003605: int3     
0x180003606: int3     
0x180003607: int3     
0x180003608: sub      rsp, 0x48
0x18000360c: or       r10d, 0xffffffff
0x180003610: lea      r8, [rip + 0x2e45]
0x180003617: xor      r9d, r9d
0x18000361a: test     rcx, rcx
0x18000361d: je       0x180003627
0x18000361f: mov      r10d, dword ptr [rcx + 0x20]
0x180003623: lea      r8, [rcx + 0x78]
0x180003627: test     byte ptr [rip + 0x4c18], 0x40
0x18000362e: je       0x180003659
0x180003630: or       rax, 0xffffffffffffffff
0x180003634: inc      rax
0x180003637: cmp      word ptr [r8 + rax*2], r9w
0x18000363c: jne      0x180003634
0x18000363e: mov      qword ptr [rsp + 0x30], r8
0x180003643: mov      r9d, edx
0x180003646: mov      r8d, r10d
0x180003649: mov      dword ptr [rsp + 0x28], eax
0x18000364d: lea      rdx, [rip + 0x2cf4]
0x180003654: call     0x1800028ec
0x180003659: add      rsp, 0x48
0x18000365d: ret      
0x18000365e: int3     
0x18000365f: int3     
0x180003660: int3     
0x180003661: int3     
0x180003662: int3     
0x180003663: int3     
0x180003664: int3     
0x180003665: int3     
0x180003666: int3     
0x180003667: int3     
0x180003668: xor      eax, eax
0x18000366a: ret      
0x18000366b: int3     
0x18000366c: int3     
0x18000366d: int3     
0x18000366e: int3     
0x18000366f: int3     
0x180003670: int3     
0x180003671: int3     
0x180003672: int3     
0x180003673: int3     
0x180003674: mov      rax, rsp
0x180003677: mov      qword ptr [rax + 8], rbx
0x18000367b: mov      qword ptr [rax + 0x10], rsi
0x18000367f: mov      qword ptr [rax + 0x18], rdi
0x180003683: push     rbp
0x180003684: lea      rbp, [rax - 0x5f]
0x180003688: sub      rsp, 0xe0
0x18000368f: xorps    xmm0, xmm0
0x180003692: mov      rsi, rcx
0x180003695: movups   xmmword ptr [rbp - 0x59], xmm0
0x180003699: mov      ebx, 0xc0000017
0x18000369e: xor      eax, eax
0x1800036a0: lock xadd dword ptr [rip + 0x4b98], eax
0x1800036a8: test     eax, eax
0x1800036aa: je       0x1800036b3
0x1800036ac: xor      eax, eax
0x1800036ae: jmp      0x180003817
0x1800036b3: xor      edx, edx
0x1800036b5: lea      rcx, [rbp - 0x59]
0x1800036b9: call     qword ptr [rip + 0x6a70]  ; -> RtlInitAnsiString
0x1800036c0: nop      dword ptr [rax + rax]
0x1800036c5: movzx    edx, word ptr [rsi]
0x1800036c8: mov      ecx, 0x40
0x1800036cd: add      rdx, 2
0x1800036d1: mov      r8d, 0x74727341
0x1800036d7: call     qword ptr [rip + 0x6972]  ; -> ExAllocatePool2
0x1800036de: nop      dword ptr [rax + rax]
0x1800036e3: mov      rdi, rax
0x1800036e6: test     rax, rax
0x1800036e9: je       0x180003815
0x1800036ef: movzx    r8d, word ptr [rsi]
0x1800036f3: mov      rcx, rax
0x1800036f6: mov      rdx, qword ptr [rsi + 8]
0x1800036fa: call     0x1800042c0
0x1800036ff: xorps    xmm0, xmm0
0x180003702: lea      rcx, [rbp - 0x49]
0x180003706: xor      edx, edx
0x180003708: movups   xmmword ptr [rbp - 0x49], xmm0
0x18000370c: call     qword ptr [rip + 0x6a0d]  ; -> RtlInitUnicodeString
0x180003713: nop      dword ptr [rax + rax]
0x180003718: xor      edx, edx
0x18000371a: lea      rcx, [rbp - 0x19]
0x18000371e: lea      r8d, [rdx + 0x70]
0x180003722: call     0x1800045c0
0x180003727: and      qword ptr [rsp + 0x20], 0
0x18000372d: lea      rax, [rip + 0x2d2c]
0x180003734: mov      qword ptr [rbp - 9], rax
0x180003738: lea      r8, [rbp - 0x19]
0x18000373c: lea      rax, [rbp - 0x49]
0x180003740: mov      dword ptr [rbp - 0x11], 0x20
0x180003747: xor      r9d, r9d
0x18000374a: mov      qword ptr [rbp - 1], rax
0x18000374e: mov      rdx, rdi
0x180003751: mov      dword ptr [rbp + 7], 2
0x180003758: xor      ecx, ecx
0x18000375a: call     qword ptr [rip + 0x69a7]  ; -> RtlQueryRegistryValuesEx
0x180003761: nop      dword ptr [rax + rax]
0x180003766: mov      ebx, eax
0x180003768: test     eax, eax
0x18000376a: js       0x180003801
0x180003770: mov      r8b, 1
0x180003773: lea      rdx, [rbp - 0x49]
0x180003777: lea      rcx, [rbp - 0x59]
0x18000377b: call     qword ptr [rip + 0x69a6]  ; -> RtlUnicodeStringToAnsiString
0x180003782: nop      dword ptr [rax + rax]
0x180003787: mov      rcx, qword ptr [rbp - 0x41]
0x18000378b: xor      edx, edx
0x18000378d: mov      ebx, eax
0x18000378f: call     qword ptr [rip + 0x68c2]  ; -> ExFreePoolWithTag
0x180003796: nop      dword ptr [rax + rax]
0x18000379b: test     ebx, ebx
0x18000379d: js       0x180003801
0x18000379f: movzx    edx, word ptr [rbp - 0x59]
0x1800037a3: lea      ecx, [rdx - 1]
0x1800037a6: test     ecx, ecx
0x1800037a8: je       0x1800037f1
0x1800037aa: mov      r8, qword ptr [rbp - 0x51]
0x1800037ae: cmp      byte ptr [rcx + r8], 0x5c
0x1800037b3: je       0x1800037bc
0x1800037b5: add      ecx, -1
0x1800037b8: jne      0x1800037ae
0x1800037ba: jmp      0x1800037f1
0x1800037bc: cmp      ecx, edx
0x1800037be: je       0x1800037f1
0x1800037c0: lea      edx, [rcx + 1]
0x1800037c3: xorps    xmm0, xmm0
0x1800037c6: add      rdx, r8
0x1800037c9: lea      rcx, [rbp - 0x39]
0x1800037cd: movups   xmmword ptr [rbp - 0x39], xmm0
0x1800037d1: call     qword ptr [rip + 0x6958]  ; -> RtlInitAnsiString
0x1800037d8: nop      dword ptr [rax + rax]
0x1800037dd: movaps   xmm0, xmmword ptr [rbp - 0x39]
0x1800037e1: lea      rcx, [rbp - 0x29]
0x1800037e5: movdqa   xmmword ptr [rbp - 0x29], xmm0
0x1800037ea: call     0x180003838
0x1800037ef: mov      ebx, eax
0x1800037f1: lea      rcx, [rbp - 0x59]
0x1800037f5: call     qword ptr [rip + 0x6904]  ; -> RtlFreeAnsiString
0x1800037fc: nop      dword ptr [rax + rax]
0x180003801: mov      edx, 0x74727341
0x180003806: mov      rcx, rdi
0x180003809: call     qword ptr [rip + 0x6848]  ; -> ExFreePoolWithTag
0x180003810: nop      dword ptr [rax + rax]
0x180003815: mov      eax, ebx
0x180003817: lea      r11, [rsp + 0xe0]
0x18000381f: mov      rbx, qword ptr [r11 + 0x10]
0x180003823: mov      rsi, qword ptr [r11 + 0x18]
0x180003827: mov      rdi, qword ptr [r11 + 0x20]
0x18000382b: mov      rsp, r11
0x18000382e: pop      rbp
0x18000382f: ret      
0x180003830: int3     
0x180003831: int3     
0x180003832: int3     
0x180003833: int3     
0x180003834: int3     
0x180003835: int3     
0x180003836: int3     
0x180003837: int3     
0x180003838: mov      qword ptr [rsp + 8], rbx
0x18000383d: push     rdi
0x18000383e: sub      rsp, 0x20
0x180003842: mov      rdi, rcx
0x180003845: lea      rcx, [rip + 0x49d4]
0x18000384c: call     qword ptr [rip + 0x685d]  ; -> KeInitializeSpinLock
0x180003853: nop      dword ptr [rax + rax]
0x180003858: movzx    edx, word ptr [rdi]
0x18000385b: xor      ebx, ebx
0x18000385d: inc      rdx
0x180003860: mov      r8d, 0x74727341
0x180003866: lea      ecx, [rbx + 0x40]
0x180003869: call     qword ptr [rip + 0x67e0]  ; -> ExAllocatePool2
0x180003870: nop      dword ptr [rax + rax]
0x180003875: mov      qword ptr [rip + 0x7784], rax
0x18000387c: test     rax, rax
0x18000387f: jne      0x180003888
0x180003881: mov      ebx, 0xc0000017
0x180003886: jmp      0x1800038d8
0x180003888: movzx    r8d, word ptr [rdi]
0x18000388c: mov      rcx, rax
0x18000388f: mov      rdx, qword ptr [rdi + 8]
0x180003893: call     0x1800042c0
0x180003898: lea      rax, [rip + 0x4991]
0x18000389f: lea      rcx, [rip + 0x779a]
0x1800038a6: mov      qword ptr [rip + 0x498b], rax
0x1800038ad: mov      qword ptr [rip + 0x497c], rax
0x1800038b4: call     0x18000cfe4
0x1800038b9: lea      rcx, [rip + 0x7748]
0x1800038c0: call     0x18000cfe4
0x1800038c5: lea      rcx, [rip + 0x77ac]
0x1800038cc: call     0x18000cfe4
0x1800038d1: lock inc dword ptr [rip + 0x4968]
0x1800038d8: mov      eax, ebx
0x1800038da: mov      rbx, qword ptr [rsp + 0x30]
0x1800038df: add      rsp, 0x20
0x1800038e3: pop      rdi
0x1800038e4: ret      
0x1800038e5: int3     
0x1800038e6: int3     
0x1800038e7: int3     
0x1800038e8: int3     
0x1800038e9: int3     
0x1800038ea: int3     
0x1800038eb: int3     
0x1800038ec: sub      rsp, 0x38
0x1800038f0: and      qword ptr [rsp + 0x28], 0
0x1800038f6: or       r9d, 0xffffffff
0x1800038fa: mov      rcx, qword ptr [rsp + 0x38]
0x1800038ff: xor      r8d, r8d
0x180003902: xor      edx, edx
0x180003904: mov      dword ptr [rsp + 0x20], r9d
0x180003909: call     0x18000391c
0x18000390e: add      rsp, 0x38
0x180003912: ret      
0x180003913: int3     
0x180003914: int3     
0x180003915: int3     
0x180003916: int3     
0x180003917: int3     
0x180003918: int3     
0x180003919: int3     
0x18000391a: int3     
0x18000391b: int3     
0x18000391c: mov      rax, rsp
0x18000391f: mov      qword ptr [rax + 0x10], rbx
0x180003923: mov      qword ptr [rax + 0x18], rsi
0x180003927: mov      qword ptr [rax + 0x20], rdi
0x18000392b: push     rbp
0x18000392c: push     r12
0x18000392e: push     r13
0x180003930: push     r14
0x180003932: push     r15
0x180003934: lea      rbp, [rax - 0x108]
0x18000393b: sub      rsp, 0x1e0
0x180003942: mov      rax, qword ptr [rip + 0x47b7]
0x180003949: xor      rax, rsp
0x18000394c: mov      qword ptr [rbp + 0xd0], rax
0x180003953: xor      esi, esi
0x180003955: mov      r12, rcx
0x180003958: mov      eax, esi
0x18000395a: lock xadd dword ptr [rip + 0x48de], eax
0x180003962: test     eax, eax
0x180003964: je       0x180003e9c
0x18000396a: lea      rcx, [rip + 0x48af]
0x180003971: call     qword ptr [rip + 0x67c0]  ; -> KeAcquireSpinLockRaiseToDpc
0x180003978: nop      dword ptr [rax + rax]
0x18000397d: mov      rcx, qword ptr [rip + 0x48ac]
0x180003984: lea      r14, [rip + 0x48a5]
0x18000398b: mov      r15b, al
0x18000398e: movabs   rbx, 0xfffff78000000320
0x180003998: movabs   r13, 0x346dc5d63886594b
0x1800039a2: cmp      r14, rcx
0x1800039a5: je       0x1800039bf
0x1800039a7: lea      rdi, [rcx - 0x20]
0x1800039ab: cmp      qword ptr [rdi], r12
0x1800039ae: je       0x180003a56
0x1800039b4: mov      rax, qword ptr [rcx]
0x1800039b7: mov      rcx, rax
0x1800039ba: cmp      r14, rax
0x1800039bd: jne      0x1800039a7
0x1800039bf: mov      edx, 0x30
0x1800039c4: mov      r8d, 0x74727341
0x1800039ca: lea      ecx, [rdx + 0x12]
0x1800039cd: call     qword ptr [rip + 0x667c]  ; -> ExAllocatePool2
0x1800039d4: nop      dword ptr [rax + rax]
0x1800039d9: mov      rdi, rax
0x1800039dc: test     rax, rax
0x1800039df: je       0x180003e86
0x1800039e5: mov      rbx, qword ptr [rbx]
0x1800039e8: mov      qword ptr [rax], r12
0x1800039eb: call     qword ptr [rip + 0x6626]  ; -> KeQueryTimeIncrement
0x1800039f2: nop      dword ptr [rax + rax]
0x1800039f7: mov      ecx, eax
0x1800039f9: mov      rax, r13
0x1800039fc: imul     rcx, rbx
0x180003a00: mov      qword ptr [rdi + 0x10], rsi
0x180003a04: imul     rcx
0x180003a07: mov      dword ptr [rdi + 0x18], esi
0x180003a0a: sar      rdx, 0xb
0x180003a0e: mov      rax, rdx
0x180003a11: shr      rax, 0x3f
0x180003a15: add      rax, -0xea61
0x180003a1b: add      rax, rdx
0x180003a1e: mov      qword ptr [rdi + 8], rax
0x180003a22: lea      rax, [rdi + 0x20]
0x180003a26: mov      rcx, qword ptr [rip + 0x4803]
0x180003a2d: cmp      qword ptr [rcx + 8], r14
0x180003a31: je       0x180003a3a
0x180003a33: mov      ecx, 3
0x180003a38: int      0x29
0x180003a3a: mov      qword ptr [rax], rcx
0x180003a3d: movabs   rbx, 0xfffff78000000320
0x180003a47: mov      qword ptr [rax + 8], r14
0x180003a4b: mov      qword ptr [rcx + 8], rax
0x180003a4f: mov      qword ptr [rip + 0x47da], rax
0x180003a56: inc      dword ptr [rdi + 0x10]
0x180003a59: inc      dword ptr [rdi + 0x14]
0x180003a5c: mov      rbx, qword ptr [rbx]
0x180003a5f: call     qword ptr [rip + 0x65b2]  ; -> KeQueryTimeIncrement
0x180003a66: nop      dword ptr [rax + rax]
0x180003a6b: mov      ecx, eax
0x180003a6d: mov      rax, r13
0x180003a70: imul     rcx, rbx
0x180003a74: imul     rcx
0x180003a77: sar      rdx, 0xb
0x180003a7b: mov      rax, rdx
0x180003a7e: shr      rax, 0x3f
0x180003a82: add      rdx, rax
0x180003a85: mov      rax, rdx
0x180003a88: sub      rax, qword ptr [rdi + 8]
0x180003a8c: cmp      rax, 0xea60
0x180003a92: jbe      0x180003e86
0x180003a98: movsxd   rax, dword ptr [rip - 0x3a63]
0x180003a9f: lea      r9, [rip - 0x3aa6]
0x180003aa6: add      rax, r9
0x180003aa9: mov      r8d, 0x10b
0x180003aaf: movzx    ecx, word ptr [rax + 0x18]
0x180003ab3: cmp      cx, r8w
0x180003ab7: je       0x180003ac5
0x180003ab9: mov      r8d, 0x20b
0x180003abf: cmp      cx, r8w
0x180003ac3: jne      0x180003acf
0x180003ac5: mov      r13d, dword ptr [rax + 8]
0x180003ac9: mov      r14d, dword ptr [rax + 0x50]
0x180003acd: jmp      0x180003ad5
0x180003acf: mov      r13d, esi
0x180003ad2: mov      r14d, esi
0x180003ad5: cmp      r12, r9
0x180003ad8: jb       0x180003af0
0x180003ada: mov      ecx, r14d
0x180003add: add      rcx, r9
0x180003ae0: cmp      rcx, r9
0x180003ae3: jbe      0x180003af0
0x180003ae5: cmp      r12, rcx
0x180003ae8: ja       0x180003af0
0x180003aea: mov      esi, r12d
0x180003aed: sub      esi, r9d
0x180003af0: mov      eax, dword ptr [rdi + 0x10]
0x180003af3: lea      rcx, [rip + 0x4726]
0x180003afa: mov      qword ptr [rdi + 8], rdx
0x180003afe: mov      dl, r15b
0x180003b01: mov      dword ptr [rsp + 0x6c], eax
0x180003b05: mov      eax, dword ptr [rdi + 0x14]
0x180003b08: mov      edi, dword ptr [rdi + 0x18]
0x180003b0b: mov      dword ptr [rsp + 0x70], eax
0x180003b0f: call     qword ptr [rip + 0x662a]  ; -> KeReleaseSpinLock
0x180003b16: nop      dword ptr [rax + rax]
0x180003b1b: or       rbx, 0xffffffffffffffff
0x180003b1f: lea      r15, [rip + 0x2938]
0x180003b26: cmp      dword ptr [rip + 0x7513], 5
0x180003b2d: lea      r9, [rip + 0x2944]
0x180003b34: movabs   rdx, 0x400000000000
0x180003b3e: jbe      0x180003c83
0x180003b44: test     qword ptr [rip + 0x7505], rdx
0x180003b4b: je       0x180003c83
0x180003b51: mov      rax, qword ptr [rip + 0x7500]
0x180003b58: and      rax, rdx
0x180003b5b: cmp      rax, qword ptr [rip + 0x74f6]
0x180003b62: jne      0x180003c83
0x180003b68: mov      rcx, qword ptr [rip + 0x7491]
0x180003b6f: lea      rax, [rsp + 0x50]
0x180003b74: mov      qword ptr [rbp - 0x60], rax
0x180003b78: xor      edx, edx
0x180003b7a: mov      dword ptr [rsp + 0x50], 0xa
0x180003b82: lea      rax, [rsp + 0x54]
0x180003b87: mov      qword ptr [rbp - 0x50], rax
0x180003b8b: lea      rax, [rsp + 0x58]
0x180003b90: mov      qword ptr [rbp - 0x40], rax
0x180003b94: lea      rax, [rsp + 0x5c]
0x180003b99: mov      qword ptr [rbp - 0x30], rax
0x180003b9d: mov      qword ptr [rbp - 0x58], 4
0x180003ba5: mov      dword ptr [rsp + 0x54], esi
0x180003ba9: mov      qword ptr [rbp - 0x48], 4
0x180003bb1: mov      dword ptr [rsp + 0x58], r13d
0x180003bb6: mov      qword ptr [rbp - 0x38], 4
0x180003bbe: mov      dword ptr [rsp + 0x5c], r14d
0x180003bc3: mov      qword ptr [rbp - 0x28], 4
0x180003bcb: test     rcx, rcx
0x180003bce: jne      0x180003bd3
0x180003bd0: mov      rcx, r9
0x180003bd3: mov      rax, rbx
0x180003bd6: inc      rax
0x180003bd9: cmp      byte ptr [rcx + rax], dl
0x180003bdc: jne      0x180003bd6
0x180003bde: inc      eax
0x180003be0: mov      qword ptr [rbp - 0x20], rcx
0x180003be4: mov      dword ptr [rbp - 0x18], eax
0x180003be7: mov      eax, dword ptr [rsp + 0x6c]
0x180003beb: mov      dword ptr [rsp + 0x60], eax
0x180003bef: lea      rax, [rsp + 0x60]
0x180003bf4: mov      qword ptr [rbp - 0x10], rax
0x180003bf8: mov      eax, dword ptr [rsp + 0x70]
0x180003bfc: mov      dword ptr [rsp + 0x64], eax
0x180003c00: lea      rax, [rsp + 0x64]
0x180003c05: mov      qword ptr [rbp], rax
0x180003c09: mov      dword ptr [rbp - 0x14], edx
0x180003c0c: mov      qword ptr [rbp - 8], 4
0x180003c14: mov      qword ptr [rbp + 8], 4
0x180003c1c: call     qword ptr [rip + 0x64ed]  ; -> KeGetCurrentIrql
0x180003c23: nop      dword ptr [rax + rax]
0x180003c28: and      dword ptr [rbp + 0x1c], 0
0x180003c2c: lea      rdx, [rip + 0x33db]
0x180003c33: and      dword ptr [rbp + 0x2c], 0
0x180003c37: lea      rcx, [rip + 0x7402]
0x180003c3e: movzx    eax, al
0x180003c41: xor      r9d, r9d
0x180003c44: mov      dword ptr [rsp + 0x68], eax
0x180003c48: xor      r8d, r8d
0x180003c4b: lea      rax, [rsp + 0x68]
0x180003c50: mov      dword ptr [rbp + 0x18], 4
0x180003c57: mov      qword ptr [rbp + 0x10], rax
0x180003c5b: lea      rax, [rip + 0x2816]
0x180003c62: mov      qword ptr [rbp + 0x20], rax
0x180003c66: lea      rax, [rbp - 0x80]
0x180003c6a: mov      qword ptr [rsp + 0x28], rax
0x180003c6f: mov      dword ptr [rsp + 0x20], 0xb
0x180003c77: mov      dword ptr [rbp + 0x28], 0xa
0x180003c7e: call     0x18000112c
0x180003c83: cmp      dword ptr [rip + 0x73ee], 0
0x180003c8a: jbe      0x180003e9c
0x180003c90: test     edi, edi
0x180003c92: jne      0x180003e9c
0x180003c98: call     qword ptr [rip + 0x6471]  ; -> KeGetCurrentIrql
0x180003c9f: nop      dword ptr [rax + rax]
0x180003ca4: xor      edx, edx
0x180003ca6: test     al, al
0x180003ca8: jne      0x180003e9c
0x180003cae: mov      r9, qword ptr [rip + 0x734b]
0x180003cb5: mov      dword ptr [rsp + 0x40], edx
0x180003cb9: mov      qword ptr [rsp + 0x38], rdx
0x180003cbe: mov      qword ptr [rsp + 0x30], rdx
0x180003cc3: mov      edx, 0x1d1
0x180003cc8: mov      eax, r14d
0x180003ccb: mov      ecx, r13d
0x180003cce: mov      qword ptr [rsp + 0x28], rax
0x180003cd3: mov      qword ptr [rsp + 0x20], rcx
0x180003cd8: lea      rcx, [rip + 0x27a9]
0x180003cdf: mov      r8d, esi
0x180003ce2: call     qword ptr [rip + 0x642f]  ; -> DbgkWerCaptureLiveKernelDump
0x180003ce9: nop      dword ptr [rax + rax]
0x180003cee: cmp      dword ptr [rip + 0x734b], 5
0x180003cf5: mov      edi, eax
0x180003cf7: jbe      0x180003e43
0x180003cfd: movabs   rax, 0x400000000000
0x180003d07: test     qword ptr [rip + 0x7342], rax
0x180003d0e: je       0x180003e43
0x180003d14: mov      rcx, qword ptr [rip + 0x733d]
0x180003d1b: and      rcx, rax
0x180003d1e: cmp      rcx, qword ptr [rip + 0x7333]
0x180003d25: jne      0x180003e43
0x180003d2b: lea      rax, [rsp + 0x68]
0x180003d30: mov      qword ptr [rbp + 0x58], 4
0x180003d38: mov      qword ptr [rbp + 0x50], rax
0x180003d3c: xor      ecx, ecx
0x180003d3e: lea      rax, [rsp + 0x64]
0x180003d43: mov      dword ptr [rsp + 0x64], esi
0x180003d47: mov      qword ptr [rbp + 0x60], rax
0x180003d4b: mov      r8d, 0xa
0x180003d51: lea      rax, [rsp + 0x60]
0x180003d56: mov      dword ptr [rsp + 0x68], r8d
0x180003d5b: mov      qword ptr [rbp + 0x70], rax
0x180003d5f: lea      rax, [rsp + 0x5c]
0x180003d64: mov      qword ptr [rbp + 0x80], rax
0x180003d6b: mov      rax, qword ptr [rip + 0x728e]
0x180003d72: mov      qword ptr [rbp + 0x68], 4
0x180003d7a: mov      dword ptr [rsp + 0x60], r13d
0x180003d7f: mov      qword ptr [rbp + 0x78], 4
0x180003d87: mov      dword ptr [rsp + 0x5c], r14d
0x180003d8c: mov      qword ptr [rbp + 0x88], 4
0x180003d97: test     rax, rax
0x180003d9a: jne      0x180003da3
0x180003d9c: lea      rax, [rip + 0x26d5]
0x180003da3: mov      r15, rax
0x180003da6: inc      rbx
0x180003da9: cmp      byte ptr [rax + rbx], cl
0x180003dac: jne      0x180003da6
0x180003dae: mov      eax, dword ptr [rsp + 0x6c]
0x180003db2: lea      rdx, [rip + 0x32c2]
0x180003db9: mov      dword ptr [rsp + 0x58], eax
0x180003dbd: inc      ebx
0x180003dbf: lea      rax, [rsp + 0x58]
0x180003dc4: mov      dword ptr [rbp + 0x9c], ecx
0x180003dca: mov      qword ptr [rbp + 0xa0], rax
0x180003dd1: lea      rcx, [rip + 0x7268]
0x180003dd8: mov      eax, dword ptr [rsp + 0x70]
0x180003ddc: xor      r9d, r9d
0x180003ddf: mov      dword ptr [rsp + 0x54], eax
0x180003de3: lea      rax, [rsp + 0x54]
0x180003de8: mov      qword ptr [rbp + 0xb0], rax
0x180003def: lea      rax, [rsp + 0x50]
0x180003df4: mov      qword ptr [rbp + 0xc0], rax
0x180003dfb: lea      rax, [rbp + 0x30]
0x180003dff: mov      qword ptr [rsp + 0x28], rax
0x180003e04: mov      dword ptr [rsp + 0x20], r8d
0x180003e09: xor      r8d, r8d
0x180003e0c: mov      qword ptr [rbp + 0x90], r15
0x180003e13: mov      dword ptr [rbp + 0x98], ebx
0x180003e19: mov      qword ptr [rbp + 0xa8], 4
0x180003e24: mov      qword ptr [rbp + 0xb8], 4
0x180003e2f: mov      dword ptr [rsp + 0x50], edi
0x180003e33: mov      qword ptr [rbp + 0xc8], 4
0x180003e3e: call     0x18000112c
0x180003e43: test     edi, edi
0x180003e45: jne      0x180003e9c
0x180003e47: lea      rcx, [rip + 0x43d2]
0x180003e4e: call     qword ptr [rip + 0x62e3]  ; -> KeAcquireSpinLockRaiseToDpc
0x180003e55: nop      dword ptr [rax + rax]
0x180003e5a: mov      rcx, qword ptr [rip + 0x43cf]
0x180003e61: lea      rdx, [rip + 0x43c8]
0x180003e68: mov      r15b, al
0x180003e6b: cmp      rdx, rcx
0x180003e6e: je       0x180003e86
0x180003e70: cmp      qword ptr [rcx - 0x20], r12
0x180003e74: je       0x180003e83
0x180003e76: mov      rax, qword ptr [rcx]
0x180003e79: mov      rcx, rax
0x180003e7c: cmp      rdx, rax
0x180003e7f: jne      0x180003e70
0x180003e81: jmp      0x180003e86
0x180003e83: inc      dword ptr [rcx - 8]
0x180003e86: mov      dl, r15b
0x180003e89: lea      rcx, [rip + 0x4390]
0x180003e90: call     qword ptr [rip + 0x62a9]  ; -> KeReleaseSpinLock
0x180003e97: nop      dword ptr [rax + rax]
0x180003e9c: mov      rcx, qword ptr [rbp + 0xd0]
0x180003ea3: xor      rcx, rsp
0x180003ea6: call     0x1800041a0
0x180003eab: lea      r11, [rsp + 0x1e0]
0x180003eb3: mov      rbx, qword ptr [r11 + 0x38]
0x180003eb7: mov      rsi, qword ptr [r11 + 0x40]
0x180003ebb: mov      rdi, qword ptr [r11 + 0x48]
0x180003ebf: mov      rsp, r11
0x180003ec2: pop      r15
0x180003ec4: pop      r14
0x180003ec6: pop      r13
0x180003ec8: pop      r12
0x180003eca: pop      rbp
0x180003ecb: ret      
0x180003ecc: int3     
0x180003ecd: int3     
0x180003ece: int3     
0x180003ecf: int3     
0x180003ed0: int3     
0x180003ed1: int3     
0x180003ed2: int3     
0x180003ed3: int3     
0x180003ed4: mov      qword ptr [rsp + 8], rbx
0x180003ed9: push     rsi
0x180003eda: sub      rsp, 0x20
0x180003ede: xor      eax, eax
0x180003ee0: lock xadd dword ptr [rip + 0x4358], eax
0x180003ee8: test     eax, eax
0x180003eea: je       0x180003ff7
0x180003ef0: lock dec dword ptr [rip + 0x4349]
0x180003ef7: lea      rcx, [rip + 0x4322]
0x180003efe: call     qword ptr [rip + 0x6233]  ; -> KeAcquireSpinLockRaiseToDpc
0x180003f05: nop      dword ptr [rax + rax]
0x180003f0a: mov      bl, al
0x180003f0c: lea      rsi, [rip + 0x431d]
0x180003f13: mov      rcx, qword ptr [rip + 0x4316]
0x180003f1a: cmp      rcx, rsi
0x180003f1d: je       0x180003f57
0x180003f1f: cmp      qword ptr [rcx + 8], rsi
0x180003f23: jne      0x180003f50
0x180003f25: mov      rax, qword ptr [rcx]
0x180003f28: cmp      qword ptr [rax + 8], rcx
0x180003f2c: jne      0x180003f50
0x180003f2e: mov      qword ptr [rip + 0x42fb], rax
0x180003f35: add      rcx, -0x20
0x180003f39: mov      edx, 0x74727341
0x180003f3e: mov      qword ptr [rax + 8], rsi
0x180003f42: call     qword ptr [rip + 0x610f]  ; -> ExFreePoolWithTag
0x180003f49: nop      dword ptr [rax + rax]
0x180003f4e: jmp      0x180003f13
0x180003f50: mov      ecx, 3
0x180003f55: int      0x29
0x180003f57: mov      dl, bl
0x180003f59: lea      rcx, [rip + 0x42c0]
0x180003f60: call     qword ptr [rip + 0x61d9]  ; -> KeReleaseSpinLock
0x180003f67: nop      dword ptr [rax + rax]
0x180003f6c: mov      rcx, qword ptr [rip + 0x708d]
0x180003f73: test     rcx, rcx
0x180003f76: je       0x180003f91
0x180003f78: mov      edx, 0x74727341
0x180003f7d: call     qword ptr [rip + 0x60d4]  ; -> ExFreePoolWithTag
0x180003f84: nop      dword ptr [rax + rax]
0x180003f89: and      qword ptr [rip + 0x706f], 0
0x180003f91: mov      rcx, qword ptr [rip + 0x7100]
0x180003f98: and      qword ptr [rip + 0x70f8], 0
0x180003fa0: and      dword ptr [rip + 0x70d1], 0
0x180003fa7: call     qword ptr [rip + 0x60c2]  ; -> EtwUnregister
0x180003fae: nop      dword ptr [rax + rax]
0x180003fb3: mov      rcx, qword ptr [rip + 0x706e]
0x180003fba: and      qword ptr [rip + 0x7066], 0
0x180003fc2: and      dword ptr [rip + 0x703f], 0
0x180003fc9: call     qword ptr [rip + 0x60a0]  ; -> EtwUnregister
0x180003fd0: nop      dword ptr [rax + rax]
0x180003fd5: mov      rcx, qword ptr [rip + 0x7084]
0x180003fdc: and      qword ptr [rip + 0x707c], 0
0x180003fe4: and      dword ptr [rip + 0x7055], 0
0x180003feb: call     qword ptr [rip + 0x607e]  ; -> EtwUnregister
0x180003ff2: nop      dword ptr [rax + rax]
0x180003ff7: mov      rbx, qword ptr [rsp + 0x30]
0x180003ffc: add      rsp, 0x20
0x180004000: pop      rsi
0x180004001: ret      
0x180004002: int3     
0x180004003: int3     
0x180004004: int3     
0x180004005: int3     
0x180004006: int3     
0x180004007: int3     
0x180004008: int3     
0x180004009: int3     
0x18000400a: int3     
0x18000400b: int3     
0x18000400c: int3     
0x18000400d: int3     
0x18000400e: int3     
0x18000400f: int3     
0x180004010: int3     
0x180004011: int3     
0x180004012: int3     
0x180004013: int3     
0x180004014: int3     
0x180004015: int3     
0x180004016: int3     
0x180004017: int3     
0x180004018: int3     
0x180004019: int3     
0x18000401a: int3     
0x18000401b: int3     
0x18000401c: int3     
0x18000401d: int3     
0x18000401e: int3     
0x18000401f: int3     
0x180004020: ret      0
0x180004023: int3     
0x180004024: int3     
0x180004025: int3     
0x180004026: int3     
0x180004027: int3     
0x180004028: int3     
0x180004029: int3     
0x18000402a: int3     
0x18000402b: int3     
0x18000402c: int3     
0x18000402d: int3     
0x18000402e: int3     
0x18000402f: int3     
0x180004030: int3     
0x180004031: int3     
0x180004032: int3     
0x180004033: int3     
0x180004034: int3     
0x180004035: int3     
0x180004036: int3     
0x180004037: int3     
0x180004038: sub      rsp, 0x28
0x18000403c: mov      r8, qword ptr [r9 + 0x38]
0x180004040: mov      rcx, rdx
0x180004043: mov      rdx, r9
0x180004046: call     0x18000405c
0x18000404b: mov      eax, 1
0x180004050: add      rsp, 0x28
0x180004054: ret      
0x180004055: int3     
0x180004056: int3     
0x180004057: int3     
0x180004058: int3     
0x180004059: int3     
0x18000405a: int3     
0x18000405b: int3     
0x18000405c: sub      rsp, 0x28
0x180004060: mov      eax, dword ptr [r8]
0x180004063: mov      r9, rcx
0x180004066: mov      r11d, eax
0x180004069: mov      r10, rcx
0x18000406c: and      r11d, 0xfffffff8
0x180004070: test     al, 4
0x180004072: je       0x180004087
0x180004074: mov      eax, dword ptr [r8 + 8]
0x180004078: movsxd   r10, dword ptr [r8 + 4]
0x18000407c: neg      eax
0x18000407e: add      r10, rcx
0x180004081: movsxd   rcx, eax
0x180004084: and      r10, rcx
0x180004087: movsxd   rax, r11d
0x18000408a: mov      r8, qword ptr [rax + r10]
0x18000408e: mov      rax, qword ptr [rdx + 0x10]
0x180004092: mov      ecx, dword ptr [rax + 8]
0x180004095: mov      rax, qword ptr [rdx + 8]
0x180004099: movzx    edx, byte ptr [rcx + rax + 3]
0x18000409e: test     dl, 0xf
0x1800040a1: je       0x1800040ab
0x1800040a3: mov      eax, edx
0x1800040a5: and      eax, 0xfffffff0
0x1800040a8: add      r9, rax
0x1800040ab: xor      r9, r8
0x1800040ae: mov      rcx, r9
0x1800040b1: call     0x1800041a0
0x1800040b6: add      rsp, 0x28
0x1800040ba: ret      
0x1800040bb: int3     
0x1800040bc: int3     
0x1800040bd: int3     
0x1800040be: int3     
0x1800040bf: int3     
0x1800040c0: int3     
0x1800040c1: int3     
0x1800040c2: int3     
0x1800040c3: int3     
0x1800040c4: int3     
0x1800040c5: int3     
0x1800040c6: int3     
0x1800040c7: int3     
0x1800040c8: int3     
0x1800040c9: int3     
0x1800040ca: int3     
0x1800040cb: int3     
0x1800040cc: int3     
0x1800040cd: int3     
0x1800040ce: int3     
0x1800040cf: int3     
0x1800040d0: push     rbx
0x1800040d2: sub      rsp, 0x10
0x1800040d6: xor      eax, eax
0x1800040d8: xor      ecx, ecx
0x1800040da: cpuid    
0x1800040dc: mov      r9d, eax
0x1800040df: xor      ecx, ecx
0x1800040e1: mov      eax, 1
0x1800040e6: xor      r8b, r8b
0x1800040e9: cpuid    
0x1800040eb: mov      dword ptr [rsp], eax
0x1800040ee: mov      dword ptr [rsp + 4], ebx
0x1800040f2: mov      dword ptr [rsp + 8], ecx
0x1800040f6: mov      dword ptr [rsp + 0xc], edx
0x1800040fa: bt       ecx, 0x14
0x1800040fe: jae      0x18000412e
0x180004100: mov      bl, 8
0x180004102: mov      r8b, bl
0x180004105: bt       ecx, 0x1b
0x180004109: jae      0x18000412e
0x18000410b: bt       ecx, 0x1c
0x18000410f: jae      0x18000412e
0x180004111: xor      ecx, ecx
0x180004113: xgetbv   
0x180004116: shl      rdx, 0x20
0x18000411a: or       rdx, rax
0x18000411d: movzx    r8d, bl
0x180004121: and      dl, 6
0x180004124: lea      eax, [rcx + 0xc]
0x180004127: cmp      dl, 6
0x18000412a: cmove    r8d, eax
0x18000412e: mov      eax, 7
0x180004133: cmp      r9d, eax
0x180004136: jl       0x180004171
0x180004138: xor      ecx, ecx
0x18000413a: cpuid    
0x18000413c: mov      dword ptr [rsp], eax
0x18000413f: mov      al, r8b
0x180004142: or       al, 2
0x180004144: mov      dword ptr [rsp + 0xc], edx
0x180004148: movzx    edx, al
0x18000414b: bt       ebx, 9
0x18000414f: movzx    eax, r8b
0x180004153: cmovae   edx, eax
0x180004156: mov      dword ptr [rsp + 4], ebx
0x18000415a: mov      dword ptr [rsp + 8], ecx
0x18000415e: mov      r8b, dl
0x180004161: test     bl, 0x20
0x180004164: je       0x180004171
0x180004166: test     dl, 4
0x180004169: je       0x180004171
0x18000416b: or       dl, 0x10
0x18000416e: mov      r8b, dl
0x180004171: or       r8b, 1
0x180004175: mov      byte ptr [rip + 0x3fc4], r8b
0x18000417c: xor      eax, eax
0x18000417e: add      rsp, 0x10
0x180004182: pop      rbx
0x180004183: ret      
0x180004184: int3     
0x180004185: int3     
0x180004186: int3     
0x180004187: int3     
0x180004188: int3     
0x180004189: int3     
0x18000418a: int3     
0x18000418b: int3     
0x18000418c: int3     
0x18000418d: int3     
0x18000418e: int3     
0x18000418f: int3     
0x180004190: int3     
0x180004191: int3     
0x180004192: int3     
0x180004193: int3     
0x180004194: int3     
0x180004195: int3     
0x180004196: nop      word ptr [rax + rax]
0x1800041a0: cmp      rcx, qword ptr [rip + 0x3f59]
0x1800041a7: jne      0x1800041b9
0x1800041a9: rol      rcx, 0x10
0x1800041ad: test     cx, 0xffff
0x1800041b2: jne      0x1800041b5
0x1800041b4: ret      
0x1800041b5: ror      rcx, 0x10
0x1800041b9: jmp      0x180001200
0x1800041be: int3     
0x1800041bf: int3     
0x1800041c0: int3     
0x1800041c1: int3     
0x1800041c2: int3     
0x1800041c3: int3     
0x1800041c4: int3     
0x1800041c5: int3     
0x1800041c6: nop      word ptr [rax + rax]
0x1800041d0: int3     
0x1800041d1: int3     
0x1800041d2: int3     
0x1800041d3: int3     
0x1800041d4: int3     
0x1800041d5: int3     
0x1800041d6: int3     
0x1800041d7: int3     
0x1800041d8: int3     
0x1800041d9: int3     
0x1800041da: int3     
0x1800041db: int3     
0x1800041dc: int3     
0x1800041dd: int3     
0x1800041de: int3     
0x1800041df: int3     
0x1800041e0: jmp      qword ptr [rip + 0x5f72]
0x1800041e6: int3     
0x1800041e7: int3     
0x1800041e8: int3     
0x1800041e9: int3     
0x1800041ea: int3     
0x1800041eb: int3     
0x1800041ec: int3     
0x1800041ed: int3     
0x1800041ee: int3     
0x1800041ef: int3     
0x1800041f0: int3     
0x1800041f1: int3     
0x1800041f2: int3     
0x1800041f3: int3     
0x1800041f4: int3     
0x1800041f5: int3     
0x1800041f6: nop      word ptr [rax + rax]
0x180004200: int3     
0x180004201: int3     
0x180004202: int3     
0x180004203: int3     
0x180004204: int3     
0x180004205: int3     
0x180004206: int3     
0x180004207: int3     
0x180004208: int3     
0x180004209: int3     
0x18000420a: int3     
0x18000420b: int3     
0x18000420c: int3     
0x18000420d: int3     
0x18000420e: int3     
0x18000420f: int3     
0x180004210: jmp      rax
0x180004212: int3     
0x180004213: int3     
0x180004214: int3     
0x180004215: int3     
0x180004216: int3     
0x180004217: int3     
0x180004218: int3     
0x180004219: int3     
0x18000421a: int3     
0x18000421b: int3     
0x18000421c: int3     
0x18000421d: int3     
0x18000421e: int3     
0x18000421f: int3     
0x180004220: int3     
0x180004221: int3     
0x180004222: int3     
0x180004223: int3     
0x180004224: int3     
0x180004225: int3     
0x180004226: nop      word ptr [rax + rax]
0x180004230: int3     
0x180004231: int3     
0x180004232: int3     
0x180004233: int3     
0x180004234: int3     
0x180004235: int3     
0x180004236: int3     
0x180004237: int3     
0x180004238: int3     
0x180004239: int3     
0x18000423a: int3     
0x18000423b: int3     
0x18000423c: int3     
0x18000423d: int3     
0x18000423e: int3     
0x18000423f: int3     
0x180004240: jmp      qword ptr [rip + 0x5f12]
0x180004246: int3     
0x180004247: int3     
0x180004248: int3     
0x180004249: int3     
0x18000424a: int3     
0x18000424b: int3     
0x18000424c: int3     
0x18000424d: int3     
0x18000424e: int3     
0x18000424f: int3     
0x180004250: int3     
0x180004251: int3     
0x180004252: int3     
0x180004253: int3     
0x180004254: int3     
0x180004255: int3     
0x180004256: int3     
0x180004257: int3     
0x180004258: int3     
0x180004259: int3     
0x18000425a: int3     
0x18000425b: int3     
0x18000425c: int3     
0x18000425d: int3     
0x18000425e: int3     
0x18000425f: int3     
0x180004260: int3     
0x180004261: int3     
0x180004262: int3     
0x180004263: int3     
0x180004264: int3     
0x180004265: int3     
0x180004266: int3     
0x180004267: int3     
0x180004268: int3     
0x180004269: int3     
0x18000426a: int3     
0x18000426b: int3     
0x18000426c: int3     
0x18000426d: int3     
0x18000426e: int3     
0x18000426f: int3     
0x180004270: int3     
0x180004271: int3     
0x180004272: int3     
0x180004273: int3     
0x180004274: int3     
0x180004275: int3     
0x180004276: int3     
0x180004277: int3     
0x180004278: int3     
0x180004279: int3     
0x18000427a: int3     
0x18000427b: int3     
0x18000427c: int3     
0x18000427d: int3     
0x18000427e: int3     
0x18000427f: int3     
0x180004280: int3     
0x180004281: int3     
0x180004282: int3     
0x180004283: int3     
0x180004284: int3     
0x180004285: int3     
0x180004286: int3     
0x180004287: int3     
0x180004288: int3     
0x180004289: int3     
0x18000428a: int3     
0x18000428b: int3     
0x18000428c: int3     
0x18000428d: int3     
0x18000428e: int3     
0x18000428f: int3     
0x180004290: int3     
0x180004291: int3     
0x180004292: int3     
0x180004293: int3     
0x180004294: int3     
0x180004295: int3     
0x180004296: int3     
0x180004297: int3     
0x180004298: int3     
0x180004299: int3     
0x18000429a: int3     
0x18000429b: int3     
0x18000429c: int3     
0x18000429d: int3     
0x18000429e: int3     
0x18000429f: int3     
0x1800042a0: int3     
0x1800042a1: int3     
0x1800042a2: int3     
0x1800042a3: int3     
0x1800042a4: int3     
0x1800042a5: int3     
0x1800042a6: int3     
0x1800042a7: int3     
0x1800042a8: int3     
0x1800042a9: int3     
0x1800042aa: int3     
0x1800042ab: int3     
0x1800042ac: int3     
0x1800042ad: int3     
0x1800042ae: int3     
0x1800042af: int3     
0x1800042b0: int3     
0x1800042b1: int3     
0x1800042b2: int3     
0x1800042b3: int3     
0x1800042b4: int3     
0x1800042b5: int3     
0x1800042b6: int3     
0x1800042b7: int3     
0x1800042b8: int3     
0x1800042b9: int3     
0x1800042ba: int3     
0x1800042bb: int3     
0x1800042bc: int3     
0x1800042bd: int3     
0x1800042be: int3     
0x1800042bf: int3     
0x1800042c0: mov      rax, rcx
0x1800042c3: cmp      r8, 8
0x1800042c7: jb       0x180004300
0x1800042c9: cmp      r8, 0x10
0x1800042cd: ja       0x1800042e0
0x1800042cf: mov      r11, qword ptr [rdx]
0x1800042d2: mov      rdx, qword ptr [rdx + r8 - 8]
0x1800042d7: mov      qword ptr [rcx], r11
0x1800042da: mov      qword ptr [rcx + r8 - 8], rdx
0x1800042df: ret      
0x1800042e0: cmp      r8, 0x20
0x1800042e4: ja       0x180004340
0x1800042e6: movups   xmm0, xmmword ptr [rdx]
0x1800042e9: movups   xmm1, xmmword ptr [rdx + r8 - 0x10]
0x1800042ef: movups   xmmword ptr [rcx], xmm0
0x1800042f2: movups   xmmword ptr [rcx + r8 - 0x10], xmm1
0x1800042f8: ret      
0x1800042f9: nop      dword ptr [rax]
0x180004300: test     r8, r8
0x180004303: je       0x18000431a
0x180004305: sub      rdx, rcx
0x180004308: jb       0x180004320
0x18000430a: mov      r11b, byte ptr [rcx + rdx]
0x18000430e: inc      rcx
0x180004311: dec      r8
0x180004314: mov      byte ptr [rcx - 1], r11b
0x180004318: jne      0x18000430a
0x18000431a: ret      
0x18000431b: nop      dword ptr [rax + rax]
0x180004320: add      rcx, r8
0x180004323: mov      r11b, byte ptr [rcx + rdx - 1]
0x180004328: dec      rcx
0x18000432b: dec      r8
0x18000432e: mov      byte ptr [rcx], r11b
0x180004331: jne      0x180004323
0x180004333: ret      
0x180004334: nop      word ptr [rax + rax]
0x180004340: lea      r11, [rdx + r8]
0x180004344: sub      rdx, rcx
0x180004347: jae      0x180004352
0x180004349: cmp      r11, rcx
0x18000434c: ja       0x1800044c0
0x180004352: movups   xmm0, xmmword ptr [rcx + rdx]
0x180004356: add      rcx, 0x10
0x18000435a: test     cl, 0xf
0x18000435d: je       0x180004371
0x18000435f: and      rcx, 0xfffffffffffffff0
0x180004363: movups   xmm1, xmmword ptr [rcx + rdx]
0x180004367: movups   xmmword ptr [rax], xmm0
0x18000436a: movaps   xmm0, xmm1
0x18000436d: add      rcx, 0x10
0x180004371: add      r8, rax
0x180004374: sub      r8, rcx
0x180004377: mov      r9, r8
0x18000437a: shr      r9, 6
0x18000437e: je       0x1800043ef
0x180004380: cmp      r9, 0x1000
0x180004387: ja       0x180004440
0x18000438d: and      r8, 0x3f
0x180004391: jmp      0x1800043c0
0x180004393: nop      word ptr [rax + rax]
0x1800043a2: nop      word ptr [rax + rax]
0x1800043b1: nop      word ptr [rax + rax]
0x1800043c0: movups   xmm1, xmmword ptr [rcx + rdx]
0x1800043c4: movups   xmm2, xmmword ptr [rcx + rdx + 0x10]
0x1800043c9: movups   xmm3, xmmword ptr [rcx + rdx + 0x20]
0x1800043ce: movups   xmm4, xmmword ptr [rcx + rdx + 0x30]
0x1800043d3: movaps   xmmword ptr [rcx - 0x10], xmm0
0x1800043d7: add      rcx, 0x40
0x1800043db: dec      r9
0x1800043de: movaps   xmmword ptr [rcx - 0x40], xmm1
0x1800043e2: movaps   xmmword ptr [rcx - 0x30], xmm2
0x1800043e6: movaps   xmmword ptr [rcx - 0x20], xmm3
0x1800043ea: movaps   xmm0, xmm4
0x1800043ed: jne      0x1800043c0
0x1800043ef: mov      r9, r8
0x1800043f2: shr      r9, 4
0x1800043f6: je       0x180004411
0x1800043f8: nop      dword ptr [rax + rax]
0x180004400: movaps   xmmword ptr [rcx - 0x10], xmm0
0x180004404: movups   xmm0, xmmword ptr [rcx + rdx]
0x180004408: add      rcx, 0x10
0x18000440c: dec      r9
0x18000440f: jne      0x180004400
0x180004411: and      r8, 0xf
0x180004415: je       0x180004425
0x180004417: lea      r11, [rcx + r8 - 0x10]
0x18000441c: movups   xmm1, xmmword ptr [r11 + rdx]
0x180004421: movups   xmmword ptr [r11], xmm1
0x180004425: movaps   xmmword ptr [rcx - 0x10], xmm0
0x180004429: ret      
0x18000442a: nop      word ptr [rax + rax]
0x180004439: nop      dword ptr [rax]
0x180004440: mov      r9, r8
0x180004443: shr      r9, 6
0x180004447: and      r8, 0x3f
0x18000444b: prefetchnta byte ptr [rcx + rdx + 0x40]
0x180004450: jmp      0x180004480
0x180004452: nop      word ptr [rax + rax]
0x180004461: nop      word ptr [rax + rax]
0x180004470: nop      word ptr [rax + rax]
0x18000447f: nop      
0x180004480: movups   xmm1, xmmword ptr [rcx + rdx]
0x180004484: movups   xmm2, xmmword ptr [rcx + rdx + 0x10]
0x180004489: movups   xmm3, xmmword ptr [rcx + rdx + 0x20]
0x18000448e: movups   xmm4, xmmword ptr [rcx + rdx + 0x30]
0x180004493: movntps  xmmword ptr [rcx - 0x10], xmm0
0x180004497: add      rcx, 0x40
0x18000449b: prefetchnta byte ptr [rcx + rdx + 0x40]
0x1800044a0: dec      r9
0x1800044a3: movntps  xmmword ptr [rcx - 0x40], xmm1
0x1800044a7: movntps  xmmword ptr [rcx - 0x30], xmm2
0x1800044ab: movntps  xmmword ptr [rcx - 0x20], xmm3
0x1800044af: movaps   xmm0, xmm4
0x1800044b2: jne      0x180004480
0x1800044b4: sfence   
0x1800044b7: jmp      0x1800043ef
0x1800044bc: nop      dword ptr [rax]
0x1800044c0: add      rcx, r8
0x1800044c3: movups   xmm0, xmmword ptr [rcx + rdx - 0x10]
0x1800044c8: sub      rcx, 0x10
0x1800044cc: sub      r8, 0x10
0x1800044d0: test     cl, 0xf
0x1800044d3: je       0x1800044ed
0x1800044d5: mov      r11, rcx
0x1800044d8: and      rcx, 0xfffffffffffffff0
0x1800044dc: movups   xmm1, xmmword ptr [rcx + rdx]
0x1800044e0: movups   xmmword ptr [r11], xmm0
0x1800044e4: movaps   xmm0, xmm1
0x1800044e7: mov      r8, rcx
0x1800044ea: sub      r8, rax
0x1800044ed: mov      r9, r8
0x1800044f0: shr      r9, 6
0x1800044f4: je       0x18000452f
0x1800044f6: and      r8, 0x3f
0x1800044fa: jmp      0x180004500
0x1800044fc: nop      dword ptr [rax]
0x180004500: movups   xmm1, xmmword ptr [rcx + rdx - 0x10]
0x180004505: movups   xmm2, xmmword ptr [rcx + rdx - 0x20]
0x18000450a: movups   xmm3, xmmword ptr [rcx + rdx - 0x30]
0x18000450f: movups   xmm4, xmmword ptr [rcx + rdx - 0x40]
0x180004514: movaps   xmmword ptr [rcx], xmm0
0x180004517: sub      rcx, 0x40
0x18000451b: dec      r9
0x18000451e: movaps   xmmword ptr [rcx + 0x30], xmm1
0x180004522: movaps   xmmword ptr [rcx + 0x20], xmm2
0x180004526: movaps   xmmword ptr [rcx + 0x10], xmm3
0x18000452a: movaps   xmm0, xmm4
0x18000452d: jne      0x180004500
0x18000452f: mov      r9, r8
0x180004532: shr      r9, 4
0x180004536: je       0x180004551
0x180004538: nop      dword ptr [rax + rax]
0x180004540: movaps   xmmword ptr [rcx], xmm0
0x180004543: movups   xmm0, xmmword ptr [rcx + rdx - 0x10]
0x180004548: sub      rcx, 0x10
0x18000454c: dec      r9
0x18000454f: jne      0x180004540
0x180004551: and      r8, 0xf
0x180004555: je       0x180004566
0x180004557: mov      r11, rcx
0x18000455a: sub      r11, r8
0x18000455d: movups   xmm1, xmmword ptr [r11 + rdx]
0x180004562: movups   xmmword ptr [r11], xmm1
0x180004566: movaps   xmmword ptr [rcx], xmm0
0x180004569: ret      
0x18000456a: int3     
0x18000456b: int3     
0x18000456c: int3     
0x18000456d: int3     
0x18000456e: int3     
0x18000456f: int3     
0x180004570: int3     
0x180004571: int3     
0x180004572: int3     
0x180004573: int3     
0x180004574: int3     
0x180004575: int3     
0x180004576: int3     
0x180004577: int3     
0x180004578: int3     
0x180004579: int3     
0x18000457a: int3     
0x18000457b: int3     
0x18000457c: int3     
0x18000457d: int3     
0x18000457e: int3     
0x18000457f: int3     
0x180004580: int3     
0x180004581: int3     
0x180004582: int3     
0x180004583: int3     
0x180004584: int3     
0x180004585: int3     
0x180004586: int3     
0x180004587: int3     
0x180004588: int3     
0x180004589: int3     
0x18000458a: int3     
0x18000458b: int3     
0x18000458c: int3     
0x18000458d: int3     
0x18000458e: int3     
0x18000458f: int3     
0x180004590: int3     
0x180004591: int3     
0x180004592: int3     
0x180004593: int3     
0x180004594: int3     
0x180004595: int3     
0x180004596: int3     
0x180004597: int3     
0x180004598: int3     
0x180004599: int3     
0x18000459a: int3     
0x18000459b: int3     
0x18000459c: int3     
0x18000459d: int3     
0x18000459e: int3     
0x18000459f: int3     
0x1800045a0: int3     
0x1800045a1: int3     
0x1800045a2: int3     
0x1800045a3: int3     
0x1800045a4: int3     
0x1800045a5: int3     
0x1800045a6: int3     
0x1800045a7: int3     
0x1800045a8: int3     
0x1800045a9: int3     
0x1800045aa: int3     
0x1800045ab: int3     
0x1800045ac: int3     
0x1800045ad: int3     
0x1800045ae: int3     
0x1800045af: int3     
0x1800045b0: int3     
0x1800045b1: int3     
0x1800045b2: int3     
0x1800045b3: int3     
0x1800045b4: int3     
0x1800045b5: int3     
0x1800045b6: int3     
0x1800045b7: int3     
0x1800045b8: int3     
0x1800045b9: int3     
0x1800045ba: int3     
0x1800045bb: int3     
0x1800045bc: int3     
0x1800045bd: int3     
0x1800045be: int3     
0x1800045bf: int3     
0x1800045c0: mov      rax, rcx
0x1800045c3: movzx    edx, dl
0x1800045c6: movabs   r9, 0x101010101010101
0x1800045d0: imul     rdx, r9
0x1800045d4: movq     xmm0, rdx
0x1800045d9: movlhps  xmm0, xmm0
0x1800045dc: cmp      r8, 0x40
0x1800045e0: jb       0x180004650
0x1800045e2: test     byte ptr [rip + 0x3b57], 2
0x1800045e9: je       0x1800045f8
0x1800045eb: cmp      r8, 0x320
0x1800045f2: jae      0x180004700
0x1800045f8: movups   xmmword ptr [rcx], xmm0
0x1800045fb: add      r8, rcx
0x1800045fe: add      rcx, 0x10
0x180004602: and      rcx, 0xfffffffffffffff0
0x180004606: sub      r8, rcx
0x180004609: cmp      r8, 0x40
0x18000460d: jb       0x180004656
0x18000460f: lea      rdx, [rcx + r8 - 0x10]
0x180004614: lea      r9, [rcx + r8 - 0x30]
0x180004619: and      r9, 0xfffffffffffffff0
0x18000461d: shr      r8, 6
0x180004621: movaps   xmmword ptr [rcx], xmm0
0x180004624: movaps   xmmword ptr [rcx + 0x10], xmm0
0x180004628: add      rcx, 0x40
0x18000462c: dec      r8
0x18000462f: movaps   xmmword ptr [rcx - 0x20], xmm0
0x180004633: movaps   xmmword ptr [rcx - 0x10], xmm0
0x180004637: jne      0x180004621
0x180004639: movaps   xmmword ptr [r9], xmm0
0x18000463d: movaps   xmmword ptr [r9 + 0x10], xmm0
0x180004642: movaps   xmmword ptr [r9 + 0x20], xmm0
0x180004647: movups   xmmword ptr [rdx], xmm0
0x18000464a: ret      
0x18000464b: nop      dword ptr [rax + rax]
0x180004650: cmp      r8, 0x10
0x180004654: jb       0x180004680
0x180004656: lea      r9, [r8 + rcx - 0x10]
0x18000465b: and      r8, 0x20
0x18000465f: movups   xmmword ptr [rcx], xmm0
0x180004662: shr      r8, 1
0x180004665: movups   xmmword ptr [r9], xmm0
0x180004669: movups   xmmword ptr [rcx + r8], xmm0
0x18000466e: neg      r8
0x180004671: movups   xmmword ptr [r9 + r8], xmm0
0x180004676: ret      
0x180004677: nop      word ptr [rax + rax]
0x180004680: cmp      r8, 4
0x180004684: jb       0x1800046b0
0x180004686: lea      r9, [r8 + rcx - 4]
0x18000468b: and      r8, 8
0x18000468f: mov      dword ptr [rcx], edx
0x180004691: shr      r8, 1
0x180004694: mov      dword ptr [r9], edx
0x180004697: mov      dword ptr [rcx + r8], edx
0x18000469b: neg      r8
0x18000469e: mov      dword ptr [r9 + r8], edx
0x1800046a2: ret      
0x1800046a3: nop      word ptr [rax + rax]
0x1800046b0: test     r8, r8
0x1800046b3: je       0x1800046c6
0x1800046b5: mov      byte ptr [rcx], dl
0x1800046b7: lea      r9, [rcx + r8 - 2]
0x1800046bc: cmp      r8, 1
0x1800046c0: je       0x1800046c6
0x1800046c2: mov      word ptr [r9], dx
0x1800046c6: ret      
0x1800046c7: int3     
0x1800046c8: int3     
0x1800046c9: int3     
0x1800046ca: int3     
0x1800046cb: int3     
0x1800046cc: int3     
0x1800046cd: int3     
0x1800046ce: int3     
0x1800046cf: int3     
0x1800046d0: int3     
0x1800046d1: int3     
0x1800046d2: int3     
0x1800046d3: int3     
0x1800046d4: int3     
0x1800046d5: int3     
0x1800046d6: int3     
0x1800046d7: int3     
0x1800046d8: int3     
0x1800046d9: int3     
0x1800046da: int3     
0x1800046db: int3     
0x1800046dc: int3     
0x1800046dd: int3     
0x1800046de: int3     
0x1800046df: int3     
0x1800046e0: int3     
0x1800046e1: int3     
0x1800046e2: int3     
0x1800046e3: int3     
0x1800046e4: int3     
0x1800046e5: int3     
0x1800046e6: int3     
0x1800046e7: int3     
0x1800046e8: int3     
0x1800046e9: int3     
0x1800046ea: int3     
0x1800046eb: int3     
0x1800046ec: int3     
0x1800046ed: int3     
0x1800046ee: int3     
0x1800046ef: int3     
0x1800046f0: int3     
0x1800046f1: int3     
0x1800046f2: int3     
0x1800046f3: int3     
0x1800046f4: int3     
0x1800046f5: int3     
0x1800046f6: int3     
0x1800046f7: int3     
0x1800046f8: int3     
0x1800046f9: int3     
0x1800046fa: int3     
0x1800046fb: int3     
0x1800046fc: int3     
0x1800046fd: int3     
0x1800046fe: int3     
0x1800046ff: int3     
0x180004700: push     rdi
0x180004701: test     byte ptr [rip + 0x3a38], 1
0x180004708: je       0x18000473c
0x18000470a: mov      rdi, rcx
0x18000470d: add      r8, rcx
0x180004710: movups   xmmword ptr [rcx], xmm0
0x180004713: add      rdi, 0x40
0x180004717: movups   xmmword ptr [rcx + 0x10], xmm0
0x18000471b: and      rdi, 0xffffffffffffffc0
0x18000471f: movups   xmmword ptr [rcx + 0x20], xmm0
0x180004723: sub      r8, rdi
0x180004726: movups   xmmword ptr [rcx + 0x30], xmm0
0x18000472a: mov      rcx, r8
0x18000472d: mov      r9, rax
0x180004730: movq     rax, xmm0
0x180004735: rep stosb byte ptr [rdi], al
0x180004737: mov      rax, r9
0x18000473a: pop      rdi
0x18000473b: ret      
0x18000473c: call     0x180004780
0x180004741: jmp      0x18000470a
0x180004743: int3     
0x180004744: int3     
0x180004745: int3     
0x180004746: int3     
0x180004747: int3     
0x180004748: int3     
0x180004749: int3     
0x18000474a: int3     
0x18000474b: int3     
0x18000474c: int3     
0x18000474d: int3     
0x18000474e: int3     
0x18000474f: int3     
0x180004750: int3     
0x180004751: int3     
0x180004752: int3     
0x180004753: int3     
0x180004754: int3     
0x180004755: int3     
0x180004756: int3     
0x180004757: int3     
0x180004758: int3     
0x180004759: int3     
0x18000475a: int3     
0x18000475b: int3     
0x18000475c: int3     
0x18000475d: int3     
0x18000475e: int3     
0x18000475f: int3     
0x180004760: int3     
0x180004761: int3     
0x180004762: int3     
0x180004763: int3     
0x180004764: int3     
0x180004765: int3     
0x180004766: int3     
0x180004767: int3     
0x180004768: int3     
0x180004769: int3     
0x18000476a: int3     
0x18000476b: int3     
0x18000476c: int3     
0x18000476d: int3     
0x18000476e: int3     
0x18000476f: int3     
0x180004770: int3     
0x180004771: int3     
0x180004772: int3     
0x180004773: int3     
0x180004774: int3     
0x180004775: int3     
0x180004776: int3     
0x180004777: int3     
0x180004778: int3     
0x180004779: int3     
0x18000477a: int3     
0x18000477b: int3     
0x18000477c: int3     
0x18000477d: int3     
0x18000477e: int3     
0x18000477f: int3     
0x180004780: push     r9
0x180004782: push     r8
0x180004784: push     rdx
0x180004785: push     rcx
0x180004786: push     rax
0x180004787: sub      rsp, 0x30
0x18000478b: movaps   xmmword ptr [rsp + 0x20], xmm0
0x180004790: call     0x1800040d0
0x180004795: movaps   xmm0, xmmword ptr [rsp + 0x20]
0x18000479a: add      rsp, 0x30
0x18000479e: pop      rax
0x18000479f: pop      rcx
0x1800047a0: pop      rdx
0x1800047a1: pop      r8
0x1800047a3: pop      r9
0x1800047a5: ret      
0x1800047a6: int3     
0x1800047a7: int3     
0x1800047a8: int3     
0x1800047a9: int3     
0x1800047aa: int3     
0x1800047ab: int3     
0x1800047ac: int3     
0x1800047ad: int3     
0x1800047ae: int3     
0x1800047af: int3     
0x1800047b0: int3     
0x1800047b1: int3     
0x1800047b2: int3     
0x1800047b3: int3     
0x1800047b4: int3     
0x1800047b5: int3     
0x1800047b6: int3     
0x1800047b7: int3     
0x1800047b8: int3     
0x1800047b9: int3     
0x1800047ba: int3     
0x1800047bb: int3     
0x1800047bc: int3     
0x1800047bd: int3     
0x1800047be: int3     
0x1800047bf: int3     
0x1800047c0: int3     
0x1800047c1: int3     
0x1800047c2: int3     
0x1800047c3: int3     
0x1800047c4: int3     
0x1800047c5: int3     
0x1800047c6: int3     
0x1800047c7: int3     
0x1800047c8: int3     
0x1800047c9: int3     
0x1800047ca: int3     
0x1800047cb: int3     
0x1800047cc: int3     
0x1800047cd: int3     
0x1800047ce: int3     
0x1800047cf: int3     
0x1800047d0: int3     
0x1800047d1: int3     
0x1800047d2: int3     
0x1800047d3: int3     
0x1800047d4: int3     
0x1800047d5: int3     
0x1800047d6: int3     
0x1800047d7: int3     
0x1800047d8: int3     
0x1800047d9: int3     
0x1800047da: int3     
0x1800047db: int3     
0x1800047dc: int3     
0x1800047dd: int3     
0x1800047de: int3     
0x1800047df: int3     
0x1800047e0: int3     
0x1800047e1: int3     
0x1800047e2: int3     
0x1800047e3: int3     
0x1800047e4: int3     
0x1800047e5: int3     
0x1800047e6: int3     
0x1800047e7: int3     
0x1800047e8: int3     
0x1800047e9: int3     
0x1800047ea: int3     
0x1800047eb: int3     
0x1800047ec: int3     
0x1800047ed: int3     
0x1800047ee: int3     
0x1800047ef: int3     
0x1800047f0: int3     
0x1800047f1: int3     
0x1800047f2: int3     
0x1800047f3: int3     
0x1800047f4: int3     
0x1800047f5: int3     
0x1800047f6: int3     
0x1800047f7: int3     
0x1800047f8: int3     
0x1800047f9: int3     
0x1800047fa: int3     
0x1800047fb: int3     
0x1800047fc: int3     
0x1800047fd: int3     
0x1800047fe: int3     
0x1800047ff: int3     
0x180004800: mov      rax, rcx
0x180004803: movzx    edx, dl
0x180004806: movabs   r9, 0x101010101010101
0x180004810: imul     rdx, r9
0x180004814: movq     xmm0, rdx
0x180004819: movlhps  xmm0, xmm0
0x18000481c: cmp      r8, 0x40
0x180004820: jb       0x180004890
0x180004822: cmp      r8, 0x320
0x180004829: jae      0x180004940
0x18000482f: movups   xmmword ptr [rcx], xmm0
0x180004832: add      r8, rcx
0x180004835: add      rcx, 0x10
0x180004839: and      rcx, 0xfffffffffffffff0
0x18000483d: sub      r8, rcx
0x180004840: cmp      r8, 0x40
0x180004844: jb       0x180004896
0x180004846: lea      rdx, [rcx + r8 - 0x10]
0x18000484b: lea      r9, [rcx + r8 - 0x30]
0x180004850: and      r9, 0xfffffffffffffff0
0x180004854: shr      r8, 6
0x180004858: movaps   xmmword ptr [rcx], xmm0
0x18000485b: movaps   xmmword ptr [rcx + 0x10], xmm0
0x18000485f: add      rcx, 0x40
0x180004863: dec      r8
0x180004866: movaps   xmmword ptr [rcx - 0x20], xmm0
0x18000486a: movaps   xmmword ptr [rcx - 0x10], xmm0
0x18000486e: jne      0x180004858
0x180004870: movaps   xmmword ptr [r9], xmm0
0x180004874: movaps   xmmword ptr [r9 + 0x10], xmm0
0x180004879: movaps   xmmword ptr [r9 + 0x20], xmm0
0x18000487e: movups   xmmword ptr [rdx], xmm0
0x180004881: ret      
0x180004882: nop      word ptr [rax + rax]
0x180004890: cmp      r8, 0x10
0x180004894: jb       0x1800048c0
0x180004896: lea      r9, [r8 + rcx - 0x10]
0x18000489b: and      r8, 0x20
0x18000489f: movups   xmmword ptr [rcx], xmm0
0x1800048a2: shr      r8, 1
0x1800048a5: movups   xmmword ptr [r9], xmm0
0x1800048a9: movups   xmmword ptr [rcx + r8], xmm0
0x1800048ae: neg      r8
0x1800048b1: movups   xmmword ptr [r9 + r8], xmm0
0x1800048b6: ret      
0x1800048b7: nop      word ptr [rax + rax]
0x1800048c0: cmp      r8, 4
0x1800048c4: jb       0x1800048f0
0x1800048c6: lea      r9, [r8 + rcx - 4]
0x1800048cb: and      r8, 8
0x1800048cf: mov      dword ptr [rcx], edx
0x1800048d1: shr      r8, 1
0x1800048d4: mov      dword ptr [r9], edx
0x1800048d7: mov      dword ptr [rcx + r8], edx
0x1800048db: neg      r8
0x1800048de: mov      dword ptr [r9 + r8], edx
0x1800048e2: ret      
0x1800048e3: nop      word ptr [rax + rax]
0x1800048f0: test     r8, r8
0x1800048f3: je       0x180004906
0x1800048f5: mov      byte ptr [rcx], dl
0x1800048f7: lea      r9, [rcx + r8 - 2]
0x1800048fc: cmp      r8, 1
0x180004900: je       0x180004906
0x180004902: mov      word ptr [r9], dx
0x180004906: ret      
0x180004907: int3     
0x180004908: int3     
0x180004909: int3     
0x18000490a: int3     
0x18000490b: int3     
0x18000490c: int3     
0x18000490d: int3     
0x18000490e: int3     
0x18000490f: int3     
0x180004910: int3     
0x180004911: int3     
0x180004912: int3     
0x180004913: int3     
0x180004914: int3     
0x180004915: int3     
0x180004916: int3     
0x180004917: int3     
0x180004918: int3     
0x180004919: int3     
0x18000491a: int3     
0x18000491b: int3     
0x18000491c: int3     
0x18000491d: int3     
0x18000491e: int3     
0x18000491f: int3     
0x180004920: int3     
0x180004921: int3     
0x180004922: int3     
0x180004923: int3     
0x180004924: int3     
0x180004925: int3     
0x180004926: int3     
0x180004927: int3     
0x180004928: int3     
0x180004929: int3     
0x18000492a: int3     
0x18000492b: int3     
0x18000492c: int3     
0x18000492d: int3     
0x18000492e: int3     
0x18000492f: int3     
0x180004930: int3     
0x180004931: int3     
0x180004932: int3     
0x180004933: int3     
0x180004934: int3     
0x180004935: int3     
0x180004936: int3     
0x180004937: int3     
0x180004938: int3     
0x180004939: int3     
0x18000493a: int3     
0x18000493b: int3     
0x18000493c: int3     
0x18000493d: int3     
0x18000493e: int3     
0x18000493f: int3     
0x180004940: push     rdi
0x180004941: mov      rdi, rcx
0x180004944: add      r8, rcx
0x180004947: movups   xmmword ptr [rcx], xmm0
0x18000494a: add      rdi, 0x40
0x18000494e: movups   xmmword ptr [rcx + 0x10], xmm0
0x180004952: and      rdi, 0xffffffffffffffc0
0x180004956: movups   xmmword ptr [rcx + 0x20], xmm0
0x18000495a: sub      r8, rdi
0x18000495d: movups   xmmword ptr [rcx + 0x30], xmm0
0x180004961: mov      rcx, r8
0x180004964: mov      r9, rax
0x180004967: movq     rax, xmm0
0x18000496c: rep stosb byte ptr [rdi], al
0x18000496e: mov      rax, r9
0x180004971: pop      rdi
0x180004972: ret      
0x180004973: int3     
0x180004974: int3     
0x180004975: int3     
0x180004976: int3     
0x180004977: int3     
0x180004978: int3     
0x180004979: int3     
0x18000497a: int3     
0x18000497b: int3     
0x18000497c: int3     
0x18000497d: int3     
0x18000497e: int3     
0x18000497f: int3     
0x180004980: int3     
0x180004981: int3     
0x180004982: int3     
0x180004983: int3     
0x180004984: int3     
0x180004985: int3     
0x180004986: int3     
0x180004987: int3     
0x180004988: int3     
0x180004989: int3     
0x18000498a: int3     
0x18000498b: int3     
0x18000498c: int3     
0x18000498d: int3     
0x18000498e: int3     
0x18000498f: int3     
0x180004990: int3     
0x180004991: int3     
0x180004992: int3     
0x180004993: int3     
0x180004994: int3     
0x180004995: int3     
0x180004996: int3     
0x180004997: int3     
0x180004998: int3     
0x180004999: int3     
0x18000499a: int3     
0x18000499b: int3     
0x18000499c: int3     
0x18000499d: int3     
0x18000499e: int3     
0x18000499f: int3     
0x1800049a0: int3     
0x1800049a1: int3     
0x1800049a2: int3     
0x1800049a3: int3     
0x1800049a4: int3     
0x1800049a5: int3     
0x1800049a6: int3     
0x1800049a7: int3     
0x1800049a8: int3     
0x1800049a9: int3     
0x1800049aa: int3     
0x1800049ab: int3     
0x1800049ac: int3     
0x1800049ad: int3     
0x1800049ae: int3     
0x1800049af: int3     
0x1800049b0: int3     
0x1800049b1: int3     
0x1800049b2: int3     
0x1800049b3: int3     
0x1800049b4: int3     
0x1800049b5: int3     
0x1800049b6: int3     
0x1800049b7: int3     
0x1800049b8: int3     
0x1800049b9: int3     
0x1800049ba: int3     
0x1800049bb: int3     
0x1800049bc: int3     
0x1800049bd: int3     
0x1800049be: int3     
0x1800049bf: int3     
0x1800049c0: mov      rax, rcx
0x1800049c3: movzx    edx, dl
0x1800049c6: movabs   r9, 0x101010101010101
0x1800049d0: imul     rdx, r9
0x1800049d4: movq     xmm0, rdx
0x1800049d9: movlhps  xmm0, xmm0
0x1800049dc: cmp      r8, 0x40
0x1800049e0: jb       0x180004a40
0x1800049e2: movups   xmmword ptr [rcx], xmm0
0x1800049e5: add      r8, rcx
0x1800049e8: add      rcx, 0x10
0x1800049ec: and      rcx, 0xfffffffffffffff0
0x1800049f0: sub      r8, rcx
0x1800049f3: cmp      r8, 0x40
0x1800049f7: jb       0x180004a46
0x1800049f9: lea      rdx, [rcx + r8 - 0x10]
0x1800049fe: lea      r9, [rcx + r8 - 0x30]
0x180004a03: and      r9, 0xfffffffffffffff0
0x180004a07: shr      r8, 6
0x180004a0b: movaps   xmmword ptr [rcx], xmm0
0x180004a0e: movaps   xmmword ptr [rcx + 0x10], xmm0
0x180004a12: add      rcx, 0x40
0x180004a16: dec      r8
0x180004a19: movaps   xmmword ptr [rcx - 0x20], xmm0
0x180004a1d: movaps   xmmword ptr [rcx - 0x10], xmm0
0x180004a21: jne      0x180004a0b
0x180004a23: movaps   xmmword ptr [r9], xmm0
0x180004a27: movaps   xmmword ptr [r9 + 0x10], xmm0
0x180004a2c: movaps   xmmword ptr [r9 + 0x20], xmm0
0x180004a31: movups   xmmword ptr [rdx], xmm0
0x180004a34: ret      
0x180004a35: nop      word ptr [rax + rax]
0x180004a40: cmp      r8, 0x10
0x180004a44: jb       0x180004a70
0x180004a46: lea      r9, [r8 + rcx - 0x10]
0x180004a4b: and      r8, 0x20
0x180004a4f: movups   xmmword ptr [rcx], xmm0
0x180004a52: shr      r8, 1
0x180004a55: movups   xmmword ptr [r9], xmm0
0x180004a59: movups   xmmword ptr [rcx + r8], xmm0
0x180004a5e: neg      r8
0x180004a61: movups   xmmword ptr [r9 + r8], xmm0
0x180004a66: ret      
0x180004a67: nop      word ptr [rax + rax]
0x180004a70: cmp      r8, 4
0x180004a74: jb       0x180004aa0
0x180004a76: lea      r9, [r8 + rcx - 4]
0x180004a7b: and      r8, 8
0x180004a7f: mov      dword ptr [rcx], edx
0x180004a81: shr      r8, 1
0x180004a84: mov      dword ptr [r9], edx
0x180004a87: mov      dword ptr [rcx + r8], edx
0x180004a8b: neg      r8
0x180004a8e: mov      dword ptr [r9 + r8], edx
0x180004a92: ret      
0x180004a93: nop      word ptr [rax + rax]
0x180004aa0: test     r8, r8
0x180004aa3: je       0x180004ab6
0x180004aa5: mov      byte ptr [rcx], dl
0x180004aa7: lea      r9, [rcx + r8 - 2]
0x180004aac: cmp      r8, 1
0x180004ab0: je       0x180004ab6
0x180004ab2: mov      word ptr [r9], dx
0x180004ab6: ret      
0x180004ab7: add      byte ptr [rax], al
0x180004ab9: add      byte ptr [rax], al
0x180004abb: add      byte ptr [rax], al
0x180004abd: add      byte ptr [rax], al
0x180004abf: add      byte ptr [rax], al
0x180004ac1: add      byte ptr [rax], al
0x180004ac3: add      byte ptr [rax], al
0x180004ac5: add      byte ptr [rax], al
0x180004ac7: add      byte ptr [rax], al
0x180004ac9: add      byte ptr [rax], al
0x180004acb: add      byte ptr [rax], al
0x180004acd: add      byte ptr [rax], al
0x180004acf: add      byte ptr [rax], al
0x180004ad1: add      byte ptr [rax], al
0x180004ad3: add      byte ptr [rax], al
0x180004ad5: add      byte ptr [rax], al
0x180004ad7: add      byte ptr [rax], al
0x180004ad9: add      byte ptr [rax], al
0x180004adb: add      byte ptr [rax], al
0x180004add: add      byte ptr [rax], al
0x180004adf: add      byte ptr [rax], al
0x180004ae1: add      byte ptr [rax], al
0x180004ae3: add      byte ptr [rax], al
0x180004ae5: add      byte ptr [rax], al
0x180004ae7: add      byte ptr [rax], al
0x180004ae9: add      byte ptr [rax], al
0x180004aeb: add      byte ptr [rax], al
0x180004aed: add      byte ptr [rax], al
0x180004aef: add      byte ptr [rax], al
0x180004af1: add      byte ptr [rax], al
0x180004af3: add      byte ptr [rax], al
0x180004af5: add      byte ptr [rax], al
0x180004af7: add      byte ptr [rax], al
0x180004af9: add      byte ptr [rax], al
0x180004afb: add      byte ptr [rax], al
0x180004afd: add      byte ptr [rax], al
0x180004aff: add      byte ptr [rax], al
0x180004b01: add      byte ptr [rax], al
0x180004b03: add      byte ptr [rax], al
0x180004b05: add      byte ptr [rax], al
0x180004b07: add      byte ptr [rax], al
0x180004b09: add      byte ptr [rax], al
0x180004b0b: add      byte ptr [rax], al
0x180004b0d: add      byte ptr [rax], al
0x180004b0f: add      byte ptr [rax], al
0x180004b11: add      byte ptr [rax], al
0x180004b13: add      byte ptr [rax], al
0x180004b15: add      byte ptr [rax], al
0x180004b17: add      byte ptr [rax], al
0x180004b19: add      byte ptr [rax], al
0x180004b1b: add      byte ptr [rax], al
0x180004b1d: add      byte ptr [rax], al
0x180004b1f: add      byte ptr [rax], al
0x180004b21: add      byte ptr [rax], al
0x180004b23: add      byte ptr [rax], al
0x180004b25: add      byte ptr [rax], al
0x180004b27: add      byte ptr [rax], al
0x180004b29: add      byte ptr [rax], al
0x180004b2b: add      byte ptr [rax], al
0x180004b2d: add      byte ptr [rax], al
0x180004b2f: add      byte ptr [rax], al
0x180004b31: add      byte ptr [rax], al
0x180004b33: add      byte ptr [rax], al
0x180004b35: add      byte ptr [rax], al
0x180004b37: add      byte ptr [rax], al
0x180004b39: add      byte ptr [rax], al
0x180004b3b: add      byte ptr [rax], al
0x180004b3d: add      byte ptr [rax], al
0x180004b3f: add      byte ptr [rax], al
0x180004b41: add      byte ptr [rax], al
0x180004b43: add      byte ptr [rax], al
0x180004b45: add      byte ptr [rax], al
0x180004b47: add      byte ptr [rax], al
0x180004b49: add      byte ptr [rax], al
0x180004b4b: add      byte ptr [rax], al
0x180004b4d: add      byte ptr [rax], al
0x180004b4f: add      byte ptr [rax], al
0x180004b51: add      byte ptr [rax], al
0x180004b53: add      byte ptr [rax], al
0x180004b55: add      byte ptr [rax], al
0x180004b57: add      byte ptr [rax], al
0x180004b59: add      byte ptr [rax], al
0x180004b5b: add      byte ptr [rax], al
0x180004b5d: add      byte ptr [rax], al
0x180004b5f: add      byte ptr [rax], al
0x180004b61: add      byte ptr [rax], al
0x180004b63: add      byte ptr [rax], al
0x180004b65: add      byte ptr [rax], al
0x180004b67: add      byte ptr [rax], al
0x180004b69: add      byte ptr [rax], al
0x180004b6b: add      byte ptr [rax], al
0x180004b6d: add      byte ptr [rax], al
0x180004b6f: add      byte ptr [rax], al
0x180004b71: add      byte ptr [rax], al
0x180004b73: add      byte ptr [rax], al
0x180004b75: add      byte ptr [rax], al
0x180004b77: add      byte ptr [rax], al
0x180004b79: add      byte ptr [rax], al
0x180004b7b: add      byte ptr [rax], al
0x180004b7d: add      byte ptr [rax], al
0x180004b7f: add      byte ptr [rax], al
0x180004b81: add      byte ptr [rax], al
0x180004b83: add      byte ptr [rax], al
0x180004b85: add      byte ptr [rax], al
0x180004b87: add      byte ptr [rax], al
0x180004b89: add      byte ptr [rax], al
0x180004b8b: add      byte ptr [rax], al
0x180004b8d: add      byte ptr [rax], al
0x180004b8f: add      byte ptr [rax], al
0x180004b91: add      byte ptr [rax], al
0x180004b93: add      byte ptr [rax], al
0x180004b95: add      byte ptr [rax], al
0x180004b97: add      byte ptr [rax], al
0x180004b99: add      byte ptr [rax], al
0x180004b9b: add      byte ptr [rax], al
0x180004b9d: add      byte ptr [rax], al
0x180004b9f: add      byte ptr [rax], al
0x180004ba1: add      byte ptr [rax], al
0x180004ba3: add      byte ptr [rax], al
0x180004ba5: add      byte ptr [rax], al
0x180004ba7: add      byte ptr [rax], al
0x180004ba9: add      byte ptr [rax], al
0x180004bab: add      byte ptr [rax], al
0x180004bad: add      byte ptr [rax], al
0x180004baf: add      byte ptr [rax], al
0x180004bb1: add      byte ptr [rax], al
0x180004bb3: add      byte ptr [rax], al
0x180004bb5: add      byte ptr [rax], al
0x180004bb7: add      byte ptr [rax], al
0x180004bb9: add      byte ptr [rax], al
0x180004bbb: add      byte ptr [rax], al
0x180004bbd: add      byte ptr [rax], al
0x180004bbf: add      byte ptr [rax], al
0x180004bc1: add      byte ptr [rax], al
0x180004bc3: add      byte ptr [rax], al
0x180004bc5: add      byte ptr [rax], al
0x180004bc7: add      byte ptr [rax], al
0x180004bc9: add      byte ptr [rax], al
0x180004bcb: add      byte ptr [rax], al
0x180004bcd: add      byte ptr [rax], al
0x180004bcf: add      byte ptr [rax], al
0x180004bd1: add      byte ptr [rax], al
0x180004bd3: add      byte ptr [rax], al
0x180004bd5: add      byte ptr [rax], al
0x180004bd7: add      byte ptr [rax], al
0x180004bd9: add      byte ptr [rax], al
0x180004bdb: add      byte ptr [rax], al
0x180004bdd: add      byte ptr [rax], al
0x180004bdf: add      byte ptr [rax], al
0x180004be1: add      byte ptr [rax], al
0x180004be3: add      byte ptr [rax], al
0x180004be5: add      byte ptr [rax], al
0x180004be7: add      byte ptr [rax], al
0x180004be9: add      byte ptr [rax], al
0x180004beb: add      byte ptr [rax], al
0x180004bed: add      byte ptr [rax], al
0x180004bef: add      byte ptr [rax], al
0x180004bf1: add      byte ptr [rax], al
0x180004bf3: add      byte ptr [rax], al
0x180004bf5: add      byte ptr [rax], al
0x180004bf7: add      byte ptr [rax], al
0x180004bf9: add      byte ptr [rax], al
0x180004bfb: add      byte ptr [rax], al
0x180004bfd: add      byte ptr [rax], al
0x180004bff: add      byte ptr [rax], al
0x180004c01: add      byte ptr [rax], al
0x180004c03: add      byte ptr [rax], al
0x180004c05: add      byte ptr [rax], al
0x180004c07: add      byte ptr [rax], al
0x180004c09: add      byte ptr [rax], al
0x180004c0b: add      byte ptr [rax], al
0x180004c0d: add      byte ptr [rax], al
0x180004c0f: add      byte ptr [rax], al
0x180004c11: add      byte ptr [rax], al
0x180004c13: add      byte ptr [rax], al
0x180004c15: add      byte ptr [rax], al
0x180004c17: add      byte ptr [rax], al
0x180004c19: add      byte ptr [rax], al
0x180004c1b: add      byte ptr [rax], al
0x180004c1d: add      byte ptr [rax], al
0x180004c1f: add      byte ptr [rax], al
0x180004c21: add      byte ptr [rax], al
0x180004c23: add      byte ptr [rax], al
0x180004c25: add      byte ptr [rax], al
0x180004c27: add      byte ptr [rax], al
0x180004c29: add      byte ptr [rax], al
0x180004c2b: add      byte ptr [rax], al
0x180004c2d: add      byte ptr [rax], al
0x180004c2f: add      byte ptr [rax], al
0x180004c31: add      byte ptr [rax], al
0x180004c33: add      byte ptr [rax], al
0x180004c35: add      byte ptr [rax], al
0x180004c37: add      byte ptr [rax], al
0x180004c39: add      byte ptr [rax], al
0x180004c3b: add      byte ptr [rax], al
0x180004c3d: add      byte ptr [rax], al
0x180004c3f: add      byte ptr [rax], al
0x180004c41: add      byte ptr [rax], al
0x180004c43: add      byte ptr [rax], al
0x180004c45: add      byte ptr [rax], al
0x180004c47: add      byte ptr [rax], al
0x180004c49: add      byte ptr [rax], al
0x180004c4b: add      byte ptr [rax], al
0x180004c4d: add      byte ptr [rax], al
0x180004c4f: add      byte ptr [rax], al
0x180004c51: add      byte ptr [rax], al
0x180004c53: add      byte ptr [rax], al
0x180004c55: add      byte ptr [rax], al
0x180004c57: add      byte ptr [rax], al
0x180004c59: add      byte ptr [rax], al
0x180004c5b: add      byte ptr [rax], al
0x180004c5d: add      byte ptr [rax], al
0x180004c5f: add      byte ptr [rax], al
0x180004c61: add      byte ptr [rax], al
0x180004c63: add      byte ptr [rax], al
0x180004c65: add      byte ptr [rax], al
0x180004c67: add      byte ptr [rax], al
0x180004c69: add      byte ptr [rax], al
0x180004c6b: add      byte ptr [rax], al
0x180004c6d: add      byte ptr [rax], al
0x180004c6f: add      byte ptr [rax], al
0x180004c71: add      byte ptr [rax], al
0x180004c73: add      byte ptr [rax], al
0x180004c75: add      byte ptr [rax], al
0x180004c77: add      byte ptr [rax], al
0x180004c79: add      byte ptr [rax], al
0x180004c7b: add      byte ptr [rax], al
0x180004c7d: add      byte ptr [rax], al
0x180004c7f: add      byte ptr [rax], al
0x180004c81: add      byte ptr [rax], al
0x180004c83: add      byte ptr [rax], al
0x180004c85: add      byte ptr [rax], al
0x180004c87: add      byte ptr [rax], al
0x180004c89: add      byte ptr [rax], al
0x180004c8b: add      byte ptr [rax], al
0x180004c8d: add      byte ptr [rax], al
0x180004c8f: add      byte ptr [rax], al
0x180004c91: add      byte ptr [rax], al
0x180004c93: add      byte ptr [rax], al
0x180004c95: add      byte ptr [rax], al
0x180004c97: add      byte ptr [rax], al
0x180004c99: add      byte ptr [rax], al
0x180004c9b: add      byte ptr [rax], al
0x180004c9d: add      byte ptr [rax], al
0x180004c9f: add      byte ptr [rax], al
0x180004ca1: add      byte ptr [rax], al
0x180004ca3: add      byte ptr [rax], al
0x180004ca5: add      byte ptr [rax], al
0x180004ca7: add      byte ptr [rax], al
0x180004ca9: add      byte ptr [rax], al
0x180004cab: add      byte ptr [rax], al
0x180004cad: add      byte ptr [rax], al
0x180004caf: add      byte ptr [rax], al
0x180004cb1: add      byte ptr [rax], al
0x180004cb3: add      byte ptr [rax], al
0x180004cb5: add      byte ptr [rax], al
0x180004cb7: add      byte ptr [rax], al
0x180004cb9: add      byte ptr [rax], al
0x180004cbb: add      byte ptr [rax], al
0x180004cbd: add      byte ptr [rax], al
0x180004cbf: add      byte ptr [rax], al
0x180004cc1: add      byte ptr [rax], al
0x180004cc3: add      byte ptr [rax], al
0x180004cc5: add      byte ptr [rax], al
0x180004cc7: add      byte ptr [rax], al
0x180004cc9: add      byte ptr [rax], al
0x180004ccb: add      byte ptr [rax], al
0x180004ccd: add      byte ptr [rax], al
0x180004ccf: add      byte ptr [rax], al
0x180004cd1: add      byte ptr [rax], al
0x180004cd3: add      byte ptr [rax], al
0x180004cd5: add      byte ptr [rax], al
0x180004cd7: add      byte ptr [rax], al
0x180004cd9: add      byte ptr [rax], al
0x180004cdb: add      byte ptr [rax], al
0x180004cdd: add      byte ptr [rax], al
0x180004cdf: add      byte ptr [rax], al
0x180004ce1: add      byte ptr [rax], al
0x180004ce3: add      byte ptr [rax], al
0x180004ce5: add      byte ptr [rax], al
0x180004ce7: add      byte ptr [rax], al
0x180004ce9: add      byte ptr [rax], al
0x180004ceb: add      byte ptr [rax], al
0x180004ced: add      byte ptr [rax], al
0x180004cef: add      byte ptr [rax], al
0x180004cf1: add      byte ptr [rax], al
0x180004cf3: add      byte ptr [rax], al
0x180004cf5: add      byte ptr [rax], al
0x180004cf7: add      byte ptr [rax], al
0x180004cf9: add      byte ptr [rax], al
0x180004cfb: add      byte ptr [rax], al
0x180004cfd: add      byte ptr [rax], al
0x180004cff: add      byte ptr [rax], al
0x180004d01: add      byte ptr [rax], al
0x180004d03: add      byte ptr [rax], al
0x180004d05: add      byte ptr [rax], al
0x180004d07: add      byte ptr [rax], al
0x180004d09: add      byte ptr [rax], al
0x180004d0b: add      byte ptr [rax], al
0x180004d0d: add      byte ptr [rax], al
0x180004d0f: add      byte ptr [rax], al
0x180004d11: add      byte ptr [rax], al
0x180004d13: add      byte ptr [rax], al
0x180004d15: add      byte ptr [rax], al
0x180004d17: add      byte ptr [rax], al
0x180004d19: add      byte ptr [rax], al
0x180004d1b: add      byte ptr [rax], al
0x180004d1d: add      byte ptr [rax], al
0x180004d1f: add      byte ptr [rax], al
0x180004d21: add      byte ptr [rax], al
0x180004d23: add      byte ptr [rax], al
0x180004d25: add      byte ptr [rax], al
0x180004d27: add      byte ptr [rax], al
0x180004d29: add      byte ptr [rax], al
0x180004d2b: add      byte ptr [rax], al
0x180004d2d: add      byte ptr [rax], al
0x180004d2f: add      byte ptr [rax], al
0x180004d31: add      byte ptr [rax], al
0x180004d33: add      byte ptr [rax], al
0x180004d35: add      byte ptr [rax], al
0x180004d37: add      byte ptr [rax], al
0x180004d39: add      byte ptr [rax], al
0x180004d3b: add      byte ptr [rax], al
0x180004d3d: add      byte ptr [rax], al
0x180004d3f: add      byte ptr [rax], al
0x180004d41: add      byte ptr [rax], al
0x180004d43: add      byte ptr [rax], al
0x180004d45: add      byte ptr [rax], al
0x180004d47: add      byte ptr [rax], al
0x180004d49: add      byte ptr [rax], al
0x180004d4b: add      byte ptr [rax], al
0x180004d4d: add      byte ptr [rax], al
0x180004d4f: add      byte ptr [rax], al
0x180004d51: add      byte ptr [rax], al
0x180004d53: add      byte ptr [rax], al
0x180004d55: add      byte ptr [rax], al
0x180004d57: add      byte ptr [rax], al
0x180004d59: add      byte ptr [rax], al
0x180004d5b: add      byte ptr [rax], al
0x180004d5d: add      byte ptr [rax], al
0x180004d5f: add      byte ptr [rax], al
0x180004d61: add      byte ptr [rax], al
0x180004d63: add      byte ptr [rax], al
0x180004d65: add      byte ptr [rax], al
0x180004d67: add      byte ptr [rax], al
0x180004d69: add      byte ptr [rax], al
0x180004d6b: add      byte ptr [rax], al
0x180004d6d: add      byte ptr [rax], al
0x180004d6f: add      byte ptr [rax], al
0x180004d71: add      byte ptr [rax], al
0x180004d73: add      byte ptr [rax], al
0x180004d75: add      byte ptr [rax], al
0x180004d77: add      byte ptr [rax], al
0x180004d79: add      byte ptr [rax], al
0x180004d7b: add      byte ptr [rax], al
0x180004d7d: add      byte ptr [rax], al
0x180004d7f: add      byte ptr [rax], al
0x180004d81: add      byte ptr [rax], al
0x180004d83: add      byte ptr [rax], al
0x180004d85: add      byte ptr [rax], al
0x180004d87: add      byte ptr [rax], al
0x180004d89: add      byte ptr [rax], al
0x180004d8b: add      byte ptr [rax], al
0x180004d8d: add      byte ptr [rax], al
0x180004d8f: add      byte ptr [rax], al
0x180004d91: add      byte ptr [rax], al
0x180004d93: add      byte ptr [rax], al
0x180004d95: add      byte ptr [rax], al
0x180004d97: add      byte ptr [rax], al
0x180004d99: add      byte ptr [rax], al
0x180004d9b: add      byte ptr [rax], al
0x180004d9d: add      byte ptr [rax], al
0x180004d9f: add      byte ptr [rax], al
0x180004da1: add      byte ptr [rax], al
0x180004da3: add      byte ptr [rax], al
0x180004da5: add      byte ptr [rax], al
0x180004da7: add      byte ptr [rax], al
0x180004da9: add      byte ptr [rax], al
0x180004dab: add      byte ptr [rax], al
0x180004dad: add      byte ptr [rax], al
0x180004daf: add      byte ptr [rax], al
0x180004db1: add      byte ptr [rax], al
0x180004db3: add      byte ptr [rax], al
0x180004db5: add      byte ptr [rax], al
0x180004db7: add      byte ptr [rax], al
0x180004db9: add      byte ptr [rax], al
0x180004dbb: add      byte ptr [rax], al
0x180004dbd: add      byte ptr [rax], al
0x180004dbf: add      byte ptr [rax], al
0x180004dc1: add      byte ptr [rax], al
0x180004dc3: add      byte ptr [rax], al
0x180004dc5: add      byte ptr [rax], al
0x180004dc7: add      byte ptr [rax], al
0x180004dc9: add      byte ptr [rax], al
0x180004dcb: add      byte ptr [rax], al
0x180004dcd: add      byte ptr [rax], al
0x180004dcf: add      byte ptr [rax], al
0x180004dd1: add      byte ptr [rax], al
0x180004dd3: add      byte ptr [rax], al
0x180004dd5: add      byte ptr [rax], al
0x180004dd7: add      byte ptr [rax], al
0x180004dd9: add      byte ptr [rax], al
0x180004ddb: add      byte ptr [rax], al
0x180004ddd: add      byte ptr [rax], al
0x180004ddf: add      byte ptr [rax], al
0x180004de1: add      byte ptr [rax], al
0x180004de3: add      byte ptr [rax], al
0x180004de5: add      byte ptr [rax], al
0x180004de7: add      byte ptr [rax], al
0x180004de9: add      byte ptr [rax], al
0x180004deb: add      byte ptr [rax], al
0x180004ded: add      byte ptr [rax], al
0x180004def: add      byte ptr [rax], al
0x180004df1: add      byte ptr [rax], al
0x180004df3: add      byte ptr [rax], al
0x180004df5: add      byte ptr [rax], al
0x180004df7: add      byte ptr [rax], al
0x180004df9: add      byte ptr [rax], al
0x180004dfb: add      byte ptr [rax], al
0x180004dfd: add      byte ptr [rax], al
0x180004dff: add      byte ptr [rax], al
0x180004e01: add      byte ptr [rax], al
0x180004e03: add      byte ptr [rax], al
0x180004e05: add      byte ptr [rax], al
0x180004e07: add      byte ptr [rax], al
0x180004e09: add      byte ptr [rax], al
0x180004e0b: add      byte ptr [rax], al
0x180004e0d: add      byte ptr [rax], al
0x180004e0f: add      byte ptr [rax], al
0x180004e11: add      byte ptr [rax], al
0x180004e13: add      byte ptr [rax], al
0x180004e15: add      byte ptr [rax], al
0x180004e17: add      byte ptr [rax], al
0x180004e19: add      byte ptr [rax], al
0x180004e1b: add      byte ptr [rax], al
0x180004e1d: add      byte ptr [rax], al
0x180004e1f: add      byte ptr [rax], al
0x180004e21: add      byte ptr [rax], al
0x180004e23: add      byte ptr [rax], al
0x180004e25: add      byte ptr [rax], al
0x180004e27: add      byte ptr [rax], al
0x180004e29: add      byte ptr [rax], al
0x180004e2b: add      byte ptr [rax], al
0x180004e2d: add      byte ptr [rax], al
0x180004e2f: add      byte ptr [rax], al
0x180004e31: add      byte ptr [rax], al
0x180004e33: add      byte ptr [rax], al
0x180004e35: add      byte ptr [rax], al
0x180004e37: add      byte ptr [rax], al
0x180004e39: add      byte ptr [rax], al
0x180004e3b: add      byte ptr [rax], al
0x180004e3d: add      byte ptr [rax], al
0x180004e3f: add      byte ptr [rax], al
0x180004e41: add      byte ptr [rax], al
0x180004e43: add      byte ptr [rax], al
0x180004e45: add      byte ptr [rax], al
0x180004e47: add      byte ptr [rax], al
0x180004e49: add      byte ptr [rax], al
0x180004e4b: add      byte ptr [rax], al
0x180004e4d: add      byte ptr [rax], al
0x180004e4f: add      byte ptr [rax], al
0x180004e51: add      byte ptr [rax], al
0x180004e53: add      byte ptr [rax], al
0x180004e55: add      byte ptr [rax], al
0x180004e57: add      byte ptr [rax], al
0x180004e59: add      byte ptr [rax], al
0x180004e5b: add      byte ptr [rax], al
0x180004e5d: add      byte ptr [rax], al
0x180004e5f: add      byte ptr [rax], al
0x180004e61: add      byte ptr [rax], al
0x180004e63: add      byte ptr [rax], al
0x180004e65: add      byte ptr [rax], al
0x180004e67: add      byte ptr [rax], al
0x180004e69: add      byte ptr [rax], al
0x180004e6b: add      byte ptr [rax], al
0x180004e6d: add      byte ptr [rax], al
0x180004e6f: add      byte ptr [rax], al
0x180004e71: add      byte ptr [rax], al
0x180004e73: add      byte ptr [rax], al
0x180004e75: add      byte ptr [rax], al
0x180004e77: add      byte ptr [rax], al
0x180004e79: add      byte ptr [rax], al
0x180004e7b: add      byte ptr [rax], al
0x180004e7d: add      byte ptr [rax], al
0x180004e7f: add      byte ptr [rax], al
0x180004e81: add      byte ptr [rax], al
0x180004e83: add      byte ptr [rax], al
0x180004e85: add      byte ptr [rax], al
0x180004e87: add      byte ptr [rax], al
0x180004e89: add      byte ptr [rax], al
0x180004e8b: add      byte ptr [rax], al
0x180004e8d: add      byte ptr [rax], al
0x180004e8f: add      byte ptr [rax], al
0x180004e91: add      byte ptr [rax], al
0x180004e93: add      byte ptr [rax], al
0x180004e95: add      byte ptr [rax], al
0x180004e97: add      byte ptr [rax], al
0x180004e99: add      byte ptr [rax], al
0x180004e9b: add      byte ptr [rax], al
0x180004e9d: add      byte ptr [rax], al
0x180004e9f: add      byte ptr [rax], al
0x180004ea1: add      byte ptr [rax], al
0x180004ea3: add      byte ptr [rax], al
0x180004ea5: add      byte ptr [rax], al
0x180004ea7: add      byte ptr [rax], al
0x180004ea9: add      byte ptr [rax], al
0x180004eab: add      byte ptr [rax], al
0x180004ead: add      byte ptr [rax], al
0x180004eaf: add      byte ptr [rax], al
0x180004eb1: add      byte ptr [rax], al
0x180004eb3: add      byte ptr [rax], al
0x180004eb5: add      byte ptr [rax], al
0x180004eb7: add      byte ptr [rax], al
0x180004eb9: add      byte ptr [rax], al
0x180004ebb: add      byte ptr [rax], al
0x180004ebd: add      byte ptr [rax], al
0x180004ebf: add      byte ptr [rax], al
0x180004ec1: add      byte ptr [rax], al
0x180004ec3: add      byte ptr [rax], al
0x180004ec5: add      byte ptr [rax], al
0x180004ec7: add      byte ptr [rax], al
0x180004ec9: add      byte ptr [rax], al
0x180004ecb: add      byte ptr [rax], al
0x180004ecd: add      byte ptr [rax], al
0x180004ecf: add      byte ptr [rax], al
0x180004ed1: add      byte ptr [rax], al
0x180004ed3: add      byte ptr [rax], al
0x180004ed5: add      byte ptr [rax], al
0x180004ed7: add      byte ptr [rax], al
0x180004ed9: add      byte ptr [rax], al
0x180004edb: add      byte ptr [rax], al
0x180004edd: add      byte ptr [rax], al
0x180004edf: add      byte ptr [rax], al
0x180004ee1: add      byte ptr [rax], al
0x180004ee3: add      byte ptr [rax], al
0x180004ee5: add      byte ptr [rax], al
0x180004ee7: add      byte ptr [rax], al
0x180004ee9: add      byte ptr [rax], al
0x180004eeb: add      byte ptr [rax], al
0x180004eed: add      byte ptr [rax], al
0x180004eef: add      byte ptr [rax], al
0x180004ef1: add      byte ptr [rax], al
0x180004ef3: add      byte ptr [rax], al
0x180004ef5: add      byte ptr [rax], al
0x180004ef7: add      byte ptr [rax], al
0x180004ef9: add      byte ptr [rax], al
0x180004efb: add      byte ptr [rax], al
0x180004efd: add      byte ptr [rax], al
0x180004eff: add      byte ptr [rax], al
0x180004f01: add      byte ptr [rax], al
0x180004f03: add      byte ptr [rax], al
0x180004f05: add      byte ptr [rax], al
0x180004f07: add      byte ptr [rax], al
0x180004f09: add      byte ptr [rax], al
0x180004f0b: add      byte ptr [rax], al
0x180004f0d: add      byte ptr [rax], al
0x180004f0f: add      byte ptr [rax], al
0x180004f11: add      byte ptr [rax], al
0x180004f13: add      byte ptr [rax], al
0x180004f15: add      byte ptr [rax], al
0x180004f17: add      byte ptr [rax], al
0x180004f19: add      byte ptr [rax], al
0x180004f1b: add      byte ptr [rax], al
0x180004f1d: add      byte ptr [rax], al
0x180004f1f: add      byte ptr [rax], al
0x180004f21: add      byte ptr [rax], al
0x180004f23: add      byte ptr [rax], al
0x180004f25: add      byte ptr [rax], al
0x180004f27: add      byte ptr [rax], al
0x180004f29: add      byte ptr [rax], al
0x180004f2b: add      byte ptr [rax], al
0x180004f2d: add      byte ptr [rax], al
0x180004f2f: add      byte ptr [rax], al
0x180004f31: add      byte ptr [rax], al
0x180004f33: add      byte ptr [rax], al
0x180004f35: add      byte ptr [rax], al
0x180004f37: add      byte ptr [rax], al
0x180004f39: add      byte ptr [rax], al
0x180004f3b: add      byte ptr [rax], al
0x180004f3d: add      byte ptr [rax], al
0x180004f3f: add      byte ptr [rax], al
0x180004f41: add      byte ptr [rax], al
0x180004f43: add      byte ptr [rax], al
0x180004f45: add      byte ptr [rax], al
0x180004f47: add      byte ptr [rax], al
0x180004f49: add      byte ptr [rax], al
0x180004f4b: add      byte ptr [rax], al
0x180004f4d: add      byte ptr [rax], al
0x180004f4f: add      byte ptr [rax], al
0x180004f51: add      byte ptr [rax], al
0x180004f53: add      byte ptr [rax], al
0x180004f55: add      byte ptr [rax], al
0x180004f57: add      byte ptr [rax], al
0x180004f59: add      byte ptr [rax], al
0x180004f5b: add      byte ptr [rax], al
0x180004f5d: add      byte ptr [rax], al
0x180004f5f: add      byte ptr [rax], al
0x180004f61: add      byte ptr [rax], al
0x180004f63: add      byte ptr [rax], al
0x180004f65: add      byte ptr [rax], al
0x180004f67: add      byte ptr [rax], al
0x180004f69: add      byte ptr [rax], al
0x180004f6b: add      byte ptr [rax], al
0x180004f6d: add      byte ptr [rax], al
0x180004f6f: add      byte ptr [rax], al
0x180004f71: add      byte ptr [rax], al
0x180004f73: add      byte ptr [rax], al
0x180004f75: add      byte ptr [rax], al
0x180004f77: add      byte ptr [rax], al
0x180004f79: add      byte ptr [rax], al
0x180004f7b: add      byte ptr [rax], al
0x180004f7d: add      byte ptr [rax], al
0x180004f7f: add      byte ptr [rax], al
0x180004f81: add      byte ptr [rax], al
0x180004f83: add      byte ptr [rax], al
0x180004f85: add      byte ptr [rax], al
0x180004f87: add      byte ptr [rax], al
0x180004f89: add      byte ptr [rax], al
0x180004f8b: add      byte ptr [rax], al
0x180004f8d: add      byte ptr [rax], al
0x180004f8f: add      byte ptr [rax], al
0x180004f91: add      byte ptr [rax], al
0x180004f93: add      byte ptr [rax], al
0x180004f95: add      byte ptr [rax], al
0x180004f97: add      byte ptr [rax], al
0x180004f99: add      byte ptr [rax], al
0x180004f9b: add      byte ptr [rax], al
0x180004f9d: add      byte ptr [rax], al
0x180004f9f: add      byte ptr [rax], al
0x180004fa1: add      byte ptr [rax], al
0x180004fa3: add      byte ptr [rax], al
0x180004fa5: add      byte ptr [rax], al
0x180004fa7: add      byte ptr [rax], al
0x180004fa9: add      byte ptr [rax], al
0x180004fab: add      byte ptr [rax], al
0x180004fad: add      byte ptr [rax], al
0x180004faf: add      byte ptr [rax], al
0x180004fb1: add      byte ptr [rax], al
0x180004fb3: add      byte ptr [rax], al
0x180004fb5: add      byte ptr [rax], al
0x180004fb7: add      byte ptr [rax], al
0x180004fb9: add      byte ptr [rax], al
0x180004fbb: add      byte ptr [rax], al
0x180004fbd: add      byte ptr [rax], al
0x180004fbf: add      byte ptr [rax], al
0x180004fc1: add      byte ptr [rax], al
0x180004fc3: add      byte ptr [rax], al
0x180004fc5: add      byte ptr [rax], al
0x180004fc7: add      byte ptr [rax], al
0x180004fc9: add      byte ptr [rax], al
0x180004fcb: add      byte ptr [rax], al
0x180004fcd: add      byte ptr [rax], al
0x180004fcf: add      byte ptr [rax], al
0x180004fd1: add      byte ptr [rax], al
0x180004fd3: add      byte ptr [rax], al
0x180004fd5: add      byte ptr [rax], al
0x180004fd7: add      byte ptr [rax], al
0x180004fd9: add      byte ptr [rax], al
0x180004fdb: add      byte ptr [rax], al
0x180004fdd: add      byte ptr [rax], al
0x180004fdf: add      byte ptr [rax], al
0x180004fe1: add      byte ptr [rax], al
0x180004fe3: add      byte ptr [rax], al
0x180004fe5: add      byte ptr [rax], al
0x180004fe7: add      byte ptr [rax], al
0x180004fe9: add      byte ptr [rax], al
0x180004feb: add      byte ptr [rax], al
0x180004fed: add      byte ptr [rax], al
0x180004fef: add      byte ptr [rax], al
0x180004ff1: add      byte ptr [rax], al
0x180004ff3: add      byte ptr [rax], al
0x180004ff5: add      byte ptr [rax], al
0x180004ff7: add      byte ptr [rax], al
0x180004ff9: add      byte ptr [rax], al
0x180004ffb: add      byte ptr [rax], al
0x180004ffd: add      byte ptr [rax], al
```

### Section: fothk (VA=0x180005000, 4088 instructions)
```asm
0x180005000: int3     
0x180005001: int3     
0x180005002: int3     
0x180005003: int3     
0x180005004: int3     
0x180005005: int3     
0x180005006: int3     
0x180005007: int3     
0x180005008: int3     
0x180005009: int3     
0x18000500a: int3     
0x18000500b: int3     
0x18000500c: int3     
0x18000500d: int3     
0x18000500e: int3     
0x18000500f: int3     
0x180005010: jmp      0x1800041e0
0x180005015: int3     
0x180005016: int3     
0x180005017: int3     
0x180005018: int3     
0x180005019: int3     
0x18000501a: int3     
0x18000501b: int3     
0x18000501c: int3     
0x18000501d: int3     
0x18000501e: int3     
0x18000501f: int3     
0x180005020: jmp      0x1800045c0
0x180005025: int3     
0x180005026: int3     
0x180005027: int3     
0x180005028: int3     
0x180005029: int3     
0x18000502a: int3     
0x18000502b: int3     
0x18000502c: int3     
0x18000502d: int3     
0x18000502e: int3     
0x18000502f: int3     
0x180005030: int3     
0x180005031: int3     
0x180005032: int3     
0x180005033: int3     
0x180005034: int3     
0x180005035: int3     
0x180005036: int3     
0x180005037: int3     
0x180005038: int3     
0x180005039: int3     
0x18000503a: int3     
0x18000503b: int3     
0x18000503c: int3     
0x18000503d: int3     
0x18000503e: int3     
0x18000503f: int3     
0x180005040: int3     
0x180005041: int3     
0x180005042: int3     
0x180005043: int3     
0x180005044: int3     
0x180005045: int3     
0x180005046: int3     
0x180005047: int3     
0x180005048: int3     
0x180005049: int3     
0x18000504a: int3     
0x18000504b: int3     
0x18000504c: int3     
0x18000504d: int3     
0x18000504e: int3     
0x18000504f: int3     
0x180005050: int3     
0x180005051: int3     
0x180005052: int3     
0x180005053: int3     
0x180005054: int3     
0x180005055: int3     
0x180005056: int3     
0x180005057: int3     
0x180005058: int3     
0x180005059: int3     
0x18000505a: int3     
0x18000505b: int3     
0x18000505c: int3     
0x18000505d: int3     
0x18000505e: int3     
0x18000505f: int3     
0x180005060: int3     
0x180005061: int3     
0x180005062: int3     
0x180005063: int3     
0x180005064: int3     
0x180005065: int3     
0x180005066: int3     
0x180005067: int3     
0x180005068: int3     
0x180005069: int3     
0x18000506a: int3     
0x18000506b: int3     
0x18000506c: int3     
0x18000506d: int3     
0x18000506e: int3     
0x18000506f: int3     
0x180005070: int3     
0x180005071: int3     
0x180005072: int3     
0x180005073: int3     
0x180005074: int3     
0x180005075: int3     
0x180005076: int3     
0x180005077: int3     
0x180005078: int3     
0x180005079: int3     
0x18000507a: int3     
0x18000507b: int3     
0x18000507c: int3     
0x18000507d: int3     
0x18000507e: int3     
0x18000507f: int3     
0x180005080: int3     
0x180005081: int3     
0x180005082: int3     
0x180005083: int3     
0x180005084: int3     
0x180005085: int3     
0x180005086: int3     
0x180005087: int3     
0x180005088: int3     
0x180005089: int3     
0x18000508a: int3     
0x18000508b: int3     
0x18000508c: int3     
0x18000508d: int3     
0x18000508e: int3     
0x18000508f: int3     
0x180005090: int3     
0x180005091: int3     
0x180005092: int3     
0x180005093: int3     
0x180005094: int3     
0x180005095: int3     
0x180005096: int3     
0x180005097: int3     
0x180005098: int3     
0x180005099: int3     
0x18000509a: int3     
0x18000509b: int3     
0x18000509c: int3     
0x18000509d: int3     
0x18000509e: int3     
0x18000509f: int3     
0x1800050a0: int3     
0x1800050a1: int3     
0x1800050a2: int3     
0x1800050a3: int3     
0x1800050a4: int3     
0x1800050a5: int3     
0x1800050a6: int3     
0x1800050a7: int3     
0x1800050a8: int3     
0x1800050a9: int3     
0x1800050aa: int3     
0x1800050ab: int3     
0x1800050ac: int3     
0x1800050ad: int3     
0x1800050ae: int3     
0x1800050af: int3     
0x1800050b0: int3     
0x1800050b1: int3     
0x1800050b2: int3     
0x1800050b3: int3     
0x1800050b4: int3     
0x1800050b5: int3     
0x1800050b6: int3     
0x1800050b7: int3     
0x1800050b8: int3     
0x1800050b9: int3     
0x1800050ba: int3     
0x1800050bb: int3     
0x1800050bc: int3     
0x1800050bd: int3     
0x1800050be: int3     
0x1800050bf: int3     
0x1800050c0: int3     
0x1800050c1: int3     
0x1800050c2: int3     
0x1800050c3: int3     
0x1800050c4: int3     
0x1800050c5: int3     
0x1800050c6: int3     
0x1800050c7: int3     
0x1800050c8: int3     
0x1800050c9: int3     
0x1800050ca: int3     
0x1800050cb: int3     
0x1800050cc: int3     
0x1800050cd: int3     
0x1800050ce: int3     
0x1800050cf: int3     
0x1800050d0: int3     
0x1800050d1: int3     
0x1800050d2: int3     
0x1800050d3: int3     
0x1800050d4: int3     
0x1800050d5: int3     
0x1800050d6: int3     
0x1800050d7: int3     
0x1800050d8: int3     
0x1800050d9: int3     
0x1800050da: int3     
0x1800050db: int3     
0x1800050dc: int3     
0x1800050dd: int3     
0x1800050de: int3     
0x1800050df: int3     
0x1800050e0: int3     
0x1800050e1: int3     
0x1800050e2: int3     
0x1800050e3: int3     
0x1800050e4: int3     
0x1800050e5: int3     
0x1800050e6: int3     
0x1800050e7: int3     
0x1800050e8: int3     
0x1800050e9: int3     
0x1800050ea: int3     
0x1800050eb: int3     
0x1800050ec: int3     
0x1800050ed: int3     
0x1800050ee: int3     
0x1800050ef: int3     
0x1800050f0: int3     
0x1800050f1: int3     
0x1800050f2: int3     
0x1800050f3: int3     
0x1800050f4: int3     
0x1800050f5: int3     
0x1800050f6: int3     
0x1800050f7: int3     
0x1800050f8: int3     
0x1800050f9: int3     
0x1800050fa: int3     
0x1800050fb: int3     
0x1800050fc: int3     
0x1800050fd: int3     
0x1800050fe: int3     
0x1800050ff: int3     
0x180005100: int3     
0x180005101: int3     
0x180005102: int3     
0x180005103: int3     
0x180005104: int3     
0x180005105: int3     
0x180005106: int3     
0x180005107: int3     
0x180005108: int3     
0x180005109: int3     
0x18000510a: int3     
0x18000510b: int3     
0x18000510c: int3     
0x18000510d: int3     
0x18000510e: int3     
0x18000510f: int3     
0x180005110: int3     
0x180005111: int3     
0x180005112: int3     
0x180005113: int3     
0x180005114: int3     
0x180005115: int3     
0x180005116: int3     
0x180005117: int3     
0x180005118: int3     
0x180005119: int3     
0x18000511a: int3     
0x18000511b: int3     
0x18000511c: int3     
0x18000511d: int3     
0x18000511e: int3     
0x18000511f: int3     
0x180005120: int3     
0x180005121: int3     
0x180005122: int3     
0x180005123: int3     
0x180005124: int3     
0x180005125: int3     
0x180005126: int3     
0x180005127: int3     
0x180005128: int3     
0x180005129: int3     
0x18000512a: int3     
0x18000512b: int3     
0x18000512c: int3     
0x18000512d: int3     
0x18000512e: int3     
0x18000512f: int3     
0x180005130: int3     
0x180005131: int3     
0x180005132: int3     
0x180005133: int3     
0x180005134: int3     
0x180005135: int3     
0x180005136: int3     
0x180005137: int3     
0x180005138: int3     
0x180005139: int3     
0x18000513a: int3     
0x18000513b: int3     
0x18000513c: int3     
0x18000513d: int3     
0x18000513e: int3     
0x18000513f: int3     
0x180005140: int3     
0x180005141: int3     
0x180005142: int3     
0x180005143: int3     
0x180005144: int3     
0x180005145: int3     
0x180005146: int3     
0x180005147: int3     
0x180005148: int3     
0x180005149: int3     
0x18000514a: int3     
0x18000514b: int3     
0x18000514c: int3     
0x18000514d: int3     
0x18000514e: int3     
0x18000514f: int3     
0x180005150: int3     
0x180005151: int3     
0x180005152: int3     
0x180005153: int3     
0x180005154: int3     
0x180005155: int3     
0x180005156: int3     
0x180005157: int3     
0x180005158: int3     
0x180005159: int3     
0x18000515a: int3     
0x18000515b: int3     
0x18000515c: int3     
0x18000515d: int3     
0x18000515e: int3     
0x18000515f: int3     
0x180005160: int3     
0x180005161: int3     
0x180005162: int3     
0x180005163: int3     
0x180005164: int3     
0x180005165: int3     
0x180005166: int3     
0x180005167: int3     
0x180005168: int3     
0x180005169: int3     
0x18000516a: int3     
0x18000516b: int3     
0x18000516c: int3     
0x18000516d: int3     
0x18000516e: int3     
0x18000516f: int3     
0x180005170: int3     
0x180005171: int3     
0x180005172: int3     
0x180005173: int3     
0x180005174: int3     
0x180005175: int3     
0x180005176: int3     
0x180005177: int3     
0x180005178: int3     
0x180005179: int3     
0x18000517a: int3     
0x18000517b: int3     
0x18000517c: int3     
0x18000517d: int3     
0x18000517e: int3     
0x18000517f: int3     
0x180005180: int3     
0x180005181: int3     
0x180005182: int3     
0x180005183: int3     
0x180005184: int3     
0x180005185: int3     
0x180005186: int3     
0x180005187: int3     
0x180005188: int3     
0x180005189: int3     
0x18000518a: int3     
0x18000518b: int3     
0x18000518c: int3     
0x18000518d: int3     
0x18000518e: int3     
0x18000518f: int3     
0x180005190: int3     
0x180005191: int3     
0x180005192: int3     
0x180005193: int3     
0x180005194: int3     
0x180005195: int3     
0x180005196: int3     
0x180005197: int3     
0x180005198: int3     
0x180005199: int3     
0x18000519a: int3     
0x18000519b: int3     
0x18000519c: int3     
0x18000519d: int3     
0x18000519e: int3     
0x18000519f: int3     
0x1800051a0: int3     
0x1800051a1: int3     
0x1800051a2: int3     
0x1800051a3: int3     
0x1800051a4: int3     
0x1800051a5: int3     
0x1800051a6: int3     
0x1800051a7: int3     
0x1800051a8: int3     
0x1800051a9: int3     
0x1800051aa: int3     
0x1800051ab: int3     
0x1800051ac: int3     
0x1800051ad: int3     
0x1800051ae: int3     
0x1800051af: int3     
0x1800051b0: int3     
0x1800051b1: int3     
0x1800051b2: int3     
0x1800051b3: int3     
0x1800051b4: int3     
0x1800051b5: int3     
0x1800051b6: int3     
0x1800051b7: int3     
0x1800051b8: int3     
0x1800051b9: int3     
0x1800051ba: int3     
0x1800051bb: int3     
0x1800051bc: int3     
0x1800051bd: int3     
0x1800051be: int3     
0x1800051bf: int3     
0x1800051c0: int3     
0x1800051c1: int3     
0x1800051c2: int3     
0x1800051c3: int3     
0x1800051c4: int3     
0x1800051c5: int3     
0x1800051c6: int3     
0x1800051c7: int3     
0x1800051c8: int3     
0x1800051c9: int3     
0x1800051ca: int3     
0x1800051cb: int3     
0x1800051cc: int3     
0x1800051cd: int3     
0x1800051ce: int3     
0x1800051cf: int3     
0x1800051d0: int3     
0x1800051d1: int3     
0x1800051d2: int3     
0x1800051d3: int3     
0x1800051d4: int3     
0x1800051d5: int3     
0x1800051d6: int3     
0x1800051d7: int3     
0x1800051d8: int3     
0x1800051d9: int3     
0x1800051da: int3     
0x1800051db: int3     
0x1800051dc: int3     
0x1800051dd: int3     
0x1800051de: int3     
0x1800051df: int3     
0x1800051e0: int3     
0x1800051e1: int3     
0x1800051e2: int3     
0x1800051e3: int3     
0x1800051e4: int3     
0x1800051e5: int3     
0x1800051e6: int3     
0x1800051e7: int3     
0x1800051e8: int3     
0x1800051e9: int3     
0x1800051ea: int3     
0x1800051eb: int3     
0x1800051ec: int3     
0x1800051ed: int3     
0x1800051ee: int3     
0x1800051ef: int3     
0x1800051f0: int3     
0x1800051f1: int3     
0x1800051f2: int3     
0x1800051f3: int3     
0x1800051f4: int3     
0x1800051f5: int3     
0x1800051f6: int3     
0x1800051f7: int3     
0x1800051f8: int3     
0x1800051f9: int3     
0x1800051fa: int3     
0x1800051fb: int3     
0x1800051fc: int3     
0x1800051fd: int3     
0x1800051fe: int3     
0x1800051ff: int3     
0x180005200: int3     
0x180005201: int3     
0x180005202: int3     
0x180005203: int3     
0x180005204: int3     
0x180005205: int3     
0x180005206: int3     
0x180005207: int3     
0x180005208: int3     
0x180005209: int3     
0x18000520a: int3     
0x18000520b: int3     
0x18000520c: int3     
0x18000520d: int3     
0x18000520e: int3     
0x18000520f: int3     
0x180005210: int3     
0x180005211: int3     
0x180005212: int3     
0x180005213: int3     
0x180005214: int3     
0x180005215: int3     
0x180005216: int3     
0x180005217: int3     
0x180005218: int3     
0x180005219: int3     
0x18000521a: int3     
0x18000521b: int3     
0x18000521c: int3     
0x18000521d: int3     
0x18000521e: int3     
0x18000521f: int3     
0x180005220: int3     
0x180005221: int3     
0x180005222: int3     
0x180005223: int3     
0x180005224: int3     
0x180005225: int3     
0x180005226: int3     
0x180005227: int3     
0x180005228: int3     
0x180005229: int3     
0x18000522a: int3     
0x18000522b: int3     
0x18000522c: int3     
0x18000522d: int3     
0x18000522e: int3     
0x18000522f: int3     
0x180005230: int3     
0x180005231: int3     
0x180005232: int3     
0x180005233: int3     
0x180005234: int3     
0x180005235: int3     
0x180005236: int3     
0x180005237: int3     
0x180005238: int3     
0x180005239: int3     
0x18000523a: int3     
0x18000523b: int3     
0x18000523c: int3     
0x18000523d: int3     
0x18000523e: int3     
0x18000523f: int3     
0x180005240: int3     
0x180005241: int3     
0x180005242: int3     
0x180005243: int3     
0x180005244: int3     
0x180005245: int3     
0x180005246: int3     
0x180005247: int3     
0x180005248: int3     
0x180005249: int3     
0x18000524a: int3     
0x18000524b: int3     
0x18000524c: int3     
0x18000524d: int3     
0x18000524e: int3     
0x18000524f: int3     
0x180005250: int3     
0x180005251: int3     
0x180005252: int3     
0x180005253: int3     
0x180005254: int3     
0x180005255: int3     
0x180005256: int3     
0x180005257: int3     
0x180005258: int3     
0x180005259: int3     
0x18000525a: int3     
0x18000525b: int3     
0x18000525c: int3     
0x18000525d: int3     
0x18000525e: int3     
0x18000525f: int3     
0x180005260: int3     
0x180005261: int3     
0x180005262: int3     
0x180005263: int3     
0x180005264: int3     
0x180005265: int3     
0x180005266: int3     
0x180005267: int3     
0x180005268: int3     
0x180005269: int3     
0x18000526a: int3     
0x18000526b: int3     
0x18000526c: int3     
0x18000526d: int3     
0x18000526e: int3     
0x18000526f: int3     
0x180005270: int3     
0x180005271: int3     
0x180005272: int3     
0x180005273: int3     
0x180005274: int3     
0x180005275: int3     
0x180005276: int3     
0x180005277: int3     
0x180005278: int3     
0x180005279: int3     
0x18000527a: int3     
0x18000527b: int3     
0x18000527c: int3     
0x18000527d: int3     
0x18000527e: int3     
0x18000527f: int3     
0x180005280: int3     
0x180005281: int3     
0x180005282: int3     
0x180005283: int3     
0x180005284: int3     
0x180005285: int3     
0x180005286: int3     
0x180005287: int3     
0x180005288: int3     
0x180005289: int3     
0x18000528a: int3     
0x18000528b: int3     
0x18000528c: int3     
0x18000528d: int3     
0x18000528e: int3     
0x18000528f: int3     
0x180005290: int3     
0x180005291: int3     
0x180005292: int3     
0x180005293: int3     
0x180005294: int3     
0x180005295: int3     
0x180005296: int3     
0x180005297: int3     
0x180005298: int3     
0x180005299: int3     
0x18000529a: int3     
0x18000529b: int3     
0x18000529c: int3     
0x18000529d: int3     
0x18000529e: int3     
0x18000529f: int3     
0x1800052a0: int3     
0x1800052a1: int3     
0x1800052a2: int3     
0x1800052a3: int3     
0x1800052a4: int3     
0x1800052a5: int3     
0x1800052a6: int3     
0x1800052a7: int3     
0x1800052a8: int3     
0x1800052a9: int3     
0x1800052aa: int3     
0x1800052ab: int3     
0x1800052ac: int3     
0x1800052ad: int3     
0x1800052ae: int3     
0x1800052af: int3     
0x1800052b0: int3     
0x1800052b1: int3     
0x1800052b2: int3     
0x1800052b3: int3     
0x1800052b4: int3     
0x1800052b5: int3     
0x1800052b6: int3     
0x1800052b7: int3     
0x1800052b8: int3     
0x1800052b9: int3     
0x1800052ba: int3     
0x1800052bb: int3     
0x1800052bc: int3     
0x1800052bd: int3     
0x1800052be: int3     
0x1800052bf: int3     
0x1800052c0: int3     
0x1800052c1: int3     
0x1800052c2: int3     
0x1800052c3: int3     
0x1800052c4: int3     
0x1800052c5: int3     
0x1800052c6: int3     
0x1800052c7: int3     
0x1800052c8: int3     
0x1800052c9: int3     
0x1800052ca: int3     
0x1800052cb: int3     
0x1800052cc: int3     
0x1800052cd: int3     
0x1800052ce: int3     
0x1800052cf: int3     
0x1800052d0: int3     
0x1800052d1: int3     
0x1800052d2: int3     
0x1800052d3: int3     
0x1800052d4: int3     
0x1800052d5: int3     
0x1800052d6: int3     
0x1800052d7: int3     
0x1800052d8: int3     
0x1800052d9: int3     
0x1800052da: int3     
0x1800052db: int3     
0x1800052dc: int3     
0x1800052dd: int3     
0x1800052de: int3     
0x1800052df: int3     
0x1800052e0: int3     
0x1800052e1: int3     
0x1800052e2: int3     
0x1800052e3: int3     
0x1800052e4: int3     
0x1800052e5: int3     
0x1800052e6: int3     
0x1800052e7: int3     
0x1800052e8: int3     
0x1800052e9: int3     
0x1800052ea: int3     
0x1800052eb: int3     
0x1800052ec: int3     
0x1800052ed: int3     
0x1800052ee: int3     
0x1800052ef: int3     
0x1800052f0: int3     
0x1800052f1: int3     
0x1800052f2: int3     
0x1800052f3: int3     
0x1800052f4: int3     
0x1800052f5: int3     
0x1800052f6: int3     
0x1800052f7: int3     
0x1800052f8: int3     
0x1800052f9: int3     
0x1800052fa: int3     
0x1800052fb: int3     
0x1800052fc: int3     
0x1800052fd: int3     
0x1800052fe: int3     
0x1800052ff: int3     
0x180005300: int3     
0x180005301: int3     
0x180005302: int3     
0x180005303: int3     
0x180005304: int3     
0x180005305: int3     
0x180005306: int3     
0x180005307: int3     
0x180005308: int3     
0x180005309: int3     
0x18000530a: int3     
0x18000530b: int3     
0x18000530c: int3     
0x18000530d: int3     
0x18000530e: int3     
0x18000530f: int3     
0x180005310: int3     
0x180005311: int3     
0x180005312: int3     
0x180005313: int3     
0x180005314: int3     
0x180005315: int3     
0x180005316: int3     
0x180005317: int3     
0x180005318: int3     
0x180005319: int3     
0x18000531a: int3     
0x18000531b: int3     
0x18000531c: int3     
0x18000531d: int3     
0x18000531e: int3     
0x18000531f: int3     
0x180005320: int3     
0x180005321: int3     
0x180005322: int3     
0x180005323: int3     
0x180005324: int3     
0x180005325: int3     
0x180005326: int3     
0x180005327: int3     
0x180005328: int3     
0x180005329: int3     
0x18000532a: int3     
0x18000532b: int3     
0x18000532c: int3     
0x18000532d: int3     
0x18000532e: int3     
0x18000532f: int3     
0x180005330: int3     
0x180005331: int3     
0x180005332: int3     
0x180005333: int3     
0x180005334: int3     
0x180005335: int3     
0x180005336: int3     
0x180005337: int3     
0x180005338: int3     
0x180005339: int3     
0x18000533a: int3     
0x18000533b: int3     
0x18000533c: int3     
0x18000533d: int3     
0x18000533e: int3     
0x18000533f: int3     
0x180005340: int3     
0x180005341: int3     
0x180005342: int3     
0x180005343: int3     
0x180005344: int3     
0x180005345: int3     
0x180005346: int3     
0x180005347: int3     
0x180005348: int3     
0x180005349: int3     
0x18000534a: int3     
0x18000534b: int3     
0x18000534c: int3     
0x18000534d: int3     
0x18000534e: int3     
0x18000534f: int3     
0x180005350: int3     
0x180005351: int3     
0x180005352: int3     
0x180005353: int3     
0x180005354: int3     
0x180005355: int3     
0x180005356: int3     
0x180005357: int3     
0x180005358: int3     
0x180005359: int3     
0x18000535a: int3     
0x18000535b: int3     
0x18000535c: int3     
0x18000535d: int3     
0x18000535e: int3     
0x18000535f: int3     
0x180005360: int3     
0x180005361: int3     
0x180005362: int3     
0x180005363: int3     
0x180005364: int3     
0x180005365: int3     
0x180005366: int3     
0x180005367: int3     
0x180005368: int3     
0x180005369: int3     
0x18000536a: int3     
0x18000536b: int3     
0x18000536c: int3     
0x18000536d: int3     
0x18000536e: int3     
0x18000536f: int3     
0x180005370: int3     
0x180005371: int3     
0x180005372: int3     
0x180005373: int3     
0x180005374: int3     
0x180005375: int3     
0x180005376: int3     
0x180005377: int3     
0x180005378: int3     
0x180005379: int3     
0x18000537a: int3     
0x18000537b: int3     
0x18000537c: int3     
0x18000537d: int3     
0x18000537e: int3     
0x18000537f: int3     
0x180005380: int3     
0x180005381: int3     
0x180005382: int3     
0x180005383: int3     
0x180005384: int3     
0x180005385: int3     
0x180005386: int3     
0x180005387: int3     
0x180005388: int3     
0x180005389: int3     
0x18000538a: int3     
0x18000538b: int3     
0x18000538c: int3     
0x18000538d: int3     
0x18000538e: int3     
0x18000538f: int3     
0x180005390: int3     
0x180005391: int3     
0x180005392: int3     
0x180005393: int3     
0x180005394: int3     
0x180005395: int3     
0x180005396: int3     
0x180005397: int3     
0x180005398: int3     
0x180005399: int3     
0x18000539a: int3     
0x18000539b: int3     
0x18000539c: int3     
0x18000539d: int3     
0x18000539e: int3     
0x18000539f: int3     
0x1800053a0: int3     
0x1800053a1: int3     
0x1800053a2: int3     
0x1800053a3: int3     
0x1800053a4: int3     
0x1800053a5: int3     
0x1800053a6: int3     
0x1800053a7: int3     
0x1800053a8: int3     
0x1800053a9: int3     
0x1800053aa: int3     
0x1800053ab: int3     
0x1800053ac: int3     
0x1800053ad: int3     
0x1800053ae: int3     
0x1800053af: int3     
0x1800053b0: int3     
0x1800053b1: int3     
0x1800053b2: int3     
0x1800053b3: int3     
0x1800053b4: int3     
0x1800053b5: int3     
0x1800053b6: int3     
0x1800053b7: int3     
0x1800053b8: int3     
0x1800053b9: int3     
0x1800053ba: int3     
0x1800053bb: int3     
0x1800053bc: int3     
0x1800053bd: int3     
0x1800053be: int3     
0x1800053bf: int3     
0x1800053c0: int3     
0x1800053c1: int3     
0x1800053c2: int3     
0x1800053c3: int3     
0x1800053c4: int3     
0x1800053c5: int3     
0x1800053c6: int3     
0x1800053c7: int3     
0x1800053c8: int3     
0x1800053c9: int3     
0x1800053ca: int3     
0x1800053cb: int3     
0x1800053cc: int3     
0x1800053cd: int3     
0x1800053ce: int3     
0x1800053cf: int3     
0x1800053d0: int3     
0x1800053d1: int3     
0x1800053d2: int3     
0x1800053d3: int3     
0x1800053d4: int3     
0x1800053d5: int3     
0x1800053d6: int3     
0x1800053d7: int3     
0x1800053d8: int3     
0x1800053d9: int3     
0x1800053da: int3     
0x1800053db: int3     
0x1800053dc: int3     
0x1800053dd: int3     
0x1800053de: int3     
0x1800053df: int3     
0x1800053e0: int3     
0x1800053e1: int3     
0x1800053e2: int3     
0x1800053e3: int3     
0x1800053e4: int3     
0x1800053e5: int3     
0x1800053e6: int3     
0x1800053e7: int3     
0x1800053e8: int3     
0x1800053e9: int3     
0x1800053ea: int3     
0x1800053eb: int3     
0x1800053ec: int3     
0x1800053ed: int3     
0x1800053ee: int3     
0x1800053ef: int3     
0x1800053f0: int3     
0x1800053f1: int3     
0x1800053f2: int3     
0x1800053f3: int3     
0x1800053f4: int3     
0x1800053f5: int3     
0x1800053f6: int3     
0x1800053f7: int3     
0x1800053f8: int3     
0x1800053f9: int3     
0x1800053fa: int3     
0x1800053fb: int3     
0x1800053fc: int3     
0x1800053fd: int3     
0x1800053fe: int3     
0x1800053ff: int3     
0x180005400: int3     
0x180005401: int3     
0x180005402: int3     
0x180005403: int3     
0x180005404: int3     
0x180005405: int3     
0x180005406: int3     
0x180005407: int3     
0x180005408: int3     
0x180005409: int3     
0x18000540a: int3     
0x18000540b: int3     
0x18000540c: int3     
0x18000540d: int3     
0x18000540e: int3     
0x18000540f: int3     
0x180005410: int3     
0x180005411: int3     
0x180005412: int3     
0x180005413: int3     
0x180005414: int3     
0x180005415: int3     
0x180005416: int3     
0x180005417: int3     
0x180005418: int3     
0x180005419: int3     
0x18000541a: int3     
0x18000541b: int3     
0x18000541c: int3     
0x18000541d: int3     
0x18000541e: int3     
0x18000541f: int3     
0x180005420: int3     
0x180005421: int3     
0x180005422: int3     
0x180005423: int3     
0x180005424: int3     
0x180005425: int3     
0x180005426: int3     
0x180005427: int3     
0x180005428: int3     
0x180005429: int3     
0x18000542a: int3     
0x18000542b: int3     
0x18000542c: int3     
0x18000542d: int3     
0x18000542e: int3     
0x18000542f: int3     
0x180005430: int3     
0x180005431: int3     
0x180005432: int3     
0x180005433: int3     
0x180005434: int3     
0x180005435: int3     
0x180005436: int3     
0x180005437: int3     
0x180005438: int3     
0x180005439: int3     
0x18000543a: int3     
0x18000543b: int3     
0x18000543c: int3     
0x18000543d: int3     
0x18000543e: int3     
0x18000543f: int3     
0x180005440: int3     
0x180005441: int3     
0x180005442: int3     
0x180005443: int3     
0x180005444: int3     
0x180005445: int3     
0x180005446: int3     
0x180005447: int3     
0x180005448: int3     
0x180005449: int3     
0x18000544a: int3     
0x18000544b: int3     
0x18000544c: int3     
0x18000544d: int3     
0x18000544e: int3     
0x18000544f: int3     
0x180005450: int3     
0x180005451: int3     
0x180005452: int3     
0x180005453: int3     
0x180005454: int3     
0x180005455: int3     
0x180005456: int3     
0x180005457: int3     
0x180005458: int3     
0x180005459: int3     
0x18000545a: int3     
0x18000545b: int3     
0x18000545c: int3     
0x18000545d: int3     
0x18000545e: int3     
0x18000545f: int3     
0x180005460: int3     
0x180005461: int3     
0x180005462: int3     
0x180005463: int3     
0x180005464: int3     
0x180005465: int3     
0x180005466: int3     
0x180005467: int3     
0x180005468: int3     
0x180005469: int3     
0x18000546a: int3     
0x18000546b: int3     
0x18000546c: int3     
0x18000546d: int3     
0x18000546e: int3     
0x18000546f: int3     
0x180005470: int3     
0x180005471: int3     
0x180005472: int3     
0x180005473: int3     
0x180005474: int3     
0x180005475: int3     
0x180005476: int3     
0x180005477: int3     
0x180005478: int3     
0x180005479: int3     
0x18000547a: int3     
0x18000547b: int3     
0x18000547c: int3     
0x18000547d: int3     
0x18000547e: int3     
0x18000547f: int3     
0x180005480: int3     
0x180005481: int3     
0x180005482: int3     
0x180005483: int3     
0x180005484: int3     
0x180005485: int3     
0x180005486: int3     
0x180005487: int3     
0x180005488: int3     
0x180005489: int3     
0x18000548a: int3     
0x18000548b: int3     
0x18000548c: int3     
0x18000548d: int3     
0x18000548e: int3     
0x18000548f: int3     
0x180005490: int3     
0x180005491: int3     
0x180005492: int3     
0x180005493: int3     
0x180005494: int3     
0x180005495: int3     
0x180005496: int3     
0x180005497: int3     
0x180005498: int3     
0x180005499: int3     
0x18000549a: int3     
0x18000549b: int3     
0x18000549c: int3     
0x18000549d: int3     
0x18000549e: int3     
0x18000549f: int3     
0x1800054a0: int3     
0x1800054a1: int3     
0x1800054a2: int3     
0x1800054a3: int3     
0x1800054a4: int3     
0x1800054a5: int3     
0x1800054a6: int3     
0x1800054a7: int3     
0x1800054a8: int3     
0x1800054a9: int3     
0x1800054aa: int3     
0x1800054ab: int3     
0x1800054ac: int3     
0x1800054ad: int3     
0x1800054ae: int3     
0x1800054af: int3     
0x1800054b0: int3     
0x1800054b1: int3     
0x1800054b2: int3     
0x1800054b3: int3     
0x1800054b4: int3     
0x1800054b5: int3     
0x1800054b6: int3     
0x1800054b7: int3     
0x1800054b8: int3     
0x1800054b9: int3     
0x1800054ba: int3     
0x1800054bb: int3     
0x1800054bc: int3     
0x1800054bd: int3     
0x1800054be: int3     
0x1800054bf: int3     
0x1800054c0: int3     
0x1800054c1: int3     
0x1800054c2: int3     
0x1800054c3: int3     
0x1800054c4: int3     
0x1800054c5: int3     
0x1800054c6: int3     
0x1800054c7: int3     
0x1800054c8: int3     
0x1800054c9: int3     
0x1800054ca: int3     
0x1800054cb: int3     
0x1800054cc: int3     
0x1800054cd: int3     
0x1800054ce: int3     
0x1800054cf: int3     
0x1800054d0: int3     
0x1800054d1: int3     
0x1800054d2: int3     
0x1800054d3: int3     
0x1800054d4: int3     
0x1800054d5: int3     
0x1800054d6: int3     
0x1800054d7: int3     
0x1800054d8: int3     
0x1800054d9: int3     
0x1800054da: int3     
0x1800054db: int3     
0x1800054dc: int3     
0x1800054dd: int3     
0x1800054de: int3     
0x1800054df: int3     
0x1800054e0: int3     
0x1800054e1: int3     
0x1800054e2: int3     
0x1800054e3: int3     
0x1800054e4: int3     
0x1800054e5: int3     
0x1800054e6: int3     
0x1800054e7: int3     
0x1800054e8: int3     
0x1800054e9: int3     
0x1800054ea: int3     
0x1800054eb: int3     
0x1800054ec: int3     
0x1800054ed: int3     
0x1800054ee: int3     
0x1800054ef: int3     
0x1800054f0: int3     
0x1800054f1: int3     
0x1800054f2: int3     
0x1800054f3: int3     
0x1800054f4: int3     
0x1800054f5: int3     
0x1800054f6: int3     
0x1800054f7: int3     
0x1800054f8: int3     
0x1800054f9: int3     
0x1800054fa: int3     
0x1800054fb: int3     
0x1800054fc: int3     
0x1800054fd: int3     
0x1800054fe: int3     
0x1800054ff: int3     
0x180005500: int3     
0x180005501: int3     
0x180005502: int3     
0x180005503: int3     
0x180005504: int3     
0x180005505: int3     
0x180005506: int3     
0x180005507: int3     
0x180005508: int3     
0x180005509: int3     
0x18000550a: int3     
0x18000550b: int3     
0x18000550c: int3     
0x18000550d: int3     
0x18000550e: int3     
0x18000550f: int3     
0x180005510: int3     
0x180005511: int3     
0x180005512: int3     
0x180005513: int3     
0x180005514: int3     
0x180005515: int3     
0x180005516: int3     
0x180005517: int3     
0x180005518: int3     
0x180005519: int3     
0x18000551a: int3     
0x18000551b: int3     
0x18000551c: int3     
0x18000551d: int3     
0x18000551e: int3     
0x18000551f: int3     
0x180005520: int3     
0x180005521: int3     
0x180005522: int3     
0x180005523: int3     
0x180005524: int3     
0x180005525: int3     
0x180005526: int3     
0x180005527: int3     
0x180005528: int3     
0x180005529: int3     
0x18000552a: int3     
0x18000552b: int3     
0x18000552c: int3     
0x18000552d: int3     
0x18000552e: int3     
0x18000552f: int3     
0x180005530: int3     
0x180005531: int3     
0x180005532: int3     
0x180005533: int3     
0x180005534: int3     
0x180005535: int3     
0x180005536: int3     
0x180005537: int3     
0x180005538: int3     
0x180005539: int3     
0x18000553a: int3     
0x18000553b: int3     
0x18000553c: int3     
0x18000553d: int3     
0x18000553e: int3     
0x18000553f: int3     
0x180005540: int3     
0x180005541: int3     
0x180005542: int3     
0x180005543: int3     
0x180005544: int3     
0x180005545: int3     
0x180005546: int3     
0x180005547: int3     
0x180005548: int3     
0x180005549: int3     
0x18000554a: int3     
0x18000554b: int3     
0x18000554c: int3     
0x18000554d: int3     
0x18000554e: int3     
0x18000554f: int3     
0x180005550: int3     
0x180005551: int3     
0x180005552: int3     
0x180005553: int3     
0x180005554: int3     
0x180005555: int3     
0x180005556: int3     
0x180005557: int3     
0x180005558: int3     
0x180005559: int3     
0x18000555a: int3     
0x18000555b: int3     
0x18000555c: int3     
0x18000555d: int3     
0x18000555e: int3     
0x18000555f: int3     
0x180005560: int3     
0x180005561: int3     
0x180005562: int3     
0x180005563: int3     
0x180005564: int3     
0x180005565: int3     
0x180005566: int3     
0x180005567: int3     
0x180005568: int3     
0x180005569: int3     
0x18000556a: int3     
0x18000556b: int3     
0x18000556c: int3     
0x18000556d: int3     
0x18000556e: int3     
0x18000556f: int3     
0x180005570: int3     
0x180005571: int3     
0x180005572: int3     
0x180005573: int3     
0x180005574: int3     
0x180005575: int3     
0x180005576: int3     
0x180005577: int3     
0x180005578: int3     
0x180005579: int3     
0x18000557a: int3     
0x18000557b: int3     
0x18000557c: int3     
0x18000557d: int3     
0x18000557e: int3     
0x18000557f: int3     
0x180005580: int3     
0x180005581: int3     
0x180005582: int3     
0x180005583: int3     
0x180005584: int3     
0x180005585: int3     
0x180005586: int3     
0x180005587: int3     
0x180005588: int3     
0x180005589: int3     
0x18000558a: int3     
0x18000558b: int3     
0x18000558c: int3     
0x18000558d: int3     
0x18000558e: int3     
0x18000558f: int3     
0x180005590: int3     
0x180005591: int3     
0x180005592: int3     
0x180005593: int3     
0x180005594: int3     
0x180005595: int3     
0x180005596: int3     
0x180005597: int3     
0x180005598: int3     
0x180005599: int3     
0x18000559a: int3     
0x18000559b: int3     
0x18000559c: int3     
0x18000559d: int3     
0x18000559e: int3     
0x18000559f: int3     
0x1800055a0: int3     
0x1800055a1: int3     
0x1800055a2: int3     
0x1800055a3: int3     
0x1800055a4: int3     
0x1800055a5: int3     
0x1800055a6: int3     
0x1800055a7: int3     
0x1800055a8: int3     
0x1800055a9: int3     
0x1800055aa: int3     
0x1800055ab: int3     
0x1800055ac: int3     
0x1800055ad: int3     
0x1800055ae: int3     
0x1800055af: int3     
0x1800055b0: int3     
0x1800055b1: int3     
0x1800055b2: int3     
0x1800055b3: int3     
0x1800055b4: int3     
0x1800055b5: int3     
0x1800055b6: int3     
0x1800055b7: int3     
0x1800055b8: int3     
0x1800055b9: int3     
0x1800055ba: int3     
0x1800055bb: int3     
0x1800055bc: int3     
0x1800055bd: int3     
0x1800055be: int3     
0x1800055bf: int3     
0x1800055c0: int3     
0x1800055c1: int3     
0x1800055c2: int3     
0x1800055c3: int3     
0x1800055c4: int3     
0x1800055c5: int3     
0x1800055c6: int3     
0x1800055c7: int3     
0x1800055c8: int3     
0x1800055c9: int3     
0x1800055ca: int3     
0x1800055cb: int3     
0x1800055cc: int3     
0x1800055cd: int3     
0x1800055ce: int3     
0x1800055cf: int3     
0x1800055d0: int3     
0x1800055d1: int3     
0x1800055d2: int3     
0x1800055d3: int3     
0x1800055d4: int3     
0x1800055d5: int3     
0x1800055d6: int3     
0x1800055d7: int3     
0x1800055d8: int3     
0x1800055d9: int3     
0x1800055da: int3     
0x1800055db: int3     
0x1800055dc: int3     
0x1800055dd: int3     
0x1800055de: int3     
0x1800055df: int3     
0x1800055e0: int3     
0x1800055e1: int3     
0x1800055e2: int3     
0x1800055e3: int3     
0x1800055e4: int3     
0x1800055e5: int3     
0x1800055e6: int3     
0x1800055e7: int3     
0x1800055e8: int3     
0x1800055e9: int3     
0x1800055ea: int3     
0x1800055eb: int3     
0x1800055ec: int3     
0x1800055ed: int3     
0x1800055ee: int3     
0x1800055ef: int3     
0x1800055f0: int3     
0x1800055f1: int3     
0x1800055f2: int3     
0x1800055f3: int3     
0x1800055f4: int3     
0x1800055f5: int3     
0x1800055f6: int3     
0x1800055f7: int3     
0x1800055f8: int3     
0x1800055f9: int3     
0x1800055fa: int3     
0x1800055fb: int3     
0x1800055fc: int3     
0x1800055fd: int3     
0x1800055fe: int3     
0x1800055ff: int3     
0x180005600: int3     
0x180005601: int3     
0x180005602: int3     
0x180005603: int3     
0x180005604: int3     
0x180005605: int3     
0x180005606: int3     
0x180005607: int3     
0x180005608: int3     
0x180005609: int3     
0x18000560a: int3     
0x18000560b: int3     
0x18000560c: int3     
0x18000560d: int3     
0x18000560e: int3     
0x18000560f: int3     
0x180005610: int3     
0x180005611: int3     
0x180005612: int3     
0x180005613: int3     
0x180005614: int3     
0x180005615: int3     
0x180005616: int3     
0x180005617: int3     
0x180005618: int3     
0x180005619: int3     
0x18000561a: int3     
0x18000561b: int3     
0x18000561c: int3     
0x18000561d: int3     
0x18000561e: int3     
0x18000561f: int3     
0x180005620: int3     
0x180005621: int3     
0x180005622: int3     
0x180005623: int3     
0x180005624: int3     
0x180005625: int3     
0x180005626: int3     
0x180005627: int3     
0x180005628: int3     
0x180005629: int3     
0x18000562a: int3     
0x18000562b: int3     
0x18000562c: int3     
0x18000562d: int3     
0x18000562e: int3     
0x18000562f: int3     
0x180005630: int3     
0x180005631: int3     
0x180005632: int3     
0x180005633: int3     
0x180005634: int3     
0x180005635: int3     
0x180005636: int3     
0x180005637: int3     
0x180005638: int3     
0x180005639: int3     
0x18000563a: int3     
0x18000563b: int3     
0x18000563c: int3     
0x18000563d: int3     
0x18000563e: int3     
0x18000563f: int3     
0x180005640: int3     
0x180005641: int3     
0x180005642: int3     
0x180005643: int3     
0x180005644: int3     
0x180005645: int3     
0x180005646: int3     
0x180005647: int3     
0x180005648: int3     
0x180005649: int3     
0x18000564a: int3     
0x18000564b: int3     
0x18000564c: int3     
0x18000564d: int3     
0x18000564e: int3     
0x18000564f: int3     
0x180005650: int3     
0x180005651: int3     
0x180005652: int3     
0x180005653: int3     
0x180005654: int3     
0x180005655: int3     
0x180005656: int3     
0x180005657: int3     
0x180005658: int3     
0x180005659: int3     
0x18000565a: int3     
0x18000565b: int3     
0x18000565c: int3     
0x18000565d: int3     
0x18000565e: int3     
0x18000565f: int3     
0x180005660: int3     
0x180005661: int3     
0x180005662: int3     
0x180005663: int3     
0x180005664: int3     
0x180005665: int3     
0x180005666: int3     
0x180005667: int3     
0x180005668: int3     
0x180005669: int3     
0x18000566a: int3     
0x18000566b: int3     
0x18000566c: int3     
0x18000566d: int3     
0x18000566e: int3     
0x18000566f: int3     
0x180005670: int3     
0x180005671: int3     
0x180005672: int3     
0x180005673: int3     
0x180005674: int3     
0x180005675: int3     
0x180005676: int3     
0x180005677: int3     
0x180005678: int3     
0x180005679: int3     
0x18000567a: int3     
0x18000567b: int3     
0x18000567c: int3     
0x18000567d: int3     
0x18000567e: int3     
0x18000567f: int3     
0x180005680: int3     
0x180005681: int3     
0x180005682: int3     
0x180005683: int3     
0x180005684: int3     
0x180005685: int3     
0x180005686: int3     
0x180005687: int3     
0x180005688: int3     
0x180005689: int3     
0x18000568a: int3     
0x18000568b: int3     
0x18000568c: int3     
0x18000568d: int3     
0x18000568e: int3     
0x18000568f: int3     
0x180005690: int3     
0x180005691: int3     
0x180005692: int3     
0x180005693: int3     
0x180005694: int3     
0x180005695: int3     
0x180005696: int3     
0x180005697: int3     
0x180005698: int3     
0x180005699: int3     
0x18000569a: int3     
0x18000569b: int3     
0x18000569c: int3     
0x18000569d: int3     
0x18000569e: int3     
0x18000569f: int3     
0x1800056a0: int3     
0x1800056a1: int3     
0x1800056a2: int3     
0x1800056a3: int3     
0x1800056a4: int3     
0x1800056a5: int3     
0x1800056a6: int3     
0x1800056a7: int3     
0x1800056a8: int3     
0x1800056a9: int3     
0x1800056aa: int3     
0x1800056ab: int3     
0x1800056ac: int3     
0x1800056ad: int3     
0x1800056ae: int3     
0x1800056af: int3     
0x1800056b0: int3     
0x1800056b1: int3     
0x1800056b2: int3     
0x1800056b3: int3     
0x1800056b4: int3     
0x1800056b5: int3     
0x1800056b6: int3     
0x1800056b7: int3     
0x1800056b8: int3     
0x1800056b9: int3     
0x1800056ba: int3     
0x1800056bb: int3     
0x1800056bc: int3     
0x1800056bd: int3     
0x1800056be: int3     
0x1800056bf: int3     
0x1800056c0: int3     
0x1800056c1: int3     
0x1800056c2: int3     
0x1800056c3: int3     
0x1800056c4: int3     
0x1800056c5: int3     
0x1800056c6: int3     
0x1800056c7: int3     
0x1800056c8: int3     
0x1800056c9: int3     
0x1800056ca: int3     
0x1800056cb: int3     
0x1800056cc: int3     
0x1800056cd: int3     
0x1800056ce: int3     
0x1800056cf: int3     
0x1800056d0: int3     
0x1800056d1: int3     
0x1800056d2: int3     
0x1800056d3: int3     
0x1800056d4: int3     
0x1800056d5: int3     
0x1800056d6: int3     
0x1800056d7: int3     
0x1800056d8: int3     
0x1800056d9: int3     
0x1800056da: int3     
0x1800056db: int3     
0x1800056dc: int3     
0x1800056dd: int3     
0x1800056de: int3     
0x1800056df: int3     
0x1800056e0: int3     
0x1800056e1: int3     
0x1800056e2: int3     
0x1800056e3: int3     
0x1800056e4: int3     
0x1800056e5: int3     
0x1800056e6: int3     
0x1800056e7: int3     
0x1800056e8: int3     
0x1800056e9: int3     
0x1800056ea: int3     
0x1800056eb: int3     
0x1800056ec: int3     
0x1800056ed: int3     
0x1800056ee: int3     
0x1800056ef: int3     
0x1800056f0: int3     
0x1800056f1: int3     
0x1800056f2: int3     
0x1800056f3: int3     
0x1800056f4: int3     
0x1800056f5: int3     
0x1800056f6: int3     
0x1800056f7: int3     
0x1800056f8: int3     
0x1800056f9: int3     
0x1800056fa: int3     
0x1800056fb: int3     
0x1800056fc: int3     
0x1800056fd: int3     
0x1800056fe: int3     
0x1800056ff: int3     
0x180005700: int3     
0x180005701: int3     
0x180005702: int3     
0x180005703: int3     
0x180005704: int3     
0x180005705: int3     
0x180005706: int3     
0x180005707: int3     
0x180005708: int3     
0x180005709: int3     
0x18000570a: int3     
0x18000570b: int3     
0x18000570c: int3     
0x18000570d: int3     
0x18000570e: int3     
0x18000570f: int3     
0x180005710: int3     
0x180005711: int3     
0x180005712: int3     
0x180005713: int3     
0x180005714: int3     
0x180005715: int3     
0x180005716: int3     
0x180005717: int3     
0x180005718: int3     
0x180005719: int3     
0x18000571a: int3     
0x18000571b: int3     
0x18000571c: int3     
0x18000571d: int3     
0x18000571e: int3     
0x18000571f: int3     
0x180005720: int3     
0x180005721: int3     
0x180005722: int3     
0x180005723: int3     
0x180005724: int3     
0x180005725: int3     
0x180005726: int3     
0x180005727: int3     
0x180005728: int3     
0x180005729: int3     
0x18000572a: int3     
0x18000572b: int3     
0x18000572c: int3     
0x18000572d: int3     
0x18000572e: int3     
0x18000572f: int3     
0x180005730: int3     
0x180005731: int3     
0x180005732: int3     
0x180005733: int3     
0x180005734: int3     
0x180005735: int3     
0x180005736: int3     
0x180005737: int3     
0x180005738: int3     
0x180005739: int3     
0x18000573a: int3     
0x18000573b: int3     
0x18000573c: int3     
0x18000573d: int3     
0x18000573e: int3     
0x18000573f: int3     
0x180005740: int3     
0x180005741: int3     
0x180005742: int3     
0x180005743: int3     
0x180005744: int3     
0x180005745: int3     
0x180005746: int3     
0x180005747: int3     
0x180005748: int3     
0x180005749: int3     
0x18000574a: int3     
0x18000574b: int3     
0x18000574c: int3     
0x18000574d: int3     
0x18000574e: int3     
0x18000574f: int3     
0x180005750: int3     
0x180005751: int3     
0x180005752: int3     
0x180005753: int3     
0x180005754: int3     
0x180005755: int3     
0x180005756: int3     
0x180005757: int3     
0x180005758: int3     
0x180005759: int3     
0x18000575a: int3     
0x18000575b: int3     
0x18000575c: int3     
0x18000575d: int3     
0x18000575e: int3     
0x18000575f: int3     
0x180005760: int3     
0x180005761: int3     
0x180005762: int3     
0x180005763: int3     
0x180005764: int3     
0x180005765: int3     
0x180005766: int3     
0x180005767: int3     
0x180005768: int3     
0x180005769: int3     
0x18000576a: int3     
0x18000576b: int3     
0x18000576c: int3     
0x18000576d: int3     
0x18000576e: int3     
0x18000576f: int3     
0x180005770: int3     
0x180005771: int3     
0x180005772: int3     
0x180005773: int3     
0x180005774: int3     
0x180005775: int3     
0x180005776: int3     
0x180005777: int3     
0x180005778: int3     
0x180005779: int3     
0x18000577a: int3     
0x18000577b: int3     
0x18000577c: int3     
0x18000577d: int3     
0x18000577e: int3     
0x18000577f: int3     
0x180005780: int3     
0x180005781: int3     
0x180005782: int3     
0x180005783: int3     
0x180005784: int3     
0x180005785: int3     
0x180005786: int3     
0x180005787: int3     
0x180005788: int3     
0x180005789: int3     
0x18000578a: int3     
0x18000578b: int3     
0x18000578c: int3     
0x18000578d: int3     
0x18000578e: int3     
0x18000578f: int3     
0x180005790: int3     
0x180005791: int3     
0x180005792: int3     
0x180005793: int3     
0x180005794: int3     
0x180005795: int3     
0x180005796: int3     
0x180005797: int3     
0x180005798: int3     
0x180005799: int3     
0x18000579a: int3     
0x18000579b: int3     
0x18000579c: int3     
0x18000579d: int3     
0x18000579e: int3     
0x18000579f: int3     
0x1800057a0: int3     
0x1800057a1: int3     
0x1800057a2: int3     
0x1800057a3: int3     
0x1800057a4: int3     
0x1800057a5: int3     
0x1800057a6: int3     
0x1800057a7: int3     
0x1800057a8: int3     
0x1800057a9: int3     
0x1800057aa: int3     
0x1800057ab: int3     
0x1800057ac: int3     
0x1800057ad: int3     
0x1800057ae: int3     
0x1800057af: int3     
0x1800057b0: int3     
0x1800057b1: int3     
0x1800057b2: int3     
0x1800057b3: int3     
0x1800057b4: int3     
0x1800057b5: int3     
0x1800057b6: int3     
0x1800057b7: int3     
0x1800057b8: int3     
0x1800057b9: int3     
0x1800057ba: int3     
0x1800057bb: int3     
0x1800057bc: int3     
0x1800057bd: int3     
0x1800057be: int3     
0x1800057bf: int3     
0x1800057c0: int3     
0x1800057c1: int3     
0x1800057c2: int3     
0x1800057c3: int3     
0x1800057c4: int3     
0x1800057c5: int3     
0x1800057c6: int3     
0x1800057c7: int3     
0x1800057c8: int3     
0x1800057c9: int3     
0x1800057ca: int3     
0x1800057cb: int3     
0x1800057cc: int3     
0x1800057cd: int3     
0x1800057ce: int3     
0x1800057cf: int3     
0x1800057d0: int3     
0x1800057d1: int3     
0x1800057d2: int3     
0x1800057d3: int3     
0x1800057d4: int3     
0x1800057d5: int3     
0x1800057d6: int3     
0x1800057d7: int3     
0x1800057d8: int3     
0x1800057d9: int3     
0x1800057da: int3     
0x1800057db: int3     
0x1800057dc: int3     
0x1800057dd: int3     
0x1800057de: int3     
0x1800057df: int3     
0x1800057e0: int3     
0x1800057e1: int3     
0x1800057e2: int3     
0x1800057e3: int3     
0x1800057e4: int3     
0x1800057e5: int3     
0x1800057e6: int3     
0x1800057e7: int3     
0x1800057e8: int3     
0x1800057e9: int3     
0x1800057ea: int3     
0x1800057eb: int3     
0x1800057ec: int3     
0x1800057ed: int3     
0x1800057ee: int3     
0x1800057ef: int3     
0x1800057f0: int3     
0x1800057f1: int3     
0x1800057f2: int3     
0x1800057f3: int3     
0x1800057f4: int3     
0x1800057f5: int3     
0x1800057f6: int3     
0x1800057f7: int3     
0x1800057f8: int3     
0x1800057f9: int3     
0x1800057fa: int3     
0x1800057fb: int3     
0x1800057fc: int3     
0x1800057fd: int3     
0x1800057fe: int3     
0x1800057ff: int3     
0x180005800: int3     
0x180005801: int3     
0x180005802: int3     
0x180005803: int3     
0x180005804: int3     
0x180005805: int3     
0x180005806: int3     
0x180005807: int3     
0x180005808: int3     
0x180005809: int3     
0x18000580a: int3     
0x18000580b: int3     
0x18000580c: int3     
0x18000580d: int3     
0x18000580e: int3     
0x18000580f: int3     
0x180005810: int3     
0x180005811: int3     
0x180005812: int3     
0x180005813: int3     
0x180005814: int3     
0x180005815: int3     
0x180005816: int3     
0x180005817: int3     
0x180005818: int3     
0x180005819: int3     
0x18000581a: int3     
0x18000581b: int3     
0x18000581c: int3     
0x18000581d: int3     
0x18000581e: int3     
0x18000581f: int3     
0x180005820: int3     
0x180005821: int3     
0x180005822: int3     
0x180005823: int3     
0x180005824: int3     
0x180005825: int3     
0x180005826: int3     
0x180005827: int3     
0x180005828: int3     
0x180005829: int3     
0x18000582a: int3     
0x18000582b: int3     
0x18000582c: int3     
0x18000582d: int3     
0x18000582e: int3     
0x18000582f: int3     
0x180005830: int3     
0x180005831: int3     
0x180005832: int3     
0x180005833: int3     
0x180005834: int3     
0x180005835: int3     
0x180005836: int3     
0x180005837: int3     
0x180005838: int3     
0x180005839: int3     
0x18000583a: int3     
0x18000583b: int3     
0x18000583c: int3     
0x18000583d: int3     
0x18000583e: int3     
0x18000583f: int3     
0x180005840: int3     
0x180005841: int3     
0x180005842: int3     
0x180005843: int3     
0x180005844: int3     
0x180005845: int3     
0x180005846: int3     
0x180005847: int3     
0x180005848: int3     
0x180005849: int3     
0x18000584a: int3     
0x18000584b: int3     
0x18000584c: int3     
0x18000584d: int3     
0x18000584e: int3     
0x18000584f: int3     
0x180005850: int3     
0x180005851: int3     
0x180005852: int3     
0x180005853: int3     
0x180005854: int3     
0x180005855: int3     
0x180005856: int3     
0x180005857: int3     
0x180005858: int3     
0x180005859: int3     
0x18000585a: int3     
0x18000585b: int3     
0x18000585c: int3     
0x18000585d: int3     
0x18000585e: int3     
0x18000585f: int3     
0x180005860: int3     
0x180005861: int3     
0x180005862: int3     
0x180005863: int3     
0x180005864: int3     
0x180005865: int3     
0x180005866: int3     
0x180005867: int3     
0x180005868: int3     
0x180005869: int3     
0x18000586a: int3     
0x18000586b: int3     
0x18000586c: int3     
0x18000586d: int3     
0x18000586e: int3     
0x18000586f: int3     
0x180005870: int3     
0x180005871: int3     
0x180005872: int3     
0x180005873: int3     
0x180005874: int3     
0x180005875: int3     
0x180005876: int3     
0x180005877: int3     
0x180005878: int3     
0x180005879: int3     
0x18000587a: int3     
0x18000587b: int3     
0x18000587c: int3     
0x18000587d: int3     
0x18000587e: int3     
0x18000587f: int3     
0x180005880: int3     
0x180005881: int3     
0x180005882: int3     
0x180005883: int3     
0x180005884: int3     
0x180005885: int3     
0x180005886: int3     
0x180005887: int3     
0x180005888: int3     
0x180005889: int3     
0x18000588a: int3     
0x18000588b: int3     
0x18000588c: int3     
0x18000588d: int3     
0x18000588e: int3     
0x18000588f: int3     
0x180005890: int3     
0x180005891: int3     
0x180005892: int3     
0x180005893: int3     
0x180005894: int3     
0x180005895: int3     
0x180005896: int3     
0x180005897: int3     
0x180005898: int3     
0x180005899: int3     
0x18000589a: int3     
0x18000589b: int3     
0x18000589c: int3     
0x18000589d: int3     
0x18000589e: int3     
0x18000589f: int3     
0x1800058a0: int3     
0x1800058a1: int3     
0x1800058a2: int3     
0x1800058a3: int3     
0x1800058a4: int3     
0x1800058a5: int3     
0x1800058a6: int3     
0x1800058a7: int3     
0x1800058a8: int3     
0x1800058a9: int3     
0x1800058aa: int3     
0x1800058ab: int3     
0x1800058ac: int3     
0x1800058ad: int3     
0x1800058ae: int3     
0x1800058af: int3     
0x1800058b0: int3     
0x1800058b1: int3     
0x1800058b2: int3     
0x1800058b3: int3     
0x1800058b4: int3     
0x1800058b5: int3     
0x1800058b6: int3     
0x1800058b7: int3     
0x1800058b8: int3     
0x1800058b9: int3     
0x1800058ba: int3     
0x1800058bb: int3     
0x1800058bc: int3     
0x1800058bd: int3     
0x1800058be: int3     
0x1800058bf: int3     
0x1800058c0: int3     
0x1800058c1: int3     
0x1800058c2: int3     
0x1800058c3: int3     
0x1800058c4: int3     
0x1800058c5: int3     
0x1800058c6: int3     
0x1800058c7: int3     
0x1800058c8: int3     
0x1800058c9: int3     
0x1800058ca: int3     
0x1800058cb: int3     
0x1800058cc: int3     
0x1800058cd: int3     
0x1800058ce: int3     
0x1800058cf: int3     
0x1800058d0: int3     
0x1800058d1: int3     
0x1800058d2: int3     
0x1800058d3: int3     
0x1800058d4: int3     
0x1800058d5: int3     
0x1800058d6: int3     
0x1800058d7: int3     
0x1800058d8: int3     
0x1800058d9: int3     
0x1800058da: int3     
0x1800058db: int3     
0x1800058dc: int3     
0x1800058dd: int3     
0x1800058de: int3     
0x1800058df: int3     
0x1800058e0: int3     
0x1800058e1: int3     
0x1800058e2: int3     
0x1800058e3: int3     
0x1800058e4: int3     
0x1800058e5: int3     
0x1800058e6: int3     
0x1800058e7: int3     
0x1800058e8: int3     
0x1800058e9: int3     
0x1800058ea: int3     
0x1800058eb: int3     
0x1800058ec: int3     
0x1800058ed: int3     
0x1800058ee: int3     
0x1800058ef: int3     
0x1800058f0: int3     
0x1800058f1: int3     
0x1800058f2: int3     
0x1800058f3: int3     
0x1800058f4: int3     
0x1800058f5: int3     
0x1800058f6: int3     
0x1800058f7: int3     
0x1800058f8: int3     
0x1800058f9: int3     
0x1800058fa: int3     
0x1800058fb: int3     
0x1800058fc: int3     
0x1800058fd: int3     
0x1800058fe: int3     
0x1800058ff: int3     
0x180005900: int3     
0x180005901: int3     
0x180005902: int3     
0x180005903: int3     
0x180005904: int3     
0x180005905: int3     
0x180005906: int3     
0x180005907: int3     
0x180005908: int3     
0x180005909: int3     
0x18000590a: int3     
0x18000590b: int3     
0x18000590c: int3     
0x18000590d: int3     
0x18000590e: int3     
0x18000590f: int3     
0x180005910: int3     
0x180005911: int3     
0x180005912: int3     
0x180005913: int3     
0x180005914: int3     
0x180005915: int3     
0x180005916: int3     
0x180005917: int3     
0x180005918: int3     
0x180005919: int3     
0x18000591a: int3     
0x18000591b: int3     
0x18000591c: int3     
0x18000591d: int3     
0x18000591e: int3     
0x18000591f: int3     
0x180005920: int3     
0x180005921: int3     
0x180005922: int3     
0x180005923: int3     
0x180005924: int3     
0x180005925: int3     
0x180005926: int3     
0x180005927: int3     
0x180005928: int3     
0x180005929: int3     
0x18000592a: int3     
0x18000592b: int3     
0x18000592c: int3     
0x18000592d: int3     
0x18000592e: int3     
0x18000592f: int3     
0x180005930: int3     
0x180005931: int3     
0x180005932: int3     
0x180005933: int3     
0x180005934: int3     
0x180005935: int3     
0x180005936: int3     
0x180005937: int3     
0x180005938: int3     
0x180005939: int3     
0x18000593a: int3     
0x18000593b: int3     
0x18000593c: int3     
0x18000593d: int3     
0x18000593e: int3     
0x18000593f: int3     
0x180005940: int3     
0x180005941: int3     
0x180005942: int3     
0x180005943: int3     
0x180005944: int3     
0x180005945: int3     
0x180005946: int3     
0x180005947: int3     
0x180005948: int3     
0x180005949: int3     
0x18000594a: int3     
0x18000594b: int3     
0x18000594c: int3     
0x18000594d: int3     
0x18000594e: int3     
0x18000594f: int3     
0x180005950: int3     
0x180005951: int3     
0x180005952: int3     
0x180005953: int3     
0x180005954: int3     
0x180005955: int3     
0x180005956: int3     
0x180005957: int3     
0x180005958: int3     
0x180005959: int3     
0x18000595a: int3     
0x18000595b: int3     
0x18000595c: int3     
0x18000595d: int3     
0x18000595e: int3     
0x18000595f: int3     
0x180005960: int3     
0x180005961: int3     
0x180005962: int3     
0x180005963: int3     
0x180005964: int3     
0x180005965: int3     
0x180005966: int3     
0x180005967: int3     
0x180005968: int3     
0x180005969: int3     
0x18000596a: int3     
0x18000596b: int3     
0x18000596c: int3     
0x18000596d: int3     
0x18000596e: int3     
0x18000596f: int3     
0x180005970: int3     
0x180005971: int3     
0x180005972: int3     
0x180005973: int3     
0x180005974: int3     
0x180005975: int3     
0x180005976: int3     
0x180005977: int3     
0x180005978: int3     
0x180005979: int3     
0x18000597a: int3     
0x18000597b: int3     
0x18000597c: int3     
0x18000597d: int3     
0x18000597e: int3     
0x18000597f: int3     
0x180005980: int3     
0x180005981: int3     
0x180005982: int3     
0x180005983: int3     
0x180005984: int3     
0x180005985: int3     
0x180005986: int3     
0x180005987: int3     
0x180005988: int3     
0x180005989: int3     
0x18000598a: int3     
0x18000598b: int3     
0x18000598c: int3     
0x18000598d: int3     
0x18000598e: int3     
0x18000598f: int3     
0x180005990: int3     
0x180005991: int3     
0x180005992: int3     
0x180005993: int3     
0x180005994: int3     
0x180005995: int3     
0x180005996: int3     
0x180005997: int3     
0x180005998: int3     
0x180005999: int3     
0x18000599a: int3     
0x18000599b: int3     
0x18000599c: int3     
0x18000599d: int3     
0x18000599e: int3     
0x18000599f: int3     
0x1800059a0: int3     
0x1800059a1: int3     
0x1800059a2: int3     
0x1800059a3: int3     
0x1800059a4: int3     
0x1800059a5: int3     
0x1800059a6: int3     
0x1800059a7: int3     
0x1800059a8: int3     
0x1800059a9: int3     
0x1800059aa: int3     
0x1800059ab: int3     
0x1800059ac: int3     
0x1800059ad: int3     
0x1800059ae: int3     
0x1800059af: int3     
0x1800059b0: int3     
0x1800059b1: int3     
0x1800059b2: int3     
0x1800059b3: int3     
0x1800059b4: int3     
0x1800059b5: int3     
0x1800059b6: int3     
0x1800059b7: int3     
0x1800059b8: int3     
0x1800059b9: int3     
0x1800059ba: int3     
0x1800059bb: int3     
0x1800059bc: int3     
0x1800059bd: int3     
0x1800059be: int3     
0x1800059bf: int3     
0x1800059c0: int3     
0x1800059c1: int3     
0x1800059c2: int3     
0x1800059c3: int3     
0x1800059c4: int3     
0x1800059c5: int3     
0x1800059c6: int3     
0x1800059c7: int3     
0x1800059c8: int3     
0x1800059c9: int3     
0x1800059ca: int3     
0x1800059cb: int3     
0x1800059cc: int3     
0x1800059cd: int3     
0x1800059ce: int3     
0x1800059cf: int3     
0x1800059d0: int3     
0x1800059d1: int3     
0x1800059d2: int3     
0x1800059d3: int3     
0x1800059d4: int3     
0x1800059d5: int3     
0x1800059d6: int3     
0x1800059d7: int3     
0x1800059d8: int3     
0x1800059d9: int3     
0x1800059da: int3     
0x1800059db: int3     
0x1800059dc: int3     
0x1800059dd: int3     
0x1800059de: int3     
0x1800059df: int3     
0x1800059e0: int3     
0x1800059e1: int3     
0x1800059e2: int3     
0x1800059e3: int3     
0x1800059e4: int3     
0x1800059e5: int3     
0x1800059e6: int3     
0x1800059e7: int3     
0x1800059e8: int3     
0x1800059e9: int3     
0x1800059ea: int3     
0x1800059eb: int3     
0x1800059ec: int3     
0x1800059ed: int3     
0x1800059ee: int3     
0x1800059ef: int3     
0x1800059f0: int3     
0x1800059f1: int3     
0x1800059f2: int3     
0x1800059f3: int3     
0x1800059f4: int3     
0x1800059f5: int3     
0x1800059f6: int3     
0x1800059f7: int3     
0x1800059f8: int3     
0x1800059f9: int3     
0x1800059fa: int3     
0x1800059fb: int3     
0x1800059fc: int3     
0x1800059fd: int3     
0x1800059fe: int3     
0x1800059ff: int3     
0x180005a00: int3     
0x180005a01: int3     
0x180005a02: int3     
0x180005a03: int3     
0x180005a04: int3     
0x180005a05: int3     
0x180005a06: int3     
0x180005a07: int3     
0x180005a08: int3     
0x180005a09: int3     
0x180005a0a: int3     
0x180005a0b: int3     
0x180005a0c: int3     
0x180005a0d: int3     
0x180005a0e: int3     
0x180005a0f: int3     
0x180005a10: int3     
0x180005a11: int3     
0x180005a12: int3     
0x180005a13: int3     
0x180005a14: int3     
0x180005a15: int3     
0x180005a16: int3     
0x180005a17: int3     
0x180005a18: int3     
0x180005a19: int3     
0x180005a1a: int3     
0x180005a1b: int3     
0x180005a1c: int3     
0x180005a1d: int3     
0x180005a1e: int3     
0x180005a1f: int3     
0x180005a20: int3     
0x180005a21: int3     
0x180005a22: int3     
0x180005a23: int3     
0x180005a24: int3     
0x180005a25: int3     
0x180005a26: int3     
0x180005a27: int3     
0x180005a28: int3     
0x180005a29: int3     
0x180005a2a: int3     
0x180005a2b: int3     
0x180005a2c: int3     
0x180005a2d: int3     
0x180005a2e: int3     
0x180005a2f: int3     
0x180005a30: int3     
0x180005a31: int3     
0x180005a32: int3     
0x180005a33: int3     
0x180005a34: int3     
0x180005a35: int3     
0x180005a36: int3     
0x180005a37: int3     
0x180005a38: int3     
0x180005a39: int3     
0x180005a3a: int3     
0x180005a3b: int3     
0x180005a3c: int3     
0x180005a3d: int3     
0x180005a3e: int3     
0x180005a3f: int3     
0x180005a40: int3     
0x180005a41: int3     
0x180005a42: int3     
0x180005a43: int3     
0x180005a44: int3     
0x180005a45: int3     
0x180005a46: int3     
0x180005a47: int3     
0x180005a48: int3     
0x180005a49: int3     
0x180005a4a: int3     
0x180005a4b: int3     
0x180005a4c: int3     
0x180005a4d: int3     
0x180005a4e: int3     
0x180005a4f: int3     
0x180005a50: int3     
0x180005a51: int3     
0x180005a52: int3     
0x180005a53: int3     
0x180005a54: int3     
0x180005a55: int3     
0x180005a56: int3     
0x180005a57: int3     
0x180005a58: int3     
0x180005a59: int3     
0x180005a5a: int3     
0x180005a5b: int3     
0x180005a5c: int3     
0x180005a5d: int3     
0x180005a5e: int3     
0x180005a5f: int3     
0x180005a60: int3     
0x180005a61: int3     
0x180005a62: int3     
0x180005a63: int3     
0x180005a64: int3     
0x180005a65: int3     
0x180005a66: int3     
0x180005a67: int3     
0x180005a68: int3     
0x180005a69: int3     
0x180005a6a: int3     
0x180005a6b: int3     
0x180005a6c: int3     
0x180005a6d: int3     
0x180005a6e: int3     
0x180005a6f: int3     
0x180005a70: int3     
0x180005a71: int3     
0x180005a72: int3     
0x180005a73: int3     
0x180005a74: int3     
0x180005a75: int3     
0x180005a76: int3     
0x180005a77: int3     
0x180005a78: int3     
0x180005a79: int3     
0x180005a7a: int3     
0x180005a7b: int3     
0x180005a7c: int3     
0x180005a7d: int3     
0x180005a7e: int3     
0x180005a7f: int3     
0x180005a80: int3     
0x180005a81: int3     
0x180005a82: int3     
0x180005a83: int3     
0x180005a84: int3     
0x180005a85: int3     
0x180005a86: int3     
0x180005a87: int3     
0x180005a88: int3     
0x180005a89: int3     
0x180005a8a: int3     
0x180005a8b: int3     
0x180005a8c: int3     
0x180005a8d: int3     
0x180005a8e: int3     
0x180005a8f: int3     
0x180005a90: int3     
0x180005a91: int3     
0x180005a92: int3     
0x180005a93: int3     
0x180005a94: int3     
0x180005a95: int3     
0x180005a96: int3     
0x180005a97: int3     
0x180005a98: int3     
0x180005a99: int3     
0x180005a9a: int3     
0x180005a9b: int3     
0x180005a9c: int3     
0x180005a9d: int3     
0x180005a9e: int3     
0x180005a9f: int3     
0x180005aa0: int3     
0x180005aa1: int3     
0x180005aa2: int3     
0x180005aa3: int3     
0x180005aa4: int3     
0x180005aa5: int3     
0x180005aa6: int3     
0x180005aa7: int3     
0x180005aa8: int3     
0x180005aa9: int3     
0x180005aaa: int3     
0x180005aab: int3     
0x180005aac: int3     
0x180005aad: int3     
0x180005aae: int3     
0x180005aaf: int3     
0x180005ab0: int3     
0x180005ab1: int3     
0x180005ab2: int3     
0x180005ab3: int3     
0x180005ab4: int3     
0x180005ab5: int3     
0x180005ab6: int3     
0x180005ab7: int3     
0x180005ab8: int3     
0x180005ab9: int3     
0x180005aba: int3     
0x180005abb: int3     
0x180005abc: int3     
0x180005abd: int3     
0x180005abe: int3     
0x180005abf: int3     
0x180005ac0: int3     
0x180005ac1: int3     
0x180005ac2: int3     
0x180005ac3: int3     
0x180005ac4: int3     
0x180005ac5: int3     
0x180005ac6: int3     
0x180005ac7: int3     
0x180005ac8: int3     
0x180005ac9: int3     
0x180005aca: int3     
0x180005acb: int3     
0x180005acc: int3     
0x180005acd: int3     
0x180005ace: int3     
0x180005acf: int3     
0x180005ad0: int3     
0x180005ad1: int3     
0x180005ad2: int3     
0x180005ad3: int3     
0x180005ad4: int3     
0x180005ad5: int3     
0x180005ad6: int3     
0x180005ad7: int3     
0x180005ad8: int3     
0x180005ad9: int3     
0x180005ada: int3     
0x180005adb: int3     
0x180005adc: int3     
0x180005add: int3     
0x180005ade: int3     
0x180005adf: int3     
0x180005ae0: int3     
0x180005ae1: int3     
0x180005ae2: int3     
0x180005ae3: int3     
0x180005ae4: int3     
0x180005ae5: int3     
0x180005ae6: int3     
0x180005ae7: int3     
0x180005ae8: int3     
0x180005ae9: int3     
0x180005aea: int3     
0x180005aeb: int3     
0x180005aec: int3     
0x180005aed: int3     
0x180005aee: int3     
0x180005aef: int3     
0x180005af0: int3     
0x180005af1: int3     
0x180005af2: int3     
0x180005af3: int3     
0x180005af4: int3     
0x180005af5: int3     
0x180005af6: int3     
0x180005af7: int3     
0x180005af8: int3     
0x180005af9: int3     
0x180005afa: int3     
0x180005afb: int3     
0x180005afc: int3     
0x180005afd: int3     
0x180005afe: int3     
0x180005aff: int3     
0x180005b00: int3     
0x180005b01: int3     
0x180005b02: int3     
0x180005b03: int3     
0x180005b04: int3     
0x180005b05: int3     
0x180005b06: int3     
0x180005b07: int3     
0x180005b08: int3     
0x180005b09: int3     
0x180005b0a: int3     
0x180005b0b: int3     
0x180005b0c: int3     
0x180005b0d: int3     
0x180005b0e: int3     
0x180005b0f: int3     
0x180005b10: int3     
0x180005b11: int3     
0x180005b12: int3     
0x180005b13: int3     
0x180005b14: int3     
0x180005b15: int3     
0x180005b16: int3     
0x180005b17: int3     
0x180005b18: int3     
0x180005b19: int3     
0x180005b1a: int3     
0x180005b1b: int3     
0x180005b1c: int3     
0x180005b1d: int3     
0x180005b1e: int3     
0x180005b1f: int3     
0x180005b20: int3     
0x180005b21: int3     
0x180005b22: int3     
0x180005b23: int3     
0x180005b24: int3     
0x180005b25: int3     
0x180005b26: int3     
0x180005b27: int3     
0x180005b28: int3     
0x180005b29: int3     
0x180005b2a: int3     
0x180005b2b: int3     
0x180005b2c: int3     
0x180005b2d: int3     
0x180005b2e: int3     
0x180005b2f: int3     
0x180005b30: int3     
0x180005b31: int3     
0x180005b32: int3     
0x180005b33: int3     
0x180005b34: int3     
0x180005b35: int3     
0x180005b36: int3     
0x180005b37: int3     
0x180005b38: int3     
0x180005b39: int3     
0x180005b3a: int3     
0x180005b3b: int3     
0x180005b3c: int3     
0x180005b3d: int3     
0x180005b3e: int3     
0x180005b3f: int3     
0x180005b40: int3     
0x180005b41: int3     
0x180005b42: int3     
0x180005b43: int3     
0x180005b44: int3     
0x180005b45: int3     
0x180005b46: int3     
0x180005b47: int3     
0x180005b48: int3     
0x180005b49: int3     
0x180005b4a: int3     
0x180005b4b: int3     
0x180005b4c: int3     
0x180005b4d: int3     
0x180005b4e: int3     
0x180005b4f: int3     
0x180005b50: int3     
0x180005b51: int3     
0x180005b52: int3     
0x180005b53: int3     
0x180005b54: int3     
0x180005b55: int3     
0x180005b56: int3     
0x180005b57: int3     
0x180005b58: int3     
0x180005b59: int3     
0x180005b5a: int3     
0x180005b5b: int3     
0x180005b5c: int3     
0x180005b5d: int3     
0x180005b5e: int3     
0x180005b5f: int3     
0x180005b60: int3     
0x180005b61: int3     
0x180005b62: int3     
0x180005b63: int3     
0x180005b64: int3     
0x180005b65: int3     
0x180005b66: int3     
0x180005b67: int3     
0x180005b68: int3     
0x180005b69: int3     
0x180005b6a: int3     
0x180005b6b: int3     
0x180005b6c: int3     
0x180005b6d: int3     
0x180005b6e: int3     
0x180005b6f: int3     
0x180005b70: int3     
0x180005b71: int3     
0x180005b72: int3     
0x180005b73: int3     
0x180005b74: int3     
0x180005b75: int3     
0x180005b76: int3     
0x180005b77: int3     
0x180005b78: int3     
0x180005b79: int3     
0x180005b7a: int3     
0x180005b7b: int3     
0x180005b7c: int3     
0x180005b7d: int3     
0x180005b7e: int3     
0x180005b7f: int3     
0x180005b80: int3     
0x180005b81: int3     
0x180005b82: int3     
0x180005b83: int3     
0x180005b84: int3     
0x180005b85: int3     
0x180005b86: int3     
0x180005b87: int3     
0x180005b88: int3     
0x180005b89: int3     
0x180005b8a: int3     
0x180005b8b: int3     
0x180005b8c: int3     
0x180005b8d: int3     
0x180005b8e: int3     
0x180005b8f: int3     
0x180005b90: int3     
0x180005b91: int3     
0x180005b92: int3     
0x180005b93: int3     
0x180005b94: int3     
0x180005b95: int3     
0x180005b96: int3     
0x180005b97: int3     
0x180005b98: int3     
0x180005b99: int3     
0x180005b9a: int3     
0x180005b9b: int3     
0x180005b9c: int3     
0x180005b9d: int3     
0x180005b9e: int3     
0x180005b9f: int3     
0x180005ba0: int3     
0x180005ba1: int3     
0x180005ba2: int3     
0x180005ba3: int3     
0x180005ba4: int3     
0x180005ba5: int3     
0x180005ba6: int3     
0x180005ba7: int3     
0x180005ba8: int3     
0x180005ba9: int3     
0x180005baa: int3     
0x180005bab: int3     
0x180005bac: int3     
0x180005bad: int3     
0x180005bae: int3     
0x180005baf: int3     
0x180005bb0: int3     
0x180005bb1: int3     
0x180005bb2: int3     
0x180005bb3: int3     
0x180005bb4: int3     
0x180005bb5: int3     
0x180005bb6: int3     
0x180005bb7: int3     
0x180005bb8: int3     
0x180005bb9: int3     
0x180005bba: int3     
0x180005bbb: int3     
0x180005bbc: int3     
0x180005bbd: int3     
0x180005bbe: int3     
0x180005bbf: int3     
0x180005bc0: int3     
0x180005bc1: int3     
0x180005bc2: int3     
0x180005bc3: int3     
0x180005bc4: int3     
0x180005bc5: int3     
0x180005bc6: int3     
0x180005bc7: int3     
0x180005bc8: int3     
0x180005bc9: int3     
0x180005bca: int3     
0x180005bcb: int3     
0x180005bcc: int3     
0x180005bcd: int3     
0x180005bce: int3     
0x180005bcf: int3     
0x180005bd0: int3     
0x180005bd1: int3     
0x180005bd2: int3     
0x180005bd3: int3     
0x180005bd4: int3     
0x180005bd5: int3     
0x180005bd6: int3     
0x180005bd7: int3     
0x180005bd8: int3     
0x180005bd9: int3     
0x180005bda: int3     
0x180005bdb: int3     
0x180005bdc: int3     
0x180005bdd: int3     
0x180005bde: int3     
0x180005bdf: int3     
0x180005be0: int3     
0x180005be1: int3     
0x180005be2: int3     
0x180005be3: int3     
0x180005be4: int3     
0x180005be5: int3     
0x180005be6: int3     
0x180005be7: int3     
0x180005be8: int3     
0x180005be9: int3     
0x180005bea: int3     
0x180005beb: int3     
0x180005bec: int3     
0x180005bed: int3     
0x180005bee: int3     
0x180005bef: int3     
0x180005bf0: int3     
0x180005bf1: int3     
0x180005bf2: int3     
0x180005bf3: int3     
0x180005bf4: int3     
0x180005bf5: int3     
0x180005bf6: int3     
0x180005bf7: int3     
0x180005bf8: int3     
0x180005bf9: int3     
0x180005bfa: int3     
0x180005bfb: int3     
0x180005bfc: int3     
0x180005bfd: int3     
0x180005bfe: int3     
0x180005bff: int3     
0x180005c00: int3     
0x180005c01: int3     
0x180005c02: int3     
0x180005c03: int3     
0x180005c04: int3     
0x180005c05: int3     
0x180005c06: int3     
0x180005c07: int3     
0x180005c08: int3     
0x180005c09: int3     
0x180005c0a: int3     
0x180005c0b: int3     
0x180005c0c: int3     
0x180005c0d: int3     
0x180005c0e: int3     
0x180005c0f: int3     
0x180005c10: int3     
0x180005c11: int3     
0x180005c12: int3     
0x180005c13: int3     
0x180005c14: int3     
0x180005c15: int3     
0x180005c16: int3     
0x180005c17: int3     
0x180005c18: int3     
0x180005c19: int3     
0x180005c1a: int3     
0x180005c1b: int3     
0x180005c1c: int3     
0x180005c1d: int3     
0x180005c1e: int3     
0x180005c1f: int3     
0x180005c20: int3     
0x180005c21: int3     
0x180005c22: int3     
0x180005c23: int3     
0x180005c24: int3     
0x180005c25: int3     
0x180005c26: int3     
0x180005c27: int3     
0x180005c28: int3     
0x180005c29: int3     
0x180005c2a: int3     
0x180005c2b: int3     
0x180005c2c: int3     
0x180005c2d: int3     
0x180005c2e: int3     
0x180005c2f: int3     
0x180005c30: int3     
0x180005c31: int3     
0x180005c32: int3     
0x180005c33: int3     
0x180005c34: int3     
0x180005c35: int3     
0x180005c36: int3     
0x180005c37: int3     
0x180005c38: int3     
0x180005c39: int3     
0x180005c3a: int3     
0x180005c3b: int3     
0x180005c3c: int3     
0x180005c3d: int3     
0x180005c3e: int3     
0x180005c3f: int3     
0x180005c40: int3     
0x180005c41: int3     
0x180005c42: int3     
0x180005c43: int3     
0x180005c44: int3     
0x180005c45: int3     
0x180005c46: int3     
0x180005c47: int3     
0x180005c48: int3     
0x180005c49: int3     
0x180005c4a: int3     
0x180005c4b: int3     
0x180005c4c: int3     
0x180005c4d: int3     
0x180005c4e: int3     
0x180005c4f: int3     
0x180005c50: int3     
0x180005c51: int3     
0x180005c52: int3     
0x180005c53: int3     
0x180005c54: int3     
0x180005c55: int3     
0x180005c56: int3     
0x180005c57: int3     
0x180005c58: int3     
0x180005c59: int3     
0x180005c5a: int3     
0x180005c5b: int3     
0x180005c5c: int3     
0x180005c5d: int3     
0x180005c5e: int3     
0x180005c5f: int3     
0x180005c60: int3     
0x180005c61: int3     
0x180005c62: int3     
0x180005c63: int3     
0x180005c64: int3     
0x180005c65: int3     
0x180005c66: int3     
0x180005c67: int3     
0x180005c68: int3     
0x180005c69: int3     
0x180005c6a: int3     
0x180005c6b: int3     
0x180005c6c: int3     
0x180005c6d: int3     
0x180005c6e: int3     
0x180005c6f: int3     
0x180005c70: int3     
0x180005c71: int3     
0x180005c72: int3     
0x180005c73: int3     
0x180005c74: int3     
0x180005c75: int3     
0x180005c76: int3     
0x180005c77: int3     
0x180005c78: int3     
0x180005c79: int3     
0x180005c7a: int3     
0x180005c7b: int3     
0x180005c7c: int3     
0x180005c7d: int3     
0x180005c7e: int3     
0x180005c7f: int3     
0x180005c80: int3     
0x180005c81: int3     
0x180005c82: int3     
0x180005c83: int3     
0x180005c84: int3     
0x180005c85: int3     
0x180005c86: int3     
0x180005c87: int3     
0x180005c88: int3     
0x180005c89: int3     
0x180005c8a: int3     
0x180005c8b: int3     
0x180005c8c: int3     
0x180005c8d: int3     
0x180005c8e: int3     
0x180005c8f: int3     
0x180005c90: int3     
0x180005c91: int3     
0x180005c92: int3     
0x180005c93: int3     
0x180005c94: int3     
0x180005c95: int3     
0x180005c96: int3     
0x180005c97: int3     
0x180005c98: int3     
0x180005c99: int3     
0x180005c9a: int3     
0x180005c9b: int3     
0x180005c9c: int3     
0x180005c9d: int3     
0x180005c9e: int3     
0x180005c9f: int3     
0x180005ca0: int3     
0x180005ca1: int3     
0x180005ca2: int3     
0x180005ca3: int3     
0x180005ca4: int3     
0x180005ca5: int3     
0x180005ca6: int3     
0x180005ca7: int3     
0x180005ca8: int3     
0x180005ca9: int3     
0x180005caa: int3     
0x180005cab: int3     
0x180005cac: int3     
0x180005cad: int3     
0x180005cae: int3     
0x180005caf: int3     
0x180005cb0: int3     
0x180005cb1: int3     
0x180005cb2: int3     
0x180005cb3: int3     
0x180005cb4: int3     
0x180005cb5: int3     
0x180005cb6: int3     
0x180005cb7: int3     
0x180005cb8: int3     
0x180005cb9: int3     
0x180005cba: int3     
0x180005cbb: int3     
0x180005cbc: int3     
0x180005cbd: int3     
0x180005cbe: int3     
0x180005cbf: int3     
0x180005cc0: int3     
0x180005cc1: int3     
0x180005cc2: int3     
0x180005cc3: int3     
0x180005cc4: int3     
0x180005cc5: int3     
0x180005cc6: int3     
0x180005cc7: int3     
0x180005cc8: int3     
0x180005cc9: int3     
0x180005cca: int3     
0x180005ccb: int3     
0x180005ccc: int3     
0x180005ccd: int3     
0x180005cce: int3     
0x180005ccf: int3     
0x180005cd0: int3     
0x180005cd1: int3     
0x180005cd2: int3     
0x180005cd3: int3     
0x180005cd4: int3     
0x180005cd5: int3     
0x180005cd6: int3     
0x180005cd7: int3     
0x180005cd8: int3     
0x180005cd9: int3     
0x180005cda: int3     
0x180005cdb: int3     
0x180005cdc: int3     
0x180005cdd: int3     
0x180005cde: int3     
0x180005cdf: int3     
0x180005ce0: int3     
0x180005ce1: int3     
0x180005ce2: int3     
0x180005ce3: int3     
0x180005ce4: int3     
0x180005ce5: int3     
0x180005ce6: int3     
0x180005ce7: int3     
0x180005ce8: int3     
0x180005ce9: int3     
0x180005cea: int3     
0x180005ceb: int3     
0x180005cec: int3     
0x180005ced: int3     
0x180005cee: int3     
0x180005cef: int3     
0x180005cf0: int3     
0x180005cf1: int3     
0x180005cf2: int3     
0x180005cf3: int3     
0x180005cf4: int3     
0x180005cf5: int3     
0x180005cf6: int3     
0x180005cf7: int3     
0x180005cf8: int3     
0x180005cf9: int3     
0x180005cfa: int3     
0x180005cfb: int3     
0x180005cfc: int3     
0x180005cfd: int3     
0x180005cfe: int3     
0x180005cff: int3     
0x180005d00: int3     
0x180005d01: int3     
0x180005d02: int3     
0x180005d03: int3     
0x180005d04: int3     
0x180005d05: int3     
0x180005d06: int3     
0x180005d07: int3     
0x180005d08: int3     
0x180005d09: int3     
0x180005d0a: int3     
0x180005d0b: int3     
0x180005d0c: int3     
0x180005d0d: int3     
0x180005d0e: int3     
0x180005d0f: int3     
0x180005d10: int3     
0x180005d11: int3     
0x180005d12: int3     
0x180005d13: int3     
0x180005d14: int3     
0x180005d15: int3     
0x180005d16: int3     
0x180005d17: int3     
0x180005d18: int3     
0x180005d19: int3     
0x180005d1a: int3     
0x180005d1b: int3     
0x180005d1c: int3     
0x180005d1d: int3     
0x180005d1e: int3     
0x180005d1f: int3     
0x180005d20: int3     
0x180005d21: int3     
0x180005d22: int3     
0x180005d23: int3     
0x180005d24: int3     
0x180005d25: int3     
0x180005d26: int3     
0x180005d27: int3     
0x180005d28: int3     
0x180005d29: int3     
0x180005d2a: int3     
0x180005d2b: int3     
0x180005d2c: int3     
0x180005d2d: int3     
0x180005d2e: int3     
0x180005d2f: int3     
0x180005d30: int3     
0x180005d31: int3     
0x180005d32: int3     
0x180005d33: int3     
0x180005d34: int3     
0x180005d35: int3     
0x180005d36: int3     
0x180005d37: int3     
0x180005d38: int3     
0x180005d39: int3     
0x180005d3a: int3     
0x180005d3b: int3     
0x180005d3c: int3     
0x180005d3d: int3     
0x180005d3e: int3     
0x180005d3f: int3     
0x180005d40: int3     
0x180005d41: int3     
0x180005d42: int3     
0x180005d43: int3     
0x180005d44: int3     
0x180005d45: int3     
0x180005d46: int3     
0x180005d47: int3     
0x180005d48: int3     
0x180005d49: int3     
0x180005d4a: int3     
0x180005d4b: int3     
0x180005d4c: int3     
0x180005d4d: int3     
0x180005d4e: int3     
0x180005d4f: int3     
0x180005d50: int3     
0x180005d51: int3     
0x180005d52: int3     
0x180005d53: int3     
0x180005d54: int3     
0x180005d55: int3     
0x180005d56: int3     
0x180005d57: int3     
0x180005d58: int3     
0x180005d59: int3     
0x180005d5a: int3     
0x180005d5b: int3     
0x180005d5c: int3     
0x180005d5d: int3     
0x180005d5e: int3     
0x180005d5f: int3     
0x180005d60: int3     
0x180005d61: int3     
0x180005d62: int3     
0x180005d63: int3     
0x180005d64: int3     
0x180005d65: int3     
0x180005d66: int3     
0x180005d67: int3     
0x180005d68: int3     
0x180005d69: int3     
0x180005d6a: int3     
0x180005d6b: int3     
0x180005d6c: int3     
0x180005d6d: int3     
0x180005d6e: int3     
0x180005d6f: int3     
0x180005d70: int3     
0x180005d71: int3     
0x180005d72: int3     
0x180005d73: int3     
0x180005d74: int3     
0x180005d75: int3     
0x180005d76: int3     
0x180005d77: int3     
0x180005d78: int3     
0x180005d79: int3     
0x180005d7a: int3     
0x180005d7b: int3     
0x180005d7c: int3     
0x180005d7d: int3     
0x180005d7e: int3     
0x180005d7f: int3     
0x180005d80: int3     
0x180005d81: int3     
0x180005d82: int3     
0x180005d83: int3     
0x180005d84: int3     
0x180005d85: int3     
0x180005d86: int3     
0x180005d87: int3     
0x180005d88: int3     
0x180005d89: int3     
0x180005d8a: int3     
0x180005d8b: int3     
0x180005d8c: int3     
0x180005d8d: int3     
0x180005d8e: int3     
0x180005d8f: int3     
0x180005d90: int3     
0x180005d91: int3     
0x180005d92: int3     
0x180005d93: int3     
0x180005d94: int3     
0x180005d95: int3     
0x180005d96: int3     
0x180005d97: int3     
0x180005d98: int3     
0x180005d99: int3     
0x180005d9a: int3     
0x180005d9b: int3     
0x180005d9c: int3     
0x180005d9d: int3     
0x180005d9e: int3     
0x180005d9f: int3     
0x180005da0: int3     
0x180005da1: int3     
0x180005da2: int3     
0x180005da3: int3     
0x180005da4: int3     
0x180005da5: int3     
0x180005da6: int3     
0x180005da7: int3     
0x180005da8: int3     
0x180005da9: int3     
0x180005daa: int3     
0x180005dab: int3     
0x180005dac: int3     
0x180005dad: int3     
0x180005dae: int3     
0x180005daf: int3     
0x180005db0: int3     
0x180005db1: int3     
0x180005db2: int3     
0x180005db3: int3     
0x180005db4: int3     
0x180005db5: int3     
0x180005db6: int3     
0x180005db7: int3     
0x180005db8: int3     
0x180005db9: int3     
0x180005dba: int3     
0x180005dbb: int3     
0x180005dbc: int3     
0x180005dbd: int3     
0x180005dbe: int3     
0x180005dbf: int3     
0x180005dc0: int3     
0x180005dc1: int3     
0x180005dc2: int3     
0x180005dc3: int3     
0x180005dc4: int3     
0x180005dc5: int3     
0x180005dc6: int3     
0x180005dc7: int3     
0x180005dc8: int3     
0x180005dc9: int3     
0x180005dca: int3     
0x180005dcb: int3     
0x180005dcc: int3     
0x180005dcd: int3     
0x180005dce: int3     
0x180005dcf: int3     
0x180005dd0: int3     
0x180005dd1: int3     
0x180005dd2: int3     
0x180005dd3: int3     
0x180005dd4: int3     
0x180005dd5: int3     
0x180005dd6: int3     
0x180005dd7: int3     
0x180005dd8: int3     
0x180005dd9: int3     
0x180005dda: int3     
0x180005ddb: int3     
0x180005ddc: int3     
0x180005ddd: int3     
0x180005dde: int3     
0x180005ddf: int3     
0x180005de0: int3     
0x180005de1: int3     
0x180005de2: int3     
0x180005de3: int3     
0x180005de4: int3     
0x180005de5: int3     
0x180005de6: int3     
0x180005de7: int3     
0x180005de8: int3     
0x180005de9: int3     
0x180005dea: int3     
0x180005deb: int3     
0x180005dec: int3     
0x180005ded: int3     
0x180005dee: int3     
0x180005def: int3     
0x180005df0: int3     
0x180005df1: int3     
0x180005df2: int3     
0x180005df3: int3     
0x180005df4: int3     
0x180005df5: int3     
0x180005df6: int3     
0x180005df7: int3     
0x180005df8: int3     
0x180005df9: int3     
0x180005dfa: int3     
0x180005dfb: int3     
0x180005dfc: int3     
0x180005dfd: int3     
0x180005dfe: int3     
0x180005dff: int3     
0x180005e00: int3     
0x180005e01: int3     
0x180005e02: int3     
0x180005e03: int3     
0x180005e04: int3     
0x180005e05: int3     
0x180005e06: int3     
0x180005e07: int3     
0x180005e08: int3     
0x180005e09: int3     
0x180005e0a: int3     
0x180005e0b: int3     
0x180005e0c: int3     
0x180005e0d: int3     
0x180005e0e: int3     
0x180005e0f: int3     
0x180005e10: int3     
0x180005e11: int3     
0x180005e12: int3     
0x180005e13: int3     
0x180005e14: int3     
0x180005e15: int3     
0x180005e16: int3     
0x180005e17: int3     
0x180005e18: int3     
0x180005e19: int3     
0x180005e1a: int3     
0x180005e1b: int3     
0x180005e1c: int3     
0x180005e1d: int3     
0x180005e1e: int3     
0x180005e1f: int3     
0x180005e20: int3     
0x180005e21: int3     
0x180005e22: int3     
0x180005e23: int3     
0x180005e24: int3     
0x180005e25: int3     
0x180005e26: int3     
0x180005e27: int3     
0x180005e28: int3     
0x180005e29: int3     
0x180005e2a: int3     
0x180005e2b: int3     
0x180005e2c: int3     
0x180005e2d: int3     
0x180005e2e: int3     
0x180005e2f: int3     
0x180005e30: int3     
0x180005e31: int3     
0x180005e32: int3     
0x180005e33: int3     
0x180005e34: int3     
0x180005e35: int3     
0x180005e36: int3     
0x180005e37: int3     
0x180005e38: int3     
0x180005e39: int3     
0x180005e3a: int3     
0x180005e3b: int3     
0x180005e3c: int3     
0x180005e3d: int3     
0x180005e3e: int3     
0x180005e3f: int3     
0x180005e40: int3     
0x180005e41: int3     
0x180005e42: int3     
0x180005e43: int3     
0x180005e44: int3     
0x180005e45: int3     
0x180005e46: int3     
0x180005e47: int3     
0x180005e48: int3     
0x180005e49: int3     
0x180005e4a: int3     
0x180005e4b: int3     
0x180005e4c: int3     
0x180005e4d: int3     
0x180005e4e: int3     
0x180005e4f: int3     
0x180005e50: int3     
0x180005e51: int3     
0x180005e52: int3     
0x180005e53: int3     
0x180005e54: int3     
0x180005e55: int3     
0x180005e56: int3     
0x180005e57: int3     
0x180005e58: int3     
0x180005e59: int3     
0x180005e5a: int3     
0x180005e5b: int3     
0x180005e5c: int3     
0x180005e5d: int3     
0x180005e5e: int3     
0x180005e5f: int3     
0x180005e60: int3     
0x180005e61: int3     
0x180005e62: int3     
0x180005e63: int3     
0x180005e64: int3     
0x180005e65: int3     
0x180005e66: int3     
0x180005e67: int3     
0x180005e68: int3     
0x180005e69: int3     
0x180005e6a: int3     
0x180005e6b: int3     
0x180005e6c: int3     
0x180005e6d: int3     
0x180005e6e: int3     
0x180005e6f: int3     
0x180005e70: int3     
0x180005e71: int3     
0x180005e72: int3     
0x180005e73: int3     
0x180005e74: int3     
0x180005e75: int3     
0x180005e76: int3     
0x180005e77: int3     
0x180005e78: int3     
0x180005e79: int3     
0x180005e7a: int3     
0x180005e7b: int3     
0x180005e7c: int3     
0x180005e7d: int3     
0x180005e7e: int3     
0x180005e7f: int3     
0x180005e80: int3     
0x180005e81: int3     
0x180005e82: int3     
0x180005e83: int3     
0x180005e84: int3     
0x180005e85: int3     
0x180005e86: int3     
0x180005e87: int3     
0x180005e88: int3     
0x180005e89: int3     
0x180005e8a: int3     
0x180005e8b: int3     
0x180005e8c: int3     
0x180005e8d: int3     
0x180005e8e: int3     
0x180005e8f: int3     
0x180005e90: int3     
0x180005e91: int3     
0x180005e92: int3     
0x180005e93: int3     
0x180005e94: int3     
0x180005e95: int3     
0x180005e96: int3     
0x180005e97: int3     
0x180005e98: int3     
0x180005e99: int3     
0x180005e9a: int3     
0x180005e9b: int3     
0x180005e9c: int3     
0x180005e9d: int3     
0x180005e9e: int3     
0x180005e9f: int3     
0x180005ea0: int3     
0x180005ea1: int3     
0x180005ea2: int3     
0x180005ea3: int3     
0x180005ea4: int3     
0x180005ea5: int3     
0x180005ea6: int3     
0x180005ea7: int3     
0x180005ea8: int3     
0x180005ea9: int3     
0x180005eaa: int3     
0x180005eab: int3     
0x180005eac: int3     
0x180005ead: int3     
0x180005eae: int3     
0x180005eaf: int3     
0x180005eb0: int3     
0x180005eb1: int3     
0x180005eb2: int3     
0x180005eb3: int3     
0x180005eb4: int3     
0x180005eb5: int3     
0x180005eb6: int3     
0x180005eb7: int3     
0x180005eb8: int3     
0x180005eb9: int3     
0x180005eba: int3     
0x180005ebb: int3     
0x180005ebc: int3     
0x180005ebd: int3     
0x180005ebe: int3     
0x180005ebf: int3     
0x180005ec0: int3     
0x180005ec1: int3     
0x180005ec2: int3     
0x180005ec3: int3     
0x180005ec4: int3     
0x180005ec5: int3     
0x180005ec6: int3     
0x180005ec7: int3     
0x180005ec8: int3     
0x180005ec9: int3     
0x180005eca: int3     
0x180005ecb: int3     
0x180005ecc: int3     
0x180005ecd: int3     
0x180005ece: int3     
0x180005ecf: int3     
0x180005ed0: int3     
0x180005ed1: int3     
0x180005ed2: int3     
0x180005ed3: int3     
0x180005ed4: int3     
0x180005ed5: int3     
0x180005ed6: int3     
0x180005ed7: int3     
0x180005ed8: int3     
0x180005ed9: int3     
0x180005eda: int3     
0x180005edb: int3     
0x180005edc: int3     
0x180005edd: int3     
0x180005ede: int3     
0x180005edf: int3     
0x180005ee0: int3     
0x180005ee1: int3     
0x180005ee2: int3     
0x180005ee3: int3     
0x180005ee4: int3     
0x180005ee5: int3     
0x180005ee6: int3     
0x180005ee7: int3     
0x180005ee8: int3     
0x180005ee9: int3     
0x180005eea: int3     
0x180005eeb: int3     
0x180005eec: int3     
0x180005eed: int3     
0x180005eee: int3     
0x180005eef: int3     
0x180005ef0: int3     
0x180005ef1: int3     
0x180005ef2: int3     
0x180005ef3: int3     
0x180005ef4: int3     
0x180005ef5: int3     
0x180005ef6: int3     
0x180005ef7: int3     
0x180005ef8: int3     
0x180005ef9: int3     
0x180005efa: int3     
0x180005efb: int3     
0x180005efc: int3     
0x180005efd: int3     
0x180005efe: int3     
0x180005eff: int3     
0x180005f00: int3     
0x180005f01: int3     
0x180005f02: int3     
0x180005f03: int3     
0x180005f04: int3     
0x180005f05: int3     
0x180005f06: int3     
0x180005f07: int3     
0x180005f08: int3     
0x180005f09: int3     
0x180005f0a: int3     
0x180005f0b: int3     
0x180005f0c: int3     
0x180005f0d: int3     
0x180005f0e: int3     
0x180005f0f: int3     
0x180005f10: int3     
0x180005f11: int3     
0x180005f12: int3     
0x180005f13: int3     
0x180005f14: int3     
0x180005f15: int3     
0x180005f16: int3     
0x180005f17: int3     
0x180005f18: int3     
0x180005f19: int3     
0x180005f1a: int3     
0x180005f1b: int3     
0x180005f1c: int3     
0x180005f1d: int3     
0x180005f1e: int3     
0x180005f1f: int3     
0x180005f20: int3     
0x180005f21: int3     
0x180005f22: int3     
0x180005f23: int3     
0x180005f24: int3     
0x180005f25: int3     
0x180005f26: int3     
0x180005f27: int3     
0x180005f28: int3     
0x180005f29: int3     
0x180005f2a: int3     
0x180005f2b: int3     
0x180005f2c: int3     
0x180005f2d: int3     
0x180005f2e: int3     
0x180005f2f: int3     
0x180005f30: int3     
0x180005f31: int3     
0x180005f32: int3     
0x180005f33: int3     
0x180005f34: int3     
0x180005f35: int3     
0x180005f36: int3     
0x180005f37: int3     
0x180005f38: int3     
0x180005f39: int3     
0x180005f3a: int3     
0x180005f3b: int3     
0x180005f3c: int3     
0x180005f3d: int3     
0x180005f3e: int3     
0x180005f3f: int3     
0x180005f40: int3     
0x180005f41: int3     
0x180005f42: int3     
0x180005f43: int3     
0x180005f44: int3     
0x180005f45: int3     
0x180005f46: int3     
0x180005f47: int3     
0x180005f48: int3     
0x180005f49: int3     
0x180005f4a: int3     
0x180005f4b: int3     
0x180005f4c: int3     
0x180005f4d: int3     
0x180005f4e: int3     
0x180005f4f: int3     
0x180005f50: int3     
0x180005f51: int3     
0x180005f52: int3     
0x180005f53: int3     
0x180005f54: int3     
0x180005f55: int3     
0x180005f56: int3     
0x180005f57: int3     
0x180005f58: int3     
0x180005f59: int3     
0x180005f5a: int3     
0x180005f5b: int3     
0x180005f5c: int3     
0x180005f5d: int3     
0x180005f5e: int3     
0x180005f5f: int3     
0x180005f60: int3     
0x180005f61: int3     
0x180005f62: int3     
0x180005f63: int3     
0x180005f64: int3     
0x180005f65: int3     
0x180005f66: int3     
0x180005f67: int3     
0x180005f68: int3     
0x180005f69: int3     
0x180005f6a: int3     
0x180005f6b: int3     
0x180005f6c: int3     
0x180005f6d: int3     
0x180005f6e: int3     
0x180005f6f: int3     
0x180005f70: int3     
0x180005f71: int3     
0x180005f72: int3     
0x180005f73: int3     
0x180005f74: int3     
0x180005f75: int3     
0x180005f76: int3     
0x180005f77: int3     
0x180005f78: int3     
0x180005f79: int3     
0x180005f7a: int3     
0x180005f7b: int3     
0x180005f7c: int3     
0x180005f7d: int3     
0x180005f7e: int3     
0x180005f7f: int3     
0x180005f80: int3     
0x180005f81: int3     
0x180005f82: int3     
0x180005f83: int3     
0x180005f84: int3     
0x180005f85: int3     
0x180005f86: int3     
0x180005f87: int3     
0x180005f88: int3     
0x180005f89: int3     
0x180005f8a: int3     
0x180005f8b: int3     
0x180005f8c: int3     
0x180005f8d: int3     
0x180005f8e: int3     
0x180005f8f: int3     
0x180005f90: int3     
0x180005f91: int3     
0x180005f92: int3     
0x180005f93: int3     
0x180005f94: int3     
0x180005f95: int3     
0x180005f96: int3     
0x180005f97: int3     
0x180005f98: int3     
0x180005f99: int3     
0x180005f9a: int3     
0x180005f9b: int3     
0x180005f9c: int3     
0x180005f9d: int3     
0x180005f9e: int3     
0x180005f9f: int3     
0x180005fa0: int3     
0x180005fa1: int3     
0x180005fa2: int3     
0x180005fa3: int3     
0x180005fa4: int3     
0x180005fa5: int3     
0x180005fa6: int3     
0x180005fa7: int3     
0x180005fa8: int3     
0x180005fa9: int3     
0x180005faa: int3     
0x180005fab: int3     
0x180005fac: int3     
0x180005fad: int3     
0x180005fae: int3     
0x180005faf: int3     
0x180005fb0: int3     
0x180005fb1: int3     
0x180005fb2: int3     
0x180005fb3: int3     
0x180005fb4: int3     
0x180005fb5: int3     
0x180005fb6: int3     
0x180005fb7: int3     
0x180005fb8: int3     
0x180005fb9: int3     
0x180005fba: int3     
0x180005fbb: int3     
0x180005fbc: int3     
0x180005fbd: int3     
0x180005fbe: int3     
0x180005fbf: int3     
0x180005fc0: int3     
0x180005fc1: int3     
0x180005fc2: int3     
0x180005fc3: int3     
0x180005fc4: int3     
0x180005fc5: int3     
0x180005fc6: int3     
0x180005fc7: int3     
0x180005fc8: int3     
0x180005fc9: int3     
0x180005fca: int3     
0x180005fcb: int3     
0x180005fcc: int3     
0x180005fcd: int3     
0x180005fce: int3     
0x180005fcf: int3     
0x180005fd0: int3     
0x180005fd1: int3     
0x180005fd2: int3     
0x180005fd3: int3     
0x180005fd4: int3     
0x180005fd5: int3     
0x180005fd6: int3     
0x180005fd7: int3     
0x180005fd8: int3     
0x180005fd9: int3     
0x180005fda: int3     
0x180005fdb: int3     
0x180005fdc: int3     
0x180005fdd: int3     
0x180005fde: int3     
0x180005fdf: int3     
0x180005fe0: int3     
0x180005fe1: int3     
0x180005fe2: int3     
0x180005fe3: int3     
0x180005fe4: int3     
0x180005fe5: int3     
0x180005fe6: int3     
0x180005fe7: int3     
0x180005fe8: int3     
0x180005fe9: int3     
0x180005fea: int3     
0x180005feb: int3     
0x180005fec: int3     
0x180005fed: int3     
0x180005fee: int3     
0x180005fef: int3     
0x180005ff0: int3     
0x180005ff1: int3     
0x180005ff2: int3     
0x180005ff3: int3     
0x180005ff4: int3     
0x180005ff5: int3     
0x180005ff6: int3     
0x180005ff7: int3     
0x180005ff8: int3     
0x180005ff9: int3     
0x180005ffa: int3     
0x180005ffb: int3     
0x180005ffc: int3     
0x180005ffd: int3     
0x180005ffe: int3     
0x180005fff: int3     
```

### Section: PAGE (VA=0x18000c000, 4185 instructions)
```asm
0x18000c000: int3     
0x18000c001: int3     
0x18000c002: int3     
0x18000c003: int3     
0x18000c004: int3     
0x18000c005: int3     
0x18000c006: int3     
0x18000c007: int3     
0x18000c008: int3     
0x18000c009: int3     
0x18000c00a: int3     
0x18000c00b: int3     
0x18000c00c: int3     
0x18000c00d: int3     
0x18000c00e: int3     
0x18000c00f: int3     
0x18000c010: mov      rax, rsp
0x18000c013: mov      qword ptr [rax + 8], rbx
0x18000c017: mov      qword ptr [rax + 0x10], rsi
0x18000c01b: mov      qword ptr [rax + 0x18], rdi
0x18000c01f: push     rbp
0x18000c020: lea      rbp, [rax - 0x5f]
0x18000c024: sub      rsp, 0xb0
0x18000c02b: mov      rax, qword ptr [rip - 0x3f32]
0x18000c032: xor      rax, rsp
0x18000c035: mov      qword ptr [rbp + 0x47], rax
0x18000c039: mov      rbx, qword ptr [rip - 0x3e48]
0x18000c040: xor      esi, esi
0x18000c042: cmp      qword ptr [rbx], rsi
0x18000c045: jne      0x18000c04c
0x18000c047: call     0x1800038ec
0x18000c04c: mov      rcx, qword ptr [rbx]
0x18000c04f: mov      dl, 1
0x18000c051: call     qword ptr [rip - 0x2050]  ; -> ExAcquireResourceExclusiveLite
0x18000c058: nop      dword ptr [rax + rax]
0x18000c05d: mov      rcx, qword ptr [rip - 0x3e74]
0x18000c064: mov      rbx, qword ptr [rbx]
0x18000c067: movzx    r8d, word ptr [rip - 0x3e8b]
0x18000c06f: test     rcx, rcx
0x18000c072: je       0x18000c15c
0x18000c078: cmp      r8w, 1
0x18000c07d: jne      0x18000c15c
0x18000c083: xor      r9d, r9d
0x18000c086: xor      r8d, r8d
0x18000c089: mov      dl, 1
0x18000c08b: call     qword ptr [rip - 0x2072]  ; -> ExDeleteTimer
0x18000c092: nop      dword ptr [rax + rax]
0x18000c097: lea      rdx, [rbp - 0x11]
0x18000c09b: mov      qword ptr [rip - 0x3eb2], rsi
0x18000c0a2: lea      rcx, [rip - 0x3ec1]
0x18000c0a9: mov      word ptr [rip - 0x3ecc], si
0x18000c0b0: mov      dil, al
0x18000c0b3: mov      qword ptr [rbp - 0x11], rsi
0x18000c0b7: call     0x180001278
0x18000c0bc: test     eax, eax
0x18000c0be: je       0x18000c0c5
0x18000c0c0: call     0x1800038ec
0x18000c0c5: cmp      dword ptr [rip - 0x4084], 4
0x18000c0cc: jbe      0x18000c141
0x18000c0ce: movabs   rdx, 0x400000000000
0x18000c0d8: test     qword ptr [rip - 0x4087], rdx
0x18000c0df: je       0x18000c141
0x18000c0e1: mov      rax, qword ptr [rip - 0x4088]
0x18000c0e8: and      rax, rdx
0x18000c0eb: cmp      rax, qword ptr [rip - 0x4092]
0x18000c0f2: jne      0x18000c141
0x18000c0f4: mov      rax, qword ptr [rbp - 0x11]
0x18000c0f8: lea      rdx, [rip - 0x5871]
0x18000c0ff: mov      qword ptr [rbp - 1], rax
0x18000c103: mov      eax, dword ptr [rip - 0x3f29]
0x18000c109: mov      dword ptr [rbp - 0x11], eax
0x18000c10c: lea      rax, [rbp - 1]
0x18000c110: mov      qword ptr [rsp + 0x38], rax
0x18000c115: lea      rax, [rbp - 0x11]
0x18000c119: mov      qword ptr [rsp + 0x30], rax
0x18000c11e: lea      rax, [rbp - 0x19]
0x18000c122: mov      qword ptr [rsp + 0x28], rax
0x18000c127: lea      rax, [rbp - 9]
0x18000c12b: mov      qword ptr [rsp + 0x20], rax
0x18000c130: mov      byte ptr [rbp - 0x19], dil
0x18000c134: mov      qword ptr [rbp - 9], 0x800
0x18000c13c: call     0x180001008
0x18000c141: test     rbx, rbx
0x18000c144: je       0x18000c155
0x18000c146: mov      rcx, rbx
0x18000c149: call     qword ptr [rip - 0x2110]  ; -> ExReleaseResourceLite
0x18000c150: nop      dword ptr [rax + rax]
0x18000c155: xor      eax, eax
0x18000c157: jmp      0x18000c1fb
0x18000c15c: cmp      dword ptr [rip - 0x411b], 2
0x18000c163: jbe      0x18000c1e2
0x18000c165: movabs   rdx, 0x400000000000
0x18000c16f: test     qword ptr [rip - 0x411e], rdx
0x18000c176: je       0x18000c1e2
0x18000c178: mov      rax, qword ptr [rip - 0x411f]
0x18000c17f: and      rax, rdx
0x18000c182: cmp      rax, qword ptr [rip - 0x4129]
0x18000c189: jne      0x18000c1e2
0x18000c18b: lea      rax, [rbp - 0x19]
0x18000c18f: mov      word ptr [rbp - 0x19], r8w
0x18000c194: mov      qword ptr [rbp + 0x37], rax
0x18000c198: lea      rdx, [rip - 0x58af]
0x18000c19f: lea      rax, [rbp - 9]
0x18000c1a3: mov      qword ptr [rbp - 9], 0x800
0x18000c1ab: mov      qword ptr [rbp + 0x27], rax
0x18000c1af: lea      rcx, [rip - 0x416e]
0x18000c1b6: lea      rax, [rbp + 7]
0x18000c1ba: mov      qword ptr [rbp + 0x3f], 2
0x18000c1c2: mov      qword ptr [rsp + 0x28], rax
0x18000c1c7: xor      r9d, r9d
0x18000c1ca: xor      r8d, r8d
0x18000c1cd: mov      dword ptr [rsp + 0x20], 4
0x18000c1d5: mov      qword ptr [rbp + 0x2f], 8
0x18000c1dd: call     0x18000112c
0x18000c1e2: test     rbx, rbx
0x18000c1e5: je       0x18000c1f6
0x18000c1e7: mov      rcx, rbx
0x18000c1ea: call     qword ptr [rip - 0x21b1]  ; -> ExReleaseResourceLite
0x18000c1f1: nop      dword ptr [rax + rax]
0x18000c1f6: mov      eax, 0xc000042a
0x18000c1fb: mov      rcx, qword ptr [rbp + 0x47]
0x18000c1ff: xor      rcx, rsp
0x18000c202: call     0x1800041a0
0x18000c207: lea      r11, [rsp + 0xb0]
0x18000c20f: mov      rbx, qword ptr [r11 + 0x10]
0x18000c213: mov      rsi, qword ptr [r11 + 0x18]
0x18000c217: mov      rdi, qword ptr [r11 + 0x20]
0x18000c21b: mov      rsp, r11
0x18000c21e: pop      rbp
0x18000c21f: ret      
0x18000c220: int3     
0x18000c221: int3     
0x18000c222: int3     
0x18000c223: int3     
0x18000c224: int3     
0x18000c225: int3     
0x18000c226: int3     
0x18000c227: int3     
0x18000c228: int3     
0x18000c229: int3     
0x18000c22a: int3     
0x18000c22b: int3     
0x18000c22c: int3     
0x18000c22d: int3     
0x18000c22e: int3     
0x18000c22f: int3     
0x18000c230: mov      qword ptr [rsp + 8], rbx
0x18000c235: mov      qword ptr [rsp + 0x10], rdi
0x18000c23a: push     rbp
0x18000c23b: lea      rbp, [rsp - 0x57]
0x18000c240: sub      rsp, 0xb0
0x18000c247: mov      rax, qword ptr [rip - 0x414e]
0x18000c24e: xor      rax, rsp
0x18000c251: mov      qword ptr [rbp + 0x47], rax
0x18000c255: mov      rbx, qword ptr [rip - 0x4064]
0x18000c25c: cmp      qword ptr [rbx], 0
0x18000c260: jne      0x18000c267
0x18000c262: call     0x1800038ec
0x18000c267: mov      rcx, qword ptr [rbx]
0x18000c26a: mov      dl, 1
0x18000c26c: call     qword ptr [rip - 0x226b]  ; -> ExAcquireResourceExclusiveLite
0x18000c273: nop      dword ptr [rax + rax]
0x18000c278: cmp      dword ptr [rip - 0x40af], 0
0x18000c27f: mov      rbx, qword ptr [rbx]
0x18000c282: jne      0x18000c2fb
0x18000c284: cmp      dword ptr [rip - 0x4243], 2
0x18000c28b: jbe      0x18000c2dd
0x18000c28d: movabs   rdx, 0x400000000000
0x18000c297: test     qword ptr [rip - 0x4246], rdx
0x18000c29e: je       0x18000c2dd
0x18000c2a0: mov      rax, qword ptr [rip - 0x4247]
0x18000c2a7: and      rax, rdx
0x18000c2aa: cmp      rax, qword ptr [rip - 0x4251]
0x18000c2b1: jne      0x18000c2dd
0x18000c2b3: and      dword ptr [rbp - 0x29], 0
0x18000c2b7: lea      rax, [rbp - 0x29]
0x18000c2bb: mov      qword ptr [rsp + 0x28], rax
0x18000c2c0: lea      rdx, [rip - 0x5c9d]
0x18000c2c7: lea      rax, [rbp - 0x21]
0x18000c2cb: mov      qword ptr [rbp - 0x21], 0x800
0x18000c2d3: mov      qword ptr [rsp + 0x20], rax
0x18000c2d8: call     0x1800010a4
0x18000c2dd: test     rbx, rbx
0x18000c2e0: je       0x18000c2f1
0x18000c2e2: mov      rcx, rbx
0x18000c2e5: call     qword ptr [rip - 0x22ac]  ; -> ExReleaseResourceLite
0x18000c2ec: nop      dword ptr [rax + rax]
0x18000c2f1: mov      eax, 0xc000042a
0x18000c2f6: jmp      0x18000c45a
0x18000c2fb: mov      rcx, qword ptr [rip - 0x412a]
0x18000c302: call     0x180002014
0x18000c307: mov      edi, eax
0x18000c309: test     eax, eax
0x18000c30b: js       0x18000c3e5
0x18000c311: and      qword ptr [rbp - 0x29], 0
0x18000c316: lea      rdx, [rbp - 0x29]
0x18000c31a: lea      rcx, [rip - 0x4159]
0x18000c321: call     0x180001278
0x18000c326: test     eax, eax
0x18000c328: je       0x18000c32f
0x18000c32a: call     0x1800038ec
0x18000c32f: cmp      dword ptr [rip - 0x42ee], 4
0x18000c336: jbe      0x18000c43d
0x18000c33c: movabs   rdx, 0x400000000000
0x18000c346: test     qword ptr [rip - 0x42f5], rdx
0x18000c34d: je       0x18000c43d
0x18000c353: mov      rax, qword ptr [rip - 0x42fa]
0x18000c35a: and      rax, rdx
0x18000c35d: cmp      rax, qword ptr [rip - 0x4304]
0x18000c364: jne      0x18000c43d
0x18000c36a: mov      rax, qword ptr [rbp - 0x29]
0x18000c36e: lea      rdx, [rip - 0x5da2]
0x18000c375: and      dword ptr [rbp + 0x43], 0
0x18000c379: mov      ecx, 8
0x18000c37e: and      dword ptr [rbp + 0x33], 0
0x18000c382: xor      r9d, r9d
0x18000c385: and      dword ptr [rbp + 0x23], 0
0x18000c389: xor      r8d, r8d
0x18000c38c: mov      qword ptr [rbp - 0x21], rax
0x18000c390: mov      eax, dword ptr [rip - 0x41c6]
0x18000c396: mov      dword ptr [rbp - 0x29], eax
0x18000c399: lea      rax, [rbp - 0x21]
0x18000c39d: mov      qword ptr [rbp + 0x37], rax
0x18000c3a1: lea      rax, [rbp - 0x29]
0x18000c3a5: mov      qword ptr [rbp + 0x27], rax
0x18000c3a9: lea      rax, [rbp - 0x19]
0x18000c3ad: mov      qword ptr [rbp + 0x17], rax
0x18000c3b1: lea      rax, [rbp - 9]
0x18000c3b5: mov      dword ptr [rbp + 0x3f], ecx
0x18000c3b8: mov      dword ptr [rbp + 0x1f], ecx
0x18000c3bb: lea      rcx, [rip - 0x437a]
0x18000c3c2: mov      qword ptr [rsp + 0x28], rax
0x18000c3c7: mov      dword ptr [rsp + 0x20], 5
0x18000c3cf: mov      qword ptr [rbp - 0x19], 0x800
0x18000c3d7: mov      dword ptr [rbp + 0x2f], 4
0x18000c3de: call     0x18000112c
0x18000c3e3: jmp      0x18000c43d
0x18000c3e5: cmp      dword ptr [rip - 0x43a4], 2
0x18000c3ec: jbe      0x18000c43d
0x18000c3ee: movabs   rdx, 0x200000000000
0x18000c3f8: test     qword ptr [rip - 0x43a7], rdx
0x18000c3ff: je       0x18000c43d
0x18000c401: mov      rax, qword ptr [rip - 0x43a8]
0x18000c408: and      rax, rdx
0x18000c40b: cmp      rax, qword ptr [rip - 0x43b2]
0x18000c412: jne      0x18000c43d
0x18000c414: lea      rax, [rbp - 0x29]
0x18000c418: mov      dword ptr [rbp - 0x29], edi
0x18000c41b: mov      qword ptr [rsp + 0x28], rax
0x18000c420: lea      rdx, [rip - 0x5e96]
0x18000c427: lea      rax, [rbp - 0x19]
0x18000c42b: mov      qword ptr [rbp - 0x19], 0x800
0x18000c433: mov      qword ptr [rsp + 0x20], rax
0x18000c438: call     0x1800010a4
0x18000c43d: and      dword ptr [rip - 0x4274], 0
0x18000c444: test     rbx, rbx
0x18000c447: je       0x18000c458
0x18000c449: mov      rcx, rbx
0x18000c44c: call     qword ptr [rip - 0x2413]  ; -> ExReleaseResourceLite
0x18000c453: nop      dword ptr [rax + rax]
0x18000c458: mov      eax, edi
0x18000c45a: mov      rcx, qword ptr [rbp + 0x47]
0x18000c45e: xor      rcx, rsp
0x18000c461: call     0x1800041a0
0x18000c466: lea      r11, [rsp + 0xb0]
0x18000c46e: mov      rbx, qword ptr [r11 + 0x10]
0x18000c472: mov      rdi, qword ptr [r11 + 0x18]
0x18000c476: mov      rsp, r11
0x18000c479: pop      rbp
0x18000c47a: ret      
0x18000c47b: int3     
0x18000c47c: int3     
0x18000c47d: int3     
0x18000c47e: int3     
0x18000c47f: int3     
0x18000c480: int3     
0x18000c481: int3     
0x18000c482: int3     
0x18000c483: int3     
0x18000c484: int3     
0x18000c485: int3     
0x18000c486: int3     
0x18000c487: int3     
0x18000c488: int3     
0x18000c489: int3     
0x18000c48a: int3     
0x18000c48b: int3     
0x18000c48c: int3     
0x18000c48d: int3     
0x18000c48e: int3     
0x18000c48f: int3     
0x18000c490: mov      rax, rsp
0x18000c493: mov      qword ptr [rax + 8], rbx
0x18000c497: mov      qword ptr [rax + 0x10], rsi
0x18000c49b: mov      qword ptr [rax + 0x18], rdi
0x18000c49f: push     rbp
0x18000c4a0: lea      rbp, [rax - 0x5f]
0x18000c4a4: sub      rsp, 0xb0
0x18000c4ab: mov      rax, qword ptr [rip - 0x43b2]
0x18000c4b2: xor      rax, rsp
0x18000c4b5: mov      qword ptr [rbp + 0x47], rax
0x18000c4b9: mov      rbx, qword ptr [rip - 0x42c8]
0x18000c4c0: xor      esi, esi
0x18000c4c2: cmp      qword ptr [rbx], rsi
0x18000c4c5: jne      0x18000c4cc
0x18000c4c7: call     0x1800038ec
0x18000c4cc: mov      rcx, qword ptr [rbx]
0x18000c4cf: mov      dl, 1
0x18000c4d1: call     qword ptr [rip - 0x24d0]  ; -> ExAcquireResourceExclusiveLite
0x18000c4d8: nop      dword ptr [rax + rax]
0x18000c4dd: mov      rcx, qword ptr [rip - 0x42f4]
0x18000c4e4: mov      r9d, 2
0x18000c4ea: mov      rbx, qword ptr [rbx]
0x18000c4ed: movzx    r8d, word ptr [rip - 0x4311]
0x18000c4f5: test     rcx, rcx
0x18000c4f8: je       0x18000c5e1
0x18000c4fe: cmp      r8w, r9w
0x18000c502: jne      0x18000c5e1
0x18000c508: xor      r9d, r9d
0x18000c50b: xor      r8d, r8d
0x18000c50e: mov      dl, 1
0x18000c510: call     qword ptr [rip - 0x24f7]  ; -> ExDeleteTimer
0x18000c517: nop      dword ptr [rax + rax]
0x18000c51c: lea      rdx, [rbp - 0x11]
0x18000c520: mov      qword ptr [rip - 0x4337], rsi
0x18000c527: lea      rcx, [rip - 0x4346]
0x18000c52e: mov      word ptr [rip - 0x4351], si
0x18000c535: mov      dil, al
0x18000c538: mov      qword ptr [rbp - 0x11], rsi
0x18000c53c: call     0x180001278
0x18000c541: test     eax, eax
0x18000c543: je       0x18000c54a
0x18000c545: call     0x1800038ec
0x18000c54a: cmp      dword ptr [rip - 0x4509], 4
0x18000c551: jbe      0x18000c5c6
0x18000c553: movabs   rdx, 0x400000000000
0x18000c55d: test     qword ptr [rip - 0x450c], rdx
0x18000c564: je       0x18000c5c6
0x18000c566: mov      rax, qword ptr [rip - 0x450d]
0x18000c56d: and      rax, rdx
0x18000c570: cmp      rax, qword ptr [rip - 0x4517]
0x18000c577: jne      0x18000c5c6
0x18000c579: mov      rax, qword ptr [rbp - 0x11]
0x18000c57d: lea      rdx, [rip - 0x5e9b]
0x18000c584: mov      qword ptr [rbp - 1], rax
0x18000c588: mov      eax, dword ptr [rip - 0x43ae]
0x18000c58e: mov      dword ptr [rbp - 0x11], eax
0x18000c591: lea      rax, [rbp - 1]
0x18000c595: mov      qword ptr [rsp + 0x38], rax
0x18000c59a: lea      rax, [rbp - 0x11]
0x18000c59e: mov      qword ptr [rsp + 0x30], rax
0x18000c5a3: lea      rax, [rbp - 0x19]
0x18000c5a7: mov      qword ptr [rsp + 0x28], rax
0x18000c5ac: lea      rax, [rbp - 9]
0x18000c5b0: mov      qword ptr [rsp + 0x20], rax
0x18000c5b5: mov      byte ptr [rbp - 0x19], dil
0x18000c5b9: mov      qword ptr [rbp - 9], 0x800
0x18000c5c1: call     0x180001008
0x18000c5c6: test     rbx, rbx
0x18000c5c9: je       0x18000c5da
0x18000c5cb: mov      rcx, rbx
0x18000c5ce: call     qword ptr [rip - 0x2595]  ; -> ExReleaseResourceLite
0x18000c5d5: nop      dword ptr [rax + rax]
0x18000c5da: xor      eax, eax
0x18000c5dc: jmp      0x18000c67c
0x18000c5e1: cmp      dword ptr [rip - 0x45a0], r9d
0x18000c5e8: jbe      0x18000c663
0x18000c5ea: movabs   rdx, 0x400000000000
0x18000c5f4: test     qword ptr [rip - 0x45a3], rdx
0x18000c5fb: je       0x18000c663
0x18000c5fd: mov      rax, qword ptr [rip - 0x45a4]
0x18000c604: and      rax, rdx
0x18000c607: cmp      rax, qword ptr [rip - 0x45ae]
0x18000c60e: jne      0x18000c663
0x18000c610: lea      rax, [rbp - 0x19]
0x18000c614: mov      word ptr [rbp - 0x19], r8w
0x18000c619: mov      qword ptr [rbp + 0x37], rax
0x18000c61d: lea      rdx, [rip - 0x5eda]
0x18000c624: lea      rax, [rbp - 9]
0x18000c628: mov      qword ptr [rbp + 0x3f], r9
0x18000c62c: mov      qword ptr [rbp + 0x27], rax
0x18000c630: lea      rcx, [rip - 0x45ef]
0x18000c637: lea      rax, [rbp + 7]
0x18000c63b: mov      qword ptr [rbp - 9], 0x800
0x18000c643: mov      qword ptr [rsp + 0x28], rax
0x18000c648: xor      r9d, r9d
0x18000c64b: xor      r8d, r8d
0x18000c64e: mov      dword ptr [rsp + 0x20], 4
0x18000c656: mov      qword ptr [rbp + 0x2f], 8
0x18000c65e: call     0x18000112c
0x18000c663: test     rbx, rbx
0x18000c666: je       0x18000c677
0x18000c668: mov      rcx, rbx
0x18000c66b: call     qword ptr [rip - 0x2632]  ; -> ExReleaseResourceLite
0x18000c672: nop      dword ptr [rax + rax]
0x18000c677: mov      eax, 0xc000042a
0x18000c67c: mov      rcx, qword ptr [rbp + 0x47]
0x18000c680: xor      rcx, rsp
0x18000c683: call     0x1800041a0
0x18000c688: lea      r11, [rsp + 0xb0]
0x18000c690: mov      rbx, qword ptr [r11 + 0x10]
0x18000c694: mov      rsi, qword ptr [r11 + 0x18]
0x18000c698: mov      rdi, qword ptr [r11 + 0x20]
0x18000c69c: mov      rsp, r11
0x18000c69f: pop      rbp
0x18000c6a0: ret      
0x18000c6a1: int3     
0x18000c6a2: int3     
0x18000c6a3: int3     
0x18000c6a4: int3     
0x18000c6a5: int3     
0x18000c6a6: int3     
0x18000c6a7: int3     
0x18000c6a8: int3     
0x18000c6a9: int3     
0x18000c6aa: int3     
0x18000c6ab: int3     
0x18000c6ac: int3     
0x18000c6ad: int3     
0x18000c6ae: int3     
0x18000c6af: int3     
0x18000c6b0: mov      r11, rsp
0x18000c6b3: mov      qword ptr [r11 + 0x18], rbx
0x18000c6b7: mov      qword ptr [r11 + 0x20], rsi
0x18000c6bb: push     rbp
0x18000c6bc: push     rdi
0x18000c6bd: push     r15
0x18000c6bf: mov      rbp, rsp
0x18000c6c2: sub      rsp, 0x80
0x18000c6c9: mov      rax, qword ptr [rip - 0x45d0]
0x18000c6d0: xor      rax, rsp
0x18000c6d3: mov      qword ptr [rbp - 8], rax
0x18000c6d7: mov      edi, ecx
0x18000c6d9: mov      rsi, rdx
0x18000c6dc: cmp      ecx, 0x2a0
0x18000c6e2: jae      0x18000c744
0x18000c6e4: cmp      dword ptr [rip - 0x46a3], 2
0x18000c6eb: jbe      0x18000c73a
0x18000c6ed: movabs   rdx, 0x200000000000
0x18000c6f7: test     qword ptr [rip - 0x46a6], rdx
0x18000c6fe: je       0x18000c73a
0x18000c700: mov      rax, qword ptr [rip - 0x46a7]
0x18000c707: and      rax, rdx
0x18000c70a: cmp      rax, qword ptr [rip - 0x46b1]
0x18000c711: jne      0x18000c73a
0x18000c713: lea      rax, [rbp - 0x50]
0x18000c717: mov      dword ptr [rbp - 0x50], edi
0x18000c71a: mov      qword ptr [r11 - 0x70], rax
0x18000c71e: lea      rdx, [rip - 0x5d34]
0x18000c725: lea      rax, [rbp - 0x48]
0x18000c729: mov      qword ptr [rbp - 0x48], 0x800
0x18000c731: mov      qword ptr [r11 - 0x78], rax
0x18000c735: call     0x1800010a4
0x18000c73a: mov      eax, 0xc000000d
0x18000c73f: jmp      0x18000c98b
0x18000c744: mov      rbx, qword ptr [rip - 0x4553]
0x18000c74b: cmp      qword ptr [rbx], 0
0x18000c74f: jne      0x18000c756
0x18000c751: call     0x1800038ec
0x18000c756: mov      rcx, qword ptr [rbx]
0x18000c759: mov      r15d, 1
0x18000c75f: mov      dl, r15b
0x18000c762: call     qword ptr [rip - 0x2761]  ; -> ExAcquireResourceExclusiveLite
0x18000c769: nop      dword ptr [rax + rax]
0x18000c76e: cmp      qword ptr [rip - 0x4586], 0
0x18000c776: mov      rbx, qword ptr [rbx]
0x18000c779: je       0x18000c811
0x18000c77f: cmp      dword ptr [rip - 0x473e], 2
0x18000c786: jbe      0x18000c7f3
0x18000c788: movabs   rdx, 0x400000000000
0x18000c792: test     qword ptr [rip - 0x4741], rdx
0x18000c799: je       0x18000c7f3
0x18000c79b: mov      rax, qword ptr [rip - 0x4742]
0x18000c7a2: and      rax, rdx
0x18000c7a5: cmp      rax, qword ptr [rip - 0x474c]
0x18000c7ac: jne      0x18000c7f3
0x18000c7ae: and      dword ptr [rbp - 0xc], 0
0x18000c7b2: lea      rax, [rbp - 0x48]
0x18000c7b6: mov      qword ptr [rbp - 0x18], rax
0x18000c7ba: lea      rdx, [rip - 0x5e0a]
0x18000c7c1: lea      rax, [rbp - 0x38]
0x18000c7c5: mov      qword ptr [rbp - 0x48], 0x800
0x18000c7cd: mov      qword ptr [rsp + 0x28], rax
0x18000c7d2: lea      rcx, [rip - 0x4791]
0x18000c7d9: xor      r9d, r9d
0x18000c7dc: mov      dword ptr [rsp + 0x20], 3
0x18000c7e4: xor      r8d, r8d
0x18000c7e7: mov      dword ptr [rbp - 0x10], 8
0x18000c7ee: call     0x18000112c
0x18000c7f3: test     rbx, rbx
0x18000c7f6: je       0x18000c807
0x18000c7f8: mov      rcx, rbx
0x18000c7fb: call     qword ptr [rip - 0x27c2]  ; -> ExReleaseResourceLite
0x18000c802: nop      dword ptr [rax + rax]
0x18000c807: mov      eax, 0xc000042a
0x18000c80c: jmp      0x18000c98b
0x18000c811: mov      eax, 0xe
0x18000c816: mov      ecx, r15d
0x18000c819: mov      word ptr [rbp - 0x40], ax
0x18000c81d: call     0x180001988
0x18000c822: mov      r9d, 2
0x18000c828: mov      word ptr [rbp - 0x3e], ax
0x18000c82c: lea      r8, [rbp - 0x40]
0x18000c830: mov      rdx, rsi
0x18000c833: lea      rcx, [rip - 0xb20a]
0x18000c83a: call     qword ptr [rip - 0x2811]
0x18000c841: nop      dword ptr [rax + rax]
0x18000c846: mov      qword ptr [rip - 0x465d], rax
0x18000c84d: mov      rcx, rax
0x18000c850: test     rax, rax
0x18000c853: jne      0x18000c8ea
0x18000c859: cmp      dword ptr [rip - 0x4818], 2
0x18000c860: jbe      0x18000c8cc
0x18000c862: movabs   rdx, 0x200000000000
0x18000c86c: test     qword ptr [rip - 0x481b], rdx
0x18000c873: je       0x18000c8cc
0x18000c875: mov      rax, qword ptr [rip - 0x481c]
0x18000c87c: and      rax, rdx
0x18000c87f: cmp      rax, qword ptr [rip - 0x4826]
0x18000c886: jne      0x18000c8cc
0x18000c888: and      dword ptr [rbp - 0xc], ecx
0x18000c88b: lea      rax, [rbp - 0x48]
0x18000c88f: mov      qword ptr [rbp - 0x18], rax
0x18000c893: lea      rdx, [rip - 0x5f21]
0x18000c89a: lea      rax, [rbp - 0x38]
0x18000c89e: mov      qword ptr [rbp - 0x48], 0x800
0x18000c8a6: mov      qword ptr [rsp + 0x28], rax
0x18000c8ab: lea      rcx, [rip - 0x486a]
0x18000c8b2: xor      r9d, r9d
0x18000c8b5: mov      dword ptr [rsp + 0x20], 3
0x18000c8bd: xor      r8d, r8d
0x18000c8c0: mov      dword ptr [rbp - 0x10], 8
0x18000c8c7: call     0x18000112c
0x18000c8cc: test     rbx, rbx
0x18000c8cf: je       0x18000c8e0
0x18000c8d1: mov      rcx, rbx
0x18000c8d4: call     qword ptr [rip - 0x289b]  ; -> ExReleaseResourceLite
0x18000c8db: nop      dword ptr [rax + rax]
0x18000c8e0: mov      eax, 0xc000009a
0x18000c8e5: jmp      0x18000c98b
0x18000c8ea: imul     rdx, rdi, -0x989680
0x18000c8f1: xor      r9d, r9d
0x18000c8f4: xor      r8d, r8d
0x18000c8f7: call     qword ptr [rip - 0x28c6]  ; -> ExSetTimer
0x18000c8fe: nop      dword ptr [rax + rax]
0x18000c903: lea      rcx, [rip - 0x4722]
0x18000c90a: call     0x18000133c
0x18000c90f: cmp      dword ptr [rip - 0x48ce], 4
0x18000c916: mov      word ptr [rip - 0x473a], r15w
0x18000c91e: mov      dword ptr [rip - 0x4744], edi
0x18000c924: jbe      0x18000c975
0x18000c926: movabs   rdx, 0x400000000000
0x18000c930: test     qword ptr [rip - 0x48df], rdx
0x18000c937: je       0x18000c975
0x18000c939: mov      rax, qword ptr [rip - 0x48e0]
0x18000c940: and      rax, rdx
0x18000c943: cmp      rax, qword ptr [rip - 0x48ea]
0x18000c94a: jne      0x18000c975
0x18000c94c: lea      rax, [rbp - 0x50]
0x18000c950: mov      dword ptr [rbp - 0x50], edi
0x18000c953: mov      qword ptr [rsp + 0x28], rax
0x18000c958: lea      rdx, [rip - 0x6027]
0x18000c95f: lea      rax, [rbp - 0x48]
0x18000c963: mov      qword ptr [rbp - 0x48], 0x800
0x18000c96b: mov      qword ptr [rsp + 0x20], rax
0x18000c970: call     0x1800010a4
0x18000c975: test     rbx, rbx
0x18000c978: je       0x18000c989
0x18000c97a: mov      rcx, rbx
0x18000c97d: call     qword ptr [rip - 0x2944]  ; -> ExReleaseResourceLite
0x18000c984: nop      dword ptr [rax + rax]
0x18000c989: xor      eax, eax
0x18000c98b: mov      rcx, qword ptr [rbp - 8]
0x18000c98f: xor      rcx, rsp
0x18000c992: call     0x1800041a0
0x18000c997: lea      r11, [rsp + 0x80]
0x18000c99f: mov      rbx, qword ptr [r11 + 0x30]
0x18000c9a3: mov      rsi, qword ptr [r11 + 0x38]
0x18000c9a7: mov      rsp, r11
0x18000c9aa: pop      r15
0x18000c9ac: pop      rdi
0x18000c9ad: pop      rbp
0x18000c9ae: ret      
0x18000c9af: int3     
0x18000c9b0: int3     
0x18000c9b1: int3     
0x18000c9b2: int3     
0x18000c9b3: int3     
0x18000c9b4: int3     
0x18000c9b5: int3     
0x18000c9b6: int3     
0x18000c9b7: int3     
0x18000c9b8: int3     
0x18000c9b9: int3     
0x18000c9ba: int3     
0x18000c9bb: int3     
0x18000c9bc: int3     
0x18000c9bd: int3     
0x18000c9be: int3     
0x18000c9bf: int3     
0x18000c9c0: mov      qword ptr [rsp + 0x10], rbx
0x18000c9c5: push     rdi
0x18000c9c6: sub      rsp, 0x80
0x18000c9cd: mov      rax, qword ptr [rip - 0x48d4]
0x18000c9d4: xor      rax, rsp
0x18000c9d7: mov      qword ptr [rsp + 0x70], rax
0x18000c9dc: mov      rbx, qword ptr [rip - 0x47eb]
0x18000c9e3: mov      rdi, rcx
0x18000c9e6: cmp      qword ptr [rbx], 0
0x18000c9ea: jne      0x18000c9f1
0x18000c9ec: call     0x1800038ec
0x18000c9f1: mov      rcx, qword ptr [rbx]
0x18000c9f4: mov      dl, 1
0x18000c9f6: call     qword ptr [rip - 0x29f5]  ; -> ExAcquireResourceExclusiveLite
0x18000c9fd: nop      dword ptr [rax + rax]
0x18000ca02: mov      rcx, qword ptr [rip - 0x4831]
0x18000ca09: lea      rdx, [rip - 0x6750]
0x18000ca10: mov      rbx, qword ptr [rbx]
0x18000ca13: mov      r9d, 0x1f
0x18000ca19: mov      r8, rdi
0x18000ca1c: call     0x180001f1c
0x18000ca21: mov      edi, eax
0x18000ca23: test     eax, eax
0x18000ca25: js       0x18000cad2
0x18000ca2b: mov      ecx, dword ptr [rip - 0x4861]
0x18000ca31: inc      ecx
0x18000ca33: mov      dword ptr [rip - 0x4869], ecx
0x18000ca39: cmp      ecx, 1
0x18000ca3c: jne      0x18000ca4a
0x18000ca3e: lea      rcx, [rip - 0x487d]
0x18000ca45: call     0x18000133c
0x18000ca4a: cmp      dword ptr [rip - 0x4a09], 4
0x18000ca51: jbe      0x18000cb2e
0x18000ca57: movabs   rdx, 0x200000000000
0x18000ca61: test     qword ptr [rip - 0x4a10], rdx
0x18000ca68: je       0x18000cb2e
0x18000ca6e: mov      rax, qword ptr [rip - 0x4a15]
0x18000ca75: and      rax, rdx
0x18000ca78: cmp      rax, qword ptr [rip - 0x4a1f]
0x18000ca7f: jne      0x18000cb2e
0x18000ca85: and      dword ptr [rsp + 0x6c], 0
0x18000ca8a: lea      rax, [rsp + 0x30]
0x18000ca8f: mov      qword ptr [rsp + 0x60], rax
0x18000ca94: lea      rdx, [rip - 0x63e2]
0x18000ca9b: lea      rax, [rsp + 0x40]
0x18000caa0: mov      qword ptr [rsp + 0x30], 0x800
0x18000caa9: mov      qword ptr [rsp + 0x28], rax
0x18000caae: lea      rcx, [rip - 0x4a6d]
0x18000cab5: xor      r9d, r9d
0x18000cab8: mov      dword ptr [rsp + 0x20], 3
0x18000cac0: xor      r8d, r8d
0x18000cac3: mov      dword ptr [rsp + 0x68], 8
0x18000cacb: call     0x18000112c
0x18000cad0: jmp      0x18000cb2e
0x18000cad2: cmp      dword ptr [rip - 0x4a91], 2
0x18000cad9: jbe      0x18000cb2e
0x18000cadb: movabs   rdx, 0x200000000000
0x18000cae5: test     qword ptr [rip - 0x4a94], rdx
0x18000caec: je       0x18000cb2e
0x18000caee: mov      rax, qword ptr [rip - 0x4a95]
0x18000caf5: and      rax, rdx
0x18000caf8: cmp      rax, qword ptr [rip - 0x4a9f]
0x18000caff: jne      0x18000cb2e
0x18000cb01: lea      rax, [rsp + 0x30]
0x18000cb06: mov      dword ptr [rsp + 0x30], edi
0x18000cb0a: mov      qword ptr [rsp + 0x28], rax
0x18000cb0f: lea      rdx, [rip - 0x649d]
0x18000cb16: lea      rax, [rsp + 0x38]
0x18000cb1b: mov      qword ptr [rsp + 0x38], 0x800
0x18000cb24: mov      qword ptr [rsp + 0x20], rax
0x18000cb29: call     0x1800010a4
0x18000cb2e: test     rbx, rbx
0x18000cb31: je       0x18000cb42
0x18000cb33: mov      rcx, rbx
0x18000cb36: call     qword ptr [rip - 0x2afd]  ; -> ExReleaseResourceLite
0x18000cb3d: nop      dword ptr [rax + rax]
0x18000cb42: mov      eax, edi
0x18000cb44: mov      rcx, qword ptr [rsp + 0x70]
0x18000cb49: xor      rcx, rsp
0x18000cb4c: call     0x1800041a0
0x18000cb51: mov      rbx, qword ptr [rsp + 0x98]
0x18000cb59: add      rsp, 0x80
0x18000cb60: pop      rdi
0x18000cb61: ret      
0x18000cb62: int3     
0x18000cb63: int3     
0x18000cb64: int3     
0x18000cb65: int3     
0x18000cb66: int3     
0x18000cb67: int3     
0x18000cb68: int3     
0x18000cb69: int3     
0x18000cb6a: int3     
0x18000cb6b: int3     
0x18000cb6c: int3     
0x18000cb6d: int3     
0x18000cb6e: int3     
0x18000cb6f: int3     
0x18000cb70: mov      r11, rsp
0x18000cb73: mov      qword ptr [r11 + 0x18], rbx
0x18000cb77: mov      qword ptr [r11 + 0x20], rsi
0x18000cb7b: push     rbp
0x18000cb7c: push     rdi
0x18000cb7d: push     r14
0x18000cb7f: mov      rbp, rsp
0x18000cb82: sub      rsp, 0x80
0x18000cb89: mov      rax, qword ptr [rip - 0x4a90]
0x18000cb90: xor      rax, rsp
0x18000cb93: mov      qword ptr [rbp - 8], rax
0x18000cb97: mov      esi, ecx
0x18000cb99: mov      r14, rdx
0x18000cb9c: cmp      ecx, 0x1e
0x18000cb9f: jae      0x18000cc05
0x18000cba1: mov      edi, 2
0x18000cba6: cmp      dword ptr [rip - 0x4b64], edi
0x18000cbac: jbe      0x18000cbfb
0x18000cbae: movabs   rdx, 0x200000000000
0x18000cbb8: test     qword ptr [rip - 0x4b67], rdx
0x18000cbbf: je       0x18000cbfb
0x18000cbc1: mov      rax, qword ptr [rip - 0x4b68]
0x18000cbc8: and      rax, rdx
0x18000cbcb: cmp      rax, qword ptr [rip - 0x4b72]
0x18000cbd2: jne      0x18000cbfb
0x18000cbd4: lea      rax, [rbp - 0x50]
0x18000cbd8: mov      dword ptr [rbp - 0x50], esi
0x18000cbdb: mov      qword ptr [r11 - 0x70], rax
0x18000cbdf: lea      rdx, [rip - 0x639f]
0x18000cbe6: lea      rax, [rbp - 0x48]
0x18000cbea: mov      qword ptr [rbp - 0x48], 0x800
0x18000cbf2: mov      qword ptr [r11 - 0x78], rax
0x18000cbf6: call     0x1800010a4
0x18000cbfb: mov      eax, 0xc000000d
0x18000cc00: jmp      0x18000ce43
0x18000cc05: mov      rbx, qword ptr [rip - 0x4a14]
0x18000cc0c: cmp      qword ptr [rbx], 0
0x18000cc10: jne      0x18000cc17
0x18000cc12: call     0x1800038ec
0x18000cc17: mov      rcx, qword ptr [rbx]
0x18000cc1a: mov      dl, 1
0x18000cc1c: call     qword ptr [rip - 0x2c1b]  ; -> ExAcquireResourceExclusiveLite
0x18000cc23: nop      dword ptr [rax + rax]
0x18000cc28: cmp      qword ptr [rip - 0x4a40], 0
0x18000cc30: mov      edi, 2
0x18000cc35: mov      rbx, qword ptr [rbx]
0x18000cc38: je       0x18000cccf
0x18000cc3e: cmp      dword ptr [rip - 0x4bfc], edi
0x18000cc44: jbe      0x18000ccb1
0x18000cc46: movabs   rdx, 0x400000000000
0x18000cc50: test     qword ptr [rip - 0x4bff], rdx
0x18000cc57: je       0x18000ccb1
0x18000cc59: mov      rax, qword ptr [rip - 0x4c00]
0x18000cc60: and      rax, rdx
0x18000cc63: cmp      rax, qword ptr [rip - 0x4c0a]
0x18000cc6a: jne      0x18000ccb1
0x18000cc6c: and      dword ptr [rbp - 0xc], 0
0x18000cc70: lea      rax, [rbp - 0x48]
0x18000cc74: mov      qword ptr [rbp - 0x18], rax
0x18000cc78: lea      rdx, [rip - 0x6471]
0x18000cc7f: lea      rax, [rbp - 0x38]
0x18000cc83: mov      qword ptr [rbp - 0x48], 0x800
0x18000cc8b: mov      qword ptr [rsp + 0x28], rax
0x18000cc90: lea      rcx, [rip - 0x4c4f]
0x18000cc97: xor      r9d, r9d
0x18000cc9a: mov      dword ptr [rsp + 0x20], 3
0x18000cca2: xor      r8d, r8d
0x18000cca5: mov      dword ptr [rbp - 0x10], 8
0x18000ccac: call     0x18000112c
0x18000ccb1: test     rbx, rbx
0x18000ccb4: je       0x18000ccc5
0x18000ccb6: mov      rcx, rbx
0x18000ccb9: call     qword ptr [rip - 0x2c80]  ; -> ExReleaseResourceLite
0x18000ccc0: nop      dword ptr [rax + rax]
0x18000ccc5: mov      eax, 0xc000042a
0x18000ccca: jmp      0x18000ce43
0x18000cccf: mov      eax, 0xe
0x18000ccd4: mov      ecx, edi
0x18000ccd6: mov      word ptr [rbp - 0x40], ax
0x18000ccda: call     0x180001988
0x18000ccdf: mov      r9d, edi
0x18000cce2: mov      word ptr [rbp - 0x3e], ax
0x18000cce6: lea      r8, [rbp - 0x40]
0x18000ccea: mov      rdx, r14
0x18000cced: lea      rcx, [rip - 0xb514]
0x18000ccf4: call     qword ptr [rip - 0x2ccb]
0x18000ccfb: nop      dword ptr [rax + rax]
0x18000cd00: mov      qword ptr [rip - 0x4b17], rax
0x18000cd07: mov      rcx, rax
0x18000cd0a: test     rax, rax
0x18000cd0d: jne      0x18000cda3
0x18000cd13: cmp      dword ptr [rip - 0x4cd1], edi
0x18000cd19: jbe      0x18000cd85
0x18000cd1b: movabs   rdx, 0x200000000000
0x18000cd25: test     qword ptr [rip - 0x4cd4], rdx
0x18000cd2c: je       0x18000cd85
0x18000cd2e: mov      rax, qword ptr [rip - 0x4cd5]
0x18000cd35: and      rax, rdx
0x18000cd38: cmp      rax, qword ptr [rip - 0x4cdf]
0x18000cd3f: jne      0x18000cd85
0x18000cd41: and      dword ptr [rbp - 0xc], ecx
0x18000cd44: lea      rax, [rbp - 0x48]
0x18000cd48: mov      qword ptr [rbp - 0x18], rax
0x18000cd4c: lea      rdx, [rip - 0x6582]
0x18000cd53: lea      rax, [rbp - 0x38]
0x18000cd57: mov      qword ptr [rbp - 0x48], 0x800
0x18000cd5f: mov      qword ptr [rsp + 0x28], rax
0x18000cd64: lea      rcx, [rip - 0x4d23]
0x18000cd6b: xor      r9d, r9d
0x18000cd6e: mov      dword ptr [rsp + 0x20], 3
0x18000cd76: xor      r8d, r8d
0x18000cd79: mov      dword ptr [rbp - 0x10], 8
0x18000cd80: call     0x18000112c
0x18000cd85: test     rbx, rbx
0x18000cd88: je       0x18000cd99
0x18000cd8a: mov      rcx, rbx
0x18000cd8d: call     qword ptr [rip - 0x2d54]  ; -> ExReleaseResourceLite
0x18000cd94: nop      dword ptr [rax + rax]
0x18000cd99: mov      eax, 0xc000009a
0x18000cd9e: jmp      0x18000ce43
0x18000cda3: imul     rdx, rsi, -0x989680
0x18000cdaa: xor      r9d, r9d
0x18000cdad: xor      r8d, r8d
0x18000cdb0: call     qword ptr [rip - 0x2d7f]  ; -> ExSetTimer
0x18000cdb7: nop      dword ptr [rax + rax]
0x18000cdbc: lea      rcx, [rip - 0x4bdb]
0x18000cdc3: call     0x18000133c
0x18000cdc8: cmp      dword ptr [rip - 0x4d87], 4
0x18000cdcf: mov      word ptr [rip - 0x4bf2], di
0x18000cdd6: mov      dword ptr [rip - 0x4bfc], esi
0x18000cddc: jbe      0x18000ce2d
0x18000cdde: movabs   rdx, 0x400000000000
0x18000cde8: test     qword ptr [rip - 0x4d97], rdx
0x18000cdef: je       0x18000ce2d
0x18000cdf1: mov      rax, qword ptr [rip - 0x4d98]
0x18000cdf8: and      rax, rdx
0x18000cdfb: cmp      rax, qword ptr [rip - 0x4da2]
0x18000ce02: jne      0x18000ce2d
0x18000ce04: lea      rax, [rbp - 0x50]
0x18000ce08: mov      dword ptr [rbp - 0x50], esi
0x18000ce0b: mov      qword ptr [rsp + 0x28], rax
0x18000ce10: lea      rdx, [rip - 0x6686]
0x18000ce17: lea      rax, [rbp - 0x48]
0x18000ce1b: mov      qword ptr [rbp - 0x48], 0x800
0x18000ce23: mov      qword ptr [rsp + 0x20], rax
0x18000ce28: call     0x1800010a4
0x18000ce2d: test     rbx, rbx
0x18000ce30: je       0x18000ce41
0x18000ce32: mov      rcx, rbx
0x18000ce35: call     qword ptr [rip - 0x2dfc]  ; -> ExReleaseResourceLite
0x18000ce3c: nop      dword ptr [rax + rax]
0x18000ce41: xor      eax, eax
0x18000ce43: mov      rcx, qword ptr [rbp - 8]
0x18000ce47: xor      rcx, rsp
0x18000ce4a: call     0x1800041a0
0x18000ce4f: lea      r11, [rsp + 0x80]
0x18000ce57: mov      rbx, qword ptr [r11 + 0x30]
0x18000ce5b: mov      rsi, qword ptr [r11 + 0x38]
0x18000ce5f: mov      rsp, r11
0x18000ce62: pop      r14
0x18000ce64: pop      rdi
0x18000ce65: pop      rbp
0x18000ce66: ret      
0x18000ce67: int3     
0x18000ce68: int3     
0x18000ce69: int3     
0x18000ce6a: int3     
0x18000ce6b: int3     
0x18000ce6c: int3     
0x18000ce6d: int3     
0x18000ce6e: int3     
0x18000ce6f: int3     
0x18000ce70: mov      qword ptr [rsp + 8], rbx
0x18000ce75: push     rdi
0x18000ce76: sub      rsp, 0x20
0x18000ce7a: and      qword ptr [rsp + 0x40], 0
0x18000ce80: mov      ebx, edx
0x18000ce82: mov      rdi, rcx
0x18000ce85: call     0x180002068
0x18000ce8a: cmp      ebx, -3
0x18000ce8d: je       0x18000cebb
0x18000ce8f: cmp      ebx, -2
0x18000ce92: je       0x18000ceb4
0x18000ce94: cmp      ebx, -1
0x18000ce97: je       0x18000cead
0x18000ce99: lea      eax, [rbx - 0x1f4]
0x18000ce9f: cmp      eax, 0x733c
0x18000cea4: jbe      0x18000cec0
0x18000cea6: mov      edi, 0xc000000d
0x18000ceab: jmp      0x18000cee6
0x18000cead: mov      ebx, 0xbb8
0x18000ceb2: jmp      0x18000cec0
0x18000ceb4: mov      ebx, 0x1f4
0x18000ceb9: jmp      0x18000cec0
0x18000cebb: mov      ebx, 0x7530
0x18000cec0: lea      rdx, [rsp + 0x40]
0x18000cec5: mov      rcx, rdi
0x18000cec8: call     0x180002450
0x18000cecd: mov      edi, eax
0x18000cecf: test     eax, eax
0x18000ced1: js       0x18000cee6
0x18000ced3: mov      rcx, qword ptr [rsp + 0x40]
0x18000ced8: test     rcx, rcx
0x18000cedb: je       0x18000cee6
0x18000cedd: mov      edx, ebx
0x18000cedf: call     0x180002090
0x18000cee4: mov      edi, eax
0x18000cee6: call     0x18000269c
0x18000ceeb: test     byte ptr [rip - 0x4d32], 1
0x18000cef2: je       0x18000cf03
0x18000cef4: mov      r9d, edi
0x18000cef7: lea      rdx, [rip - 0x6d7e]
0x18000cefe: call     0x180001eb0
0x18000cf03: mov      rbx, qword ptr [rsp + 0x30]
0x18000cf08: mov      eax, edi
0x18000cf0a: add      rsp, 0x20
0x18000cf0e: pop      rdi
0x18000cf0f: ret      
0x18000cf10: int3     
0x18000cf11: int3     
0x18000cf12: int3     
0x18000cf13: int3     
0x18000cf14: int3     
0x18000cf15: int3     
0x18000cf16: int3     
0x18000cf17: int3     
0x18000cf18: int3     
0x18000cf19: int3     
0x18000cf1a: int3     
0x18000cf1b: int3     
0x18000cf1c: int3     
0x18000cf1d: int3     
0x18000cf1e: int3     
0x18000cf1f: int3     
0x18000cf20: mov      qword ptr [rsp + 8], rbx
0x18000cf25: push     rdi
0x18000cf26: sub      rsp, 0x20
0x18000cf2a: mov      rdi, rdx
0x18000cf2d: mov      ebx, ecx
0x18000cf2f: call     0x180002068
0x18000cf34: test     ebx, ebx
0x18000cf36: je       0x18000cf3f
0x18000cf38: mov      ebx, 0xc0000002
0x18000cf3d: jmp      0x18000cf49
0x18000cf3f: mov      rcx, rdi
0x18000cf42: call     0x180002250
0x18000cf47: mov      ebx, eax
0x18000cf49: call     0x18000269c
0x18000cf4e: test     byte ptr [rip - 0x4d95], 1
0x18000cf55: je       0x18000cf66
0x18000cf57: mov      r9d, ebx
0x18000cf5a: lea      rdx, [rip - 0x6d51]
0x18000cf61: call     0x180001eb0
0x18000cf66: mov      eax, ebx
0x18000cf68: mov      rbx, qword ptr [rsp + 0x30]
0x18000cf6d: add      rsp, 0x20
0x18000cf71: pop      rdi
0x18000cf72: ret      
0x18000cf73: int3     
0x18000cf74: int3     
0x18000cf75: int3     
0x18000cf76: int3     
0x18000cf77: int3     
0x18000cf78: int3     
0x18000cf79: int3     
0x18000cf7a: int3     
0x18000cf7b: int3     
0x18000cf7c: int3     
0x18000cf7d: int3     
0x18000cf7e: int3     
0x18000cf7f: int3     
0x18000cf80: push     rbx
0x18000cf82: sub      rsp, 0x20
0x18000cf86: and      qword ptr [rsp + 0x38], 0
0x18000cf8c: mov      rbx, rcx
0x18000cf8f: call     0x180002068
0x18000cf94: lea      rdx, [rsp + 0x38]
0x18000cf99: mov      rcx, rbx
0x18000cf9c: call     0x180002450
0x18000cfa1: mov      ebx, eax
0x18000cfa3: test     eax, eax
0x18000cfa5: js       0x18000cfb8
0x18000cfa7: mov      rcx, qword ptr [rsp + 0x38]
0x18000cfac: test     rcx, rcx
0x18000cfaf: je       0x18000cfb8
0x18000cfb1: call     0x180002388
0x18000cfb6: mov      ebx, eax
0x18000cfb8: call     0x18000269c
0x18000cfbd: test     byte ptr [rip - 0x4e04], 1
0x18000cfc4: je       0x18000cfd5
0x18000cfc6: mov      r9d, ebx
0x18000cfc9: lea      rdx, [rip - 0x6db0]
0x18000cfd0: call     0x180001eb0
0x18000cfd5: mov      eax, ebx
0x18000cfd7: add      rsp, 0x20
0x18000cfdb: pop      rbx
0x18000cfdc: ret      
0x18000cfdd: int3     
0x18000cfde: int3     
0x18000cfdf: int3     
0x18000cfe0: int3     
0x18000cfe1: int3     
0x18000cfe2: int3     
0x18000cfe3: int3     
0x18000cfe4: mov      qword ptr [rsp + 0x10], rbx
0x18000cfe9: mov      qword ptr [rsp + 0x18], rsi
0x18000cfee: push     rdi
0x18000cfef: sub      rsp, 0x40
0x18000cff3: mov      rax, qword ptr [rip - 0x4efa]
0x18000cffa: xor      rax, rsp
0x18000cffd: mov      qword ptr [rsp + 0x30], rax
0x18000d002: mov      rax, qword ptr [rcx + 8]
0x18000d006: lea      rsi, [rcx + 0x20]
0x18000d00a: cmp      qword ptr [rsi], 0
0x18000d00e: mov      rbx, rcx
0x18000d011: movups   xmm0, xmmword ptr [rax - 0x10]
0x18000d015: movdqu   xmmword ptr [rsp + 0x20], xmm0
0x18000d01b: je       0x18000d024
0x18000d01d: mov      ecx, 5
0x18000d022: int      0x29
0x18000d024: and      qword ptr [rbx + 0x28], 0
0x18000d029: lea      rdx, [rip + 0x70]
0x18000d030: and      qword ptr [rbx + 0x30], 0
0x18000d035: lea      rcx, [rsp + 0x20]
0x18000d03a: mov      r9, rsi
0x18000d03d: mov      r8, rbx
0x18000d040: call     qword ptr [rip - 0x2fe7]  ; -> EtwRegister
0x18000d047: nop      dword ptr [rax + rax]
0x18000d04c: mov      edi, eax
0x18000d04e: test     eax, eax
0x18000d050: jne      0x18000d06c
0x18000d052: mov      r8, qword ptr [rbx + 8]
0x18000d056: lea      edx, [rax + 2]
0x18000d059: mov      rcx, qword ptr [rsi]
0x18000d05c: movzx    r9d, word ptr [r8]
0x18000d060: call     qword ptr [rip - 0x2fff]  ; -> EtwSetInformation
0x18000d067: nop      dword ptr [rax + rax]
0x18000d06c: mov      eax, edi
0x18000d06e: mov      rcx, qword ptr [rsp + 0x30]
0x18000d073: xor      rcx, rsp
0x18000d076: call     0x1800041a0
0x18000d07b: mov      rbx, qword ptr [rsp + 0x58]
0x18000d080: mov      rsi, qword ptr [rsp + 0x60]
0x18000d085: add      rsp, 0x40
0x18000d089: pop      rdi
0x18000d08a: ret      
0x18000d08b: int3     
0x18000d08c: int3     
0x18000d08d: int3     
0x18000d08e: int3     
0x18000d08f: int3     
0x18000d090: int3     
0x18000d091: int3     
0x18000d092: int3     
0x18000d093: int3     
0x18000d094: int3     
0x18000d095: int3     
0x18000d096: int3     
0x18000d097: int3     
0x18000d098: int3     
0x18000d099: int3     
0x18000d09a: int3     
0x18000d09b: int3     
0x18000d09c: int3     
0x18000d09d: int3     
0x18000d09e: int3     
0x18000d09f: int3     
0x18000d0a0: sub      rsp, 0x48
0x18000d0a4: mov      r11, rcx
0x18000d0a7: mov      rcx, qword ptr [rsp + 0x80]
0x18000d0af: test     rcx, rcx
0x18000d0b2: je       0x18000d10e
0x18000d0b4: mov      r10, qword ptr [rsp + 0x70]
0x18000d0b9: mov      eax, edx
0x18000d0bb: test     edx, edx
0x18000d0bd: je       0x18000d0e2
0x18000d0bf: cmp      eax, 1
0x18000d0c2: jne      0x18000d0e5
0x18000d0c4: test     r8b, r8b
0x18000d0c7: je       0x18000d0d1
0x18000d0c9: movzx    eax, r8b
0x18000d0cd: inc      eax
0x18000d0cf: jmp      0x18000d0d6
0x18000d0d1: mov      eax, 0x100
0x18000d0d6: mov      dword ptr [rcx], eax
0x18000d0d8: mov      qword ptr [rcx + 0x10], r9
0x18000d0dc: mov      qword ptr [rcx + 0x18], r10
0x18000d0e0: jmp      0x18000d0e5
0x18000d0e2: and      dword ptr [rcx], 0
0x18000d0e5: mov      rax, qword ptr [rcx + 0x28]
0x18000d0e9: test     rax, rax
0x18000d0ec: je       0x18000d10e
0x18000d0ee: mov      rcx, qword ptr [rcx + 0x30]
0x18000d0f2: mov      qword ptr [rsp + 0x30], rcx
0x18000d0f7: mov      rcx, qword ptr [rsp + 0x78]
0x18000d0fc: mov      qword ptr [rsp + 0x28], rcx
0x18000d101: mov      rcx, r11
0x18000d104: mov      qword ptr [rsp + 0x20], r10
0x18000d109: call     0x1800041e0
0x18000d10e: add      rsp, 0x48
0x18000d112: ret      
0x18000d113: int3     
0x18000d114: int3     
0x18000d115: int3     
0x18000d116: int3     
0x18000d117: int3     
0x18000d118: int3     
0x18000d119: int3     
0x18000d11a: int3     
0x18000d11b: int3     
0x18000d11c: mov      rax, rsp
0x18000d11f: mov      qword ptr [rax + 8], rbx
0x18000d123: mov      dword ptr [rax + 0x20], r9d
0x18000d127: mov      qword ptr [rax + 0x18], r8
0x18000d12b: push     rbp
0x18000d12c: push     rsi
0x18000d12d: push     rdi
0x18000d12e: push     r12
0x18000d130: push     r13
0x18000d132: push     r14
0x18000d134: push     r15
0x18000d136: lea      rbp, [rax - 0x278]
0x18000d13d: sub      rsp, 0x340
0x18000d144: mov      rbx, rdx
0x18000d147: mov      rsi, rcx
0x18000d14a: xor      edx, edx
0x18000d14c: lea      rcx, [rsp + 0x20]
0x18000d151: mov      r8d, 0x320
0x18000d157: call     0x1800045c0
0x18000d15c: mov      r13, qword ptr [rbp + 0x2b8]
0x18000d163: xor      r15d, r15d
0x18000d166: mov      qword ptr [rbp + 0x290], r15
0x18000d16d: mov      r14d, r15d
0x18000d170: mov      byte ptr [rbp + 0x298], r15b
0x18000d177: test     r13, r13
0x18000d17a: jne      0x18000d186
0x18000d17c: mov      ebx, 0xc00000f6
0x18000d181: jmp      0x18000d49a
0x18000d186: mov      r12, qword ptr [rbp + 0x2b0]
0x18000d18d: mov      dword ptr [r13], 1
0x18000d195: test     r12, r12
0x18000d198: jne      0x18000d1a4
0x18000d19a: mov      ebx, 0xc00000f5
0x18000d19f: jmp      0x18000d49a
0x18000d1a4: mov      qword ptr [r12], r15
0x18000d1a8: test     rsi, rsi
0x18000d1ab: jne      0x18000d1b7
0x18000d1ad: mov      ebx, 0xc00000ef
0x18000d1b2: jmp      0x18000d49a
0x18000d1b7: cmp      dword ptr [rsi], 0x32414450
0x18000d1bd: mov      r14, rsi
0x18000d1c0: je       0x18000d1c7
0x18000d1c2: mov      r14, r15
0x18000d1c5: jmp      0x18000d1ad
0x18000d1c7: mov      rcx, rbx
0x18000d1ca: call     0x18000dc20
0x18000d1cf: test     al, al
0x18000d1d1: jne      0x18000d1dd
0x18000d1d3: mov      ebx, 0xc00000f0
0x18000d1d8: jmp      0x18000d49a
0x18000d1dd: mov      rcx, rbx
0x18000d1e0: call     0x180002824
0x18000d1e5: test     al, al
0x18000d1e7: je       0x18000d1d3
0x18000d1e9: mov      r15, qword ptr [rbp + 0x2a0]
0x18000d1f0: xor      edi, edi
0x18000d1f2: test     r15, r15
0x18000d1f5: jne      0x18000d204
0x18000d1f7: mov      ebx, 0xc00000f3
0x18000d1fc: xor      r15d, r15d
0x18000d1ff: jmp      0x18000d49a
0x18000d204: lea      rcx, [rsi + 8]
0x18000d208: lea      rdx, [rbp + 0x298]
0x18000d20f: call     0x18000df2c
0x18000d214: cmp      qword ptr [rsi + 0x28], rdi
0x18000d218: jne      0x18000d221
0x18000d21a: mov      ebx, 0xc0000700
0x18000d21f: jmp      0x18000d1fc
0x18000d221: mov      edx, 0x258
0x18000d226: mov      ecx, 0x100
0x18000d22b: mov      r8d, 0x41434450
0x18000d231: call     qword ptr [rip - 0x31e8]  ; -> ExAllocatePool2
0x18000d238: nop      dword ptr [rax + rax]
0x18000d23d: xor      r10d, r10d
0x18000d240: mov      rdi, rax
0x18000d243: test     rax, rax
0x18000d246: jne      0x18000d24f
0x18000d248: mov      ebx, 0xc0000017
0x18000d24d: jmp      0x18000d1fc
0x18000d24f: mov      dword ptr [rax + 0x10], 0x41434450
0x18000d256: mov      r9d, 0x80
0x18000d25c: mov      dword ptr [rax + 0x14], 1
0x18000d263: mov      r8, r15
0x18000d266: mov      qword ptr [rax + 0x18], rsi
0x18000d26a: movabs   rax, 0xfffff78000000004
0x18000d274: mov      ecx, dword ptr [rax]
0x18000d276: movabs   rax, 0xfffff78000000320
0x18000d280: shl      rcx, 0x20
0x18000d284: mov      rax, qword ptr [rax]
0x18000d287: mov      r11d, dword ptr [rbx + 4]
0x18000d28b: shl      rax, 8
0x18000d28f: mul      rcx
0x18000d292: lea      rcx, [rdi + 0x48]
0x18000d296: mov      dword ptr [rdi + 0x30], r10d
0x18000d29a: mov      qword ptr [rdi + 0x28], rdx
0x18000d29e: sub      r8, rcx
0x18000d2a1: mov      edx, r9d
0x18000d2a4: mov      qword ptr [rdi + 0x20], r10
0x18000d2a8: mov      dword ptr [rdi + 0x34], r11d
0x18000d2ac: lea      rax, [rdx + 0x7fffff7e]
0x18000d2b3: test     rax, rax
0x18000d2b6: je       0x18000d2cf
0x18000d2b8: movzx    eax, word ptr [r8 + rcx]
0x18000d2bd: test     ax, ax
0x18000d2c0: je       0x18000d2cf
0x18000d2c2: mov      word ptr [rcx], ax
0x18000d2c5: add      rcx, 2
0x18000d2c9: sub      rdx, 1
0x18000d2cd: jne      0x18000d2ac
0x18000d2cf: test     rdx, rdx
0x18000d2d2: lea      rax, [rcx - 2]
0x18000d2d6: mov      rdx, qword ptr [rbx + 0x10]
0x18000d2da: cmovne   rax, rcx
0x18000d2de: mov      word ptr [rax], r10w
0x18000d2e2: test     rdx, rdx
0x18000d2e5: je       0x18000d330
0x18000d2e7: lea      rcx, [rdi + 0x148]
0x18000d2ee: mov      r10, rdx
0x18000d2f1: sub      r10, rcx
0x18000d2f4: mov      r8, r9
0x18000d2f7: lea      rax, [r8 + 0x7fffff7e]
0x18000d2fe: test     rax, rax
0x18000d301: je       0x18000d31e
0x18000d303: movzx    eax, word ptr [r10 + rcx]
0x18000d308: cmp      ax, word ptr [rbp + 0x290]
0x18000d30f: je       0x18000d31e
0x18000d311: mov      word ptr [rcx], ax
0x18000d314: add      rcx, 2
0x18000d318: sub      r8, 1
0x18000d31c: jne      0x18000d2f7
0x18000d31e: xor      r10d, r10d
0x18000d321: lea      rax, [rcx - 2]
0x18000d325: test     r8, r8
0x18000d328: cmovne   rax, rcx
0x18000d32c: mov      word ptr [rax], r10w
0x18000d330: mov      rax, qword ptr [rbx + 8]
0x18000d334: lea      rcx, [rbp - 0x80]
0x18000d338: mov      qword ptr [rsp + 0x70], rax
0x18000d33d: mov      r8, r9
0x18000d340: lea      rax, [rbp - 0x80]
0x18000d344: mov      dword ptr [rsp + 0x48], 0xa
0x18000d34c: sub      r15, rax
0x18000d34f: mov      dword ptr [rsp + 0x68], r10d
0x18000d354: mov      dword ptr [rsp + 0x78], r10d
0x18000d359: mov      dword ptr [rsp + 0x7c], r11d
0x18000d35e: lea      rax, [r8 + 0x7fffff7e]
0x18000d365: test     rax, rax
0x18000d368: je       0x18000d381
0x18000d36a: movzx    eax, word ptr [rcx + r15]
0x18000d36f: test     ax, ax
0x18000d372: je       0x18000d381
0x18000d374: mov      word ptr [rcx], ax
0x18000d377: add      rcx, 2
0x18000d37b: sub      r8, 1
0x18000d37f: jne      0x18000d35e
0x18000d381: xor      r15d, r15d
0x18000d384: lea      rax, [rcx - 2]
0x18000d388: test     r8, r8
0x18000d38b: cmovne   rax, rcx
0x18000d38f: mov      word ptr [rax], r15w
0x18000d393: test     rdx, rdx
0x18000d396: je       0x18000d3da
0x18000d398: lea      rax, [rbp + 0x80]
0x18000d39f: sub      rdx, rax
0x18000d3a2: lea      rcx, [rbp + 0x80]
0x18000d3a9: lea      rax, [r9 + 0x7fffff7e]
0x18000d3b0: test     rax, rax
0x18000d3b3: je       0x18000d3cb
0x18000d3b5: movzx    eax, word ptr [rcx + rdx]
0x18000d3b9: test     ax, ax
0x18000d3bc: je       0x18000d3cb
0x18000d3be: mov      word ptr [rcx], ax
0x18000d3c1: add      rcx, 2
0x18000d3c5: sub      r9, 1
0x18000d3c9: jne      0x18000d3a9
0x18000d3cb: test     r9, r9
0x18000d3ce: lea      rax, [rcx - 2]
0x18000d3d2: cmovne   rax, rcx
0x18000d3d6: mov      word ptr [rax], r15w
0x18000d3da: mov      rcx, qword ptr [rbx + 0x18]
0x18000d3de: test     rcx, rcx
0x18000d3e1: je       0x18000d3ef
0x18000d3e3: lea      rdx, [rbp + 0x198]
0x18000d3ea: call     0x1800027e4
0x18000d3ef: mov      rcx, qword ptr [rsi + 0x28]
0x18000d3f3: lea      rdx, [rsp + 0x20]
0x18000d3f8: call     0x180002854
0x18000d3fd: mov      ebx, eax
0x18000d3ff: test     eax, eax
0x18000d401: js       0x18000d489
0x18000d407: mov      ebx, dword ptr [rsp + 0x58]
0x18000d40b: mov      ecx, dword ptr [rsp + 0x5c]
0x18000d40f: mov      dword ptr [r13], ecx
0x18000d413: test     ebx, ebx
0x18000d415: js       0x18000d472
0x18000d417: cmp      ecx, 0x12c
0x18000d41d: je       0x18000d472
0x18000d41f: inc      dword ptr [rsi + 0xf8]
0x18000d425: inc      dword ptr [rsi + 0xfc]
0x18000d42b: mov      rax, qword ptr [rsp + 0x60]
0x18000d430: inc      dword ptr [rsi + 0x100]
0x18000d436: mov      qword ptr [rdi + 0x250], rax
0x18000d43d: lea      rax, [rsi + 0x50]
0x18000d441: mov      dword ptr [rdi + 0x38], ecx
0x18000d444: mov      rcx, qword ptr [rax + 8]
0x18000d448: mov      byte ptr [rdi + 0x3c], r15b
0x18000d44c: cmp      qword ptr [rcx], rax
0x18000d44f: je       0x18000d458
0x18000d451: mov      ecx, 3
0x18000d456: int      0x29
0x18000d458: mov      qword ptr [rdi + 8], rcx
0x18000d45c: mov      rdx, rsi
0x18000d45f: mov      qword ptr [rdi], rax
0x18000d462: mov      qword ptr [rcx], rdi
0x18000d465: mov      rcx, rdi
0x18000d468: mov      qword ptr [rax + 8], rdi
0x18000d46c: mov      qword ptr [r12], rdi
0x18000d470: jmp      0x18000d49f
0x18000d472: xor      edx, edx
0x18000d474: mov      rcx, rdi
0x18000d477: call     qword ptr [rip - 0x3426]  ; -> ExFreePoolWithTag
0x18000d47e: nop      dword ptr [rax + rax]
0x18000d483: test     ebx, ebx
0x18000d485: jns      0x18000d4a7
0x18000d487: jmp      0x18000d49a
0x18000d489: xor      edx, edx
0x18000d48b: mov      rcx, rdi
0x18000d48e: call     qword ptr [rip - 0x343d]  ; -> ExFreePoolWithTag
0x18000d495: nop      dword ptr [rax + rax]
0x18000d49a: mov      rdx, r14
0x18000d49d: xor      ecx, ecx
0x18000d49f: mov      r8d, ebx
0x18000d4a2: call     0x180002ed4
0x18000d4a7: cmp      byte ptr [rbp + 0x298], r15b
0x18000d4ae: je       0x18000d4c0
0x18000d4b0: lea      rcx, [r14 + 8]
0x18000d4b4: lea      rdx, [rbp + 0x298]
0x18000d4bb: call     0x18000dfd8
0x18000d4c0: mov      eax, ebx
0x18000d4c2: mov      rbx, qword ptr [rsp + 0x380]
0x18000d4ca: add      rsp, 0x340
0x18000d4d1: pop      r15
0x18000d4d3: pop      r14
0x18000d4d5: pop      r13
0x18000d4d7: pop      r12
0x18000d4d9: pop      rdi
0x18000d4da: pop      rsi
0x18000d4db: pop      rbp
0x18000d4dc: ret      
0x18000d4dd: int3     
0x18000d4de: int3     
0x18000d4df: int3     
0x18000d4e0: int3     
0x18000d4e1: int3     
0x18000d4e2: int3     
0x18000d4e3: int3     
0x18000d4e4: mov      qword ptr [rsp + 0x10], rbx
0x18000d4e9: mov      qword ptr [rsp + 0x18], rbp
0x18000d4ee: mov      qword ptr [rsp + 0x20], rsi
0x18000d4f3: push     rdi
0x18000d4f4: sub      rsp, 0x350
0x18000d4fb: mov      rsi, rcx
0x18000d4fe: xor      edx, edx
0x18000d500: lea      rcx, [rsp + 0x30]
0x18000d505: mov      r8d, 0x320
0x18000d50b: call     0x1800045c0
0x18000d510: xor      ebp, ebp
0x18000d512: mov      byte ptr [rsp + 0x360], 0
0x18000d51a: xor      edi, edi
0x18000d51c: test     rsi, rsi
0x18000d51f: jne      0x18000d56b
0x18000d521: mov      ebx, 0xc00000ef
0x18000d526: mov      r8d, ebx
0x18000d529: mov      rdx, rdi
0x18000d52c: mov      rcx, rbp
0x18000d52f: call     0x1800032e0
0x18000d534: cmp      byte ptr [rsp + 0x360], 0
0x18000d53c: je       0x18000d54f
0x18000d53e: lea      rcx, [rdi + 8]
0x18000d542: lea      rdx, [rsp + 0x360]
0x18000d54a: call     0x18000dfd8
0x18000d54f: lea      r11, [rsp + 0x350]
0x18000d557: mov      eax, ebx
0x18000d559: mov      rbx, qword ptr [r11 + 0x18]
0x18000d55d: mov      rbp, qword ptr [r11 + 0x20]
0x18000d561: mov      rsi, qword ptr [r11 + 0x28]
0x18000d565: mov      rsp, r11
0x18000d568: pop      rdi
0x18000d569: ret      
0x18000d56a: int3     
0x18000d56b: cmp      dword ptr [rsi + 0x10], 0x41434450
0x18000d572: mov      rbp, rsi
0x18000d575: je       0x18000d580
0x18000d577: mov      ebx, 0xc00000ef
0x18000d57c: xor      ebp, ebp
0x18000d57e: jmp      0x18000d526
0x18000d580: mov      rdi, qword ptr [rsi + 0x18]
0x18000d584: cmp      dword ptr [rdi], 0x32414450
0x18000d58a: je       0x18000d597
0x18000d58c: xor      ebp, ebp
0x18000d58e: mov      ebx, 0xc00000ef
0x18000d593: xor      edi, edi
0x18000d595: jmp      0x18000d526
0x18000d597: lea      rbx, [rdi + 8]
0x18000d59b: mov      rcx, rbx
0x18000d59e: lea      rdx, [rsp + 0x360]
0x18000d5a6: call     0x18000df2c
0x18000d5ab: mov      rax, qword ptr gs:[0x188]
0x18000d5b4: cmp      rax, qword ptr [rdi + 0x60]
0x18000d5b8: je       0x18000d600
0x18000d5ba: jmp      0x18000d5fa
0x18000d5bc: lea      rdx, [rsp + 0x360]
0x18000d5c4: mov      rcx, rbx
0x18000d5c7: call     0x18000dfd8
0x18000d5cc: mov      rcx, qword ptr [rdi + 0x68]
0x18000d5d0: xor      r9d, r9d
0x18000d5d3: and      qword ptr [rsp + 0x20], 0
0x18000d5d9: xor      r8d, r8d
0x18000d5dc: xor      edx, edx
0x18000d5de: call     qword ptr [rip - 0x353d]  ; -> KeWaitForSingleObject
0x18000d5e5: nop      dword ptr [rax + rax]
0x18000d5ea: lea      rdx, [rsp + 0x360]
0x18000d5f2: mov      rcx, rbx
0x18000d5f5: call     0x18000df2c
0x18000d5fa: cmp      qword ptr [rdi + 0x70], rsi
0x18000d5fe: je       0x18000d5bc
0x18000d600: cmp      qword ptr [rdi + 0x28], 0
0x18000d605: jne      0x18000d611
0x18000d607: mov      ebx, 0xc0000700
0x18000d60c: jmp      0x18000d526
0x18000d611: movsxd   rax, dword ptr [rsi + 0x30]
0x18000d615: cmp      dword ptr [rdi + rax*4 + 0x100], 0
0x18000d61d: jne      0x18000d629
0x18000d61f: mov      ebx, 0xc0000001
0x18000d624: jmp      0x18000d526
0x18000d629: mov      rax, qword ptr [rsi + 0x250]
0x18000d630: lea      rdx, [rsp + 0x30]
0x18000d635: mov      qword ptr [rsp + 0x70], rax
0x18000d63a: mov      dword ptr [rsp + 0x58], 0xd
0x18000d642: mov      rcx, qword ptr [rdi + 0x28]
0x18000d646: call     0x180002854
0x18000d64b: mov      ebx, eax
0x18000d64d: test     eax, eax
0x18000d64f: js       0x18000d526
0x18000d655: mov      ebx, dword ptr [rsp + 0x68]
0x18000d659: test     ebx, ebx
0x18000d65b: js       0x18000d526
0x18000d661: mov      rcx, qword ptr [rsi + 0x18]
0x18000d665: or       edx, 0xffffffff
0x18000d668: movsxd   rax, dword ptr [rsi + 0x30]
0x18000d66c: xor      r8d, r8d
0x18000d66f: add      dword ptr [rcx + rax*4 + 0x100], edx
0x18000d676: add      dword ptr [rcx + 0xfc], edx
0x18000d67c: mov      rdx, rdi
0x18000d67f: and      dword ptr [rsi + 0x10], 0
0x18000d683: mov      rcx, rsi
0x18000d686: call     0x1800032e0
0x18000d68b: mov      rcx, qword ptr [rsi]
0x18000d68e: cmp      qword ptr [rcx + 8], rsi
0x18000d692: jne      0x18000d6be
0x18000d694: mov      rax, qword ptr [rsi + 8]
0x18000d698: cmp      qword ptr [rax], rsi
0x18000d69b: jne      0x18000d6be
0x18000d69d: mov      qword ptr [rax], rcx
0x18000d6a0: xor      edx, edx
0x18000d6a2: mov      qword ptr [rcx + 8], rax
0x18000d6a6: mov      rcx, rsi
0x18000d6a9: and      dword ptr [rsi + 0x10], 0
0x18000d6ad: call     qword ptr [rip - 0x365c]  ; -> ExFreePoolWithTag
0x18000d6b4: nop      dword ptr [rax + rax]
0x18000d6b9: jmp      0x18000d534
0x18000d6be: mov      ecx, 3
0x18000d6c3: int      0x29
0x18000d6c5: int3     
0x18000d6c6: int3     
0x18000d6c7: int3     
0x18000d6c8: int3     
0x18000d6c9: int3     
0x18000d6ca: int3     
0x18000d6cb: int3     
0x18000d6cc: mov      qword ptr [rsp + 8], rbx
0x18000d6d1: mov      qword ptr [rsp + 0x10], rbp
0x18000d6d6: mov      qword ptr [rsp + 0x20], rsi
0x18000d6db: push     rdi
0x18000d6dc: push     r14
0x18000d6de: push     r15
0x18000d6e0: sub      rsp, 0x50
0x18000d6e4: and      qword ptr [r8], 0
0x18000d6e8: mov      r14, r8
0x18000d6eb: cmp      dword ptr [rdx], 1
0x18000d6ee: mov      rbx, rdx
0x18000d6f1: je       0x18000d6fd
0x18000d6f3: mov      edi, 0xc00000f0
0x18000d6f8: jmp      0x18000d8a3
0x18000d6fd: cmp      qword ptr [rdx + 8], 0
0x18000d702: je       0x18000d6f3
0x18000d704: mov      edx, 0x118
0x18000d709: mov      r8d, 0x32414450
0x18000d70f: lea      ecx, [rdx - 0x18]
0x18000d712: call     qword ptr [rip - 0x36c9]  ; -> ExAllocatePool2
0x18000d719: nop      dword ptr [rax + rax]
0x18000d71e: mov      rsi, rax
0x18000d721: mov      rbp, rax
0x18000d724: test     rax, rax
0x18000d727: jne      0x18000d733
0x18000d729: mov      edi, 0xc0000017
0x18000d72e: jmp      0x18000d8a3
0x18000d733: mov      edx, 0x38
0x18000d738: lea      r15, [rax + 8]
0x18000d73c: mov      r8d, 0x4c636450
0x18000d742: lea      ecx, [rdx + 8]
0x18000d745: call     qword ptr [rip - 0x36fc]  ; -> ExAllocatePool2
0x18000d74c: nop      dword ptr [rax + rax]
0x18000d751: mov      rdi, rax
0x18000d754: test     rax, rax
0x18000d757: jne      0x18000d763
0x18000d759: mov      edi, 0xc0000017
0x18000d75e: jmp      0x18000d892
0x18000d763: xorps    xmm0, xmm0
0x18000d766: xor      eax, eax
0x18000d768: movups   xmmword ptr [r15], xmm0
0x18000d76c: xor      edx, edx
0x18000d76e: mov      qword ptr [r15 + 0x10], rax
0x18000d772: mov      rcx, rdi
0x18000d775: call     qword ptr [rip - 0x3694]  ; -> KeInitializeMutex
0x18000d77c: nop      dword ptr [rax + rax]
0x18000d781: xor      edx, edx
0x18000d783: mov      qword ptr [r15], rdi
0x18000d786: mov      rcx, r15
0x18000d789: call     0x18000df2c
0x18000d78e: mov      edx, 0x18
0x18000d793: mov      r8d, 0x45636450
0x18000d799: lea      ecx, [rdx + 0x28]
0x18000d79c: call     qword ptr [rip - 0x3753]  ; -> ExAllocatePool2
0x18000d7a3: nop      dword ptr [rax + rax]
0x18000d7a8: mov      rdi, rax
0x18000d7ab: test     rax, rax
0x18000d7ae: je       0x18000d7c4
0x18000d7b0: mov      r8b, 1
0x18000d7b3: xor      edx, edx
0x18000d7b5: mov      rcx, rax
0x18000d7b8: call     qword ptr [rip - 0x3737]  ; -> KeInitializeEvent
0x18000d7bf: nop      dword ptr [rax + rax]
0x18000d7c4: mov      qword ptr [rsi + 0x68], rdi
0x18000d7c8: test     rdi, rdi
0x18000d7cb: jne      0x18000d7d7
0x18000d7cd: mov      edi, 0xc000009a
0x18000d7d2: jmp      0x18000d86f
0x18000d7d7: movups   xmm0, xmmword ptr [rbx]
0x18000d7da: lea      rax, [rsi + 0x50]
0x18000d7de: mov      r8, rsi
0x18000d7e1: movsd    xmm1, qword ptr [rbx + 0x10]
0x18000d7e6: lea      r9, [rsp + 0x80]
0x18000d7ee: mov      qword ptr [rax + 8], rax
0x18000d7f2: mov      qword ptr [rax], rax
0x18000d7f5: lea      rax, [rip + 0x264]
0x18000d7fc: mov      qword ptr [rsp + 0x80], rax
0x18000d804: lea      rax, [rsi + 0x28]
0x18000d808: mov      qword ptr [rsp + 0x40], rax
0x18000d80d: and      qword ptr [rsp + 0x30], 0
0x18000d813: movups   xmmword ptr [rsi + 0x30], xmm0
0x18000d817: mov      dword ptr [rsi], 0x32414450
0x18000d81d: mov      dword ptr [rsi + 0x20], 0x54
0x18000d824: mov      byte ptr [rsi + 0x48], 1
0x18000d828: movsd    qword ptr [rsi + 0x40], xmm1
0x18000d82d: call     0x18000dcb8
0x18000d832: mov      edi, eax
0x18000d834: mov      ebx, eax
0x18000d836: test     eax, eax
0x18000d838: jne      0x18000d858
0x18000d83a: mov      qword ptr [r14], rsi
0x18000d83d: call     0x180002e3c
0x18000d842: xor      edx, edx
0x18000d844: mov      rcx, rsi
0x18000d847: call     0x1800035a8
0x18000d84c: xor      edx, edx
0x18000d84e: mov      rcx, r15
0x18000d851: call     0x18000dfd8
0x18000d856: jmp      0x18000d8a3
0x18000d858: mov      rcx, qword ptr [rsi + 0x68]
0x18000d85c: test     rcx, rcx
0x18000d85f: je       0x18000d86f
0x18000d861: xor      edx, edx
0x18000d863: call     qword ptr [rip - 0x3812]  ; -> ExFreePoolWithTag
0x18000d86a: nop      dword ptr [rax + rax]
0x18000d86f: lea      rbx, [rsi + 8]
0x18000d873: xor      edx, edx
0x18000d875: mov      rcx, rbx
0x18000d878: call     0x18000dfd8
0x18000d87d: mov      rcx, qword ptr [rbx]
0x18000d880: xor      edx, edx
0x18000d882: call     qword ptr [rip - 0x3831]  ; -> ExFreePoolWithTag
0x18000d889: nop      dword ptr [rax + rax]
0x18000d88e: and      qword ptr [rbx], 0
0x18000d892: xor      edx, edx
0x18000d894: mov      rcx, rsi
0x18000d897: call     qword ptr [rip - 0x3846]  ; -> ExFreePoolWithTag
0x18000d89e: nop      dword ptr [rax + rax]
0x18000d8a3: lea      r11, [rsp + 0x50]
0x18000d8a8: mov      eax, edi
0x18000d8aa: mov      rbx, qword ptr [r11 + 0x20]
0x18000d8ae: mov      rbp, qword ptr [r11 + 0x28]
0x18000d8b2: mov      rsi, qword ptr [r11 + 0x38]
0x18000d8b6: mov      rsp, r11
0x18000d8b9: pop      r15
0x18000d8bb: pop      r14
0x18000d8bd: pop      rdi
0x18000d8be: ret      
0x18000d8bf: int3     
0x18000d8c0: int3     
0x18000d8c1: int3     
0x18000d8c2: int3     
0x18000d8c3: int3     
0x18000d8c4: int3     
0x18000d8c5: int3     
0x18000d8c6: int3     
0x18000d8c7: int3     
0x18000d8c8: mov      qword ptr [rsp + 0x10], rbx
0x18000d8cd: mov      qword ptr [rsp + 0x18], rsi
0x18000d8d2: mov      qword ptr [rsp + 0x20], rdi
0x18000d8d7: push     r14
0x18000d8d9: sub      rsp, 0x20
0x18000d8dd: xor      edi, edi
0x18000d8df: mov      rsi, rcx
0x18000d8e2: test     rcx, rcx
0x18000d8e5: jne      0x18000d8ee
0x18000d8e7: mov      ebx, 0xc00000ef
0x18000d8ec: jmp      0x18000d934
0x18000d8ee: cmp      dword ptr [rcx], 0x32414450
0x18000d8f4: mov      rdi, rsi
0x18000d8f7: je       0x18000d902
0x18000d8f9: mov      ebx, 0xc00000ef
0x18000d8fe: xor      edi, edi
0x18000d900: jmp      0x18000d934
0x18000d902: lea      r14, [rcx + 8]
0x18000d906: mov      rcx, r14
0x18000d909: lea      rdx, [rsp + 0x30]
0x18000d90e: call     0x18000df2c
0x18000d913: mov      rax, qword ptr gs:[0x188]
0x18000d91c: lea      rdx, [rsp + 0x30]
0x18000d921: mov      rcx, r14
0x18000d924: cmp      qword ptr [rsi + 0x60], rax
0x18000d928: jne      0x18000d943
0x18000d92a: mov      ebx, 0xc00000bb
0x18000d92f: call     0x18000dfd8
0x18000d934: mov      edx, ebx
0x18000d936: mov      rcx, rdi
0x18000d939: call     0x180003608
0x18000d93e: jmp      0x18000da3c
0x18000d943: mov      rdi, qword ptr [rsi + 0x28]
0x18000d947: and      qword ptr [rsi + 0x28], 0
0x18000d94c: mov      byte ptr [rsi + 0x48], 0
0x18000d950: call     0x18000dfd8
0x18000d955: lea      rcx, [rdi + 8]
0x18000d959: call     qword ptr [rip - 0x38a0]  ; -> ExWaitForRundownProtectionRelease
0x18000d960: nop      dword ptr [rax + rax]
0x18000d965: lea      rcx, [rdi + 8]
0x18000d969: call     qword ptr [rip - 0x38b8]  ; -> ExRundownCompleted
0x18000d970: nop      dword ptr [rax + rax]
0x18000d975: mov      rcx, rdi
0x18000d978: call     0x18000deac
0x18000d97d: lea      rdx, [rsp + 0x30]
0x18000d982: mov      rcx, r14
0x18000d985: call     0x18000df2c
0x18000d98a: or       edi, 0xffffffff
0x18000d98d: lea      rbx, [rsi + 0x50]
0x18000d991: mov      rcx, qword ptr [rbx]
0x18000d994: cmp      rcx, rbx
0x18000d997: je       0x18000d9df
0x18000d999: cmp      qword ptr [rcx + 8], rbx
0x18000d99d: jne      0x18000d9d8
0x18000d99f: mov      rax, qword ptr [rcx]
0x18000d9a2: cmp      qword ptr [rax + 8], rcx
0x18000d9a6: jne      0x18000d9d8
0x18000d9a8: mov      qword ptr [rbx], rax
0x18000d9ab: mov      qword ptr [rax + 8], rbx
0x18000d9af: mov      rdx, qword ptr [rcx + 0x18]
0x18000d9b3: movsxd   rax, dword ptr [rcx + 0x30]
0x18000d9b7: add      dword ptr [rdx + rax*4 + 0x100], edi
0x18000d9be: add      dword ptr [rdx + 0xfc], edi
0x18000d9c4: xor      edx, edx
0x18000d9c6: and      dword ptr [rcx + 0x10], 0
0x18000d9ca: call     qword ptr [rip - 0x3979]  ; -> ExFreePoolWithTag
0x18000d9d1: nop      dword ptr [rax + rax]
0x18000d9d6: jmp      0x18000d991
0x18000d9d8: mov      ecx, 3
0x18000d9dd: int      0x29
0x18000d9df: and      dword ptr [rsi], 0
0x18000d9e2: xor      edx, edx
0x18000d9e4: mov      rcx, rsi
0x18000d9e7: xor      ebx, ebx
0x18000d9e9: call     0x180003608
0x18000d9ee: lea      rdx, [rsp + 0x30]
0x18000d9f3: mov      rcx, r14
0x18000d9f6: call     0x18000dfd8
0x18000d9fb: mov      rcx, qword ptr [r14]
0x18000d9fe: xor      edx, edx
0x18000da00: call     qword ptr [rip - 0x39af]  ; -> ExFreePoolWithTag
0x18000da07: nop      dword ptr [rax + rax]
0x18000da0c: and      qword ptr [r14], rbx
0x18000da0f: mov      rcx, qword ptr [rsi + 0x68]
0x18000da13: test     rcx, rcx
0x18000da16: je       0x18000da26
0x18000da18: xor      edx, edx
0x18000da1a: call     qword ptr [rip - 0x39c9]  ; -> ExFreePoolWithTag
0x18000da21: nop      dword ptr [rax + rax]
0x18000da26: xor      edx, edx
0x18000da28: mov      rcx, rsi
0x18000da2b: call     qword ptr [rip - 0x39da]  ; -> ExFreePoolWithTag
0x18000da32: nop      dword ptr [rax + rax]
0x18000da37: call     0x180002e84
0x18000da3c: mov      rsi, qword ptr [rsp + 0x40]
0x18000da41: mov      eax, ebx
0x18000da43: mov      rbx, qword ptr [rsp + 0x38]
0x18000da48: mov      rdi, qword ptr [rsp + 0x48]
0x18000da4d: add      rsp, 0x20
0x18000da51: pop      r14
0x18000da53: ret      
0x18000da54: int3     
0x18000da55: int3     
0x18000da56: int3     
0x18000da57: int3     
0x18000da58: int3     
0x18000da59: int3     
0x18000da5a: int3     
0x18000da5b: int3     
0x18000da5c: int3     
0x18000da5d: int3     
0x18000da5e: int3     
0x18000da5f: int3     
0x18000da60: mov      qword ptr [rsp + 0x10], rbx
0x18000da65: mov      qword ptr [rsp + 0x18], rbp
0x18000da6a: push     rsi
0x18000da6b: push     rdi
0x18000da6c: push     r14
0x18000da6e: sub      rsp, 0x30
0x18000da72: xor      ebp, ebp
0x18000da74: mov      rsi, rdx
0x18000da77: mov      byte ptr [rsp + 0x50], bpl
0x18000da7c: mov      rbx, rcx
0x18000da7f: test     rcx, rcx
0x18000da82: jne      0x18000da8e
0x18000da84: mov      edi, 0xc00000ef
0x18000da89: jmp      0x18000db2c
0x18000da8e: cmp      dword ptr [rcx], 0x32414450
0x18000da94: je       0x18000daa2
0x18000da96: mov      edi, 0xc00000ef
0x18000da9b: xor      ebx, ebx
0x18000da9d: jmp      0x18000db2c
0x18000daa2: cmp      dword ptr [rdx + 0x28], 0xc
0x18000daa6: je       0x18000daaf
0x18000daa8: mov      edi, 0xc0000702
0x18000daad: jmp      0x18000db2c
0x18000daaf: call     0x180003668
0x18000dab4: mov      edi, eax
0x18000dab6: lea      r14, [rcx + 8]
0x18000daba: jmp      0x18000dae6
0x18000dabc: lea      rdx, [rsp + 0x50]
0x18000dac1: mov      rcx, r14
0x18000dac4: call     0x18000dfd8
0x18000dac9: mov      rcx, qword ptr [rbx + 0x68]
0x18000dacd: xor      r9d, r9d
0x18000dad0: and      qword ptr [rsp + 0x20], rbp
0x18000dad5: xor      r8d, r8d
0x18000dad8: xor      edx, edx
0x18000dada: call     qword ptr [rip - 0x3a39]  ; -> KeWaitForSingleObject
0x18000dae1: nop      dword ptr [rax + rax]
0x18000dae6: lea      rdx, [rsp + 0x50]
0x18000daeb: mov      rcx, r14
0x18000daee: call     0x18000df2c
0x18000daf3: cmp      qword ptr [rbx + 0x60], rbp
0x18000daf7: jne      0x18000dabc
0x18000daf9: cmp      qword ptr [rbx + 0x28], rbp
0x18000dafd: jne      0x18000db06
0x18000daff: mov      edi, 0xc0000700
0x18000db04: jmp      0x18000db2c
0x18000db06: mov      rcx, qword ptr [rsi + 0x38]
0x18000db0a: lea      rax, [rbx + 0x50]
0x18000db0e: mov      ebp, dword ptr [rsi + 0x40]
0x18000db11: mov      rsi, qword ptr [rax]
0x18000db14: jmp      0x18000db22
0x18000db16: cmp      qword ptr [rsi + 0x250], rcx
0x18000db1d: je       0x18000db67
0x18000db1f: mov      rsi, qword ptr [rsi]
0x18000db22: cmp      rsi, rax
0x18000db25: jne      0x18000db16
0x18000db27: mov      edi, 0xc0000189
0x18000db2c: mov      r9d, edi
0x18000db2f: mov      r8d, ebp
0x18000db32: mov      rdx, rbx
0x18000db35: xor      ecx, ecx
0x18000db37: call     0x180002fc4
0x18000db3c: cmp      byte ptr [rsp + 0x50], 0
0x18000db41: je       0x18000db51
0x18000db43: lea      rcx, [rbx + 8]
0x18000db47: lea      rdx, [rsp + 0x50]
0x18000db4c: call     0x18000dfd8
0x18000db51: mov      rbx, qword ptr [rsp + 0x58]
0x18000db56: mov      eax, edi
0x18000db58: mov      rbp, qword ptr [rsp + 0x60]
0x18000db5d: add      rsp, 0x30
0x18000db61: pop      r14
0x18000db63: pop      rdi
0x18000db64: pop      rsi
0x18000db65: ret      
0x18000db66: int3     
0x18000db67: cmp      ebp, 0x65
0x18000db6a: jl       0x18000db73
0x18000db6c: inc      dword ptr [rsi + 0x44]
0x18000db6f: mov      byte ptr [rsi + 0x3c], 1
0x18000db73: mov      r9d, edi
0x18000db76: mov      r8d, ebp
0x18000db79: mov      rdx, rbx
0x18000db7c: mov      rcx, rsi
0x18000db7f: call     0x180002fc4
0x18000db84: mov      rax, qword ptr gs:[0x188]
0x18000db8d: mov      rcx, qword ptr [rbx + 0x68]
0x18000db91: mov      qword ptr [rbx + 0x60], rax
0x18000db95: mov      qword ptr [rbx + 0x70], rsi
0x18000db99: call     0x1800028d0
0x18000db9e: mov      r8, qword ptr gs:[0x188]
0x18000dba7: lea      rdx, [rsp + 0x50]
0x18000dbac: mov      rax, qword ptr [rbx + 0x28]
0x18000dbb0: mov      rcx, r14
0x18000dbb3: mov      qword ptr [rax + 0x6e0], r8
0x18000dbba: call     0x18000dfd8
0x18000dbbf: mov      rax, qword ptr [rbx + 0x38]
0x18000dbc3: mov      edx, ebp
0x18000dbc5: mov      r9, qword ptr [rsi + 0x20]
0x18000dbc9: mov      rcx, rsi
0x18000dbcc: mov      r8, qword ptr [rbx + 0x40]
0x18000dbd0: call     0x1800041e0
0x18000dbd5: lea      rdx, [rsp + 0x50]
0x18000dbda: mov      rcx, r14
0x18000dbdd: call     0x18000df2c
0x18000dbe2: mov      rax, qword ptr [rbx + 0x28]
0x18000dbe6: test     rax, rax
0x18000dbe9: je       0x18000dbf3
0x18000dbeb: and      qword ptr [rax + 0x6e0], 0
0x18000dbf3: and      qword ptr [rbx + 0x60], 0
0x18000dbf8: xor      r8d, r8d
0x18000dbfb: and      qword ptr [rbx + 0x70], 0
0x18000dc00: xor      edx, edx
0x18000dc02: mov      rcx, qword ptr [rbx + 0x68]
0x18000dc06: call     qword ptr [rip - 0x3be5]  ; -> KeSetEvent
0x18000dc0d: nop      dword ptr [rax + rax]
0x18000dc12: jmp      0x18000db3c
0x18000dc17: int3     
0x18000dc18: int3     
0x18000dc19: int3     
0x18000dc1a: int3     
0x18000dc1b: int3     
0x18000dc1c: int3     
0x18000dc1d: int3     
0x18000dc1e: int3     
0x18000dc1f: int3     
0x18000dc20: xor      edx, edx
0x18000dc22: test     rcx, rcx
0x18000dc25: je       0x18000dcae
0x18000dc2b: mov      eax, dword ptr [rcx]
0x18000dc2d: dec      eax
0x18000dc2f: cmp      eax, 1
0x18000dc32: ja       0x18000dcae
0x18000dc34: test     qword ptr [rcx + 8], -4
0x18000dc3c: jne      0x18000dcae
0x18000dc3e: mov      eax, dword ptr [rcx + 4]
0x18000dc41: sub      eax, 0xa
0x18000dc44: cmp      eax, 0x122
0x18000dc49: ja       0x18000dcae
0x18000dc4b: mov      r8, qword ptr [rcx + 0x18]
0x18000dc4f: test     r8, r8
0x18000dc52: je       0x18000dcac
0x18000dc54: mov      rcx, qword ptr [r8]
0x18000dc57: cmp      rcx, 0xa
0x18000dc5b: ja       0x18000dcae
0x18000dc5d: mov      r9d, edx
0x18000dc60: test     rcx, rcx
0x18000dc63: je       0x18000dc80
0x18000dc65: lea      rax, [r8 + 8]
0x18000dc69: cmp      qword ptr [rax], rdx
0x18000dc6c: je       0x18000dcae
0x18000dc6e: cmp      qword ptr [rax + 8], rdx
0x18000dc72: je       0x18000dcae
0x18000dc74: inc      r9
0x18000dc77: add      rax, 0x10
0x18000dc7b: cmp      r9, rcx
0x18000dc7e: jb       0x18000dc69
0x18000dc80: cmp      rcx, 0xa
0x18000dc84: jae      0x18000dcac
0x18000dc86: mov      rax, rcx
0x18000dc89: add      r8, 8
0x18000dc8d: shl      rax, 4
0x18000dc91: add      r8, rax
0x18000dc94: cmp      qword ptr [r8], rdx
0x18000dc97: jne      0x18000dcae
0x18000dc99: cmp      qword ptr [r8 + 8], rdx
0x18000dc9d: jne      0x18000dcae
0x18000dc9f: inc      rcx
0x18000dca2: add      r8, 0x10
0x18000dca6: cmp      rcx, 0xa
0x18000dcaa: jb       0x18000dc94
0x18000dcac: mov      dl, 1
0x18000dcae: mov      al, dl
0x18000dcb0: ret      
0x18000dcb1: int3     
0x18000dcb2: int3     
0x18000dcb3: int3     
0x18000dcb4: int3     
0x18000dcb5: int3     
0x18000dcb6: int3     
0x18000dcb7: int3     
0x18000dcb8: mov      rax, rsp
0x18000dcbb: mov      qword ptr [rax + 8], rbx
0x18000dcbf: mov      qword ptr [rax + 0x10], rsi
0x18000dcc3: mov      qword ptr [rax + 0x18], rdi
0x18000dcc7: mov      qword ptr [rax + 0x20], r12
0x18000dccb: push     rbp
0x18000dccc: push     r14
0x18000dcce: push     r15
0x18000dcd0: lea      rbp, [rax - 0x268]
0x18000dcd7: sub      rsp, 0x350
0x18000dcde: mov      r14, r8
0x18000dce1: lea      rcx, [rsp + 0x30]
0x18000dce6: mov      r8d, 0x320
0x18000dcec: xor      edx, edx
0x18000dcee: mov      rbx, r9
0x18000dcf1: call     0x1800045c0
0x18000dcf6: mov      r15, qword ptr [rbp + 0x2b0]
0x18000dcfd: xor      r12d, r12d
0x18000dd00: mov      edx, 0x6e8
0x18000dd05: mov      ecx, 0x100
0x18000dd0a: mov      r8d, 0x50636450
0x18000dd10: mov      edi, r12d
0x18000dd13: mov      qword ptr [r15], r12
0x18000dd16: call     qword ptr [rip - 0x3ccd]  ; -> ExAllocatePool2
0x18000dd1d: nop      dword ptr [rax + rax]
0x18000dd22: mov      rsi, rax
0x18000dd25: test     rax, rax
0x18000dd28: jne      0x18000dd76
0x18000dd2a: mov      ebx, 0xc0000017
0x18000dd2f: test     rsi, rsi
0x18000dd32: je       0x18000dd3c
0x18000dd34: mov      rcx, rsi
0x18000dd37: call     0x18000deac
0x18000dd3c: test     rdi, rdi
0x18000dd3f: je       0x18000dd52
0x18000dd41: xor      edx, edx
0x18000dd43: mov      rcx, rdi
0x18000dd46: call     qword ptr [rip - 0x3cf5]  ; -> ExFreePoolWithTag
0x18000dd4d: nop      dword ptr [rax + rax]
0x18000dd52: lea      r11, [rsp + 0x350]
0x18000dd5a: mov      eax, ebx
0x18000dd5c: mov      rbx, qword ptr [r11 + 0x20]
0x18000dd60: mov      rsi, qword ptr [r11 + 0x28]
0x18000dd64: mov      rdi, qword ptr [r11 + 0x30]
0x18000dd68: mov      r12, qword ptr [r11 + 0x38]
0x18000dd6c: mov      rsp, r11
0x18000dd6f: pop      r15
0x18000dd71: pop      r14
0x18000dd73: pop      rbp
0x18000dd74: ret      
0x18000dd75: int3     
0x18000dd76: mov      qword ptr [rax + 0x6d0], r14
0x18000dd7d: lea      rcx, [rax + 8]
0x18000dd81: mov      r14d, 0x54
0x18000dd87: mov      dword ptr [rax], 0x50636450
0x18000dd8d: mov      dword ptr [rax + 0x10], r14d
0x18000dd91: mov      dword ptr [rax + 0x14], 7
0x18000dd98: call     qword ptr [rip - 0x3cd7]  ; -> ExInitializeRundownProtection
0x18000dd9f: nop      dword ptr [rax + rax]
0x18000dda4: mov      rax, qword ptr [rbx]
0x18000dda7: mov      qword ptr [rsi + 0x6d8], rax
0x18000ddae: test     rax, rax
0x18000ddb1: jne      0x18000ddbd
0x18000ddb3: mov      ebx, 0xc00000f1
0x18000ddb8: jmp      0x18000dd2f
0x18000ddbd: mov      rdx, qword ptr [rbp + 0x2a0]
0x18000ddc4: mov      dword ptr [rsp + 0x5c], 6
0x18000ddcc: mov      dword ptr [rsp + 0x68], r14d
0x18000ddd1: mov      dword ptr [rsp + 0x6c], 7
0x18000ddd9: test     rdx, rdx
0x18000dddc: je       0x18000de22
0x18000ddde: lea      rax, [rsp + 0x78]
0x18000dde3: mov      r9d, 0x40
0x18000dde9: sub      rdx, rax
0x18000ddec: lea      rcx, [rsp + 0x78]
0x18000ddf1: lea      rax, [r9 + 0x7fffffbe]
0x18000ddf8: test     rax, rax
0x18000ddfb: je       0x18000de13
0x18000ddfd: movzx    eax, word ptr [rdx + rcx]
0x18000de01: test     ax, ax
0x18000de04: je       0x18000de13
0x18000de06: mov      word ptr [rcx], ax
0x18000de09: add      rcx, 2
0x18000de0d: sub      r9, 1
0x18000de11: jne      0x18000ddf1
0x18000de13: test     r9, r9
0x18000de16: lea      rax, [rcx - 2]
0x18000de1a: cmovne   rax, rcx
0x18000de1e: mov      word ptr [rax], r12w
0x18000de22: mov      ebx, 0xe0
0x18000de27: mov      qword ptr [rsp + 0x30], 0x32002f8
0x18000de30: mov      r8d, 0x50636450
0x18000de36: mov      qword ptr [rsp + 0x38], r12
0x18000de3b: mov      edx, ebx
0x18000de3d: mov      qword ptr [rsp + 0x40], r12
0x18000de42: lea      ecx, [rbx + 0x20]
0x18000de45: call     qword ptr [rip - 0x3dfc]  ; -> ExAllocatePool2
0x18000de4c: nop      dword ptr [rax + rax]
0x18000de51: mov      rdi, rax
0x18000de54: test     rax, rax
0x18000de57: je       0x18000dd2a
0x18000de5d: xor      r9d, r9d
0x18000de60: mov      dword ptr [rax], 1
0x18000de66: lea      rax, [rsp + 0x30]
0x18000de6b: mov      qword ptr [rdi + 0x10], rsi
0x18000de6f: mov      r8d, ebx
0x18000de72: mov      qword ptr [rdi + 8], rax
0x18000de76: mov      rdx, rdi
0x18000de79: mov      dword ptr [rsp + 0x20], r12d
0x18000de7e: lea      ecx, [r9 + 0x43]
0x18000de82: call     qword ptr [rip - 0x3db9]  ; -> ZwPowerInformation
0x18000de89: nop      dword ptr [rax + rax]
0x18000de8e: mov      ebx, eax
0x18000de90: test     eax, eax
0x18000de92: js       0x18000dd2f
0x18000de98: mov      qword ptr [r15], rsi
0x18000de9b: mov      ebx, r12d
0x18000de9e: jmp      0x18000dd41
0x18000dea3: int3     
0x18000dea4: int3     
0x18000dea5: int3     
0x18000dea6: int3     
0x18000dea7: int3     
0x18000dea8: int3     
0x18000dea9: int3     
0x18000deaa: int3     
0x18000deab: int3     
0x18000deac: push     rbx
0x18000deae: sub      rsp, 0x340
0x18000deb5: mov      rbx, rcx
0x18000deb8: xor      edx, edx
0x18000deba: lea      rcx, [rsp + 0x20]
0x18000debf: mov      r8d, 0x320
0x18000dec5: call     0x1800045c0
0x18000deca: mov      rcx, qword ptr [rbx + 0x18]
0x18000dece: and      dword ptr [rbx], 0
0x18000ded1: test     rcx, rcx
0x18000ded4: je       0x18000df08
0x18000ded6: mov      eax, dword ptr [rbx + 0x10]
0x18000ded9: lea      rdx, [rsp + 0x20]
0x18000dede: mov      dword ptr [rsp + 0x58], eax
0x18000dee2: mov      r8d, 0x320
0x18000dee8: mov      eax, dword ptr [rbx + 0x14]
0x18000deeb: mov      dword ptr [rsp + 0x5c], eax
0x18000deef: mov      rax, qword ptr [rbx + 0x20]
0x18000def3: mov      dword ptr [rsp + 0x48], 1
0x18000defb: mov      dword ptr [rsp + 0x4c], 6
0x18000df03: call     0x1800041e0
0x18000df08: xor      edx, edx
0x18000df0a: mov      rcx, rbx
0x18000df0d: call     qword ptr [rip - 0x3ebc]  ; -> ExFreePoolWithTag
0x18000df14: nop      dword ptr [rax + rax]
0x18000df19: add      rsp, 0x340
0x18000df20: pop      rbx
0x18000df21: ret      
0x18000df22: int3     
0x18000df23: int3     
0x18000df24: int3     
0x18000df25: int3     
0x18000df26: int3     
0x18000df27: int3     
0x18000df28: int3     
0x18000df29: int3     
0x18000df2a: int3     
0x18000df2b: int3     
0x18000df2c: mov      qword ptr [rsp + 0x10], rbx
0x18000df31: push     rdi
0x18000df32: sub      rsp, 0x30
0x18000df36: mov      qword ptr [rsp + 0x40], 0xffffffffdc3cba00
0x18000df3f: mov      rdi, rdx
0x18000df42: mov      rbx, rcx
0x18000df45: test     rdx, rdx
0x18000df48: je       0x18000df4d
0x18000df4a: mov      byte ptr [rdx], 0
0x18000df4d: mov      rcx, qword ptr [rbx]
0x18000df50: lea      rax, [rsp + 0x40]
0x18000df55: xor      r9d, r9d
0x18000df58: mov      qword ptr [rsp + 0x20], rax
0x18000df5d: xor      r8d, r8d
0x18000df60: xor      edx, edx
0x18000df62: call     qword ptr [rip - 0x3ec1]  ; -> KeWaitForSingleObject
0x18000df69: nop      dword ptr [rax + rax]
0x18000df6e: test     eax, eax
0x18000df70: je       0x18000df8a
0x18000df72: sub      eax, 0xc0
0x18000df77: je       0x18000df83
0x18000df79: sub      eax, 0x41
0x18000df7c: je       0x18000df83
0x18000df7e: cmp      eax, 1
0x18000df81: je       0x18000df4d
0x18000df83: mov      ecx, 5
0x18000df88: int      0x29
0x18000df8a: test     rdi, rdi
0x18000df8d: je       0x18000df92
0x18000df8f: mov      byte ptr [rdi], 1
0x18000df92: mov      eax, 1
0x18000df97: lock xadd dword ptr [rbx + 0x10], eax
0x18000df9c: inc      eax
0x18000df9e: cmp      eax, 1
0x18000dfa1: jne      0x18000dfb0
0x18000dfa3: mov      rax, qword ptr gs:[0x188]
0x18000dfac: mov      qword ptr [rbx + 8], rax
0x18000dfb0: mov      rax, qword ptr gs:[0x188]
0x18000dfb9: cmp      qword ptr [rbx + 8], rax
0x18000dfbd: je       0x18000dfc6
0x18000dfbf: mov      ecx, 0x28
0x18000dfc4: int      0x29
0x18000dfc6: mov      rbx, qword ptr [rsp + 0x48]
0x18000dfcb: add      rsp, 0x30
0x18000dfcf: pop      rdi
0x18000dfd0: ret      
0x18000dfd1: int3     
0x18000dfd2: int3     
0x18000dfd3: int3     
0x18000dfd4: int3     
0x18000dfd5: int3     
0x18000dfd6: int3     
0x18000dfd7: int3     
0x18000dfd8: push     rbx
0x18000dfda: sub      rsp, 0x20
0x18000dfde: mov      rbx, rdx
0x18000dfe1: test     rdx, rdx
0x18000dfe4: je       0x18000dfe9
0x18000dfe6: mov      byte ptr [rdx], 1
0x18000dfe9: cmp      qword ptr [rcx], 0
0x18000dfed: je       0x18000e036
0x18000dfef: mov      rax, qword ptr gs:[0x188]
0x18000dff8: cmp      qword ptr [rcx + 8], rax
0x18000dffc: jne      0x18000e036
0x18000dffe: cmp      dword ptr [rcx + 0x10], 0
0x18000e002: jle      0x18000e036
0x18000e004: or       eax, 0xffffffff
0x18000e007: lock xadd dword ptr [rcx + 0x10], eax
0x18000e00c: cmp      eax, 1
0x18000e00f: jne      0x18000e016
0x18000e011: and      qword ptr [rcx + 8], 0
0x18000e016: mov      rcx, qword ptr [rcx]
0x18000e019: xor      edx, edx
0x18000e01b: call     qword ptr [rip - 0x3f32]  ; -> KeReleaseMutex
0x18000e022: nop      dword ptr [rax + rax]
0x18000e027: test     rbx, rbx
0x18000e02a: je       0x18000e02f
0x18000e02c: mov      byte ptr [rbx], 0
0x18000e02f: add      rsp, 0x20
0x18000e033: pop      rbx
0x18000e034: ret      
0x18000e035: int3     
0x18000e036: mov      ecx, 5
0x18000e03b: int      0x29
0x18000e03d: add      byte ptr [rax], al
0x18000e03f: add      byte ptr [rax], al
0x18000e041: add      byte ptr [rax], al
0x18000e043: add      byte ptr [rax], al
0x18000e045: add      byte ptr [rax], al
0x18000e047: add      byte ptr [rax], al
0x18000e049: add      byte ptr [rax], al
0x18000e04b: add      byte ptr [rax], al
0x18000e04d: add      byte ptr [rax], al
0x18000e04f: add      byte ptr [rax], al
0x18000e051: add      byte ptr [rax], al
0x18000e053: add      byte ptr [rax], al
0x18000e055: add      byte ptr [rax], al
0x18000e057: add      byte ptr [rax], al
0x18000e059: add      byte ptr [rax], al
0x18000e05b: add      byte ptr [rax], al
0x18000e05d: add      byte ptr [rax], al
0x18000e05f: add      byte ptr [rax], al
0x18000e061: add      byte ptr [rax], al
0x18000e063: add      byte ptr [rax], al
0x18000e065: add      byte ptr [rax], al
0x18000e067: add      byte ptr [rax], al
0x18000e069: add      byte ptr [rax], al
0x18000e06b: add      byte ptr [rax], al
0x18000e06d: add      byte ptr [rax], al
0x18000e06f: add      byte ptr [rax], al
0x18000e071: add      byte ptr [rax], al
0x18000e073: add      byte ptr [rax], al
0x18000e075: add      byte ptr [rax], al
0x18000e077: add      byte ptr [rax], al
0x18000e079: add      byte ptr [rax], al
0x18000e07b: add      byte ptr [rax], al
0x18000e07d: add      byte ptr [rax], al
0x18000e07f: add      byte ptr [rax], al
0x18000e081: add      byte ptr [rax], al
0x18000e083: add      byte ptr [rax], al
0x18000e085: add      byte ptr [rax], al
0x18000e087: add      byte ptr [rax], al
0x18000e089: add      byte ptr [rax], al
0x18000e08b: add      byte ptr [rax], al
0x18000e08d: add      byte ptr [rax], al
0x18000e08f: add      byte ptr [rax], al
0x18000e091: add      byte ptr [rax], al
0x18000e093: add      byte ptr [rax], al
0x18000e095: add      byte ptr [rax], al
0x18000e097: add      byte ptr [rax], al
0x18000e099: add      byte ptr [rax], al
0x18000e09b: add      byte ptr [rax], al
0x18000e09d: add      byte ptr [rax], al
0x18000e09f: add      byte ptr [rax], al
0x18000e0a1: add      byte ptr [rax], al
0x18000e0a3: add      byte ptr [rax], al
0x18000e0a5: add      byte ptr [rax], al
0x18000e0a7: add      byte ptr [rax], al
0x18000e0a9: add      byte ptr [rax], al
0x18000e0ab: add      byte ptr [rax], al
0x18000e0ad: add      byte ptr [rax], al
0x18000e0af: add      byte ptr [rax], al
0x18000e0b1: add      byte ptr [rax], al
0x18000e0b3: add      byte ptr [rax], al
0x18000e0b5: add      byte ptr [rax], al
0x18000e0b7: add      byte ptr [rax], al
0x18000e0b9: add      byte ptr [rax], al
0x18000e0bb: add      byte ptr [rax], al
0x18000e0bd: add      byte ptr [rax], al
0x18000e0bf: add      byte ptr [rax], al
0x18000e0c1: add      byte ptr [rax], al
0x18000e0c3: add      byte ptr [rax], al
0x18000e0c5: add      byte ptr [rax], al
0x18000e0c7: add      byte ptr [rax], al
0x18000e0c9: add      byte ptr [rax], al
0x18000e0cb: add      byte ptr [rax], al
0x18000e0cd: add      byte ptr [rax], al
0x18000e0cf: add      byte ptr [rax], al
0x18000e0d1: add      byte ptr [rax], al
0x18000e0d3: add      byte ptr [rax], al
0x18000e0d5: add      byte ptr [rax], al
0x18000e0d7: add      byte ptr [rax], al
0x18000e0d9: add      byte ptr [rax], al
0x18000e0db: add      byte ptr [rax], al
0x18000e0dd: add      byte ptr [rax], al
0x18000e0df: add      byte ptr [rax], al
0x18000e0e1: add      byte ptr [rax], al
0x18000e0e3: add      byte ptr [rax], al
0x18000e0e5: add      byte ptr [rax], al
0x18000e0e7: add      byte ptr [rax], al
0x18000e0e9: add      byte ptr [rax], al
0x18000e0eb: add      byte ptr [rax], al
0x18000e0ed: add      byte ptr [rax], al
0x18000e0ef: add      byte ptr [rax], al
0x18000e0f1: add      byte ptr [rax], al
0x18000e0f3: add      byte ptr [rax], al
0x18000e0f5: add      byte ptr [rax], al
0x18000e0f7: add      byte ptr [rax], al
0x18000e0f9: add      byte ptr [rax], al
0x18000e0fb: add      byte ptr [rax], al
0x18000e0fd: add      byte ptr [rax], al
0x18000e0ff: add      byte ptr [rax], al
0x18000e101: add      byte ptr [rax], al
0x18000e103: add      byte ptr [rax], al
0x18000e105: add      byte ptr [rax], al
0x18000e107: add      byte ptr [rax], al
0x18000e109: add      byte ptr [rax], al
0x18000e10b: add      byte ptr [rax], al
0x18000e10d: add      byte ptr [rax], al
0x18000e10f: add      byte ptr [rax], al
0x18000e111: add      byte ptr [rax], al
0x18000e113: add      byte ptr [rax], al
0x18000e115: add      byte ptr [rax], al
0x18000e117: add      byte ptr [rax], al
0x18000e119: add      byte ptr [rax], al
0x18000e11b: add      byte ptr [rax], al
0x18000e11d: add      byte ptr [rax], al
0x18000e11f: add      byte ptr [rax], al
0x18000e121: add      byte ptr [rax], al
0x18000e123: add      byte ptr [rax], al
0x18000e125: add      byte ptr [rax], al
0x18000e127: add      byte ptr [rax], al
0x18000e129: add      byte ptr [rax], al
0x18000e12b: add      byte ptr [rax], al
0x18000e12d: add      byte ptr [rax], al
0x18000e12f: add      byte ptr [rax], al
0x18000e131: add      byte ptr [rax], al
0x18000e133: add      byte ptr [rax], al
0x18000e135: add      byte ptr [rax], al
0x18000e137: add      byte ptr [rax], al
0x18000e139: add      byte ptr [rax], al
0x18000e13b: add      byte ptr [rax], al
0x18000e13d: add      byte ptr [rax], al
0x18000e13f: add      byte ptr [rax], al
0x18000e141: add      byte ptr [rax], al
0x18000e143: add      byte ptr [rax], al
0x18000e145: add      byte ptr [rax], al
0x18000e147: add      byte ptr [rax], al
0x18000e149: add      byte ptr [rax], al
0x18000e14b: add      byte ptr [rax], al
0x18000e14d: add      byte ptr [rax], al
0x18000e14f: add      byte ptr [rax], al
0x18000e151: add      byte ptr [rax], al
0x18000e153: add      byte ptr [rax], al
0x18000e155: add      byte ptr [rax], al
0x18000e157: add      byte ptr [rax], al
0x18000e159: add      byte ptr [rax], al
0x18000e15b: add      byte ptr [rax], al
0x18000e15d: add      byte ptr [rax], al
0x18000e15f: add      byte ptr [rax], al
0x18000e161: add      byte ptr [rax], al
0x18000e163: add      byte ptr [rax], al
0x18000e165: add      byte ptr [rax], al
0x18000e167: add      byte ptr [rax], al
0x18000e169: add      byte ptr [rax], al
0x18000e16b: add      byte ptr [rax], al
0x18000e16d: add      byte ptr [rax], al
0x18000e16f: add      byte ptr [rax], al
0x18000e171: add      byte ptr [rax], al
0x18000e173: add      byte ptr [rax], al
0x18000e175: add      byte ptr [rax], al
0x18000e177: add      byte ptr [rax], al
0x18000e179: add      byte ptr [rax], al
0x18000e17b: add      byte ptr [rax], al
0x18000e17d: add      byte ptr [rax], al
0x18000e17f: add      byte ptr [rax], al
0x18000e181: add      byte ptr [rax], al
0x18000e183: add      byte ptr [rax], al
0x18000e185: add      byte ptr [rax], al
0x18000e187: add      byte ptr [rax], al
0x18000e189: add      byte ptr [rax], al
0x18000e18b: add      byte ptr [rax], al
0x18000e18d: add      byte ptr [rax], al
0x18000e18f: add      byte ptr [rax], al
0x18000e191: add      byte ptr [rax], al
0x18000e193: add      byte ptr [rax], al
0x18000e195: add      byte ptr [rax], al
0x18000e197: add      byte ptr [rax], al
0x18000e199: add      byte ptr [rax], al
0x18000e19b: add      byte ptr [rax], al
0x18000e19d: add      byte ptr [rax], al
0x18000e19f: add      byte ptr [rax], al
0x18000e1a1: add      byte ptr [rax], al
0x18000e1a3: add      byte ptr [rax], al
0x18000e1a5: add      byte ptr [rax], al
0x18000e1a7: add      byte ptr [rax], al
0x18000e1a9: add      byte ptr [rax], al
0x18000e1ab: add      byte ptr [rax], al
0x18000e1ad: add      byte ptr [rax], al
0x18000e1af: add      byte ptr [rax], al
0x18000e1b1: add      byte ptr [rax], al
0x18000e1b3: add      byte ptr [rax], al
0x18000e1b5: add      byte ptr [rax], al
0x18000e1b7: add      byte ptr [rax], al
0x18000e1b9: add      byte ptr [rax], al
0x18000e1bb: add      byte ptr [rax], al
0x18000e1bd: add      byte ptr [rax], al
0x18000e1bf: add      byte ptr [rax], al
0x18000e1c1: add      byte ptr [rax], al
0x18000e1c3: add      byte ptr [rax], al
0x18000e1c5: add      byte ptr [rax], al
0x18000e1c7: add      byte ptr [rax], al
0x18000e1c9: add      byte ptr [rax], al
0x18000e1cb: add      byte ptr [rax], al
0x18000e1cd: add      byte ptr [rax], al
0x18000e1cf: add      byte ptr [rax], al
0x18000e1d1: add      byte ptr [rax], al
0x18000e1d3: add      byte ptr [rax], al
0x18000e1d5: add      byte ptr [rax], al
0x18000e1d7: add      byte ptr [rax], al
0x18000e1d9: add      byte ptr [rax], al
0x18000e1db: add      byte ptr [rax], al
0x18000e1dd: add      byte ptr [rax], al
0x18000e1df: add      byte ptr [rax], al
0x18000e1e1: add      byte ptr [rax], al
0x18000e1e3: add      byte ptr [rax], al
0x18000e1e5: add      byte ptr [rax], al
0x18000e1e7: add      byte ptr [rax], al
0x18000e1e9: add      byte ptr [rax], al
0x18000e1eb: add      byte ptr [rax], al
0x18000e1ed: add      byte ptr [rax], al
0x18000e1ef: add      byte ptr [rax], al
0x18000e1f1: add      byte ptr [rax], al
0x18000e1f3: add      byte ptr [rax], al
0x18000e1f5: add      byte ptr [rax], al
0x18000e1f7: add      byte ptr [rax], al
0x18000e1f9: add      byte ptr [rax], al
0x18000e1fb: add      byte ptr [rax], al
0x18000e1fd: add      byte ptr [rax], al
0x18000e1ff: add      byte ptr [rax], al
0x18000e201: add      byte ptr [rax], al
0x18000e203: add      byte ptr [rax], al
0x18000e205: add      byte ptr [rax], al
0x18000e207: add      byte ptr [rax], al
0x18000e209: add      byte ptr [rax], al
0x18000e20b: add      byte ptr [rax], al
0x18000e20d: add      byte ptr [rax], al
0x18000e20f: add      byte ptr [rax], al
0x18000e211: add      byte ptr [rax], al
0x18000e213: add      byte ptr [rax], al
0x18000e215: add      byte ptr [rax], al
0x18000e217: add      byte ptr [rax], al
0x18000e219: add      byte ptr [rax], al
0x18000e21b: add      byte ptr [rax], al
0x18000e21d: add      byte ptr [rax], al
0x18000e21f: add      byte ptr [rax], al
0x18000e221: add      byte ptr [rax], al
0x18000e223: add      byte ptr [rax], al
0x18000e225: add      byte ptr [rax], al
0x18000e227: add      byte ptr [rax], al
0x18000e229: add      byte ptr [rax], al
0x18000e22b: add      byte ptr [rax], al
0x18000e22d: add      byte ptr [rax], al
0x18000e22f: add      byte ptr [rax], al
0x18000e231: add      byte ptr [rax], al
0x18000e233: add      byte ptr [rax], al
0x18000e235: add      byte ptr [rax], al
0x18000e237: add      byte ptr [rax], al
0x18000e239: add      byte ptr [rax], al
0x18000e23b: add      byte ptr [rax], al
0x18000e23d: add      byte ptr [rax], al
0x18000e23f: add      byte ptr [rax], al
0x18000e241: add      byte ptr [rax], al
0x18000e243: add      byte ptr [rax], al
0x18000e245: add      byte ptr [rax], al
0x18000e247: add      byte ptr [rax], al
0x18000e249: add      byte ptr [rax], al
0x18000e24b: add      byte ptr [rax], al
0x18000e24d: add      byte ptr [rax], al
0x18000e24f: add      byte ptr [rax], al
0x18000e251: add      byte ptr [rax], al
0x18000e253: add      byte ptr [rax], al
0x18000e255: add      byte ptr [rax], al
0x18000e257: add      byte ptr [rax], al
0x18000e259: add      byte ptr [rax], al
0x18000e25b: add      byte ptr [rax], al
0x18000e25d: add      byte ptr [rax], al
0x18000e25f: add      byte ptr [rax], al
0x18000e261: add      byte ptr [rax], al
0x18000e263: add      byte ptr [rax], al
0x18000e265: add      byte ptr [rax], al
0x18000e267: add      byte ptr [rax], al
0x18000e269: add      byte ptr [rax], al
0x18000e26b: add      byte ptr [rax], al
0x18000e26d: add      byte ptr [rax], al
0x18000e26f: add      byte ptr [rax], al
0x18000e271: add      byte ptr [rax], al
0x18000e273: add      byte ptr [rax], al
0x18000e275: add      byte ptr [rax], al
0x18000e277: add      byte ptr [rax], al
0x18000e279: add      byte ptr [rax], al
0x18000e27b: add      byte ptr [rax], al
0x18000e27d: add      byte ptr [rax], al
0x18000e27f: add      byte ptr [rax], al
0x18000e281: add      byte ptr [rax], al
0x18000e283: add      byte ptr [rax], al
0x18000e285: add      byte ptr [rax], al
0x18000e287: add      byte ptr [rax], al
0x18000e289: add      byte ptr [rax], al
0x18000e28b: add      byte ptr [rax], al
0x18000e28d: add      byte ptr [rax], al
0x18000e28f: add      byte ptr [rax], al
0x18000e291: add      byte ptr [rax], al
0x18000e293: add      byte ptr [rax], al
0x18000e295: add      byte ptr [rax], al
0x18000e297: add      byte ptr [rax], al
0x18000e299: add      byte ptr [rax], al
0x18000e29b: add      byte ptr [rax], al
0x18000e29d: add      byte ptr [rax], al
0x18000e29f: add      byte ptr [rax], al
0x18000e2a1: add      byte ptr [rax], al
0x18000e2a3: add      byte ptr [rax], al
0x18000e2a5: add      byte ptr [rax], al
0x18000e2a7: add      byte ptr [rax], al
0x18000e2a9: add      byte ptr [rax], al
0x18000e2ab: add      byte ptr [rax], al
0x18000e2ad: add      byte ptr [rax], al
0x18000e2af: add      byte ptr [rax], al
0x18000e2b1: add      byte ptr [rax], al
0x18000e2b3: add      byte ptr [rax], al
0x18000e2b5: add      byte ptr [rax], al
0x18000e2b7: add      byte ptr [rax], al
0x18000e2b9: add      byte ptr [rax], al
0x18000e2bb: add      byte ptr [rax], al
0x18000e2bd: add      byte ptr [rax], al
0x18000e2bf: add      byte ptr [rax], al
0x18000e2c1: add      byte ptr [rax], al
0x18000e2c3: add      byte ptr [rax], al
0x18000e2c5: add      byte ptr [rax], al
0x18000e2c7: add      byte ptr [rax], al
0x18000e2c9: add      byte ptr [rax], al
0x18000e2cb: add      byte ptr [rax], al
0x18000e2cd: add      byte ptr [rax], al
0x18000e2cf: add      byte ptr [rax], al
0x18000e2d1: add      byte ptr [rax], al
0x18000e2d3: add      byte ptr [rax], al
0x18000e2d5: add      byte ptr [rax], al
0x18000e2d7: add      byte ptr [rax], al
0x18000e2d9: add      byte ptr [rax], al
0x18000e2db: add      byte ptr [rax], al
0x18000e2dd: add      byte ptr [rax], al
0x18000e2df: add      byte ptr [rax], al
0x18000e2e1: add      byte ptr [rax], al
0x18000e2e3: add      byte ptr [rax], al
0x18000e2e5: add      byte ptr [rax], al
0x18000e2e7: add      byte ptr [rax], al
0x18000e2e9: add      byte ptr [rax], al
0x18000e2eb: add      byte ptr [rax], al
0x18000e2ed: add      byte ptr [rax], al
0x18000e2ef: add      byte ptr [rax], al
0x18000e2f1: add      byte ptr [rax], al
0x18000e2f3: add      byte ptr [rax], al
0x18000e2f5: add      byte ptr [rax], al
0x18000e2f7: add      byte ptr [rax], al
0x18000e2f9: add      byte ptr [rax], al
0x18000e2fb: add      byte ptr [rax], al
0x18000e2fd: add      byte ptr [rax], al
0x18000e2ff: add      byte ptr [rax], al
0x18000e301: add      byte ptr [rax], al
0x18000e303: add      byte ptr [rax], al
0x18000e305: add      byte ptr [rax], al
0x18000e307: add      byte ptr [rax], al
0x18000e309: add      byte ptr [rax], al
0x18000e30b: add      byte ptr [rax], al
0x18000e30d: add      byte ptr [rax], al
0x18000e30f: add      byte ptr [rax], al
0x18000e311: add      byte ptr [rax], al
0x18000e313: add      byte ptr [rax], al
0x18000e315: add      byte ptr [rax], al
0x18000e317: add      byte ptr [rax], al
0x18000e319: add      byte ptr [rax], al
0x18000e31b: add      byte ptr [rax], al
0x18000e31d: add      byte ptr [rax], al
0x18000e31f: add      byte ptr [rax], al
0x18000e321: add      byte ptr [rax], al
0x18000e323: add      byte ptr [rax], al
0x18000e325: add      byte ptr [rax], al
0x18000e327: add      byte ptr [rax], al
0x18000e329: add      byte ptr [rax], al
0x18000e32b: add      byte ptr [rax], al
0x18000e32d: add      byte ptr [rax], al
0x18000e32f: add      byte ptr [rax], al
0x18000e331: add      byte ptr [rax], al
0x18000e333: add      byte ptr [rax], al
0x18000e335: add      byte ptr [rax], al
0x18000e337: add      byte ptr [rax], al
0x18000e339: add      byte ptr [rax], al
0x18000e33b: add      byte ptr [rax], al
0x18000e33d: add      byte ptr [rax], al
0x18000e33f: add      byte ptr [rax], al
0x18000e341: add      byte ptr [rax], al
0x18000e343: add      byte ptr [rax], al
0x18000e345: add      byte ptr [rax], al
0x18000e347: add      byte ptr [rax], al
0x18000e349: add      byte ptr [rax], al
0x18000e34b: add      byte ptr [rax], al
0x18000e34d: add      byte ptr [rax], al
0x18000e34f: add      byte ptr [rax], al
0x18000e351: add      byte ptr [rax], al
0x18000e353: add      byte ptr [rax], al
0x18000e355: add      byte ptr [rax], al
0x18000e357: add      byte ptr [rax], al
0x18000e359: add      byte ptr [rax], al
0x18000e35b: add      byte ptr [rax], al
0x18000e35d: add      byte ptr [rax], al
0x18000e35f: add      byte ptr [rax], al
0x18000e361: add      byte ptr [rax], al
0x18000e363: add      byte ptr [rax], al
0x18000e365: add      byte ptr [rax], al
0x18000e367: add      byte ptr [rax], al
0x18000e369: add      byte ptr [rax], al
0x18000e36b: add      byte ptr [rax], al
0x18000e36d: add      byte ptr [rax], al
0x18000e36f: add      byte ptr [rax], al
0x18000e371: add      byte ptr [rax], al
0x18000e373: add      byte ptr [rax], al
0x18000e375: add      byte ptr [rax], al
0x18000e377: add      byte ptr [rax], al
0x18000e379: add      byte ptr [rax], al
0x18000e37b: add      byte ptr [rax], al
0x18000e37d: add      byte ptr [rax], al
0x18000e37f: add      byte ptr [rax], al
0x18000e381: add      byte ptr [rax], al
0x18000e383: add      byte ptr [rax], al
0x18000e385: add      byte ptr [rax], al
0x18000e387: add      byte ptr [rax], al
0x18000e389: add      byte ptr [rax], al
0x18000e38b: add      byte ptr [rax], al
0x18000e38d: add      byte ptr [rax], al
0x18000e38f: add      byte ptr [rax], al
0x18000e391: add      byte ptr [rax], al
0x18000e393: add      byte ptr [rax], al
0x18000e395: add      byte ptr [rax], al
0x18000e397: add      byte ptr [rax], al
0x18000e399: add      byte ptr [rax], al
0x18000e39b: add      byte ptr [rax], al
0x18000e39d: add      byte ptr [rax], al
0x18000e39f: add      byte ptr [rax], al
0x18000e3a1: add      byte ptr [rax], al
0x18000e3a3: add      byte ptr [rax], al
0x18000e3a5: add      byte ptr [rax], al
0x18000e3a7: add      byte ptr [rax], al
0x18000e3a9: add      byte ptr [rax], al
0x18000e3ab: add      byte ptr [rax], al
0x18000e3ad: add      byte ptr [rax], al
0x18000e3af: add      byte ptr [rax], al
0x18000e3b1: add      byte ptr [rax], al
0x18000e3b3: add      byte ptr [rax], al
0x18000e3b5: add      byte ptr [rax], al
0x18000e3b7: add      byte ptr [rax], al
0x18000e3b9: add      byte ptr [rax], al
0x18000e3bb: add      byte ptr [rax], al
0x18000e3bd: add      byte ptr [rax], al
0x18000e3bf: add      byte ptr [rax], al
0x18000e3c1: add      byte ptr [rax], al
0x18000e3c3: add      byte ptr [rax], al
0x18000e3c5: add      byte ptr [rax], al
0x18000e3c7: add      byte ptr [rax], al
0x18000e3c9: add      byte ptr [rax], al
0x18000e3cb: add      byte ptr [rax], al
0x18000e3cd: add      byte ptr [rax], al
0x18000e3cf: add      byte ptr [rax], al
0x18000e3d1: add      byte ptr [rax], al
0x18000e3d3: add      byte ptr [rax], al
0x18000e3d5: add      byte ptr [rax], al
0x18000e3d7: add      byte ptr [rax], al
0x18000e3d9: add      byte ptr [rax], al
0x18000e3db: add      byte ptr [rax], al
0x18000e3dd: add      byte ptr [rax], al
0x18000e3df: add      byte ptr [rax], al
0x18000e3e1: add      byte ptr [rax], al
0x18000e3e3: add      byte ptr [rax], al
0x18000e3e5: add      byte ptr [rax], al
0x18000e3e7: add      byte ptr [rax], al
0x18000e3e9: add      byte ptr [rax], al
0x18000e3eb: add      byte ptr [rax], al
0x18000e3ed: add      byte ptr [rax], al
0x18000e3ef: add      byte ptr [rax], al
0x18000e3f1: add      byte ptr [rax], al
0x18000e3f3: add      byte ptr [rax], al
0x18000e3f5: add      byte ptr [rax], al
0x18000e3f7: add      byte ptr [rax], al
0x18000e3f9: add      byte ptr [rax], al
0x18000e3fb: add      byte ptr [rax], al
0x18000e3fd: add      byte ptr [rax], al
0x18000e3ff: add      byte ptr [rax], al
0x18000e401: add      byte ptr [rax], al
0x18000e403: add      byte ptr [rax], al
0x18000e405: add      byte ptr [rax], al
0x18000e407: add      byte ptr [rax], al
0x18000e409: add      byte ptr [rax], al
0x18000e40b: add      byte ptr [rax], al
0x18000e40d: add      byte ptr [rax], al
0x18000e40f: add      byte ptr [rax], al
0x18000e411: add      byte ptr [rax], al
0x18000e413: add      byte ptr [rax], al
0x18000e415: add      byte ptr [rax], al
0x18000e417: add      byte ptr [rax], al
0x18000e419: add      byte ptr [rax], al
0x18000e41b: add      byte ptr [rax], al
0x18000e41d: add      byte ptr [rax], al
0x18000e41f: add      byte ptr [rax], al
0x18000e421: add      byte ptr [rax], al
0x18000e423: add      byte ptr [rax], al
0x18000e425: add      byte ptr [rax], al
0x18000e427: add      byte ptr [rax], al
0x18000e429: add      byte ptr [rax], al
0x18000e42b: add      byte ptr [rax], al
0x18000e42d: add      byte ptr [rax], al
0x18000e42f: add      byte ptr [rax], al
0x18000e431: add      byte ptr [rax], al
0x18000e433: add      byte ptr [rax], al
0x18000e435: add      byte ptr [rax], al
0x18000e437: add      byte ptr [rax], al
0x18000e439: add      byte ptr [rax], al
0x18000e43b: add      byte ptr [rax], al
0x18000e43d: add      byte ptr [rax], al
0x18000e43f: add      byte ptr [rax], al
0x18000e441: add      byte ptr [rax], al
0x18000e443: add      byte ptr [rax], al
0x18000e445: add      byte ptr [rax], al
0x18000e447: add      byte ptr [rax], al
0x18000e449: add      byte ptr [rax], al
0x18000e44b: add      byte ptr [rax], al
0x18000e44d: add      byte ptr [rax], al
0x18000e44f: add      byte ptr [rax], al
0x18000e451: add      byte ptr [rax], al
0x18000e453: add      byte ptr [rax], al
0x18000e455: add      byte ptr [rax], al
0x18000e457: add      byte ptr [rax], al
0x18000e459: add      byte ptr [rax], al
0x18000e45b: add      byte ptr [rax], al
0x18000e45d: add      byte ptr [rax], al
0x18000e45f: add      byte ptr [rax], al
0x18000e461: add      byte ptr [rax], al
0x18000e463: add      byte ptr [rax], al
0x18000e465: add      byte ptr [rax], al
0x18000e467: add      byte ptr [rax], al
0x18000e469: add      byte ptr [rax], al
0x18000e46b: add      byte ptr [rax], al
0x18000e46d: add      byte ptr [rax], al
0x18000e46f: add      byte ptr [rax], al
0x18000e471: add      byte ptr [rax], al
0x18000e473: add      byte ptr [rax], al
0x18000e475: add      byte ptr [rax], al
0x18000e477: add      byte ptr [rax], al
0x18000e479: add      byte ptr [rax], al
0x18000e47b: add      byte ptr [rax], al
0x18000e47d: add      byte ptr [rax], al
0x18000e47f: add      byte ptr [rax], al
0x18000e481: add      byte ptr [rax], al
0x18000e483: add      byte ptr [rax], al
0x18000e485: add      byte ptr [rax], al
0x18000e487: add      byte ptr [rax], al
0x18000e489: add      byte ptr [rax], al
0x18000e48b: add      byte ptr [rax], al
0x18000e48d: add      byte ptr [rax], al
0x18000e48f: add      byte ptr [rax], al
0x18000e491: add      byte ptr [rax], al
0x18000e493: add      byte ptr [rax], al
0x18000e495: add      byte ptr [rax], al
0x18000e497: add      byte ptr [rax], al
0x18000e499: add      byte ptr [rax], al
0x18000e49b: add      byte ptr [rax], al
0x18000e49d: add      byte ptr [rax], al
0x18000e49f: add      byte ptr [rax], al
0x18000e4a1: add      byte ptr [rax], al
0x18000e4a3: add      byte ptr [rax], al
0x18000e4a5: add      byte ptr [rax], al
0x18000e4a7: add      byte ptr [rax], al
0x18000e4a9: add      byte ptr [rax], al
0x18000e4ab: add      byte ptr [rax], al
0x18000e4ad: add      byte ptr [rax], al
0x18000e4af: add      byte ptr [rax], al
0x18000e4b1: add      byte ptr [rax], al
0x18000e4b3: add      byte ptr [rax], al
0x18000e4b5: add      byte ptr [rax], al
0x18000e4b7: add      byte ptr [rax], al
0x18000e4b9: add      byte ptr [rax], al
0x18000e4bb: add      byte ptr [rax], al
0x18000e4bd: add      byte ptr [rax], al
0x18000e4bf: add      byte ptr [rax], al
0x18000e4c1: add      byte ptr [rax], al
0x18000e4c3: add      byte ptr [rax], al
0x18000e4c5: add      byte ptr [rax], al
0x18000e4c7: add      byte ptr [rax], al
0x18000e4c9: add      byte ptr [rax], al
0x18000e4cb: add      byte ptr [rax], al
0x18000e4cd: add      byte ptr [rax], al
0x18000e4cf: add      byte ptr [rax], al
0x18000e4d1: add      byte ptr [rax], al
0x18000e4d3: add      byte ptr [rax], al
0x18000e4d5: add      byte ptr [rax], al
0x18000e4d7: add      byte ptr [rax], al
0x18000e4d9: add      byte ptr [rax], al
0x18000e4db: add      byte ptr [rax], al
0x18000e4dd: add      byte ptr [rax], al
0x18000e4df: add      byte ptr [rax], al
0x18000e4e1: add      byte ptr [rax], al
0x18000e4e3: add      byte ptr [rax], al
0x18000e4e5: add      byte ptr [rax], al
0x18000e4e7: add      byte ptr [rax], al
0x18000e4e9: add      byte ptr [rax], al
0x18000e4eb: add      byte ptr [rax], al
0x18000e4ed: add      byte ptr [rax], al
0x18000e4ef: add      byte ptr [rax], al
0x18000e4f1: add      byte ptr [rax], al
0x18000e4f3: add      byte ptr [rax], al
0x18000e4f5: add      byte ptr [rax], al
0x18000e4f7: add      byte ptr [rax], al
0x18000e4f9: add      byte ptr [rax], al
0x18000e4fb: add      byte ptr [rax], al
0x18000e4fd: add      byte ptr [rax], al
0x18000e4ff: add      byte ptr [rax], al
0x18000e501: add      byte ptr [rax], al
0x18000e503: add      byte ptr [rax], al
0x18000e505: add      byte ptr [rax], al
0x18000e507: add      byte ptr [rax], al
0x18000e509: add      byte ptr [rax], al
0x18000e50b: add      byte ptr [rax], al
0x18000e50d: add      byte ptr [rax], al
0x18000e50f: add      byte ptr [rax], al
0x18000e511: add      byte ptr [rax], al
0x18000e513: add      byte ptr [rax], al
0x18000e515: add      byte ptr [rax], al
0x18000e517: add      byte ptr [rax], al
0x18000e519: add      byte ptr [rax], al
0x18000e51b: add      byte ptr [rax], al
0x18000e51d: add      byte ptr [rax], al
0x18000e51f: add      byte ptr [rax], al
0x18000e521: add      byte ptr [rax], al
0x18000e523: add      byte ptr [rax], al
0x18000e525: add      byte ptr [rax], al
0x18000e527: add      byte ptr [rax], al
0x18000e529: add      byte ptr [rax], al
0x18000e52b: add      byte ptr [rax], al
0x18000e52d: add      byte ptr [rax], al
0x18000e52f: add      byte ptr [rax], al
0x18000e531: add      byte ptr [rax], al
0x18000e533: add      byte ptr [rax], al
0x18000e535: add      byte ptr [rax], al
0x18000e537: add      byte ptr [rax], al
0x18000e539: add      byte ptr [rax], al
0x18000e53b: add      byte ptr [rax], al
0x18000e53d: add      byte ptr [rax], al
0x18000e53f: add      byte ptr [rax], al
0x18000e541: add      byte ptr [rax], al
0x18000e543: add      byte ptr [rax], al
0x18000e545: add      byte ptr [rax], al
0x18000e547: add      byte ptr [rax], al
0x18000e549: add      byte ptr [rax], al
0x18000e54b: add      byte ptr [rax], al
0x18000e54d: add      byte ptr [rax], al
0x18000e54f: add      byte ptr [rax], al
0x18000e551: add      byte ptr [rax], al
0x18000e553: add      byte ptr [rax], al
0x18000e555: add      byte ptr [rax], al
0x18000e557: add      byte ptr [rax], al
0x18000e559: add      byte ptr [rax], al
0x18000e55b: add      byte ptr [rax], al
0x18000e55d: add      byte ptr [rax], al
0x18000e55f: add      byte ptr [rax], al
0x18000e561: add      byte ptr [rax], al
0x18000e563: add      byte ptr [rax], al
0x18000e565: add      byte ptr [rax], al
0x18000e567: add      byte ptr [rax], al
0x18000e569: add      byte ptr [rax], al
0x18000e56b: add      byte ptr [rax], al
0x18000e56d: add      byte ptr [rax], al
0x18000e56f: add      byte ptr [rax], al
0x18000e571: add      byte ptr [rax], al
0x18000e573: add      byte ptr [rax], al
0x18000e575: add      byte ptr [rax], al
0x18000e577: add      byte ptr [rax], al
0x18000e579: add      byte ptr [rax], al
0x18000e57b: add      byte ptr [rax], al
0x18000e57d: add      byte ptr [rax], al
0x18000e57f: add      byte ptr [rax], al
0x18000e581: add      byte ptr [rax], al
0x18000e583: add      byte ptr [rax], al
0x18000e585: add      byte ptr [rax], al
0x18000e587: add      byte ptr [rax], al
0x18000e589: add      byte ptr [rax], al
0x18000e58b: add      byte ptr [rax], al
0x18000e58d: add      byte ptr [rax], al
0x18000e58f: add      byte ptr [rax], al
0x18000e591: add      byte ptr [rax], al
0x18000e593: add      byte ptr [rax], al
0x18000e595: add      byte ptr [rax], al
0x18000e597: add      byte ptr [rax], al
0x18000e599: add      byte ptr [rax], al
0x18000e59b: add      byte ptr [rax], al
0x18000e59d: add      byte ptr [rax], al
0x18000e59f: add      byte ptr [rax], al
0x18000e5a1: add      byte ptr [rax], al
0x18000e5a3: add      byte ptr [rax], al
0x18000e5a5: add      byte ptr [rax], al
0x18000e5a7: add      byte ptr [rax], al
0x18000e5a9: add      byte ptr [rax], al
0x18000e5ab: add      byte ptr [rax], al
0x18000e5ad: add      byte ptr [rax], al
0x18000e5af: add      byte ptr [rax], al
0x18000e5b1: add      byte ptr [rax], al
0x18000e5b3: add      byte ptr [rax], al
0x18000e5b5: add      byte ptr [rax], al
0x18000e5b7: add      byte ptr [rax], al
0x18000e5b9: add      byte ptr [rax], al
0x18000e5bb: add      byte ptr [rax], al
0x18000e5bd: add      byte ptr [rax], al
0x18000e5bf: add      byte ptr [rax], al
0x18000e5c1: add      byte ptr [rax], al
0x18000e5c3: add      byte ptr [rax], al
0x18000e5c5: add      byte ptr [rax], al
0x18000e5c7: add      byte ptr [rax], al
0x18000e5c9: add      byte ptr [rax], al
0x18000e5cb: add      byte ptr [rax], al
0x18000e5cd: add      byte ptr [rax], al
0x18000e5cf: add      byte ptr [rax], al
0x18000e5d1: add      byte ptr [rax], al
0x18000e5d3: add      byte ptr [rax], al
0x18000e5d5: add      byte ptr [rax], al
0x18000e5d7: add      byte ptr [rax], al
0x18000e5d9: add      byte ptr [rax], al
0x18000e5db: add      byte ptr [rax], al
0x18000e5dd: add      byte ptr [rax], al
0x18000e5df: add      byte ptr [rax], al
0x18000e5e1: add      byte ptr [rax], al
0x18000e5e3: add      byte ptr [rax], al
0x18000e5e5: add      byte ptr [rax], al
0x18000e5e7: add      byte ptr [rax], al
0x18000e5e9: add      byte ptr [rax], al
0x18000e5eb: add      byte ptr [rax], al
0x18000e5ed: add      byte ptr [rax], al
0x18000e5ef: add      byte ptr [rax], al
0x18000e5f1: add      byte ptr [rax], al
0x18000e5f3: add      byte ptr [rax], al
0x18000e5f5: add      byte ptr [rax], al
0x18000e5f7: add      byte ptr [rax], al
0x18000e5f9: add      byte ptr [rax], al
0x18000e5fb: add      byte ptr [rax], al
0x18000e5fd: add      byte ptr [rax], al
0x18000e5ff: add      byte ptr [rax], al
0x18000e601: add      byte ptr [rax], al
0x18000e603: add      byte ptr [rax], al
0x18000e605: add      byte ptr [rax], al
0x18000e607: add      byte ptr [rax], al
0x18000e609: add      byte ptr [rax], al
0x18000e60b: add      byte ptr [rax], al
0x18000e60d: add      byte ptr [rax], al
0x18000e60f: add      byte ptr [rax], al
0x18000e611: add      byte ptr [rax], al
0x18000e613: add      byte ptr [rax], al
0x18000e615: add      byte ptr [rax], al
0x18000e617: add      byte ptr [rax], al
0x18000e619: add      byte ptr [rax], al
0x18000e61b: add      byte ptr [rax], al
0x18000e61d: add      byte ptr [rax], al
0x18000e61f: add      byte ptr [rax], al
0x18000e621: add      byte ptr [rax], al
0x18000e623: add      byte ptr [rax], al
0x18000e625: add      byte ptr [rax], al
0x18000e627: add      byte ptr [rax], al
0x18000e629: add      byte ptr [rax], al
0x18000e62b: add      byte ptr [rax], al
0x18000e62d: add      byte ptr [rax], al
0x18000e62f: add      byte ptr [rax], al
0x18000e631: add      byte ptr [rax], al
0x18000e633: add      byte ptr [rax], al
0x18000e635: add      byte ptr [rax], al
0x18000e637: add      byte ptr [rax], al
0x18000e639: add      byte ptr [rax], al
0x18000e63b: add      byte ptr [rax], al
0x18000e63d: add      byte ptr [rax], al
0x18000e63f: add      byte ptr [rax], al
0x18000e641: add      byte ptr [rax], al
0x18000e643: add      byte ptr [rax], al
0x18000e645: add      byte ptr [rax], al
0x18000e647: add      byte ptr [rax], al
0x18000e649: add      byte ptr [rax], al
0x18000e64b: add      byte ptr [rax], al
0x18000e64d: add      byte ptr [rax], al
0x18000e64f: add      byte ptr [rax], al
0x18000e651: add      byte ptr [rax], al
0x18000e653: add      byte ptr [rax], al
0x18000e655: add      byte ptr [rax], al
0x18000e657: add      byte ptr [rax], al
0x18000e659: add      byte ptr [rax], al
0x18000e65b: add      byte ptr [rax], al
0x18000e65d: add      byte ptr [rax], al
0x18000e65f: add      byte ptr [rax], al
0x18000e661: add      byte ptr [rax], al
0x18000e663: add      byte ptr [rax], al
0x18000e665: add      byte ptr [rax], al
0x18000e667: add      byte ptr [rax], al
0x18000e669: add      byte ptr [rax], al
0x18000e66b: add      byte ptr [rax], al
0x18000e66d: add      byte ptr [rax], al
0x18000e66f: add      byte ptr [rax], al
0x18000e671: add      byte ptr [rax], al
0x18000e673: add      byte ptr [rax], al
0x18000e675: add      byte ptr [rax], al
0x18000e677: add      byte ptr [rax], al
0x18000e679: add      byte ptr [rax], al
0x18000e67b: add      byte ptr [rax], al
0x18000e67d: add      byte ptr [rax], al
0x18000e67f: add      byte ptr [rax], al
0x18000e681: add      byte ptr [rax], al
0x18000e683: add      byte ptr [rax], al
0x18000e685: add      byte ptr [rax], al
0x18000e687: add      byte ptr [rax], al
0x18000e689: add      byte ptr [rax], al
0x18000e68b: add      byte ptr [rax], al
0x18000e68d: add      byte ptr [rax], al
0x18000e68f: add      byte ptr [rax], al
0x18000e691: add      byte ptr [rax], al
0x18000e693: add      byte ptr [rax], al
0x18000e695: add      byte ptr [rax], al
0x18000e697: add      byte ptr [rax], al
0x18000e699: add      byte ptr [rax], al
0x18000e69b: add      byte ptr [rax], al
0x18000e69d: add      byte ptr [rax], al
0x18000e69f: add      byte ptr [rax], al
0x18000e6a1: add      byte ptr [rax], al
0x18000e6a3: add      byte ptr [rax], al
0x18000e6a5: add      byte ptr [rax], al
0x18000e6a7: add      byte ptr [rax], al
0x18000e6a9: add      byte ptr [rax], al
0x18000e6ab: add      byte ptr [rax], al
0x18000e6ad: add      byte ptr [rax], al
0x18000e6af: add      byte ptr [rax], al
0x18000e6b1: add      byte ptr [rax], al
0x18000e6b3: add      byte ptr [rax], al
0x18000e6b5: add      byte ptr [rax], al
0x18000e6b7: add      byte ptr [rax], al
0x18000e6b9: add      byte ptr [rax], al
0x18000e6bb: add      byte ptr [rax], al
0x18000e6bd: add      byte ptr [rax], al
0x18000e6bf: add      byte ptr [rax], al
0x18000e6c1: add      byte ptr [rax], al
0x18000e6c3: add      byte ptr [rax], al
0x18000e6c5: add      byte ptr [rax], al
0x18000e6c7: add      byte ptr [rax], al
0x18000e6c9: add      byte ptr [rax], al
0x18000e6cb: add      byte ptr [rax], al
0x18000e6cd: add      byte ptr [rax], al
0x18000e6cf: add      byte ptr [rax], al
0x18000e6d1: add      byte ptr [rax], al
0x18000e6d3: add      byte ptr [rax], al
0x18000e6d5: add      byte ptr [rax], al
0x18000e6d7: add      byte ptr [rax], al
0x18000e6d9: add      byte ptr [rax], al
0x18000e6db: add      byte ptr [rax], al
0x18000e6dd: add      byte ptr [rax], al
0x18000e6df: add      byte ptr [rax], al
0x18000e6e1: add      byte ptr [rax], al
0x18000e6e3: add      byte ptr [rax], al
0x18000e6e5: add      byte ptr [rax], al
0x18000e6e7: add      byte ptr [rax], al
0x18000e6e9: add      byte ptr [rax], al
0x18000e6eb: add      byte ptr [rax], al
0x18000e6ed: add      byte ptr [rax], al
0x18000e6ef: add      byte ptr [rax], al
0x18000e6f1: add      byte ptr [rax], al
0x18000e6f3: add      byte ptr [rax], al
0x18000e6f5: add      byte ptr [rax], al
0x18000e6f7: add      byte ptr [rax], al
0x18000e6f9: add      byte ptr [rax], al
0x18000e6fb: add      byte ptr [rax], al
0x18000e6fd: add      byte ptr [rax], al
0x18000e6ff: add      byte ptr [rax], al
0x18000e701: add      byte ptr [rax], al
0x18000e703: add      byte ptr [rax], al
0x18000e705: add      byte ptr [rax], al
0x18000e707: add      byte ptr [rax], al
0x18000e709: add      byte ptr [rax], al
0x18000e70b: add      byte ptr [rax], al
0x18000e70d: add      byte ptr [rax], al
0x18000e70f: add      byte ptr [rax], al
0x18000e711: add      byte ptr [rax], al
0x18000e713: add      byte ptr [rax], al
0x18000e715: add      byte ptr [rax], al
0x18000e717: add      byte ptr [rax], al
0x18000e719: add      byte ptr [rax], al
0x18000e71b: add      byte ptr [rax], al
0x18000e71d: add      byte ptr [rax], al
0x18000e71f: add      byte ptr [rax], al
0x18000e721: add      byte ptr [rax], al
0x18000e723: add      byte ptr [rax], al
0x18000e725: add      byte ptr [rax], al
0x18000e727: add      byte ptr [rax], al
0x18000e729: add      byte ptr [rax], al
0x18000e72b: add      byte ptr [rax], al
0x18000e72d: add      byte ptr [rax], al
0x18000e72f: add      byte ptr [rax], al
0x18000e731: add      byte ptr [rax], al
0x18000e733: add      byte ptr [rax], al
0x18000e735: add      byte ptr [rax], al
0x18000e737: add      byte ptr [rax], al
0x18000e739: add      byte ptr [rax], al
0x18000e73b: add      byte ptr [rax], al
0x18000e73d: add      byte ptr [rax], al
0x18000e73f: add      byte ptr [rax], al
0x18000e741: add      byte ptr [rax], al
0x18000e743: add      byte ptr [rax], al
0x18000e745: add      byte ptr [rax], al
0x18000e747: add      byte ptr [rax], al
0x18000e749: add      byte ptr [rax], al
0x18000e74b: add      byte ptr [rax], al
0x18000e74d: add      byte ptr [rax], al
0x18000e74f: add      byte ptr [rax], al
0x18000e751: add      byte ptr [rax], al
0x18000e753: add      byte ptr [rax], al
0x18000e755: add      byte ptr [rax], al
0x18000e757: add      byte ptr [rax], al
0x18000e759: add      byte ptr [rax], al
0x18000e75b: add      byte ptr [rax], al
0x18000e75d: add      byte ptr [rax], al
0x18000e75f: add      byte ptr [rax], al
0x18000e761: add      byte ptr [rax], al
0x18000e763: add      byte ptr [rax], al
0x18000e765: add      byte ptr [rax], al
0x18000e767: add      byte ptr [rax], al
0x18000e769: add      byte ptr [rax], al
0x18000e76b: add      byte ptr [rax], al
0x18000e76d: add      byte ptr [rax], al
0x18000e76f: add      byte ptr [rax], al
0x18000e771: add      byte ptr [rax], al
0x18000e773: add      byte ptr [rax], al
0x18000e775: add      byte ptr [rax], al
0x18000e777: add      byte ptr [rax], al
0x18000e779: add      byte ptr [rax], al
0x18000e77b: add      byte ptr [rax], al
0x18000e77d: add      byte ptr [rax], al
0x18000e77f: add      byte ptr [rax], al
0x18000e781: add      byte ptr [rax], al
0x18000e783: add      byte ptr [rax], al
0x18000e785: add      byte ptr [rax], al
0x18000e787: add      byte ptr [rax], al
0x18000e789: add      byte ptr [rax], al
0x18000e78b: add      byte ptr [rax], al
0x18000e78d: add      byte ptr [rax], al
0x18000e78f: add      byte ptr [rax], al
0x18000e791: add      byte ptr [rax], al
0x18000e793: add      byte ptr [rax], al
0x18000e795: add      byte ptr [rax], al
0x18000e797: add      byte ptr [rax], al
0x18000e799: add      byte ptr [rax], al
0x18000e79b: add      byte ptr [rax], al
0x18000e79d: add      byte ptr [rax], al
0x18000e79f: add      byte ptr [rax], al
0x18000e7a1: add      byte ptr [rax], al
0x18000e7a3: add      byte ptr [rax], al
0x18000e7a5: add      byte ptr [rax], al
0x18000e7a7: add      byte ptr [rax], al
0x18000e7a9: add      byte ptr [rax], al
0x18000e7ab: add      byte ptr [rax], al
0x18000e7ad: add      byte ptr [rax], al
0x18000e7af: add      byte ptr [rax], al
0x18000e7b1: add      byte ptr [rax], al
0x18000e7b3: add      byte ptr [rax], al
0x18000e7b5: add      byte ptr [rax], al
0x18000e7b7: add      byte ptr [rax], al
0x18000e7b9: add      byte ptr [rax], al
0x18000e7bb: add      byte ptr [rax], al
0x18000e7bd: add      byte ptr [rax], al
0x18000e7bf: add      byte ptr [rax], al
0x18000e7c1: add      byte ptr [rax], al
0x18000e7c3: add      byte ptr [rax], al
0x18000e7c5: add      byte ptr [rax], al
0x18000e7c7: add      byte ptr [rax], al
0x18000e7c9: add      byte ptr [rax], al
0x18000e7cb: add      byte ptr [rax], al
0x18000e7cd: add      byte ptr [rax], al
0x18000e7cf: add      byte ptr [rax], al
0x18000e7d1: add      byte ptr [rax], al
0x18000e7d3: add      byte ptr [rax], al
0x18000e7d5: add      byte ptr [rax], al
0x18000e7d7: add      byte ptr [rax], al
0x18000e7d9: add      byte ptr [rax], al
0x18000e7db: add      byte ptr [rax], al
0x18000e7dd: add      byte ptr [rax], al
0x18000e7df: add      byte ptr [rax], al
0x18000e7e1: add      byte ptr [rax], al
0x18000e7e3: add      byte ptr [rax], al
0x18000e7e5: add      byte ptr [rax], al
0x18000e7e7: add      byte ptr [rax], al
0x18000e7e9: add      byte ptr [rax], al
0x18000e7eb: add      byte ptr [rax], al
0x18000e7ed: add      byte ptr [rax], al
0x18000e7ef: add      byte ptr [rax], al
0x18000e7f1: add      byte ptr [rax], al
0x18000e7f3: add      byte ptr [rax], al
0x18000e7f5: add      byte ptr [rax], al
0x18000e7f7: add      byte ptr [rax], al
0x18000e7f9: add      byte ptr [rax], al
0x18000e7fb: add      byte ptr [rax], al
0x18000e7fd: add      byte ptr [rax], al
0x18000e7ff: add      byte ptr [rax], al
0x18000e801: add      byte ptr [rax], al
0x18000e803: add      byte ptr [rax], al
0x18000e805: add      byte ptr [rax], al
0x18000e807: add      byte ptr [rax], al
0x18000e809: add      byte ptr [rax], al
0x18000e80b: add      byte ptr [rax], al
0x18000e80d: add      byte ptr [rax], al
0x18000e80f: add      byte ptr [rax], al
0x18000e811: add      byte ptr [rax], al
0x18000e813: add      byte ptr [rax], al
0x18000e815: add      byte ptr [rax], al
0x18000e817: add      byte ptr [rax], al
0x18000e819: add      byte ptr [rax], al
0x18000e81b: add      byte ptr [rax], al
0x18000e81d: add      byte ptr [rax], al
0x18000e81f: add      byte ptr [rax], al
0x18000e821: add      byte ptr [rax], al
0x18000e823: add      byte ptr [rax], al
0x18000e825: add      byte ptr [rax], al
0x18000e827: add      byte ptr [rax], al
0x18000e829: add      byte ptr [rax], al
0x18000e82b: add      byte ptr [rax], al
0x18000e82d: add      byte ptr [rax], al
0x18000e82f: add      byte ptr [rax], al
0x18000e831: add      byte ptr [rax], al
0x18000e833: add      byte ptr [rax], al
0x18000e835: add      byte ptr [rax], al
0x18000e837: add      byte ptr [rax], al
0x18000e839: add      byte ptr [rax], al
0x18000e83b: add      byte ptr [rax], al
0x18000e83d: add      byte ptr [rax], al
0x18000e83f: add      byte ptr [rax], al
0x18000e841: add      byte ptr [rax], al
0x18000e843: add      byte ptr [rax], al
0x18000e845: add      byte ptr [rax], al
0x18000e847: add      byte ptr [rax], al
0x18000e849: add      byte ptr [rax], al
0x18000e84b: add      byte ptr [rax], al
0x18000e84d: add      byte ptr [rax], al
0x18000e84f: add      byte ptr [rax], al
0x18000e851: add      byte ptr [rax], al
0x18000e853: add      byte ptr [rax], al
0x18000e855: add      byte ptr [rax], al
0x18000e857: add      byte ptr [rax], al
0x18000e859: add      byte ptr [rax], al
0x18000e85b: add      byte ptr [rax], al
0x18000e85d: add      byte ptr [rax], al
0x18000e85f: add      byte ptr [rax], al
0x18000e861: add      byte ptr [rax], al
0x18000e863: add      byte ptr [rax], al
0x18000e865: add      byte ptr [rax], al
0x18000e867: add      byte ptr [rax], al
0x18000e869: add      byte ptr [rax], al
0x18000e86b: add      byte ptr [rax], al
0x18000e86d: add      byte ptr [rax], al
0x18000e86f: add      byte ptr [rax], al
0x18000e871: add      byte ptr [rax], al
0x18000e873: add      byte ptr [rax], al
0x18000e875: add      byte ptr [rax], al
0x18000e877: add      byte ptr [rax], al
0x18000e879: add      byte ptr [rax], al
0x18000e87b: add      byte ptr [rax], al
0x18000e87d: add      byte ptr [rax], al
0x18000e87f: add      byte ptr [rax], al
0x18000e881: add      byte ptr [rax], al
0x18000e883: add      byte ptr [rax], al
0x18000e885: add      byte ptr [rax], al
0x18000e887: add      byte ptr [rax], al
0x18000e889: add      byte ptr [rax], al
0x18000e88b: add      byte ptr [rax], al
0x18000e88d: add      byte ptr [rax], al
0x18000e88f: add      byte ptr [rax], al
0x18000e891: add      byte ptr [rax], al
0x18000e893: add      byte ptr [rax], al
0x18000e895: add      byte ptr [rax], al
0x18000e897: add      byte ptr [rax], al
0x18000e899: add      byte ptr [rax], al
0x18000e89b: add      byte ptr [rax], al
0x18000e89d: add      byte ptr [rax], al
0x18000e89f: add      byte ptr [rax], al
0x18000e8a1: add      byte ptr [rax], al
0x18000e8a3: add      byte ptr [rax], al
0x18000e8a5: add      byte ptr [rax], al
0x18000e8a7: add      byte ptr [rax], al
0x18000e8a9: add      byte ptr [rax], al
0x18000e8ab: add      byte ptr [rax], al
0x18000e8ad: add      byte ptr [rax], al
0x18000e8af: add      byte ptr [rax], al
0x18000e8b1: add      byte ptr [rax], al
0x18000e8b3: add      byte ptr [rax], al
0x18000e8b5: add      byte ptr [rax], al
0x18000e8b7: add      byte ptr [rax], al
0x18000e8b9: add      byte ptr [rax], al
0x18000e8bb: add      byte ptr [rax], al
0x18000e8bd: add      byte ptr [rax], al
0x18000e8bf: add      byte ptr [rax], al
0x18000e8c1: add      byte ptr [rax], al
0x18000e8c3: add      byte ptr [rax], al
0x18000e8c5: add      byte ptr [rax], al
0x18000e8c7: add      byte ptr [rax], al
0x18000e8c9: add      byte ptr [rax], al
0x18000e8cb: add      byte ptr [rax], al
0x18000e8cd: add      byte ptr [rax], al
0x18000e8cf: add      byte ptr [rax], al
0x18000e8d1: add      byte ptr [rax], al
0x18000e8d3: add      byte ptr [rax], al
0x18000e8d5: add      byte ptr [rax], al
0x18000e8d7: add      byte ptr [rax], al
0x18000e8d9: add      byte ptr [rax], al
0x18000e8db: add      byte ptr [rax], al
0x18000e8dd: add      byte ptr [rax], al
0x18000e8df: add      byte ptr [rax], al
0x18000e8e1: add      byte ptr [rax], al
0x18000e8e3: add      byte ptr [rax], al
0x18000e8e5: add      byte ptr [rax], al
0x18000e8e7: add      byte ptr [rax], al
0x18000e8e9: add      byte ptr [rax], al
0x18000e8eb: add      byte ptr [rax], al
0x18000e8ed: add      byte ptr [rax], al
0x18000e8ef: add      byte ptr [rax], al
0x18000e8f1: add      byte ptr [rax], al
0x18000e8f3: add      byte ptr [rax], al
0x18000e8f5: add      byte ptr [rax], al
0x18000e8f7: add      byte ptr [rax], al
0x18000e8f9: add      byte ptr [rax], al
0x18000e8fb: add      byte ptr [rax], al
0x18000e8fd: add      byte ptr [rax], al
0x18000e8ff: add      byte ptr [rax], al
0x18000e901: add      byte ptr [rax], al
0x18000e903: add      byte ptr [rax], al
0x18000e905: add      byte ptr [rax], al
0x18000e907: add      byte ptr [rax], al
0x18000e909: add      byte ptr [rax], al
0x18000e90b: add      byte ptr [rax], al
0x18000e90d: add      byte ptr [rax], al
0x18000e90f: add      byte ptr [rax], al
0x18000e911: add      byte ptr [rax], al
0x18000e913: add      byte ptr [rax], al
0x18000e915: add      byte ptr [rax], al
0x18000e917: add      byte ptr [rax], al
0x18000e919: add      byte ptr [rax], al
0x18000e91b: add      byte ptr [rax], al
0x18000e91d: add      byte ptr [rax], al
0x18000e91f: add      byte ptr [rax], al
0x18000e921: add      byte ptr [rax], al
0x18000e923: add      byte ptr [rax], al
0x18000e925: add      byte ptr [rax], al
0x18000e927: add      byte ptr [rax], al
0x18000e929: add      byte ptr [rax], al
0x18000e92b: add      byte ptr [rax], al
0x18000e92d: add      byte ptr [rax], al
0x18000e92f: add      byte ptr [rax], al
0x18000e931: add      byte ptr [rax], al
0x18000e933: add      byte ptr [rax], al
0x18000e935: add      byte ptr [rax], al
0x18000e937: add      byte ptr [rax], al
0x18000e939: add      byte ptr [rax], al
0x18000e93b: add      byte ptr [rax], al
0x18000e93d: add      byte ptr [rax], al
0x18000e93f: add      byte ptr [rax], al
0x18000e941: add      byte ptr [rax], al
0x18000e943: add      byte ptr [rax], al
0x18000e945: add      byte ptr [rax], al
0x18000e947: add      byte ptr [rax], al
0x18000e949: add      byte ptr [rax], al
0x18000e94b: add      byte ptr [rax], al
0x18000e94d: add      byte ptr [rax], al
0x18000e94f: add      byte ptr [rax], al
0x18000e951: add      byte ptr [rax], al
0x18000e953: add      byte ptr [rax], al
0x18000e955: add      byte ptr [rax], al
0x18000e957: add      byte ptr [rax], al
0x18000e959: add      byte ptr [rax], al
0x18000e95b: add      byte ptr [rax], al
0x18000e95d: add      byte ptr [rax], al
0x18000e95f: add      byte ptr [rax], al
0x18000e961: add      byte ptr [rax], al
0x18000e963: add      byte ptr [rax], al
0x18000e965: add      byte ptr [rax], al
0x18000e967: add      byte ptr [rax], al
0x18000e969: add      byte ptr [rax], al
0x18000e96b: add      byte ptr [rax], al
0x18000e96d: add      byte ptr [rax], al
0x18000e96f: add      byte ptr [rax], al
0x18000e971: add      byte ptr [rax], al
0x18000e973: add      byte ptr [rax], al
0x18000e975: add      byte ptr [rax], al
0x18000e977: add      byte ptr [rax], al
0x18000e979: add      byte ptr [rax], al
0x18000e97b: add      byte ptr [rax], al
0x18000e97d: add      byte ptr [rax], al
0x18000e97f: add      byte ptr [rax], al
0x18000e981: add      byte ptr [rax], al
0x18000e983: add      byte ptr [rax], al
0x18000e985: add      byte ptr [rax], al
0x18000e987: add      byte ptr [rax], al
0x18000e989: add      byte ptr [rax], al
0x18000e98b: add      byte ptr [rax], al
0x18000e98d: add      byte ptr [rax], al
0x18000e98f: add      byte ptr [rax], al
0x18000e991: add      byte ptr [rax], al
0x18000e993: add      byte ptr [rax], al
0x18000e995: add      byte ptr [rax], al
0x18000e997: add      byte ptr [rax], al
0x18000e999: add      byte ptr [rax], al
0x18000e99b: add      byte ptr [rax], al
0x18000e99d: add      byte ptr [rax], al
0x18000e99f: add      byte ptr [rax], al
0x18000e9a1: add      byte ptr [rax], al
0x18000e9a3: add      byte ptr [rax], al
0x18000e9a5: add      byte ptr [rax], al
0x18000e9a7: add      byte ptr [rax], al
0x18000e9a9: add      byte ptr [rax], al
0x18000e9ab: add      byte ptr [rax], al
0x18000e9ad: add      byte ptr [rax], al
0x18000e9af: add      byte ptr [rax], al
0x18000e9b1: add      byte ptr [rax], al
0x18000e9b3: add      byte ptr [rax], al
0x18000e9b5: add      byte ptr [rax], al
0x18000e9b7: add      byte ptr [rax], al
0x18000e9b9: add      byte ptr [rax], al
0x18000e9bb: add      byte ptr [rax], al
0x18000e9bd: add      byte ptr [rax], al
0x18000e9bf: add      byte ptr [rax], al
0x18000e9c1: add      byte ptr [rax], al
0x18000e9c3: add      byte ptr [rax], al
0x18000e9c5: add      byte ptr [rax], al
0x18000e9c7: add      byte ptr [rax], al
0x18000e9c9: add      byte ptr [rax], al
0x18000e9cb: add      byte ptr [rax], al
0x18000e9cd: add      byte ptr [rax], al
0x18000e9cf: add      byte ptr [rax], al
0x18000e9d1: add      byte ptr [rax], al
0x18000e9d3: add      byte ptr [rax], al
0x18000e9d5: add      byte ptr [rax], al
0x18000e9d7: add      byte ptr [rax], al
0x18000e9d9: add      byte ptr [rax], al
0x18000e9db: add      byte ptr [rax], al
0x18000e9dd: add      byte ptr [rax], al
0x18000e9df: add      byte ptr [rax], al
0x18000e9e1: add      byte ptr [rax], al
0x18000e9e3: add      byte ptr [rax], al
0x18000e9e5: add      byte ptr [rax], al
0x18000e9e7: add      byte ptr [rax], al
0x18000e9e9: add      byte ptr [rax], al
0x18000e9eb: add      byte ptr [rax], al
0x18000e9ed: add      byte ptr [rax], al
0x18000e9ef: add      byte ptr [rax], al
0x18000e9f1: add      byte ptr [rax], al
0x18000e9f3: add      byte ptr [rax], al
0x18000e9f5: add      byte ptr [rax], al
0x18000e9f7: add      byte ptr [rax], al
0x18000e9f9: add      byte ptr [rax], al
0x18000e9fb: add      byte ptr [rax], al
0x18000e9fd: add      byte ptr [rax], al
0x18000e9ff: add      byte ptr [rax], al
0x18000ea01: add      byte ptr [rax], al
0x18000ea03: add      byte ptr [rax], al
0x18000ea05: add      byte ptr [rax], al
0x18000ea07: add      byte ptr [rax], al
0x18000ea09: add      byte ptr [rax], al
0x18000ea0b: add      byte ptr [rax], al
0x18000ea0d: add      byte ptr [rax], al
0x18000ea0f: add      byte ptr [rax], al
0x18000ea11: add      byte ptr [rax], al
0x18000ea13: add      byte ptr [rax], al
0x18000ea15: add      byte ptr [rax], al
0x18000ea17: add      byte ptr [rax], al
0x18000ea19: add      byte ptr [rax], al
0x18000ea1b: add      byte ptr [rax], al
0x18000ea1d: add      byte ptr [rax], al
0x18000ea1f: add      byte ptr [rax], al
0x18000ea21: add      byte ptr [rax], al
0x18000ea23: add      byte ptr [rax], al
0x18000ea25: add      byte ptr [rax], al
0x18000ea27: add      byte ptr [rax], al
0x18000ea29: add      byte ptr [rax], al
0x18000ea2b: add      byte ptr [rax], al
0x18000ea2d: add      byte ptr [rax], al
0x18000ea2f: add      byte ptr [rax], al
0x18000ea31: add      byte ptr [rax], al
0x18000ea33: add      byte ptr [rax], al
0x18000ea35: add      byte ptr [rax], al
0x18000ea37: add      byte ptr [rax], al
0x18000ea39: add      byte ptr [rax], al
0x18000ea3b: add      byte ptr [rax], al
0x18000ea3d: add      byte ptr [rax], al
0x18000ea3f: add      byte ptr [rax], al
0x18000ea41: add      byte ptr [rax], al
0x18000ea43: add      byte ptr [rax], al
0x18000ea45: add      byte ptr [rax], al
0x18000ea47: add      byte ptr [rax], al
0x18000ea49: add      byte ptr [rax], al
0x18000ea4b: add      byte ptr [rax], al
0x18000ea4d: add      byte ptr [rax], al
0x18000ea4f: add      byte ptr [rax], al
0x18000ea51: add      byte ptr [rax], al
0x18000ea53: add      byte ptr [rax], al
0x18000ea55: add      byte ptr [rax], al
0x18000ea57: add      byte ptr [rax], al
0x18000ea59: add      byte ptr [rax], al
0x18000ea5b: add      byte ptr [rax], al
0x18000ea5d: add      byte ptr [rax], al
0x18000ea5f: add      byte ptr [rax], al
0x18000ea61: add      byte ptr [rax], al
0x18000ea63: add      byte ptr [rax], al
0x18000ea65: add      byte ptr [rax], al
0x18000ea67: add      byte ptr [rax], al
0x18000ea69: add      byte ptr [rax], al
0x18000ea6b: add      byte ptr [rax], al
0x18000ea6d: add      byte ptr [rax], al
0x18000ea6f: add      byte ptr [rax], al
0x18000ea71: add      byte ptr [rax], al
0x18000ea73: add      byte ptr [rax], al
0x18000ea75: add      byte ptr [rax], al
0x18000ea77: add      byte ptr [rax], al
0x18000ea79: add      byte ptr [rax], al
0x18000ea7b: add      byte ptr [rax], al
0x18000ea7d: add      byte ptr [rax], al
0x18000ea7f: add      byte ptr [rax], al
0x18000ea81: add      byte ptr [rax], al
0x18000ea83: add      byte ptr [rax], al
0x18000ea85: add      byte ptr [rax], al
0x18000ea87: add      byte ptr [rax], al
0x18000ea89: add      byte ptr [rax], al
0x18000ea8b: add      byte ptr [rax], al
0x18000ea8d: add      byte ptr [rax], al
0x18000ea8f: add      byte ptr [rax], al
0x18000ea91: add      byte ptr [rax], al
0x18000ea93: add      byte ptr [rax], al
0x18000ea95: add      byte ptr [rax], al
0x18000ea97: add      byte ptr [rax], al
0x18000ea99: add      byte ptr [rax], al
0x18000ea9b: add      byte ptr [rax], al
0x18000ea9d: add      byte ptr [rax], al
0x18000ea9f: add      byte ptr [rax], al
0x18000eaa1: add      byte ptr [rax], al
0x18000eaa3: add      byte ptr [rax], al
0x18000eaa5: add      byte ptr [rax], al
0x18000eaa7: add      byte ptr [rax], al
0x18000eaa9: add      byte ptr [rax], al
0x18000eaab: add      byte ptr [rax], al
0x18000eaad: add      byte ptr [rax], al
0x18000eaaf: add      byte ptr [rax], al
0x18000eab1: add      byte ptr [rax], al
0x18000eab3: add      byte ptr [rax], al
0x18000eab5: add      byte ptr [rax], al
0x18000eab7: add      byte ptr [rax], al
0x18000eab9: add      byte ptr [rax], al
0x18000eabb: add      byte ptr [rax], al
0x18000eabd: add      byte ptr [rax], al
0x18000eabf: add      byte ptr [rax], al
0x18000eac1: add      byte ptr [rax], al
0x18000eac3: add      byte ptr [rax], al
0x18000eac5: add      byte ptr [rax], al
0x18000eac7: add      byte ptr [rax], al
0x18000eac9: add      byte ptr [rax], al
0x18000eacb: add      byte ptr [rax], al
0x18000eacd: add      byte ptr [rax], al
0x18000eacf: add      byte ptr [rax], al
0x18000ead1: add      byte ptr [rax], al
0x18000ead3: add      byte ptr [rax], al
0x18000ead5: add      byte ptr [rax], al
0x18000ead7: add      byte ptr [rax], al
0x18000ead9: add      byte ptr [rax], al
0x18000eadb: add      byte ptr [rax], al
0x18000eadd: add      byte ptr [rax], al
0x18000eadf: add      byte ptr [rax], al
0x18000eae1: add      byte ptr [rax], al
0x18000eae3: add      byte ptr [rax], al
0x18000eae5: add      byte ptr [rax], al
0x18000eae7: add      byte ptr [rax], al
0x18000eae9: add      byte ptr [rax], al
0x18000eaeb: add      byte ptr [rax], al
0x18000eaed: add      byte ptr [rax], al
0x18000eaef: add      byte ptr [rax], al
0x18000eaf1: add      byte ptr [rax], al
0x18000eaf3: add      byte ptr [rax], al
0x18000eaf5: add      byte ptr [rax], al
0x18000eaf7: add      byte ptr [rax], al
0x18000eaf9: add      byte ptr [rax], al
0x18000eafb: add      byte ptr [rax], al
0x18000eafd: add      byte ptr [rax], al
0x18000eaff: add      byte ptr [rax], al
0x18000eb01: add      byte ptr [rax], al
0x18000eb03: add      byte ptr [rax], al
0x18000eb05: add      byte ptr [rax], al
0x18000eb07: add      byte ptr [rax], al
0x18000eb09: add      byte ptr [rax], al
0x18000eb0b: add      byte ptr [rax], al
0x18000eb0d: add      byte ptr [rax], al
0x18000eb0f: add      byte ptr [rax], al
0x18000eb11: add      byte ptr [rax], al
0x18000eb13: add      byte ptr [rax], al
0x18000eb15: add      byte ptr [rax], al
0x18000eb17: add      byte ptr [rax], al
0x18000eb19: add      byte ptr [rax], al
0x18000eb1b: add      byte ptr [rax], al
0x18000eb1d: add      byte ptr [rax], al
0x18000eb1f: add      byte ptr [rax], al
0x18000eb21: add      byte ptr [rax], al
0x18000eb23: add      byte ptr [rax], al
0x18000eb25: add      byte ptr [rax], al
0x18000eb27: add      byte ptr [rax], al
0x18000eb29: add      byte ptr [rax], al
0x18000eb2b: add      byte ptr [rax], al
0x18000eb2d: add      byte ptr [rax], al
0x18000eb2f: add      byte ptr [rax], al
0x18000eb31: add      byte ptr [rax], al
0x18000eb33: add      byte ptr [rax], al
0x18000eb35: add      byte ptr [rax], al
0x18000eb37: add      byte ptr [rax], al
0x18000eb39: add      byte ptr [rax], al
0x18000eb3b: add      byte ptr [rax], al
0x18000eb3d: add      byte ptr [rax], al
0x18000eb3f: add      byte ptr [rax], al
0x18000eb41: add      byte ptr [rax], al
0x18000eb43: add      byte ptr [rax], al
0x18000eb45: add      byte ptr [rax], al
0x18000eb47: add      byte ptr [rax], al
0x18000eb49: add      byte ptr [rax], al
0x18000eb4b: add      byte ptr [rax], al
0x18000eb4d: add      byte ptr [rax], al
0x18000eb4f: add      byte ptr [rax], al
0x18000eb51: add      byte ptr [rax], al
0x18000eb53: add      byte ptr [rax], al
0x18000eb55: add      byte ptr [rax], al
0x18000eb57: add      byte ptr [rax], al
0x18000eb59: add      byte ptr [rax], al
0x18000eb5b: add      byte ptr [rax], al
0x18000eb5d: add      byte ptr [rax], al
0x18000eb5f: add      byte ptr [rax], al
0x18000eb61: add      byte ptr [rax], al
0x18000eb63: add      byte ptr [rax], al
0x18000eb65: add      byte ptr [rax], al
0x18000eb67: add      byte ptr [rax], al
0x18000eb69: add      byte ptr [rax], al
0x18000eb6b: add      byte ptr [rax], al
0x18000eb6d: add      byte ptr [rax], al
0x18000eb6f: add      byte ptr [rax], al
0x18000eb71: add      byte ptr [rax], al
0x18000eb73: add      byte ptr [rax], al
0x18000eb75: add      byte ptr [rax], al
0x18000eb77: add      byte ptr [rax], al
0x18000eb79: add      byte ptr [rax], al
0x18000eb7b: add      byte ptr [rax], al
0x18000eb7d: add      byte ptr [rax], al
0x18000eb7f: add      byte ptr [rax], al
0x18000eb81: add      byte ptr [rax], al
0x18000eb83: add      byte ptr [rax], al
0x18000eb85: add      byte ptr [rax], al
0x18000eb87: add      byte ptr [rax], al
0x18000eb89: add      byte ptr [rax], al
0x18000eb8b: add      byte ptr [rax], al
0x18000eb8d: add      byte ptr [rax], al
0x18000eb8f: add      byte ptr [rax], al
0x18000eb91: add      byte ptr [rax], al
0x18000eb93: add      byte ptr [rax], al
0x18000eb95: add      byte ptr [rax], al
0x18000eb97: add      byte ptr [rax], al
0x18000eb99: add      byte ptr [rax], al
0x18000eb9b: add      byte ptr [rax], al
0x18000eb9d: add      byte ptr [rax], al
0x18000eb9f: add      byte ptr [rax], al
0x18000eba1: add      byte ptr [rax], al
0x18000eba3: add      byte ptr [rax], al
0x18000eba5: add      byte ptr [rax], al
0x18000eba7: add      byte ptr [rax], al
0x18000eba9: add      byte ptr [rax], al
0x18000ebab: add      byte ptr [rax], al
0x18000ebad: add      byte ptr [rax], al
0x18000ebaf: add      byte ptr [rax], al
0x18000ebb1: add      byte ptr [rax], al
0x18000ebb3: add      byte ptr [rax], al
0x18000ebb5: add      byte ptr [rax], al
0x18000ebb7: add      byte ptr [rax], al
0x18000ebb9: add      byte ptr [rax], al
0x18000ebbb: add      byte ptr [rax], al
0x18000ebbd: add      byte ptr [rax], al
0x18000ebbf: add      byte ptr [rax], al
0x18000ebc1: add      byte ptr [rax], al
0x18000ebc3: add      byte ptr [rax], al
0x18000ebc5: add      byte ptr [rax], al
0x18000ebc7: add      byte ptr [rax], al
0x18000ebc9: add      byte ptr [rax], al
0x18000ebcb: add      byte ptr [rax], al
0x18000ebcd: add      byte ptr [rax], al
0x18000ebcf: add      byte ptr [rax], al
0x18000ebd1: add      byte ptr [rax], al
0x18000ebd3: add      byte ptr [rax], al
0x18000ebd5: add      byte ptr [rax], al
0x18000ebd7: add      byte ptr [rax], al
0x18000ebd9: add      byte ptr [rax], al
0x18000ebdb: add      byte ptr [rax], al
0x18000ebdd: add      byte ptr [rax], al
0x18000ebdf: add      byte ptr [rax], al
0x18000ebe1: add      byte ptr [rax], al
0x18000ebe3: add      byte ptr [rax], al
0x18000ebe5: add      byte ptr [rax], al
0x18000ebe7: add      byte ptr [rax], al
0x18000ebe9: add      byte ptr [rax], al
0x18000ebeb: add      byte ptr [rax], al
0x18000ebed: add      byte ptr [rax], al
0x18000ebef: add      byte ptr [rax], al
0x18000ebf1: add      byte ptr [rax], al
0x18000ebf3: add      byte ptr [rax], al
0x18000ebf5: add      byte ptr [rax], al
0x18000ebf7: add      byte ptr [rax], al
0x18000ebf9: add      byte ptr [rax], al
0x18000ebfb: add      byte ptr [rax], al
0x18000ebfd: add      byte ptr [rax], al
0x18000ebff: add      byte ptr [rax], al
0x18000ec01: add      byte ptr [rax], al
0x18000ec03: add      byte ptr [rax], al
0x18000ec05: add      byte ptr [rax], al
0x18000ec07: add      byte ptr [rax], al
0x18000ec09: add      byte ptr [rax], al
0x18000ec0b: add      byte ptr [rax], al
0x18000ec0d: add      byte ptr [rax], al
0x18000ec0f: add      byte ptr [rax], al
0x18000ec11: add      byte ptr [rax], al
0x18000ec13: add      byte ptr [rax], al
0x18000ec15: add      byte ptr [rax], al
0x18000ec17: add      byte ptr [rax], al
0x18000ec19: add      byte ptr [rax], al
0x18000ec1b: add      byte ptr [rax], al
0x18000ec1d: add      byte ptr [rax], al
0x18000ec1f: add      byte ptr [rax], al
0x18000ec21: add      byte ptr [rax], al
0x18000ec23: add      byte ptr [rax], al
0x18000ec25: add      byte ptr [rax], al
0x18000ec27: add      byte ptr [rax], al
0x18000ec29: add      byte ptr [rax], al
0x18000ec2b: add      byte ptr [rax], al
0x18000ec2d: add      byte ptr [rax], al
0x18000ec2f: add      byte ptr [rax], al
0x18000ec31: add      byte ptr [rax], al
0x18000ec33: add      byte ptr [rax], al
0x18000ec35: add      byte ptr [rax], al
0x18000ec37: add      byte ptr [rax], al
0x18000ec39: add      byte ptr [rax], al
0x18000ec3b: add      byte ptr [rax], al
0x18000ec3d: add      byte ptr [rax], al
0x18000ec3f: add      byte ptr [rax], al
0x18000ec41: add      byte ptr [rax], al
0x18000ec43: add      byte ptr [rax], al
0x18000ec45: add      byte ptr [rax], al
0x18000ec47: add      byte ptr [rax], al
0x18000ec49: add      byte ptr [rax], al
0x18000ec4b: add      byte ptr [rax], al
0x18000ec4d: add      byte ptr [rax], al
0x18000ec4f: add      byte ptr [rax], al
0x18000ec51: add      byte ptr [rax], al
0x18000ec53: add      byte ptr [rax], al
0x18000ec55: add      byte ptr [rax], al
0x18000ec57: add      byte ptr [rax], al
0x18000ec59: add      byte ptr [rax], al
0x18000ec5b: add      byte ptr [rax], al
0x18000ec5d: add      byte ptr [rax], al
0x18000ec5f: add      byte ptr [rax], al
0x18000ec61: add      byte ptr [rax], al
0x18000ec63: add      byte ptr [rax], al
0x18000ec65: add      byte ptr [rax], al
0x18000ec67: add      byte ptr [rax], al
0x18000ec69: add      byte ptr [rax], al
0x18000ec6b: add      byte ptr [rax], al
0x18000ec6d: add      byte ptr [rax], al
0x18000ec6f: add      byte ptr [rax], al
0x18000ec71: add      byte ptr [rax], al
0x18000ec73: add      byte ptr [rax], al
0x18000ec75: add      byte ptr [rax], al
0x18000ec77: add      byte ptr [rax], al
0x18000ec79: add      byte ptr [rax], al
0x18000ec7b: add      byte ptr [rax], al
0x18000ec7d: add      byte ptr [rax], al
0x18000ec7f: add      byte ptr [rax], al
0x18000ec81: add      byte ptr [rax], al
0x18000ec83: add      byte ptr [rax], al
0x18000ec85: add      byte ptr [rax], al
0x18000ec87: add      byte ptr [rax], al
0x18000ec89: add      byte ptr [rax], al
0x18000ec8b: add      byte ptr [rax], al
0x18000ec8d: add      byte ptr [rax], al
0x18000ec8f: add      byte ptr [rax], al
0x18000ec91: add      byte ptr [rax], al
0x18000ec93: add      byte ptr [rax], al
0x18000ec95: add      byte ptr [rax], al
0x18000ec97: add      byte ptr [rax], al
0x18000ec99: add      byte ptr [rax], al
0x18000ec9b: add      byte ptr [rax], al
0x18000ec9d: add      byte ptr [rax], al
0x18000ec9f: add      byte ptr [rax], al
0x18000eca1: add      byte ptr [rax], al
0x18000eca3: add      byte ptr [rax], al
0x18000eca5: add      byte ptr [rax], al
0x18000eca7: add      byte ptr [rax], al
0x18000eca9: add      byte ptr [rax], al
0x18000ecab: add      byte ptr [rax], al
0x18000ecad: add      byte ptr [rax], al
0x18000ecaf: add      byte ptr [rax], al
0x18000ecb1: add      byte ptr [rax], al
0x18000ecb3: add      byte ptr [rax], al
0x18000ecb5: add      byte ptr [rax], al
0x18000ecb7: add      byte ptr [rax], al
0x18000ecb9: add      byte ptr [rax], al
0x18000ecbb: add      byte ptr [rax], al
0x18000ecbd: add      byte ptr [rax], al
0x18000ecbf: add      byte ptr [rax], al
0x18000ecc1: add      byte ptr [rax], al
0x18000ecc3: add      byte ptr [rax], al
0x18000ecc5: add      byte ptr [rax], al
0x18000ecc7: add      byte ptr [rax], al
0x18000ecc9: add      byte ptr [rax], al
0x18000eccb: add      byte ptr [rax], al
0x18000eccd: add      byte ptr [rax], al
0x18000eccf: add      byte ptr [rax], al
0x18000ecd1: add      byte ptr [rax], al
0x18000ecd3: add      byte ptr [rax], al
0x18000ecd5: add      byte ptr [rax], al
0x18000ecd7: add      byte ptr [rax], al
0x18000ecd9: add      byte ptr [rax], al
0x18000ecdb: add      byte ptr [rax], al
0x18000ecdd: add      byte ptr [rax], al
0x18000ecdf: add      byte ptr [rax], al
0x18000ece1: add      byte ptr [rax], al
0x18000ece3: add      byte ptr [rax], al
0x18000ece5: add      byte ptr [rax], al
0x18000ece7: add      byte ptr [rax], al
0x18000ece9: add      byte ptr [rax], al
0x18000eceb: add      byte ptr [rax], al
0x18000eced: add      byte ptr [rax], al
0x18000ecef: add      byte ptr [rax], al
0x18000ecf1: add      byte ptr [rax], al
0x18000ecf3: add      byte ptr [rax], al
0x18000ecf5: add      byte ptr [rax], al
0x18000ecf7: add      byte ptr [rax], al
0x18000ecf9: add      byte ptr [rax], al
0x18000ecfb: add      byte ptr [rax], al
0x18000ecfd: add      byte ptr [rax], al
0x18000ecff: add      byte ptr [rax], al
0x18000ed01: add      byte ptr [rax], al
0x18000ed03: add      byte ptr [rax], al
0x18000ed05: add      byte ptr [rax], al
0x18000ed07: add      byte ptr [rax], al
0x18000ed09: add      byte ptr [rax], al
0x18000ed0b: add      byte ptr [rax], al
0x18000ed0d: add      byte ptr [rax], al
0x18000ed0f: add      byte ptr [rax], al
0x18000ed11: add      byte ptr [rax], al
0x18000ed13: add      byte ptr [rax], al
0x18000ed15: add      byte ptr [rax], al
0x18000ed17: add      byte ptr [rax], al
0x18000ed19: add      byte ptr [rax], al
0x18000ed1b: add      byte ptr [rax], al
0x18000ed1d: add      byte ptr [rax], al
0x18000ed1f: add      byte ptr [rax], al
0x18000ed21: add      byte ptr [rax], al
0x18000ed23: add      byte ptr [rax], al
0x18000ed25: add      byte ptr [rax], al
0x18000ed27: add      byte ptr [rax], al
0x18000ed29: add      byte ptr [rax], al
0x18000ed2b: add      byte ptr [rax], al
0x18000ed2d: add      byte ptr [rax], al
0x18000ed2f: add      byte ptr [rax], al
0x18000ed31: add      byte ptr [rax], al
0x18000ed33: add      byte ptr [rax], al
0x18000ed35: add      byte ptr [rax], al
0x18000ed37: add      byte ptr [rax], al
0x18000ed39: add      byte ptr [rax], al
0x18000ed3b: add      byte ptr [rax], al
0x18000ed3d: add      byte ptr [rax], al
0x18000ed3f: add      byte ptr [rax], al
0x18000ed41: add      byte ptr [rax], al
0x18000ed43: add      byte ptr [rax], al
0x18000ed45: add      byte ptr [rax], al
0x18000ed47: add      byte ptr [rax], al
0x18000ed49: add      byte ptr [rax], al
0x18000ed4b: add      byte ptr [rax], al
0x18000ed4d: add      byte ptr [rax], al
0x18000ed4f: add      byte ptr [rax], al
0x18000ed51: add      byte ptr [rax], al
0x18000ed53: add      byte ptr [rax], al
0x18000ed55: add      byte ptr [rax], al
0x18000ed57: add      byte ptr [rax], al
0x18000ed59: add      byte ptr [rax], al
0x18000ed5b: add      byte ptr [rax], al
0x18000ed5d: add      byte ptr [rax], al
0x18000ed5f: add      byte ptr [rax], al
0x18000ed61: add      byte ptr [rax], al
0x18000ed63: add      byte ptr [rax], al
0x18000ed65: add      byte ptr [rax], al
0x18000ed67: add      byte ptr [rax], al
0x18000ed69: add      byte ptr [rax], al
0x18000ed6b: add      byte ptr [rax], al
0x18000ed6d: add      byte ptr [rax], al
0x18000ed6f: add      byte ptr [rax], al
0x18000ed71: add      byte ptr [rax], al
0x18000ed73: add      byte ptr [rax], al
0x18000ed75: add      byte ptr [rax], al
0x18000ed77: add      byte ptr [rax], al
0x18000ed79: add      byte ptr [rax], al
0x18000ed7b: add      byte ptr [rax], al
0x18000ed7d: add      byte ptr [rax], al
0x18000ed7f: add      byte ptr [rax], al
0x18000ed81: add      byte ptr [rax], al
0x18000ed83: add      byte ptr [rax], al
0x18000ed85: add      byte ptr [rax], al
0x18000ed87: add      byte ptr [rax], al
0x18000ed89: add      byte ptr [rax], al
0x18000ed8b: add      byte ptr [rax], al
0x18000ed8d: add      byte ptr [rax], al
0x18000ed8f: add      byte ptr [rax], al
0x18000ed91: add      byte ptr [rax], al
0x18000ed93: add      byte ptr [rax], al
0x18000ed95: add      byte ptr [rax], al
0x18000ed97: add      byte ptr [rax], al
0x18000ed99: add      byte ptr [rax], al
0x18000ed9b: add      byte ptr [rax], al
0x18000ed9d: add      byte ptr [rax], al
0x18000ed9f: add      byte ptr [rax], al
0x18000eda1: add      byte ptr [rax], al
0x18000eda3: add      byte ptr [rax], al
0x18000eda5: add      byte ptr [rax], al
0x18000eda7: add      byte ptr [rax], al
0x18000eda9: add      byte ptr [rax], al
0x18000edab: add      byte ptr [rax], al
0x18000edad: add      byte ptr [rax], al
0x18000edaf: add      byte ptr [rax], al
0x18000edb1: add      byte ptr [rax], al
0x18000edb3: add      byte ptr [rax], al
0x18000edb5: add      byte ptr [rax], al
0x18000edb7: add      byte ptr [rax], al
0x18000edb9: add      byte ptr [rax], al
0x18000edbb: add      byte ptr [rax], al
0x18000edbd: add      byte ptr [rax], al
0x18000edbf: add      byte ptr [rax], al
0x18000edc1: add      byte ptr [rax], al
0x18000edc3: add      byte ptr [rax], al
0x18000edc5: add      byte ptr [rax], al
0x18000edc7: add      byte ptr [rax], al
0x18000edc9: add      byte ptr [rax], al
0x18000edcb: add      byte ptr [rax], al
0x18000edcd: add      byte ptr [rax], al
0x18000edcf: add      byte ptr [rax], al
0x18000edd1: add      byte ptr [rax], al
0x18000edd3: add      byte ptr [rax], al
0x18000edd5: add      byte ptr [rax], al
0x18000edd7: add      byte ptr [rax], al
0x18000edd9: add      byte ptr [rax], al
0x18000eddb: add      byte ptr [rax], al
0x18000eddd: add      byte ptr [rax], al
0x18000eddf: add      byte ptr [rax], al
0x18000ede1: add      byte ptr [rax], al
0x18000ede3: add      byte ptr [rax], al
0x18000ede5: add      byte ptr [rax], al
0x18000ede7: add      byte ptr [rax], al
0x18000ede9: add      byte ptr [rax], al
0x18000edeb: add      byte ptr [rax], al
0x18000eded: add      byte ptr [rax], al
0x18000edef: add      byte ptr [rax], al
0x18000edf1: add      byte ptr [rax], al
0x18000edf3: add      byte ptr [rax], al
0x18000edf5: add      byte ptr [rax], al
0x18000edf7: add      byte ptr [rax], al
0x18000edf9: add      byte ptr [rax], al
0x18000edfb: add      byte ptr [rax], al
0x18000edfd: add      byte ptr [rax], al
0x18000edff: add      byte ptr [rax], al
0x18000ee01: add      byte ptr [rax], al
0x18000ee03: add      byte ptr [rax], al
0x18000ee05: add      byte ptr [rax], al
0x18000ee07: add      byte ptr [rax], al
0x18000ee09: add      byte ptr [rax], al
0x18000ee0b: add      byte ptr [rax], al
0x18000ee0d: add      byte ptr [rax], al
0x18000ee0f: add      byte ptr [rax], al
0x18000ee11: add      byte ptr [rax], al
0x18000ee13: add      byte ptr [rax], al
0x18000ee15: add      byte ptr [rax], al
0x18000ee17: add      byte ptr [rax], al
0x18000ee19: add      byte ptr [rax], al
0x18000ee1b: add      byte ptr [rax], al
0x18000ee1d: add      byte ptr [rax], al
0x18000ee1f: add      byte ptr [rax], al
0x18000ee21: add      byte ptr [rax], al
0x18000ee23: add      byte ptr [rax], al
0x18000ee25: add      byte ptr [rax], al
0x18000ee27: add      byte ptr [rax], al
0x18000ee29: add      byte ptr [rax], al
0x18000ee2b: add      byte ptr [rax], al
0x18000ee2d: add      byte ptr [rax], al
0x18000ee2f: add      byte ptr [rax], al
0x18000ee31: add      byte ptr [rax], al
0x18000ee33: add      byte ptr [rax], al
0x18000ee35: add      byte ptr [rax], al
0x18000ee37: add      byte ptr [rax], al
0x18000ee39: add      byte ptr [rax], al
0x18000ee3b: add      byte ptr [rax], al
0x18000ee3d: add      byte ptr [rax], al
0x18000ee3f: add      byte ptr [rax], al
0x18000ee41: add      byte ptr [rax], al
0x18000ee43: add      byte ptr [rax], al
0x18000ee45: add      byte ptr [rax], al
0x18000ee47: add      byte ptr [rax], al
0x18000ee49: add      byte ptr [rax], al
0x18000ee4b: add      byte ptr [rax], al
0x18000ee4d: add      byte ptr [rax], al
0x18000ee4f: add      byte ptr [rax], al
0x18000ee51: add      byte ptr [rax], al
0x18000ee53: add      byte ptr [rax], al
0x18000ee55: add      byte ptr [rax], al
0x18000ee57: add      byte ptr [rax], al
0x18000ee59: add      byte ptr [rax], al
0x18000ee5b: add      byte ptr [rax], al
0x18000ee5d: add      byte ptr [rax], al
0x18000ee5f: add      byte ptr [rax], al
0x18000ee61: add      byte ptr [rax], al
0x18000ee63: add      byte ptr [rax], al
0x18000ee65: add      byte ptr [rax], al
0x18000ee67: add      byte ptr [rax], al
0x18000ee69: add      byte ptr [rax], al
0x18000ee6b: add      byte ptr [rax], al
0x18000ee6d: add      byte ptr [rax], al
0x18000ee6f: add      byte ptr [rax], al
0x18000ee71: add      byte ptr [rax], al
0x18000ee73: add      byte ptr [rax], al
0x18000ee75: add      byte ptr [rax], al
0x18000ee77: add      byte ptr [rax], al
0x18000ee79: add      byte ptr [rax], al
0x18000ee7b: add      byte ptr [rax], al
0x18000ee7d: add      byte ptr [rax], al
0x18000ee7f: add      byte ptr [rax], al
0x18000ee81: add      byte ptr [rax], al
0x18000ee83: add      byte ptr [rax], al
0x18000ee85: add      byte ptr [rax], al
0x18000ee87: add      byte ptr [rax], al
0x18000ee89: add      byte ptr [rax], al
0x18000ee8b: add      byte ptr [rax], al
0x18000ee8d: add      byte ptr [rax], al
0x18000ee8f: add      byte ptr [rax], al
0x18000ee91: add      byte ptr [rax], al
0x18000ee93: add      byte ptr [rax], al
0x18000ee95: add      byte ptr [rax], al
0x18000ee97: add      byte ptr [rax], al
0x18000ee99: add      byte ptr [rax], al
0x18000ee9b: add      byte ptr [rax], al
0x18000ee9d: add      byte ptr [rax], al
0x18000ee9f: add      byte ptr [rax], al
0x18000eea1: add      byte ptr [rax], al
0x18000eea3: add      byte ptr [rax], al
0x18000eea5: add      byte ptr [rax], al
0x18000eea7: add      byte ptr [rax], al
0x18000eea9: add      byte ptr [rax], al
0x18000eeab: add      byte ptr [rax], al
0x18000eead: add      byte ptr [rax], al
0x18000eeaf: add      byte ptr [rax], al
0x18000eeb1: add      byte ptr [rax], al
0x18000eeb3: add      byte ptr [rax], al
0x18000eeb5: add      byte ptr [rax], al
0x18000eeb7: add      byte ptr [rax], al
0x18000eeb9: add      byte ptr [rax], al
0x18000eebb: add      byte ptr [rax], al
0x18000eebd: add      byte ptr [rax], al
0x18000eebf: add      byte ptr [rax], al
0x18000eec1: add      byte ptr [rax], al
0x18000eec3: add      byte ptr [rax], al
0x18000eec5: add      byte ptr [rax], al
0x18000eec7: add      byte ptr [rax], al
0x18000eec9: add      byte ptr [rax], al
0x18000eecb: add      byte ptr [rax], al
0x18000eecd: add      byte ptr [rax], al
0x18000eecf: add      byte ptr [rax], al
0x18000eed1: add      byte ptr [rax], al
0x18000eed3: add      byte ptr [rax], al
0x18000eed5: add      byte ptr [rax], al
0x18000eed7: add      byte ptr [rax], al
0x18000eed9: add      byte ptr [rax], al
0x18000eedb: add      byte ptr [rax], al
0x18000eedd: add      byte ptr [rax], al
0x18000eedf: add      byte ptr [rax], al
0x18000eee1: add      byte ptr [rax], al
0x18000eee3: add      byte ptr [rax], al
0x18000eee5: add      byte ptr [rax], al
0x18000eee7: add      byte ptr [rax], al
0x18000eee9: add      byte ptr [rax], al
0x18000eeeb: add      byte ptr [rax], al
0x18000eeed: add      byte ptr [rax], al
0x18000eeef: add      byte ptr [rax], al
0x18000eef1: add      byte ptr [rax], al
0x18000eef3: add      byte ptr [rax], al
0x18000eef5: add      byte ptr [rax], al
0x18000eef7: add      byte ptr [rax], al
0x18000eef9: add      byte ptr [rax], al
0x18000eefb: add      byte ptr [rax], al
0x18000eefd: add      byte ptr [rax], al
0x18000eeff: add      byte ptr [rax], al
0x18000ef01: add      byte ptr [rax], al
0x18000ef03: add      byte ptr [rax], al
0x18000ef05: add      byte ptr [rax], al
0x18000ef07: add      byte ptr [rax], al
0x18000ef09: add      byte ptr [rax], al
0x18000ef0b: add      byte ptr [rax], al
0x18000ef0d: add      byte ptr [rax], al
0x18000ef0f: add      byte ptr [rax], al
0x18000ef11: add      byte ptr [rax], al
0x18000ef13: add      byte ptr [rax], al
0x18000ef15: add      byte ptr [rax], al
0x18000ef17: add      byte ptr [rax], al
0x18000ef19: add      byte ptr [rax], al
0x18000ef1b: add      byte ptr [rax], al
0x18000ef1d: add      byte ptr [rax], al
0x18000ef1f: add      byte ptr [rax], al
0x18000ef21: add      byte ptr [rax], al
0x18000ef23: add      byte ptr [rax], al
0x18000ef25: add      byte ptr [rax], al
0x18000ef27: add      byte ptr [rax], al
0x18000ef29: add      byte ptr [rax], al
0x18000ef2b: add      byte ptr [rax], al
0x18000ef2d: add      byte ptr [rax], al
0x18000ef2f: add      byte ptr [rax], al
0x18000ef31: add      byte ptr [rax], al
0x18000ef33: add      byte ptr [rax], al
0x18000ef35: add      byte ptr [rax], al
0x18000ef37: add      byte ptr [rax], al
0x18000ef39: add      byte ptr [rax], al
0x18000ef3b: add      byte ptr [rax], al
0x18000ef3d: add      byte ptr [rax], al
0x18000ef3f: add      byte ptr [rax], al
0x18000ef41: add      byte ptr [rax], al
0x18000ef43: add      byte ptr [rax], al
0x18000ef45: add      byte ptr [rax], al
0x18000ef47: add      byte ptr [rax], al
0x18000ef49: add      byte ptr [rax], al
0x18000ef4b: add      byte ptr [rax], al
0x18000ef4d: add      byte ptr [rax], al
0x18000ef4f: add      byte ptr [rax], al
0x18000ef51: add      byte ptr [rax], al
0x18000ef53: add      byte ptr [rax], al
0x18000ef55: add      byte ptr [rax], al
0x18000ef57: add      byte ptr [rax], al
0x18000ef59: add      byte ptr [rax], al
0x18000ef5b: add      byte ptr [rax], al
0x18000ef5d: add      byte ptr [rax], al
0x18000ef5f: add      byte ptr [rax], al
0x18000ef61: add      byte ptr [rax], al
0x18000ef63: add      byte ptr [rax], al
0x18000ef65: add      byte ptr [rax], al
0x18000ef67: add      byte ptr [rax], al
0x18000ef69: add      byte ptr [rax], al
0x18000ef6b: add      byte ptr [rax], al
0x18000ef6d: add      byte ptr [rax], al
0x18000ef6f: add      byte ptr [rax], al
0x18000ef71: add      byte ptr [rax], al
0x18000ef73: add      byte ptr [rax], al
0x18000ef75: add      byte ptr [rax], al
0x18000ef77: add      byte ptr [rax], al
0x18000ef79: add      byte ptr [rax], al
0x18000ef7b: add      byte ptr [rax], al
0x18000ef7d: add      byte ptr [rax], al
0x18000ef7f: add      byte ptr [rax], al
0x18000ef81: add      byte ptr [rax], al
0x18000ef83: add      byte ptr [rax], al
0x18000ef85: add      byte ptr [rax], al
0x18000ef87: add      byte ptr [rax], al
0x18000ef89: add      byte ptr [rax], al
0x18000ef8b: add      byte ptr [rax], al
0x18000ef8d: add      byte ptr [rax], al
0x18000ef8f: add      byte ptr [rax], al
0x18000ef91: add      byte ptr [rax], al
0x18000ef93: add      byte ptr [rax], al
0x18000ef95: add      byte ptr [rax], al
0x18000ef97: add      byte ptr [rax], al
0x18000ef99: add      byte ptr [rax], al
0x18000ef9b: add      byte ptr [rax], al
0x18000ef9d: add      byte ptr [rax], al
0x18000ef9f: add      byte ptr [rax], al
0x18000efa1: add      byte ptr [rax], al
0x18000efa3: add      byte ptr [rax], al
0x18000efa5: add      byte ptr [rax], al
0x18000efa7: add      byte ptr [rax], al
0x18000efa9: add      byte ptr [rax], al
0x18000efab: add      byte ptr [rax], al
0x18000efad: add      byte ptr [rax], al
0x18000efaf: add      byte ptr [rax], al
0x18000efb1: add      byte ptr [rax], al
0x18000efb3: add      byte ptr [rax], al
0x18000efb5: add      byte ptr [rax], al
0x18000efb7: add      byte ptr [rax], al
0x18000efb9: add      byte ptr [rax], al
0x18000efbb: add      byte ptr [rax], al
0x18000efbd: add      byte ptr [rax], al
0x18000efbf: add      byte ptr [rax], al
0x18000efc1: add      byte ptr [rax], al
0x18000efc3: add      byte ptr [rax], al
0x18000efc5: add      byte ptr [rax], al
0x18000efc7: add      byte ptr [rax], al
0x18000efc9: add      byte ptr [rax], al
0x18000efcb: add      byte ptr [rax], al
0x18000efcd: add      byte ptr [rax], al
0x18000efcf: add      byte ptr [rax], al
0x18000efd1: add      byte ptr [rax], al
0x18000efd3: add      byte ptr [rax], al
0x18000efd5: add      byte ptr [rax], al
0x18000efd7: add      byte ptr [rax], al
0x18000efd9: add      byte ptr [rax], al
0x18000efdb: add      byte ptr [rax], al
0x18000efdd: add      byte ptr [rax], al
0x18000efdf: add      byte ptr [rax], al
0x18000efe1: add      byte ptr [rax], al
0x18000efe3: add      byte ptr [rax], al
0x18000efe5: add      byte ptr [rax], al
0x18000efe7: add      byte ptr [rax], al
0x18000efe9: add      byte ptr [rax], al
0x18000efeb: add      byte ptr [rax], al
0x18000efed: add      byte ptr [rax], al
0x18000efef: add      byte ptr [rax], al
0x18000eff1: add      byte ptr [rax], al
0x18000eff3: add      byte ptr [rax], al
0x18000eff5: add      byte ptr [rax], al
0x18000eff7: add      byte ptr [rax], al
0x18000eff9: add      byte ptr [rax], al
0x18000effb: add      byte ptr [rax], al
0x18000effd: add      byte ptr [rax], al
```

### Section: INIT (VA=0x180010000, 2041 instructions)
```asm
0x180010000: int3     
0x180010001: int3     
0x180010002: int3     
0x180010003: int3     
0x180010004: int3     
0x180010005: int3     
0x180010006: int3     
0x180010007: int3     
0x180010008: mov      rax, qword ptr [rip - 0x7f0f]
0x18001000f: test     rax, rax
0x180010012: je       0x18001002f
0x180010014: movabs   rcx, 0x2b992ddfa232
0x18001001e: cmp      rax, rcx
0x180010021: je       0x18001002f
0x180010023: not      rax
0x180010026: mov      qword ptr [rip - 0x7f25], rax
0x18001002d: ret      
0x18001002e: int3     
0x18001002f: mov      ecx, 6
0x180010034: int      0x29
0x180010036: add      byte ptr [rax], al
0x180010038: add      byte ptr [rax], al
0x18001003a: add      byte ptr [rax], al
0x18001003c: add      byte ptr [rax], al
0x18001003e: add      byte ptr [rax], al
0x180010040: add      byte ptr [rax], al
0x180010042: add      byte ptr [rax], al
0x180010044: add      byte ptr [rax], al
0x180010046: add      byte ptr [rax], al
0x180010048: add      byte ptr [rax], al
0x18001004a: add      byte ptr [rax], al
0x18001004c: add      byte ptr [rax], al
0x18001004e: add      byte ptr [rax], al
0x180010050: add      byte ptr [rax], al
0x180010052: add      byte ptr [rax], al
0x180010054: add      byte ptr [rax], al
0x180010056: add      byte ptr [rax], al
0x180010058: add      byte ptr [rax], al
0x18001005a: add      byte ptr [rax], al
0x18001005c: add      byte ptr [rax], al
0x18001005e: add      byte ptr [rax], al
0x180010060: add      byte ptr [rax], al
0x180010062: add      byte ptr [rax], al
0x180010064: add      byte ptr [rax], al
0x180010066: add      byte ptr [rax], al
0x180010068: add      byte ptr [rax], al
0x18001006a: add      byte ptr [rax], al
0x18001006c: add      byte ptr [rax], al
0x18001006e: add      byte ptr [rax], al
0x180010070: add      byte ptr [rax], al
0x180010072: add      byte ptr [rax], al
0x180010074: add      byte ptr [rax], al
0x180010076: add      byte ptr [rax], al
0x180010078: add      byte ptr [rax], al
0x18001007a: add      byte ptr [rax], al
0x18001007c: add      byte ptr [rax], al
0x18001007e: add      byte ptr [rax], al
0x180010080: add      byte ptr [rax], al
0x180010082: add      byte ptr [rax], al
0x180010084: add      byte ptr [rax], al
0x180010086: add      byte ptr [rax], al
0x180010088: add      byte ptr [rax], al
0x18001008a: add      byte ptr [rax], al
0x18001008c: add      byte ptr [rax], al
0x18001008e: add      byte ptr [rax], al
0x180010090: add      byte ptr [rax], al
0x180010092: add      byte ptr [rax], al
0x180010094: add      byte ptr [rax], al
0x180010096: add      byte ptr [rax], al
0x180010098: add      byte ptr [rax], al
0x18001009a: add      byte ptr [rax], al
0x18001009c: add      byte ptr [rax], al
0x18001009e: add      byte ptr [rax], al
0x1800100a0: add      byte ptr [rax], al
0x1800100a2: add      byte ptr [rax], al
0x1800100a4: add      byte ptr [rax], al
0x1800100a6: add      byte ptr [rax], al
0x1800100a8: add      byte ptr [rax], al
0x1800100aa: add      byte ptr [rax], al
0x1800100ac: add      byte ptr [rax], al
0x1800100ae: add      byte ptr [rax], al
0x1800100b0: add      byte ptr [rax], al
0x1800100b2: add      byte ptr [rax], al
0x1800100b4: add      byte ptr [rax], al
0x1800100b6: add      byte ptr [rax], al
0x1800100b8: add      byte ptr [rax], al
0x1800100ba: add      byte ptr [rax], al
0x1800100bc: add      byte ptr [rax], al
0x1800100be: add      byte ptr [rax], al
0x1800100c0: add      byte ptr [rax], al
0x1800100c2: add      byte ptr [rax], al
0x1800100c4: add      byte ptr [rax], al
0x1800100c6: add      byte ptr [rax], al
0x1800100c8: add      byte ptr [rax], al
0x1800100ca: add      byte ptr [rax], al
0x1800100cc: add      byte ptr [rax], al
0x1800100ce: add      byte ptr [rax], al
0x1800100d0: add      byte ptr [rax], al
0x1800100d2: add      byte ptr [rax], al
0x1800100d4: add      byte ptr [rax], al
0x1800100d6: add      byte ptr [rax], al
0x1800100d8: add      byte ptr [rax], al
0x1800100da: add      byte ptr [rax], al
0x1800100dc: add      byte ptr [rax], al
0x1800100de: add      byte ptr [rax], al
0x1800100e0: add      byte ptr [rax], al
0x1800100e2: add      byte ptr [rax], al
0x1800100e4: add      byte ptr [rax], al
0x1800100e6: add      byte ptr [rax], al
0x1800100e8: add      byte ptr [rax], al
0x1800100ea: add      byte ptr [rax], al
0x1800100ec: add      byte ptr [rax], al
0x1800100ee: add      byte ptr [rax], al
0x1800100f0: add      byte ptr [rax], al
0x1800100f2: add      byte ptr [rax], al
0x1800100f4: add      byte ptr [rax], al
0x1800100f6: add      byte ptr [rax], al
0x1800100f8: add      byte ptr [rax], al
0x1800100fa: add      byte ptr [rax], al
0x1800100fc: add      byte ptr [rax], al
0x1800100fe: add      byte ptr [rax], al
0x180010100: add      byte ptr [rax], al
0x180010102: add      byte ptr [rax], al
0x180010104: add      byte ptr [rax], al
0x180010106: add      byte ptr [rax], al
0x180010108: add      byte ptr [rax], al
0x18001010a: add      byte ptr [rax], al
0x18001010c: add      byte ptr [rax], al
0x18001010e: add      byte ptr [rax], al
0x180010110: add      byte ptr [rax], al
0x180010112: add      byte ptr [rax], al
0x180010114: add      byte ptr [rax], al
0x180010116: add      byte ptr [rax], al
0x180010118: add      byte ptr [rax], al
0x18001011a: add      byte ptr [rax], al
0x18001011c: add      byte ptr [rax], al
0x18001011e: add      byte ptr [rax], al
0x180010120: add      byte ptr [rax], al
0x180010122: add      byte ptr [rax], al
0x180010124: add      byte ptr [rax], al
0x180010126: add      byte ptr [rax], al
0x180010128: add      byte ptr [rax], al
0x18001012a: add      byte ptr [rax], al
0x18001012c: add      byte ptr [rax], al
0x18001012e: add      byte ptr [rax], al
0x180010130: add      byte ptr [rax], al
0x180010132: add      byte ptr [rax], al
0x180010134: add      byte ptr [rax], al
0x180010136: add      byte ptr [rax], al
0x180010138: add      byte ptr [rax], al
0x18001013a: add      byte ptr [rax], al
0x18001013c: add      byte ptr [rax], al
0x18001013e: add      byte ptr [rax], al
0x180010140: add      byte ptr [rax], al
0x180010142: add      byte ptr [rax], al
0x180010144: add      byte ptr [rax], al
0x180010146: add      byte ptr [rax], al
0x180010148: add      byte ptr [rax], al
0x18001014a: add      byte ptr [rax], al
0x18001014c: add      byte ptr [rax], al
0x18001014e: add      byte ptr [rax], al
0x180010150: add      byte ptr [rax], al
0x180010152: add      byte ptr [rax], al
0x180010154: add      byte ptr [rax], al
0x180010156: add      byte ptr [rax], al
0x180010158: add      byte ptr [rax], al
0x18001015a: add      byte ptr [rax], al
0x18001015c: add      byte ptr [rax], al
0x18001015e: add      byte ptr [rax], al
0x180010160: add      byte ptr [rax], al
0x180010162: add      byte ptr [rax], al
0x180010164: add      byte ptr [rax], al
0x180010166: add      byte ptr [rax], al
0x180010168: add      byte ptr [rax], al
0x18001016a: add      byte ptr [rax], al
0x18001016c: add      byte ptr [rax], al
0x18001016e: add      byte ptr [rax], al
0x180010170: add      byte ptr [rax], al
0x180010172: add      byte ptr [rax], al
0x180010174: add      byte ptr [rax], al
0x180010176: add      byte ptr [rax], al
0x180010178: add      byte ptr [rax], al
0x18001017a: add      byte ptr [rax], al
0x18001017c: add      byte ptr [rax], al
0x18001017e: add      byte ptr [rax], al
0x180010180: add      byte ptr [rax], al
0x180010182: add      byte ptr [rax], al
0x180010184: add      byte ptr [rax], al
0x180010186: add      byte ptr [rax], al
0x180010188: add      byte ptr [rax], al
0x18001018a: add      byte ptr [rax], al
0x18001018c: add      byte ptr [rax], al
0x18001018e: add      byte ptr [rax], al
0x180010190: add      byte ptr [rax], al
0x180010192: add      byte ptr [rax], al
0x180010194: add      byte ptr [rax], al
0x180010196: add      byte ptr [rax], al
0x180010198: add      byte ptr [rax], al
0x18001019a: add      byte ptr [rax], al
0x18001019c: add      byte ptr [rax], al
0x18001019e: add      byte ptr [rax], al
0x1800101a0: add      byte ptr [rax], al
0x1800101a2: add      byte ptr [rax], al
0x1800101a4: add      byte ptr [rax], al
0x1800101a6: add      byte ptr [rax], al
0x1800101a8: add      byte ptr [rax], al
0x1800101aa: add      byte ptr [rax], al
0x1800101ac: add      byte ptr [rax], al
0x1800101ae: add      byte ptr [rax], al
0x1800101b0: add      byte ptr [rax], al
0x1800101b2: add      byte ptr [rax], al
0x1800101b4: add      byte ptr [rax], al
0x1800101b6: add      byte ptr [rax], al
0x1800101b8: add      byte ptr [rax], al
0x1800101ba: add      byte ptr [rax], al
0x1800101bc: add      byte ptr [rax], al
0x1800101be: add      byte ptr [rax], al
0x1800101c0: add      byte ptr [rax], al
0x1800101c2: add      byte ptr [rax], al
0x1800101c4: add      byte ptr [rax], al
0x1800101c6: add      byte ptr [rax], al
0x1800101c8: add      byte ptr [rax], al
0x1800101ca: add      byte ptr [rax], al
0x1800101cc: add      byte ptr [rax], al
0x1800101ce: add      byte ptr [rax], al
0x1800101d0: add      byte ptr [rax], al
0x1800101d2: add      byte ptr [rax], al
0x1800101d4: add      byte ptr [rax], al
0x1800101d6: add      byte ptr [rax], al
0x1800101d8: add      byte ptr [rax], al
0x1800101da: add      byte ptr [rax], al
0x1800101dc: add      byte ptr [rax], al
0x1800101de: add      byte ptr [rax], al
0x1800101e0: add      byte ptr [rax], al
0x1800101e2: add      byte ptr [rax], al
0x1800101e4: add      byte ptr [rax], al
0x1800101e6: add      byte ptr [rax], al
0x1800101e8: add      byte ptr [rax], al
0x1800101ea: add      byte ptr [rax], al
0x1800101ec: add      byte ptr [rax], al
0x1800101ee: add      byte ptr [rax], al
0x1800101f0: add      byte ptr [rax], al
0x1800101f2: add      byte ptr [rax], al
0x1800101f4: add      byte ptr [rax], al
0x1800101f6: add      byte ptr [rax], al
0x1800101f8: add      byte ptr [rax], al
0x1800101fa: add      byte ptr [rax], al
0x1800101fc: add      byte ptr [rax], al
0x1800101fe: add      byte ptr [rax], al
0x180010200: add      byte ptr [rax], al
0x180010202: add      byte ptr [rax], al
0x180010204: add      byte ptr [rax], al
0x180010206: add      byte ptr [rax], al
0x180010208: add      byte ptr [rax], al
0x18001020a: add      byte ptr [rax], al
0x18001020c: add      byte ptr [rax], al
0x18001020e: add      byte ptr [rax], al
0x180010210: add      byte ptr [rax], al
0x180010212: add      byte ptr [rax], al
0x180010214: add      byte ptr [rax], al
0x180010216: add      byte ptr [rax], al
0x180010218: add      byte ptr [rax], al
0x18001021a: add      byte ptr [rax], al
0x18001021c: add      byte ptr [rax], al
0x18001021e: add      byte ptr [rax], al
0x180010220: add      byte ptr [rax], al
0x180010222: add      byte ptr [rax], al
0x180010224: add      byte ptr [rax], al
0x180010226: add      byte ptr [rax], al
0x180010228: add      byte ptr [rax], al
0x18001022a: add      byte ptr [rax], al
0x18001022c: add      byte ptr [rax], al
0x18001022e: add      byte ptr [rax], al
0x180010230: add      byte ptr [rax], al
0x180010232: add      byte ptr [rax], al
0x180010234: add      byte ptr [rax], al
0x180010236: add      byte ptr [rax], al
0x180010238: add      byte ptr [rax], al
0x18001023a: add      byte ptr [rax], al
0x18001023c: add      byte ptr [rax], al
0x18001023e: add      byte ptr [rax], al
0x180010240: add      byte ptr [rax], al
0x180010242: add      byte ptr [rax], al
0x180010244: add      byte ptr [rax], al
0x180010246: add      byte ptr [rax], al
0x180010248: add      byte ptr [rax], al
0x18001024a: add      byte ptr [rax], al
0x18001024c: add      byte ptr [rax], al
0x18001024e: add      byte ptr [rax], al
0x180010250: add      byte ptr [rax], al
0x180010252: add      byte ptr [rax], al
0x180010254: add      byte ptr [rax], al
0x180010256: add      byte ptr [rax], al
0x180010258: add      byte ptr [rax], al
0x18001025a: add      byte ptr [rax], al
0x18001025c: add      byte ptr [rax], al
0x18001025e: add      byte ptr [rax], al
0x180010260: add      byte ptr [rax], al
0x180010262: add      byte ptr [rax], al
0x180010264: add      byte ptr [rax], al
0x180010266: add      byte ptr [rax], al
0x180010268: add      byte ptr [rax], al
0x18001026a: add      byte ptr [rax], al
0x18001026c: add      byte ptr [rax], al
0x18001026e: add      byte ptr [rax], al
0x180010270: add      byte ptr [rax], al
0x180010272: add      byte ptr [rax], al
0x180010274: add      byte ptr [rax], al
0x180010276: add      byte ptr [rax], al
0x180010278: add      byte ptr [rax], al
0x18001027a: add      byte ptr [rax], al
0x18001027c: add      byte ptr [rax], al
0x18001027e: add      byte ptr [rax], al
0x180010280: add      byte ptr [rax], al
0x180010282: add      byte ptr [rax], al
0x180010284: add      byte ptr [rax], al
0x180010286: add      byte ptr [rax], al
0x180010288: add      byte ptr [rax], al
0x18001028a: add      byte ptr [rax], al
0x18001028c: add      byte ptr [rax], al
0x18001028e: add      byte ptr [rax], al
0x180010290: add      byte ptr [rax], al
0x180010292: add      byte ptr [rax], al
0x180010294: add      byte ptr [rax], al
0x180010296: add      byte ptr [rax], al
0x180010298: add      byte ptr [rax], al
0x18001029a: add      byte ptr [rax], al
0x18001029c: add      byte ptr [rax], al
0x18001029e: add      byte ptr [rax], al
0x1800102a0: add      byte ptr [rax], al
0x1800102a2: add      byte ptr [rax], al
0x1800102a4: add      byte ptr [rax], al
0x1800102a6: add      byte ptr [rax], al
0x1800102a8: add      byte ptr [rax], al
0x1800102aa: add      byte ptr [rax], al
0x1800102ac: add      byte ptr [rax], al
0x1800102ae: add      byte ptr [rax], al
0x1800102b0: add      byte ptr [rax], al
0x1800102b2: add      byte ptr [rax], al
0x1800102b4: add      byte ptr [rax], al
0x1800102b6: add      byte ptr [rax], al
0x1800102b8: add      byte ptr [rax], al
0x1800102ba: add      byte ptr [rax], al
0x1800102bc: add      byte ptr [rax], al
0x1800102be: add      byte ptr [rax], al
0x1800102c0: add      byte ptr [rax], al
0x1800102c2: add      byte ptr [rax], al
0x1800102c4: add      byte ptr [rax], al
0x1800102c6: add      byte ptr [rax], al
0x1800102c8: add      byte ptr [rax], al
0x1800102ca: add      byte ptr [rax], al
0x1800102cc: add      byte ptr [rax], al
0x1800102ce: add      byte ptr [rax], al
0x1800102d0: add      byte ptr [rax], al
0x1800102d2: add      byte ptr [rax], al
0x1800102d4: add      byte ptr [rax], al
0x1800102d6: add      byte ptr [rax], al
0x1800102d8: add      byte ptr [rax], al
0x1800102da: add      byte ptr [rax], al
0x1800102dc: add      byte ptr [rax], al
0x1800102de: add      byte ptr [rax], al
0x1800102e0: add      byte ptr [rax], al
0x1800102e2: add      byte ptr [rax], al
0x1800102e4: add      byte ptr [rax], al
0x1800102e6: add      byte ptr [rax], al
0x1800102e8: add      byte ptr [rax], al
0x1800102ea: add      byte ptr [rax], al
0x1800102ec: add      byte ptr [rax], al
0x1800102ee: add      byte ptr [rax], al
0x1800102f0: add      byte ptr [rax], al
0x1800102f2: add      byte ptr [rax], al
0x1800102f4: add      byte ptr [rax], al
0x1800102f6: add      byte ptr [rax], al
0x1800102f8: add      byte ptr [rax], al
0x1800102fa: add      byte ptr [rax], al
0x1800102fc: add      byte ptr [rax], al
0x1800102fe: add      byte ptr [rax], al
0x180010300: add      byte ptr [rax], al
0x180010302: add      byte ptr [rax], al
0x180010304: add      byte ptr [rax], al
0x180010306: add      byte ptr [rax], al
0x180010308: add      byte ptr [rax], al
0x18001030a: add      byte ptr [rax], al
0x18001030c: add      byte ptr [rax], al
0x18001030e: add      byte ptr [rax], al
0x180010310: add      byte ptr [rax], al
0x180010312: add      byte ptr [rax], al
0x180010314: add      byte ptr [rax], al
0x180010316: add      byte ptr [rax], al
0x180010318: add      byte ptr [rax], al
0x18001031a: add      byte ptr [rax], al
0x18001031c: add      byte ptr [rax], al
0x18001031e: add      byte ptr [rax], al
0x180010320: add      byte ptr [rax], al
0x180010322: add      byte ptr [rax], al
0x180010324: add      byte ptr [rax], al
0x180010326: add      byte ptr [rax], al
0x180010328: add      byte ptr [rax], al
0x18001032a: add      byte ptr [rax], al
0x18001032c: add      byte ptr [rax], al
0x18001032e: add      byte ptr [rax], al
0x180010330: add      byte ptr [rax], al
0x180010332: add      byte ptr [rax], al
0x180010334: add      byte ptr [rax], al
0x180010336: add      byte ptr [rax], al
0x180010338: add      byte ptr [rax], al
0x18001033a: add      byte ptr [rax], al
0x18001033c: add      byte ptr [rax], al
0x18001033e: add      byte ptr [rax], al
0x180010340: add      byte ptr [rax], al
0x180010342: add      byte ptr [rax], al
0x180010344: add      byte ptr [rax], al
0x180010346: add      byte ptr [rax], al
0x180010348: add      byte ptr [rax], al
0x18001034a: add      byte ptr [rax], al
0x18001034c: add      byte ptr [rax], al
0x18001034e: add      byte ptr [rax], al
0x180010350: add      byte ptr [rax], al
0x180010352: add      byte ptr [rax], al
0x180010354: add      byte ptr [rax], al
0x180010356: add      byte ptr [rax], al
0x180010358: add      byte ptr [rax], al
0x18001035a: add      byte ptr [rax], al
0x18001035c: add      byte ptr [rax], al
0x18001035e: add      byte ptr [rax], al
0x180010360: add      byte ptr [rax], al
0x180010362: add      byte ptr [rax], al
0x180010364: add      byte ptr [rax], al
0x180010366: add      byte ptr [rax], al
0x180010368: add      byte ptr [rax], al
0x18001036a: add      byte ptr [rax], al
0x18001036c: add      byte ptr [rax], al
0x18001036e: add      byte ptr [rax], al
0x180010370: add      byte ptr [rax], al
0x180010372: add      byte ptr [rax], al
0x180010374: add      byte ptr [rax], al
0x180010376: add      byte ptr [rax], al
0x180010378: add      byte ptr [rax], al
0x18001037a: add      byte ptr [rax], al
0x18001037c: add      byte ptr [rax], al
0x18001037e: add      byte ptr [rax], al
0x180010380: add      byte ptr [rax], al
0x180010382: add      byte ptr [rax], al
0x180010384: add      byte ptr [rax], al
0x180010386: add      byte ptr [rax], al
0x180010388: add      byte ptr [rax], al
0x18001038a: add      byte ptr [rax], al
0x18001038c: add      byte ptr [rax], al
0x18001038e: add      byte ptr [rax], al
0x180010390: add      byte ptr [rax], al
0x180010392: add      byte ptr [rax], al
0x180010394: add      byte ptr [rax], al
0x180010396: add      byte ptr [rax], al
0x180010398: add      byte ptr [rax], al
0x18001039a: add      byte ptr [rax], al
0x18001039c: add      byte ptr [rax], al
0x18001039e: add      byte ptr [rax], al
0x1800103a0: add      byte ptr [rax], al
0x1800103a2: add      byte ptr [rax], al
0x1800103a4: add      byte ptr [rax], al
0x1800103a6: add      byte ptr [rax], al
0x1800103a8: add      byte ptr [rax], al
0x1800103aa: add      byte ptr [rax], al
0x1800103ac: add      byte ptr [rax], al
0x1800103ae: add      byte ptr [rax], al
0x1800103b0: add      byte ptr [rax], al
0x1800103b2: add      byte ptr [rax], al
0x1800103b4: add      byte ptr [rax], al
0x1800103b6: add      byte ptr [rax], al
0x1800103b8: add      byte ptr [rax], al
0x1800103ba: add      byte ptr [rax], al
0x1800103bc: add      byte ptr [rax], al
0x1800103be: add      byte ptr [rax], al
0x1800103c0: add      byte ptr [rax], al
0x1800103c2: add      byte ptr [rax], al
0x1800103c4: add      byte ptr [rax], al
0x1800103c6: add      byte ptr [rax], al
0x1800103c8: add      byte ptr [rax], al
0x1800103ca: add      byte ptr [rax], al
0x1800103cc: add      byte ptr [rax], al
0x1800103ce: add      byte ptr [rax], al
0x1800103d0: add      byte ptr [rax], al
0x1800103d2: add      byte ptr [rax], al
0x1800103d4: add      byte ptr [rax], al
0x1800103d6: add      byte ptr [rax], al
0x1800103d8: add      byte ptr [rax], al
0x1800103da: add      byte ptr [rax], al
0x1800103dc: add      byte ptr [rax], al
0x1800103de: add      byte ptr [rax], al
0x1800103e0: add      byte ptr [rax], al
0x1800103e2: add      byte ptr [rax], al
0x1800103e4: add      byte ptr [rax], al
0x1800103e6: add      byte ptr [rax], al
0x1800103e8: add      byte ptr [rax], al
0x1800103ea: add      byte ptr [rax], al
0x1800103ec: add      byte ptr [rax], al
0x1800103ee: add      byte ptr [rax], al
0x1800103f0: add      byte ptr [rax], al
0x1800103f2: add      byte ptr [rax], al
0x1800103f4: add      byte ptr [rax], al
0x1800103f6: add      byte ptr [rax], al
0x1800103f8: add      byte ptr [rax], al
0x1800103fa: add      byte ptr [rax], al
0x1800103fc: add      byte ptr [rax], al
0x1800103fe: add      byte ptr [rax], al
0x180010400: add      byte ptr [rax], al
0x180010402: add      byte ptr [rax], al
0x180010404: add      byte ptr [rax], al
0x180010406: add      byte ptr [rax], al
0x180010408: add      byte ptr [rax], al
0x18001040a: add      byte ptr [rax], al
0x18001040c: add      byte ptr [rax], al
0x18001040e: add      byte ptr [rax], al
0x180010410: add      byte ptr [rax], al
0x180010412: add      byte ptr [rax], al
0x180010414: add      byte ptr [rax], al
0x180010416: add      byte ptr [rax], al
0x180010418: add      byte ptr [rax], al
0x18001041a: add      byte ptr [rax], al
0x18001041c: add      byte ptr [rax], al
0x18001041e: add      byte ptr [rax], al
0x180010420: add      byte ptr [rax], al
0x180010422: add      byte ptr [rax], al
0x180010424: add      byte ptr [rax], al
0x180010426: add      byte ptr [rax], al
0x180010428: add      byte ptr [rax], al
0x18001042a: add      byte ptr [rax], al
0x18001042c: add      byte ptr [rax], al
0x18001042e: add      byte ptr [rax], al
0x180010430: add      byte ptr [rax], al
0x180010432: add      byte ptr [rax], al
0x180010434: add      byte ptr [rax], al
0x180010436: add      byte ptr [rax], al
0x180010438: add      byte ptr [rax], al
0x18001043a: add      byte ptr [rax], al
0x18001043c: add      byte ptr [rax], al
0x18001043e: add      byte ptr [rax], al
0x180010440: add      byte ptr [rax], al
0x180010442: add      byte ptr [rax], al
0x180010444: add      byte ptr [rax], al
0x180010446: add      byte ptr [rax], al
0x180010448: add      byte ptr [rax], al
0x18001044a: add      byte ptr [rax], al
0x18001044c: add      byte ptr [rax], al
0x18001044e: add      byte ptr [rax], al
0x180010450: add      byte ptr [rax], al
0x180010452: add      byte ptr [rax], al
0x180010454: add      byte ptr [rax], al
0x180010456: add      byte ptr [rax], al
0x180010458: add      byte ptr [rax], al
0x18001045a: add      byte ptr [rax], al
0x18001045c: add      byte ptr [rax], al
0x18001045e: add      byte ptr [rax], al
0x180010460: add      byte ptr [rax], al
0x180010462: add      byte ptr [rax], al
0x180010464: add      byte ptr [rax], al
0x180010466: add      byte ptr [rax], al
0x180010468: add      byte ptr [rax], al
0x18001046a: add      byte ptr [rax], al
0x18001046c: add      byte ptr [rax], al
0x18001046e: add      byte ptr [rax], al
0x180010470: add      byte ptr [rax], al
0x180010472: add      byte ptr [rax], al
0x180010474: add      byte ptr [rax], al
0x180010476: add      byte ptr [rax], al
0x180010478: add      byte ptr [rax], al
0x18001047a: add      byte ptr [rax], al
0x18001047c: add      byte ptr [rax], al
0x18001047e: add      byte ptr [rax], al
0x180010480: add      byte ptr [rax], al
0x180010482: add      byte ptr [rax], al
0x180010484: add      byte ptr [rax], al
0x180010486: add      byte ptr [rax], al
0x180010488: add      byte ptr [rax], al
0x18001048a: add      byte ptr [rax], al
0x18001048c: add      byte ptr [rax], al
0x18001048e: add      byte ptr [rax], al
0x180010490: add      byte ptr [rax], al
0x180010492: add      byte ptr [rax], al
0x180010494: add      byte ptr [rax], al
0x180010496: add      byte ptr [rax], al
0x180010498: add      byte ptr [rax], al
0x18001049a: add      byte ptr [rax], al
0x18001049c: add      byte ptr [rax], al
0x18001049e: add      byte ptr [rax], al
0x1800104a0: add      byte ptr [rax], al
0x1800104a2: add      byte ptr [rax], al
0x1800104a4: add      byte ptr [rax], al
0x1800104a6: add      byte ptr [rax], al
0x1800104a8: add      byte ptr [rax], al
0x1800104aa: add      byte ptr [rax], al
0x1800104ac: add      byte ptr [rax], al
0x1800104ae: add      byte ptr [rax], al
0x1800104b0: add      byte ptr [rax], al
0x1800104b2: add      byte ptr [rax], al
0x1800104b4: add      byte ptr [rax], al
0x1800104b6: add      byte ptr [rax], al
0x1800104b8: add      byte ptr [rax], al
0x1800104ba: add      byte ptr [rax], al
0x1800104bc: add      byte ptr [rax], al
0x1800104be: add      byte ptr [rax], al
0x1800104c0: add      byte ptr [rax], al
0x1800104c2: add      byte ptr [rax], al
0x1800104c4: add      byte ptr [rax], al
0x1800104c6: add      byte ptr [rax], al
0x1800104c8: add      byte ptr [rax], al
0x1800104ca: add      byte ptr [rax], al
0x1800104cc: add      byte ptr [rax], al
0x1800104ce: add      byte ptr [rax], al
0x1800104d0: add      byte ptr [rax], al
0x1800104d2: add      byte ptr [rax], al
0x1800104d4: add      byte ptr [rax], al
0x1800104d6: add      byte ptr [rax], al
0x1800104d8: add      byte ptr [rax], al
0x1800104da: add      byte ptr [rax], al
0x1800104dc: add      byte ptr [rax], al
0x1800104de: add      byte ptr [rax], al
0x1800104e0: add      byte ptr [rax], al
0x1800104e2: add      byte ptr [rax], al
0x1800104e4: add      byte ptr [rax], al
0x1800104e6: add      byte ptr [rax], al
0x1800104e8: add      byte ptr [rax], al
0x1800104ea: add      byte ptr [rax], al
0x1800104ec: add      byte ptr [rax], al
0x1800104ee: add      byte ptr [rax], al
0x1800104f0: add      byte ptr [rax], al
0x1800104f2: add      byte ptr [rax], al
0x1800104f4: add      byte ptr [rax], al
0x1800104f6: add      byte ptr [rax], al
0x1800104f8: add      byte ptr [rax], al
0x1800104fa: add      byte ptr [rax], al
0x1800104fc: add      byte ptr [rax], al
0x1800104fe: add      byte ptr [rax], al
0x180010500: add      byte ptr [rax], al
0x180010502: add      byte ptr [rax], al
0x180010504: add      byte ptr [rax], al
0x180010506: add      byte ptr [rax], al
0x180010508: add      byte ptr [rax], al
0x18001050a: add      byte ptr [rax], al
0x18001050c: add      byte ptr [rax], al
0x18001050e: add      byte ptr [rax], al
0x180010510: add      byte ptr [rax], al
0x180010512: add      byte ptr [rax], al
0x180010514: add      byte ptr [rax], al
0x180010516: add      byte ptr [rax], al
0x180010518: add      byte ptr [rax], al
0x18001051a: add      byte ptr [rax], al
0x18001051c: add      byte ptr [rax], al
0x18001051e: add      byte ptr [rax], al
0x180010520: add      byte ptr [rax], al
0x180010522: add      byte ptr [rax], al
0x180010524: add      byte ptr [rax], al
0x180010526: add      byte ptr [rax], al
0x180010528: add      byte ptr [rax], al
0x18001052a: add      byte ptr [rax], al
0x18001052c: add      byte ptr [rax], al
0x18001052e: add      byte ptr [rax], al
0x180010530: add      byte ptr [rax], al
0x180010532: add      byte ptr [rax], al
0x180010534: add      byte ptr [rax], al
0x180010536: add      byte ptr [rax], al
0x180010538: add      byte ptr [rax], al
0x18001053a: add      byte ptr [rax], al
0x18001053c: add      byte ptr [rax], al
0x18001053e: add      byte ptr [rax], al
0x180010540: add      byte ptr [rax], al
0x180010542: add      byte ptr [rax], al
0x180010544: add      byte ptr [rax], al
0x180010546: add      byte ptr [rax], al
0x180010548: add      byte ptr [rax], al
0x18001054a: add      byte ptr [rax], al
0x18001054c: add      byte ptr [rax], al
0x18001054e: add      byte ptr [rax], al
0x180010550: add      byte ptr [rax], al
0x180010552: add      byte ptr [rax], al
0x180010554: add      byte ptr [rax], al
0x180010556: add      byte ptr [rax], al
0x180010558: add      byte ptr [rax], al
0x18001055a: add      byte ptr [rax], al
0x18001055c: add      byte ptr [rax], al
0x18001055e: add      byte ptr [rax], al
0x180010560: add      byte ptr [rax], al
0x180010562: add      byte ptr [rax], al
0x180010564: add      byte ptr [rax], al
0x180010566: add      byte ptr [rax], al
0x180010568: add      byte ptr [rax], al
0x18001056a: add      byte ptr [rax], al
0x18001056c: add      byte ptr [rax], al
0x18001056e: add      byte ptr [rax], al
0x180010570: add      byte ptr [rax], al
0x180010572: add      byte ptr [rax], al
0x180010574: add      byte ptr [rax], al
0x180010576: add      byte ptr [rax], al
0x180010578: add      byte ptr [rax], al
0x18001057a: add      byte ptr [rax], al
0x18001057c: add      byte ptr [rax], al
0x18001057e: add      byte ptr [rax], al
0x180010580: add      byte ptr [rax], al
0x180010582: add      byte ptr [rax], al
0x180010584: add      byte ptr [rax], al
0x180010586: add      byte ptr [rax], al
0x180010588: add      byte ptr [rax], al
0x18001058a: add      byte ptr [rax], al
0x18001058c: add      byte ptr [rax], al
0x18001058e: add      byte ptr [rax], al
0x180010590: add      byte ptr [rax], al
0x180010592: add      byte ptr [rax], al
0x180010594: add      byte ptr [rax], al
0x180010596: add      byte ptr [rax], al
0x180010598: add      byte ptr [rax], al
0x18001059a: add      byte ptr [rax], al
0x18001059c: add      byte ptr [rax], al
0x18001059e: add      byte ptr [rax], al
0x1800105a0: add      byte ptr [rax], al
0x1800105a2: add      byte ptr [rax], al
0x1800105a4: add      byte ptr [rax], al
0x1800105a6: add      byte ptr [rax], al
0x1800105a8: add      byte ptr [rax], al
0x1800105aa: add      byte ptr [rax], al
0x1800105ac: add      byte ptr [rax], al
0x1800105ae: add      byte ptr [rax], al
0x1800105b0: add      byte ptr [rax], al
0x1800105b2: add      byte ptr [rax], al
0x1800105b4: add      byte ptr [rax], al
0x1800105b6: add      byte ptr [rax], al
0x1800105b8: add      byte ptr [rax], al
0x1800105ba: add      byte ptr [rax], al
0x1800105bc: add      byte ptr [rax], al
0x1800105be: add      byte ptr [rax], al
0x1800105c0: add      byte ptr [rax], al
0x1800105c2: add      byte ptr [rax], al
0x1800105c4: add      byte ptr [rax], al
0x1800105c6: add      byte ptr [rax], al
0x1800105c8: add      byte ptr [rax], al
0x1800105ca: add      byte ptr [rax], al
0x1800105cc: add      byte ptr [rax], al
0x1800105ce: add      byte ptr [rax], al
0x1800105d0: add      byte ptr [rax], al
0x1800105d2: add      byte ptr [rax], al
0x1800105d4: add      byte ptr [rax], al
0x1800105d6: add      byte ptr [rax], al
0x1800105d8: add      byte ptr [rax], al
0x1800105da: add      byte ptr [rax], al
0x1800105dc: add      byte ptr [rax], al
0x1800105de: add      byte ptr [rax], al
0x1800105e0: add      byte ptr [rax], al
0x1800105e2: add      byte ptr [rax], al
0x1800105e4: add      byte ptr [rax], al
0x1800105e6: add      byte ptr [rax], al
0x1800105e8: add      byte ptr [rax], al
0x1800105ea: add      byte ptr [rax], al
0x1800105ec: add      byte ptr [rax], al
0x1800105ee: add      byte ptr [rax], al
0x1800105f0: add      byte ptr [rax], al
0x1800105f2: add      byte ptr [rax], al
0x1800105f4: add      byte ptr [rax], al
0x1800105f6: add      byte ptr [rax], al
0x1800105f8: add      byte ptr [rax], al
0x1800105fa: add      byte ptr [rax], al
0x1800105fc: add      byte ptr [rax], al
0x1800105fe: add      byte ptr [rax], al
0x180010600: add      byte ptr [rax], al
0x180010602: add      byte ptr [rax], al
0x180010604: add      byte ptr [rax], al
0x180010606: add      byte ptr [rax], al
0x180010608: add      byte ptr [rax], al
0x18001060a: add      byte ptr [rax], al
0x18001060c: add      byte ptr [rax], al
0x18001060e: add      byte ptr [rax], al
0x180010610: add      byte ptr [rax], al
0x180010612: add      byte ptr [rax], al
0x180010614: add      byte ptr [rax], al
0x180010616: add      byte ptr [rax], al
0x180010618: add      byte ptr [rax], al
0x18001061a: add      byte ptr [rax], al
0x18001061c: add      byte ptr [rax], al
0x18001061e: add      byte ptr [rax], al
0x180010620: add      byte ptr [rax], al
0x180010622: add      byte ptr [rax], al
0x180010624: add      byte ptr [rax], al
0x180010626: add      byte ptr [rax], al
0x180010628: add      byte ptr [rax], al
0x18001062a: add      byte ptr [rax], al
0x18001062c: add      byte ptr [rax], al
0x18001062e: add      byte ptr [rax], al
0x180010630: add      byte ptr [rax], al
0x180010632: add      byte ptr [rax], al
0x180010634: add      byte ptr [rax], al
0x180010636: add      byte ptr [rax], al
0x180010638: add      byte ptr [rax], al
0x18001063a: add      byte ptr [rax], al
0x18001063c: add      byte ptr [rax], al
0x18001063e: add      byte ptr [rax], al
0x180010640: add      byte ptr [rax], al
0x180010642: add      byte ptr [rax], al
0x180010644: add      byte ptr [rax], al
0x180010646: add      byte ptr [rax], al
0x180010648: add      byte ptr [rax], al
0x18001064a: add      byte ptr [rax], al
0x18001064c: add      byte ptr [rax], al
0x18001064e: add      byte ptr [rax], al
0x180010650: add      byte ptr [rax], al
0x180010652: add      byte ptr [rax], al
0x180010654: add      byte ptr [rax], al
0x180010656: add      byte ptr [rax], al
0x180010658: add      byte ptr [rax], al
0x18001065a: add      byte ptr [rax], al
0x18001065c: add      byte ptr [rax], al
0x18001065e: add      byte ptr [rax], al
0x180010660: add      byte ptr [rax], al
0x180010662: add      byte ptr [rax], al
0x180010664: add      byte ptr [rax], al
0x180010666: add      byte ptr [rax], al
0x180010668: add      byte ptr [rax], al
0x18001066a: add      byte ptr [rax], al
0x18001066c: add      byte ptr [rax], al
0x18001066e: add      byte ptr [rax], al
0x180010670: add      byte ptr [rax], al
0x180010672: add      byte ptr [rax], al
0x180010674: add      byte ptr [rax], al
0x180010676: add      byte ptr [rax], al
0x180010678: add      byte ptr [rax], al
0x18001067a: add      byte ptr [rax], al
0x18001067c: add      byte ptr [rax], al
0x18001067e: add      byte ptr [rax], al
0x180010680: add      byte ptr [rax], al
0x180010682: add      byte ptr [rax], al
0x180010684: add      byte ptr [rax], al
0x180010686: add      byte ptr [rax], al
0x180010688: add      byte ptr [rax], al
0x18001068a: add      byte ptr [rax], al
0x18001068c: add      byte ptr [rax], al
0x18001068e: add      byte ptr [rax], al
0x180010690: add      byte ptr [rax], al
0x180010692: add      byte ptr [rax], al
0x180010694: add      byte ptr [rax], al
0x180010696: add      byte ptr [rax], al
0x180010698: add      byte ptr [rax], al
0x18001069a: add      byte ptr [rax], al
0x18001069c: add      byte ptr [rax], al
0x18001069e: add      byte ptr [rax], al
0x1800106a0: add      byte ptr [rax], al
0x1800106a2: add      byte ptr [rax], al
0x1800106a4: add      byte ptr [rax], al
0x1800106a6: add      byte ptr [rax], al
0x1800106a8: add      byte ptr [rax], al
0x1800106aa: add      byte ptr [rax], al
0x1800106ac: add      byte ptr [rax], al
0x1800106ae: add      byte ptr [rax], al
0x1800106b0: add      byte ptr [rax], al
0x1800106b2: add      byte ptr [rax], al
0x1800106b4: add      byte ptr [rax], al
0x1800106b6: add      byte ptr [rax], al
0x1800106b8: add      byte ptr [rax], al
0x1800106ba: add      byte ptr [rax], al
0x1800106bc: add      byte ptr [rax], al
0x1800106be: add      byte ptr [rax], al
0x1800106c0: add      byte ptr [rax], al
0x1800106c2: add      byte ptr [rax], al
0x1800106c4: add      byte ptr [rax], al
0x1800106c6: add      byte ptr [rax], al
0x1800106c8: add      byte ptr [rax], al
0x1800106ca: add      byte ptr [rax], al
0x1800106cc: add      byte ptr [rax], al
0x1800106ce: add      byte ptr [rax], al
0x1800106d0: add      byte ptr [rax], al
0x1800106d2: add      byte ptr [rax], al
0x1800106d4: add      byte ptr [rax], al
0x1800106d6: add      byte ptr [rax], al
0x1800106d8: add      byte ptr [rax], al
0x1800106da: add      byte ptr [rax], al
0x1800106dc: add      byte ptr [rax], al
0x1800106de: add      byte ptr [rax], al
0x1800106e0: add      byte ptr [rax], al
0x1800106e2: add      byte ptr [rax], al
0x1800106e4: add      byte ptr [rax], al
0x1800106e6: add      byte ptr [rax], al
0x1800106e8: add      byte ptr [rax], al
0x1800106ea: add      byte ptr [rax], al
0x1800106ec: add      byte ptr [rax], al
0x1800106ee: add      byte ptr [rax], al
0x1800106f0: add      byte ptr [rax], al
0x1800106f2: add      byte ptr [rax], al
0x1800106f4: add      byte ptr [rax], al
0x1800106f6: add      byte ptr [rax], al
0x1800106f8: add      byte ptr [rax], al
0x1800106fa: add      byte ptr [rax], al
0x1800106fc: add      byte ptr [rax], al
0x1800106fe: add      byte ptr [rax], al
0x180010700: add      byte ptr [rax], al
0x180010702: add      byte ptr [rax], al
0x180010704: add      byte ptr [rax], al
0x180010706: add      byte ptr [rax], al
0x180010708: add      byte ptr [rax], al
0x18001070a: add      byte ptr [rax], al
0x18001070c: add      byte ptr [rax], al
0x18001070e: add      byte ptr [rax], al
0x180010710: add      byte ptr [rax], al
0x180010712: add      byte ptr [rax], al
0x180010714: add      byte ptr [rax], al
0x180010716: add      byte ptr [rax], al
0x180010718: add      byte ptr [rax], al
0x18001071a: add      byte ptr [rax], al
0x18001071c: add      byte ptr [rax], al
0x18001071e: add      byte ptr [rax], al
0x180010720: add      byte ptr [rax], al
0x180010722: add      byte ptr [rax], al
0x180010724: add      byte ptr [rax], al
0x180010726: add      byte ptr [rax], al
0x180010728: add      byte ptr [rax], al
0x18001072a: add      byte ptr [rax], al
0x18001072c: add      byte ptr [rax], al
0x18001072e: add      byte ptr [rax], al
0x180010730: add      byte ptr [rax], al
0x180010732: add      byte ptr [rax], al
0x180010734: add      byte ptr [rax], al
0x180010736: add      byte ptr [rax], al
0x180010738: add      byte ptr [rax], al
0x18001073a: add      byte ptr [rax], al
0x18001073c: add      byte ptr [rax], al
0x18001073e: add      byte ptr [rax], al
0x180010740: add      byte ptr [rax], al
0x180010742: add      byte ptr [rax], al
0x180010744: add      byte ptr [rax], al
0x180010746: add      byte ptr [rax], al
0x180010748: add      byte ptr [rax], al
0x18001074a: add      byte ptr [rax], al
0x18001074c: add      byte ptr [rax], al
0x18001074e: add      byte ptr [rax], al
0x180010750: add      byte ptr [rax], al
0x180010752: add      byte ptr [rax], al
0x180010754: add      byte ptr [rax], al
0x180010756: add      byte ptr [rax], al
0x180010758: add      byte ptr [rax], al
0x18001075a: add      byte ptr [rax], al
0x18001075c: add      byte ptr [rax], al
0x18001075e: add      byte ptr [rax], al
0x180010760: add      byte ptr [rax], al
0x180010762: add      byte ptr [rax], al
0x180010764: add      byte ptr [rax], al
0x180010766: add      byte ptr [rax], al
0x180010768: add      byte ptr [rax], al
0x18001076a: add      byte ptr [rax], al
0x18001076c: add      byte ptr [rax], al
0x18001076e: add      byte ptr [rax], al
0x180010770: add      byte ptr [rax], al
0x180010772: add      byte ptr [rax], al
0x180010774: add      byte ptr [rax], al
0x180010776: add      byte ptr [rax], al
0x180010778: add      byte ptr [rax], al
0x18001077a: add      byte ptr [rax], al
0x18001077c: add      byte ptr [rax], al
0x18001077e: add      byte ptr [rax], al
0x180010780: add      byte ptr [rax], al
0x180010782: add      byte ptr [rax], al
0x180010784: add      byte ptr [rax], al
0x180010786: add      byte ptr [rax], al
0x180010788: add      byte ptr [rax], al
0x18001078a: add      byte ptr [rax], al
0x18001078c: add      byte ptr [rax], al
0x18001078e: add      byte ptr [rax], al
0x180010790: add      byte ptr [rax], al
0x180010792: add      byte ptr [rax], al
0x180010794: add      byte ptr [rax], al
0x180010796: add      byte ptr [rax], al
0x180010798: add      byte ptr [rax], al
0x18001079a: add      byte ptr [rax], al
0x18001079c: add      byte ptr [rax], al
0x18001079e: add      byte ptr [rax], al
0x1800107a0: add      byte ptr [rax], al
0x1800107a2: add      byte ptr [rax], al
0x1800107a4: add      byte ptr [rax], al
0x1800107a6: add      byte ptr [rax], al
0x1800107a8: add      byte ptr [rax], al
0x1800107aa: add      byte ptr [rax], al
0x1800107ac: add      byte ptr [rax], al
0x1800107ae: add      byte ptr [rax], al
0x1800107b0: add      byte ptr [rax], al
0x1800107b2: add      byte ptr [rax], al
0x1800107b4: add      byte ptr [rax], al
0x1800107b6: add      byte ptr [rax], al
0x1800107b8: add      byte ptr [rax], al
0x1800107ba: add      byte ptr [rax], al
0x1800107bc: add      byte ptr [rax], al
0x1800107be: add      byte ptr [rax], al
0x1800107c0: add      byte ptr [rax], al
0x1800107c2: add      byte ptr [rax], al
0x1800107c4: add      byte ptr [rax], al
0x1800107c6: add      byte ptr [rax], al
0x1800107c8: add      byte ptr [rax], al
0x1800107ca: add      byte ptr [rax], al
0x1800107cc: add      byte ptr [rax], al
0x1800107ce: add      byte ptr [rax], al
0x1800107d0: add      byte ptr [rax], al
0x1800107d2: add      byte ptr [rax], al
0x1800107d4: add      byte ptr [rax], al
0x1800107d6: add      byte ptr [rax], al
0x1800107d8: add      byte ptr [rax], al
0x1800107da: add      byte ptr [rax], al
0x1800107dc: add      byte ptr [rax], al
0x1800107de: add      byte ptr [rax], al
0x1800107e0: add      byte ptr [rax], al
0x1800107e2: add      byte ptr [rax], al
0x1800107e4: add      byte ptr [rax], al
0x1800107e6: add      byte ptr [rax], al
0x1800107e8: add      byte ptr [rax], al
0x1800107ea: add      byte ptr [rax], al
0x1800107ec: add      byte ptr [rax], al
0x1800107ee: add      byte ptr [rax], al
0x1800107f0: add      byte ptr [rax], al
0x1800107f2: add      byte ptr [rax], al
0x1800107f4: add      byte ptr [rax], al
0x1800107f6: add      byte ptr [rax], al
0x1800107f8: add      byte ptr [rax], al
0x1800107fa: add      byte ptr [rax], al
0x1800107fc: add      byte ptr [rax], al
0x1800107fe: add      byte ptr [rax], al
0x180010800: add      byte ptr [rax], al
0x180010802: add      byte ptr [rax], al
0x180010804: add      byte ptr [rax], al
0x180010806: add      byte ptr [rax], al
0x180010808: add      byte ptr [rax], al
0x18001080a: add      byte ptr [rax], al
0x18001080c: add      byte ptr [rax], al
0x18001080e: add      byte ptr [rax], al
0x180010810: add      byte ptr [rax], al
0x180010812: add      byte ptr [rax], al
0x180010814: add      byte ptr [rax], al
0x180010816: add      byte ptr [rax], al
0x180010818: add      byte ptr [rax], al
0x18001081a: add      byte ptr [rax], al
0x18001081c: add      byte ptr [rax], al
0x18001081e: add      byte ptr [rax], al
0x180010820: add      byte ptr [rax], al
0x180010822: add      byte ptr [rax], al
0x180010824: add      byte ptr [rax], al
0x180010826: add      byte ptr [rax], al
0x180010828: add      byte ptr [rax], al
0x18001082a: add      byte ptr [rax], al
0x18001082c: add      byte ptr [rax], al
0x18001082e: add      byte ptr [rax], al
0x180010830: add      byte ptr [rax], al
0x180010832: add      byte ptr [rax], al
0x180010834: add      byte ptr [rax], al
0x180010836: add      byte ptr [rax], al
0x180010838: add      byte ptr [rax], al
0x18001083a: add      byte ptr [rax], al
0x18001083c: add      byte ptr [rax], al
0x18001083e: add      byte ptr [rax], al
0x180010840: add      byte ptr [rax], al
0x180010842: add      byte ptr [rax], al
0x180010844: add      byte ptr [rax], al
0x180010846: add      byte ptr [rax], al
0x180010848: add      byte ptr [rax], al
0x18001084a: add      byte ptr [rax], al
0x18001084c: add      byte ptr [rax], al
0x18001084e: add      byte ptr [rax], al
0x180010850: add      byte ptr [rax], al
0x180010852: add      byte ptr [rax], al
0x180010854: add      byte ptr [rax], al
0x180010856: add      byte ptr [rax], al
0x180010858: add      byte ptr [rax], al
0x18001085a: add      byte ptr [rax], al
0x18001085c: add      byte ptr [rax], al
0x18001085e: add      byte ptr [rax], al
0x180010860: add      byte ptr [rax], al
0x180010862: add      byte ptr [rax], al
0x180010864: add      byte ptr [rax], al
0x180010866: add      byte ptr [rax], al
0x180010868: add      byte ptr [rax], al
0x18001086a: add      byte ptr [rax], al
0x18001086c: add      byte ptr [rax], al
0x18001086e: add      byte ptr [rax], al
0x180010870: add      byte ptr [rax], al
0x180010872: add      byte ptr [rax], al
0x180010874: add      byte ptr [rax], al
0x180010876: add      byte ptr [rax], al
0x180010878: add      byte ptr [rax], al
0x18001087a: add      byte ptr [rax], al
0x18001087c: add      byte ptr [rax], al
0x18001087e: add      byte ptr [rax], al
0x180010880: add      byte ptr [rax], al
0x180010882: add      byte ptr [rax], al
0x180010884: add      byte ptr [rax], al
0x180010886: add      byte ptr [rax], al
0x180010888: add      byte ptr [rax], al
0x18001088a: add      byte ptr [rax], al
0x18001088c: add      byte ptr [rax], al
0x18001088e: add      byte ptr [rax], al
0x180010890: add      byte ptr [rax], al
0x180010892: add      byte ptr [rax], al
0x180010894: add      byte ptr [rax], al
0x180010896: add      byte ptr [rax], al
0x180010898: add      byte ptr [rax], al
0x18001089a: add      byte ptr [rax], al
0x18001089c: add      byte ptr [rax], al
0x18001089e: add      byte ptr [rax], al
0x1800108a0: add      byte ptr [rax], al
0x1800108a2: add      byte ptr [rax], al
0x1800108a4: add      byte ptr [rax], al
0x1800108a6: add      byte ptr [rax], al
0x1800108a8: add      byte ptr [rax], al
0x1800108aa: add      byte ptr [rax], al
0x1800108ac: add      byte ptr [rax], al
0x1800108ae: add      byte ptr [rax], al
0x1800108b0: add      byte ptr [rax], al
0x1800108b2: add      byte ptr [rax], al
0x1800108b4: add      byte ptr [rax], al
0x1800108b6: add      byte ptr [rax], al
0x1800108b8: add      byte ptr [rax], al
0x1800108ba: add      byte ptr [rax], al
0x1800108bc: add      byte ptr [rax], al
0x1800108be: add      byte ptr [rax], al
0x1800108c0: add      byte ptr [rax], al
0x1800108c2: add      byte ptr [rax], al
0x1800108c4: add      byte ptr [rax], al
0x1800108c6: add      byte ptr [rax], al
0x1800108c8: add      byte ptr [rax], al
0x1800108ca: add      byte ptr [rax], al
0x1800108cc: add      byte ptr [rax], al
0x1800108ce: add      byte ptr [rax], al
0x1800108d0: add      byte ptr [rax], al
0x1800108d2: add      byte ptr [rax], al
0x1800108d4: add      byte ptr [rax], al
0x1800108d6: add      byte ptr [rax], al
0x1800108d8: add      byte ptr [rax], al
0x1800108da: add      byte ptr [rax], al
0x1800108dc: add      byte ptr [rax], al
0x1800108de: add      byte ptr [rax], al
0x1800108e0: add      byte ptr [rax], al
0x1800108e2: add      byte ptr [rax], al
0x1800108e4: add      byte ptr [rax], al
0x1800108e6: add      byte ptr [rax], al
0x1800108e8: add      byte ptr [rax], al
0x1800108ea: add      byte ptr [rax], al
0x1800108ec: add      byte ptr [rax], al
0x1800108ee: add      byte ptr [rax], al
0x1800108f0: add      byte ptr [rax], al
0x1800108f2: add      byte ptr [rax], al
0x1800108f4: add      byte ptr [rax], al
0x1800108f6: add      byte ptr [rax], al
0x1800108f8: add      byte ptr [rax], al
0x1800108fa: add      byte ptr [rax], al
0x1800108fc: add      byte ptr [rax], al
0x1800108fe: add      byte ptr [rax], al
0x180010900: add      byte ptr [rax], al
0x180010902: add      byte ptr [rax], al
0x180010904: add      byte ptr [rax], al
0x180010906: add      byte ptr [rax], al
0x180010908: add      byte ptr [rax], al
0x18001090a: add      byte ptr [rax], al
0x18001090c: add      byte ptr [rax], al
0x18001090e: add      byte ptr [rax], al
0x180010910: add      byte ptr [rax], al
0x180010912: add      byte ptr [rax], al
0x180010914: add      byte ptr [rax], al
0x180010916: add      byte ptr [rax], al
0x180010918: add      byte ptr [rax], al
0x18001091a: add      byte ptr [rax], al
0x18001091c: add      byte ptr [rax], al
0x18001091e: add      byte ptr [rax], al
0x180010920: add      byte ptr [rax], al
0x180010922: add      byte ptr [rax], al
0x180010924: add      byte ptr [rax], al
0x180010926: add      byte ptr [rax], al
0x180010928: add      byte ptr [rax], al
0x18001092a: add      byte ptr [rax], al
0x18001092c: add      byte ptr [rax], al
0x18001092e: add      byte ptr [rax], al
0x180010930: add      byte ptr [rax], al
0x180010932: add      byte ptr [rax], al
0x180010934: add      byte ptr [rax], al
0x180010936: add      byte ptr [rax], al
0x180010938: add      byte ptr [rax], al
0x18001093a: add      byte ptr [rax], al
0x18001093c: add      byte ptr [rax], al
0x18001093e: add      byte ptr [rax], al
0x180010940: add      byte ptr [rax], al
0x180010942: add      byte ptr [rax], al
0x180010944: add      byte ptr [rax], al
0x180010946: add      byte ptr [rax], al
0x180010948: add      byte ptr [rax], al
0x18001094a: add      byte ptr [rax], al
0x18001094c: add      byte ptr [rax], al
0x18001094e: add      byte ptr [rax], al
0x180010950: add      byte ptr [rax], al
0x180010952: add      byte ptr [rax], al
0x180010954: add      byte ptr [rax], al
0x180010956: add      byte ptr [rax], al
0x180010958: add      byte ptr [rax], al
0x18001095a: add      byte ptr [rax], al
0x18001095c: add      byte ptr [rax], al
0x18001095e: add      byte ptr [rax], al
0x180010960: add      byte ptr [rax], al
0x180010962: add      byte ptr [rax], al
0x180010964: add      byte ptr [rax], al
0x180010966: add      byte ptr [rax], al
0x180010968: add      byte ptr [rax], al
0x18001096a: add      byte ptr [rax], al
0x18001096c: add      byte ptr [rax], al
0x18001096e: add      byte ptr [rax], al
0x180010970: add      byte ptr [rax], al
0x180010972: add      byte ptr [rax], al
0x180010974: add      byte ptr [rax], al
0x180010976: add      byte ptr [rax], al
0x180010978: add      byte ptr [rax], al
0x18001097a: add      byte ptr [rax], al
0x18001097c: add      byte ptr [rax], al
0x18001097e: add      byte ptr [rax], al
0x180010980: add      byte ptr [rax], al
0x180010982: add      byte ptr [rax], al
0x180010984: add      byte ptr [rax], al
0x180010986: add      byte ptr [rax], al
0x180010988: add      byte ptr [rax], al
0x18001098a: add      byte ptr [rax], al
0x18001098c: add      byte ptr [rax], al
0x18001098e: add      byte ptr [rax], al
0x180010990: add      byte ptr [rax], al
0x180010992: add      byte ptr [rax], al
0x180010994: add      byte ptr [rax], al
0x180010996: add      byte ptr [rax], al
0x180010998: add      byte ptr [rax], al
0x18001099a: add      byte ptr [rax], al
0x18001099c: add      byte ptr [rax], al
0x18001099e: add      byte ptr [rax], al
0x1800109a0: add      byte ptr [rax], al
0x1800109a2: add      byte ptr [rax], al
0x1800109a4: add      byte ptr [rax], al
0x1800109a6: add      byte ptr [rax], al
0x1800109a8: add      byte ptr [rax], al
0x1800109aa: add      byte ptr [rax], al
0x1800109ac: add      byte ptr [rax], al
0x1800109ae: add      byte ptr [rax], al
0x1800109b0: add      byte ptr [rax], al
0x1800109b2: add      byte ptr [rax], al
0x1800109b4: add      byte ptr [rax], al
0x1800109b6: add      byte ptr [rax], al
0x1800109b8: add      byte ptr [rax], al
0x1800109ba: add      byte ptr [rax], al
0x1800109bc: add      byte ptr [rax], al
0x1800109be: add      byte ptr [rax], al
0x1800109c0: add      byte ptr [rax], al
0x1800109c2: add      byte ptr [rax], al
0x1800109c4: add      byte ptr [rax], al
0x1800109c6: add      byte ptr [rax], al
0x1800109c8: add      byte ptr [rax], al
0x1800109ca: add      byte ptr [rax], al
0x1800109cc: add      byte ptr [rax], al
0x1800109ce: add      byte ptr [rax], al
0x1800109d0: add      byte ptr [rax], al
0x1800109d2: add      byte ptr [rax], al
0x1800109d4: add      byte ptr [rax], al
0x1800109d6: add      byte ptr [rax], al
0x1800109d8: add      byte ptr [rax], al
0x1800109da: add      byte ptr [rax], al
0x1800109dc: add      byte ptr [rax], al
0x1800109de: add      byte ptr [rax], al
0x1800109e0: add      byte ptr [rax], al
0x1800109e2: add      byte ptr [rax], al
0x1800109e4: add      byte ptr [rax], al
0x1800109e6: add      byte ptr [rax], al
0x1800109e8: add      byte ptr [rax], al
0x1800109ea: add      byte ptr [rax], al
0x1800109ec: add      byte ptr [rax], al
0x1800109ee: add      byte ptr [rax], al
0x1800109f0: add      byte ptr [rax], al
0x1800109f2: add      byte ptr [rax], al
0x1800109f4: add      byte ptr [rax], al
0x1800109f6: add      byte ptr [rax], al
0x1800109f8: add      byte ptr [rax], al
0x1800109fa: add      byte ptr [rax], al
0x1800109fc: add      byte ptr [rax], al
0x1800109fe: add      byte ptr [rax], al
0x180010a00: add      byte ptr [rax], al
0x180010a02: add      byte ptr [rax], al
0x180010a04: add      byte ptr [rax], al
0x180010a06: add      byte ptr [rax], al
0x180010a08: add      byte ptr [rax], al
0x180010a0a: add      byte ptr [rax], al
0x180010a0c: add      byte ptr [rax], al
0x180010a0e: add      byte ptr [rax], al
0x180010a10: add      byte ptr [rax], al
0x180010a12: add      byte ptr [rax], al
0x180010a14: add      byte ptr [rax], al
0x180010a16: add      byte ptr [rax], al
0x180010a18: add      byte ptr [rax], al
0x180010a1a: add      byte ptr [rax], al
0x180010a1c: add      byte ptr [rax], al
0x180010a1e: add      byte ptr [rax], al
0x180010a20: add      byte ptr [rax], al
0x180010a22: add      byte ptr [rax], al
0x180010a24: add      byte ptr [rax], al
0x180010a26: add      byte ptr [rax], al
0x180010a28: add      byte ptr [rax], al
0x180010a2a: add      byte ptr [rax], al
0x180010a2c: add      byte ptr [rax], al
0x180010a2e: add      byte ptr [rax], al
0x180010a30: add      byte ptr [rax], al
0x180010a32: add      byte ptr [rax], al
0x180010a34: add      byte ptr [rax], al
0x180010a36: add      byte ptr [rax], al
0x180010a38: add      byte ptr [rax], al
0x180010a3a: add      byte ptr [rax], al
0x180010a3c: add      byte ptr [rax], al
0x180010a3e: add      byte ptr [rax], al
0x180010a40: add      byte ptr [rax], al
0x180010a42: add      byte ptr [rax], al
0x180010a44: add      byte ptr [rax], al
0x180010a46: add      byte ptr [rax], al
0x180010a48: add      byte ptr [rax], al
0x180010a4a: add      byte ptr [rax], al
0x180010a4c: add      byte ptr [rax], al
0x180010a4e: add      byte ptr [rax], al
0x180010a50: add      byte ptr [rax], al
0x180010a52: add      byte ptr [rax], al
0x180010a54: add      byte ptr [rax], al
0x180010a56: add      byte ptr [rax], al
0x180010a58: add      byte ptr [rax], al
0x180010a5a: add      byte ptr [rax], al
0x180010a5c: add      byte ptr [rax], al
0x180010a5e: add      byte ptr [rax], al
0x180010a60: add      byte ptr [rax], al
0x180010a62: add      byte ptr [rax], al
0x180010a64: add      byte ptr [rax], al
0x180010a66: add      byte ptr [rax], al
0x180010a68: add      byte ptr [rax], al
0x180010a6a: add      byte ptr [rax], al
0x180010a6c: add      byte ptr [rax], al
0x180010a6e: add      byte ptr [rax], al
0x180010a70: add      byte ptr [rax], al
0x180010a72: add      byte ptr [rax], al
0x180010a74: add      byte ptr [rax], al
0x180010a76: add      byte ptr [rax], al
0x180010a78: add      byte ptr [rax], al
0x180010a7a: add      byte ptr [rax], al
0x180010a7c: add      byte ptr [rax], al
0x180010a7e: add      byte ptr [rax], al
0x180010a80: add      byte ptr [rax], al
0x180010a82: add      byte ptr [rax], al
0x180010a84: add      byte ptr [rax], al
0x180010a86: add      byte ptr [rax], al
0x180010a88: add      byte ptr [rax], al
0x180010a8a: add      byte ptr [rax], al
0x180010a8c: add      byte ptr [rax], al
0x180010a8e: add      byte ptr [rax], al
0x180010a90: add      byte ptr [rax], al
0x180010a92: add      byte ptr [rax], al
0x180010a94: add      byte ptr [rax], al
0x180010a96: add      byte ptr [rax], al
0x180010a98: add      byte ptr [rax], al
0x180010a9a: add      byte ptr [rax], al
0x180010a9c: add      byte ptr [rax], al
0x180010a9e: add      byte ptr [rax], al
0x180010aa0: add      byte ptr [rax], al
0x180010aa2: add      byte ptr [rax], al
0x180010aa4: add      byte ptr [rax], al
0x180010aa6: add      byte ptr [rax], al
0x180010aa8: add      byte ptr [rax], al
0x180010aaa: add      byte ptr [rax], al
0x180010aac: add      byte ptr [rax], al
0x180010aae: add      byte ptr [rax], al
0x180010ab0: add      byte ptr [rax], al
0x180010ab2: add      byte ptr [rax], al
0x180010ab4: add      byte ptr [rax], al
0x180010ab6: add      byte ptr [rax], al
0x180010ab8: add      byte ptr [rax], al
0x180010aba: add      byte ptr [rax], al
0x180010abc: add      byte ptr [rax], al
0x180010abe: add      byte ptr [rax], al
0x180010ac0: add      byte ptr [rax], al
0x180010ac2: add      byte ptr [rax], al
0x180010ac4: add      byte ptr [rax], al
0x180010ac6: add      byte ptr [rax], al
0x180010ac8: add      byte ptr [rax], al
0x180010aca: add      byte ptr [rax], al
0x180010acc: add      byte ptr [rax], al
0x180010ace: add      byte ptr [rax], al
0x180010ad0: add      byte ptr [rax], al
0x180010ad2: add      byte ptr [rax], al
0x180010ad4: add      byte ptr [rax], al
0x180010ad6: add      byte ptr [rax], al
0x180010ad8: add      byte ptr [rax], al
0x180010ada: add      byte ptr [rax], al
0x180010adc: add      byte ptr [rax], al
0x180010ade: add      byte ptr [rax], al
0x180010ae0: add      byte ptr [rax], al
0x180010ae2: add      byte ptr [rax], al
0x180010ae4: add      byte ptr [rax], al
0x180010ae6: add      byte ptr [rax], al
0x180010ae8: add      byte ptr [rax], al
0x180010aea: add      byte ptr [rax], al
0x180010aec: add      byte ptr [rax], al
0x180010aee: add      byte ptr [rax], al
0x180010af0: add      byte ptr [rax], al
0x180010af2: add      byte ptr [rax], al
0x180010af4: add      byte ptr [rax], al
0x180010af6: add      byte ptr [rax], al
0x180010af8: add      byte ptr [rax], al
0x180010afa: add      byte ptr [rax], al
0x180010afc: add      byte ptr [rax], al
0x180010afe: add      byte ptr [rax], al
0x180010b00: add      byte ptr [rax], al
0x180010b02: add      byte ptr [rax], al
0x180010b04: add      byte ptr [rax], al
0x180010b06: add      byte ptr [rax], al
0x180010b08: add      byte ptr [rax], al
0x180010b0a: add      byte ptr [rax], al
0x180010b0c: add      byte ptr [rax], al
0x180010b0e: add      byte ptr [rax], al
0x180010b10: add      byte ptr [rax], al
0x180010b12: add      byte ptr [rax], al
0x180010b14: add      byte ptr [rax], al
0x180010b16: add      byte ptr [rax], al
0x180010b18: add      byte ptr [rax], al
0x180010b1a: add      byte ptr [rax], al
0x180010b1c: add      byte ptr [rax], al
0x180010b1e: add      byte ptr [rax], al
0x180010b20: add      byte ptr [rax], al
0x180010b22: add      byte ptr [rax], al
0x180010b24: add      byte ptr [rax], al
0x180010b26: add      byte ptr [rax], al
0x180010b28: add      byte ptr [rax], al
0x180010b2a: add      byte ptr [rax], al
0x180010b2c: add      byte ptr [rax], al
0x180010b2e: add      byte ptr [rax], al
0x180010b30: add      byte ptr [rax], al
0x180010b32: add      byte ptr [rax], al
0x180010b34: add      byte ptr [rax], al
0x180010b36: add      byte ptr [rax], al
0x180010b38: add      byte ptr [rax], al
0x180010b3a: add      byte ptr [rax], al
0x180010b3c: add      byte ptr [rax], al
0x180010b3e: add      byte ptr [rax], al
0x180010b40: add      byte ptr [rax], al
0x180010b42: add      byte ptr [rax], al
0x180010b44: add      byte ptr [rax], al
0x180010b46: add      byte ptr [rax], al
0x180010b48: add      byte ptr [rax], al
0x180010b4a: add      byte ptr [rax], al
0x180010b4c: add      byte ptr [rax], al
0x180010b4e: add      byte ptr [rax], al
0x180010b50: add      byte ptr [rax], al
0x180010b52: add      byte ptr [rax], al
0x180010b54: add      byte ptr [rax], al
0x180010b56: add      byte ptr [rax], al
0x180010b58: add      byte ptr [rax], al
0x180010b5a: add      byte ptr [rax], al
0x180010b5c: add      byte ptr [rax], al
0x180010b5e: add      byte ptr [rax], al
0x180010b60: add      byte ptr [rax], al
0x180010b62: add      byte ptr [rax], al
0x180010b64: add      byte ptr [rax], al
0x180010b66: add      byte ptr [rax], al
0x180010b68: add      byte ptr [rax], al
0x180010b6a: add      byte ptr [rax], al
0x180010b6c: add      byte ptr [rax], al
0x180010b6e: add      byte ptr [rax], al
0x180010b70: add      byte ptr [rax], al
0x180010b72: add      byte ptr [rax], al
0x180010b74: add      byte ptr [rax], al
0x180010b76: add      byte ptr [rax], al
0x180010b78: add      byte ptr [rax], al
0x180010b7a: add      byte ptr [rax], al
0x180010b7c: add      byte ptr [rax], al
0x180010b7e: add      byte ptr [rax], al
0x180010b80: add      byte ptr [rax], al
0x180010b82: add      byte ptr [rax], al
0x180010b84: add      byte ptr [rax], al
0x180010b86: add      byte ptr [rax], al
0x180010b88: add      byte ptr [rax], al
0x180010b8a: add      byte ptr [rax], al
0x180010b8c: add      byte ptr [rax], al
0x180010b8e: add      byte ptr [rax], al
0x180010b90: add      byte ptr [rax], al
0x180010b92: add      byte ptr [rax], al
0x180010b94: add      byte ptr [rax], al
0x180010b96: add      byte ptr [rax], al
0x180010b98: add      byte ptr [rax], al
0x180010b9a: add      byte ptr [rax], al
0x180010b9c: add      byte ptr [rax], al
0x180010b9e: add      byte ptr [rax], al
0x180010ba0: add      byte ptr [rax], al
0x180010ba2: add      byte ptr [rax], al
0x180010ba4: add      byte ptr [rax], al
0x180010ba6: add      byte ptr [rax], al
0x180010ba8: add      byte ptr [rax], al
0x180010baa: add      byte ptr [rax], al
0x180010bac: add      byte ptr [rax], al
0x180010bae: add      byte ptr [rax], al
0x180010bb0: add      byte ptr [rax], al
0x180010bb2: add      byte ptr [rax], al
0x180010bb4: add      byte ptr [rax], al
0x180010bb6: add      byte ptr [rax], al
0x180010bb8: add      byte ptr [rax], al
0x180010bba: add      byte ptr [rax], al
0x180010bbc: add      byte ptr [rax], al
0x180010bbe: add      byte ptr [rax], al
0x180010bc0: add      byte ptr [rax], al
0x180010bc2: add      byte ptr [rax], al
0x180010bc4: add      byte ptr [rax], al
0x180010bc6: add      byte ptr [rax], al
0x180010bc8: add      byte ptr [rax], al
0x180010bca: add      byte ptr [rax], al
0x180010bcc: add      byte ptr [rax], al
0x180010bce: add      byte ptr [rax], al
0x180010bd0: add      byte ptr [rax], al
0x180010bd2: add      byte ptr [rax], al
0x180010bd4: add      byte ptr [rax], al
0x180010bd6: add      byte ptr [rax], al
0x180010bd8: add      byte ptr [rax], al
0x180010bda: add      byte ptr [rax], al
0x180010bdc: add      byte ptr [rax], al
0x180010bde: add      byte ptr [rax], al
0x180010be0: add      byte ptr [rax], al
0x180010be2: add      byte ptr [rax], al
0x180010be4: add      byte ptr [rax], al
0x180010be6: add      byte ptr [rax], al
0x180010be8: add      byte ptr [rax], al
0x180010bea: add      byte ptr [rax], al
0x180010bec: add      byte ptr [rax], al
0x180010bee: add      byte ptr [rax], al
0x180010bf0: add      byte ptr [rax], al
0x180010bf2: add      byte ptr [rax], al
0x180010bf4: add      byte ptr [rax], al
0x180010bf6: add      byte ptr [rax], al
0x180010bf8: add      byte ptr [rax], al
0x180010bfa: add      byte ptr [rax], al
0x180010bfc: add      byte ptr [rax], al
0x180010bfe: add      byte ptr [rax], al
0x180010c00: add      byte ptr [rax], al
0x180010c02: add      byte ptr [rax], al
0x180010c04: add      byte ptr [rax], al
0x180010c06: add      byte ptr [rax], al
0x180010c08: add      byte ptr [rax], al
0x180010c0a: add      byte ptr [rax], al
0x180010c0c: add      byte ptr [rax], al
0x180010c0e: add      byte ptr [rax], al
0x180010c10: add      byte ptr [rax], al
0x180010c12: add      byte ptr [rax], al
0x180010c14: add      byte ptr [rax], al
0x180010c16: add      byte ptr [rax], al
0x180010c18: add      byte ptr [rax], al
0x180010c1a: add      byte ptr [rax], al
0x180010c1c: add      byte ptr [rax], al
0x180010c1e: add      byte ptr [rax], al
0x180010c20: add      byte ptr [rax], al
0x180010c22: add      byte ptr [rax], al
0x180010c24: add      byte ptr [rax], al
0x180010c26: add      byte ptr [rax], al
0x180010c28: add      byte ptr [rax], al
0x180010c2a: add      byte ptr [rax], al
0x180010c2c: add      byte ptr [rax], al
0x180010c2e: add      byte ptr [rax], al
0x180010c30: add      byte ptr [rax], al
0x180010c32: add      byte ptr [rax], al
0x180010c34: add      byte ptr [rax], al
0x180010c36: add      byte ptr [rax], al
0x180010c38: add      byte ptr [rax], al
0x180010c3a: add      byte ptr [rax], al
0x180010c3c: add      byte ptr [rax], al
0x180010c3e: add      byte ptr [rax], al
0x180010c40: add      byte ptr [rax], al
0x180010c42: add      byte ptr [rax], al
0x180010c44: add      byte ptr [rax], al
0x180010c46: add      byte ptr [rax], al
0x180010c48: add      byte ptr [rax], al
0x180010c4a: add      byte ptr [rax], al
0x180010c4c: add      byte ptr [rax], al
0x180010c4e: add      byte ptr [rax], al
0x180010c50: add      byte ptr [rax], al
0x180010c52: add      byte ptr [rax], al
0x180010c54: add      byte ptr [rax], al
0x180010c56: add      byte ptr [rax], al
0x180010c58: add      byte ptr [rax], al
0x180010c5a: add      byte ptr [rax], al
0x180010c5c: add      byte ptr [rax], al
0x180010c5e: add      byte ptr [rax], al
0x180010c60: add      byte ptr [rax], al
0x180010c62: add      byte ptr [rax], al
0x180010c64: add      byte ptr [rax], al
0x180010c66: add      byte ptr [rax], al
0x180010c68: add      byte ptr [rax], al
0x180010c6a: add      byte ptr [rax], al
0x180010c6c: add      byte ptr [rax], al
0x180010c6e: add      byte ptr [rax], al
0x180010c70: add      byte ptr [rax], al
0x180010c72: add      byte ptr [rax], al
0x180010c74: add      byte ptr [rax], al
0x180010c76: add      byte ptr [rax], al
0x180010c78: add      byte ptr [rax], al
0x180010c7a: add      byte ptr [rax], al
0x180010c7c: add      byte ptr [rax], al
0x180010c7e: add      byte ptr [rax], al
0x180010c80: add      byte ptr [rax], al
0x180010c82: add      byte ptr [rax], al
0x180010c84: add      byte ptr [rax], al
0x180010c86: add      byte ptr [rax], al
0x180010c88: add      byte ptr [rax], al
0x180010c8a: add      byte ptr [rax], al
0x180010c8c: add      byte ptr [rax], al
0x180010c8e: add      byte ptr [rax], al
0x180010c90: add      byte ptr [rax], al
0x180010c92: add      byte ptr [rax], al
0x180010c94: add      byte ptr [rax], al
0x180010c96: add      byte ptr [rax], al
0x180010c98: add      byte ptr [rax], al
0x180010c9a: add      byte ptr [rax], al
0x180010c9c: add      byte ptr [rax], al
0x180010c9e: add      byte ptr [rax], al
0x180010ca0: add      byte ptr [rax], al
0x180010ca2: add      byte ptr [rax], al
0x180010ca4: add      byte ptr [rax], al
0x180010ca6: add      byte ptr [rax], al
0x180010ca8: add      byte ptr [rax], al
0x180010caa: add      byte ptr [rax], al
0x180010cac: add      byte ptr [rax], al
0x180010cae: add      byte ptr [rax], al
0x180010cb0: add      byte ptr [rax], al
0x180010cb2: add      byte ptr [rax], al
0x180010cb4: add      byte ptr [rax], al
0x180010cb6: add      byte ptr [rax], al
0x180010cb8: add      byte ptr [rax], al
0x180010cba: add      byte ptr [rax], al
0x180010cbc: add      byte ptr [rax], al
0x180010cbe: add      byte ptr [rax], al
0x180010cc0: add      byte ptr [rax], al
0x180010cc2: add      byte ptr [rax], al
0x180010cc4: add      byte ptr [rax], al
0x180010cc6: add      byte ptr [rax], al
0x180010cc8: add      byte ptr [rax], al
0x180010cca: add      byte ptr [rax], al
0x180010ccc: add      byte ptr [rax], al
0x180010cce: add      byte ptr [rax], al
0x180010cd0: add      byte ptr [rax], al
0x180010cd2: add      byte ptr [rax], al
0x180010cd4: add      byte ptr [rax], al
0x180010cd6: add      byte ptr [rax], al
0x180010cd8: add      byte ptr [rax], al
0x180010cda: add      byte ptr [rax], al
0x180010cdc: add      byte ptr [rax], al
0x180010cde: add      byte ptr [rax], al
0x180010ce0: add      byte ptr [rax], al
0x180010ce2: add      byte ptr [rax], al
0x180010ce4: add      byte ptr [rax], al
0x180010ce6: add      byte ptr [rax], al
0x180010ce8: add      byte ptr [rax], al
0x180010cea: add      byte ptr [rax], al
0x180010cec: add      byte ptr [rax], al
0x180010cee: add      byte ptr [rax], al
0x180010cf0: add      byte ptr [rax], al
0x180010cf2: add      byte ptr [rax], al
0x180010cf4: add      byte ptr [rax], al
0x180010cf6: add      byte ptr [rax], al
0x180010cf8: add      byte ptr [rax], al
0x180010cfa: add      byte ptr [rax], al
0x180010cfc: add      byte ptr [rax], al
0x180010cfe: add      byte ptr [rax], al
0x180010d00: add      byte ptr [rax], al
0x180010d02: add      byte ptr [rax], al
0x180010d04: add      byte ptr [rax], al
0x180010d06: add      byte ptr [rax], al
0x180010d08: add      byte ptr [rax], al
0x180010d0a: add      byte ptr [rax], al
0x180010d0c: add      byte ptr [rax], al
0x180010d0e: add      byte ptr [rax], al
0x180010d10: add      byte ptr [rax], al
0x180010d12: add      byte ptr [rax], al
0x180010d14: add      byte ptr [rax], al
0x180010d16: add      byte ptr [rax], al
0x180010d18: add      byte ptr [rax], al
0x180010d1a: add      byte ptr [rax], al
0x180010d1c: add      byte ptr [rax], al
0x180010d1e: add      byte ptr [rax], al
0x180010d20: add      byte ptr [rax], al
0x180010d22: add      byte ptr [rax], al
0x180010d24: add      byte ptr [rax], al
0x180010d26: add      byte ptr [rax], al
0x180010d28: add      byte ptr [rax], al
0x180010d2a: add      byte ptr [rax], al
0x180010d2c: add      byte ptr [rax], al
0x180010d2e: add      byte ptr [rax], al
0x180010d30: add      byte ptr [rax], al
0x180010d32: add      byte ptr [rax], al
0x180010d34: add      byte ptr [rax], al
0x180010d36: add      byte ptr [rax], al
0x180010d38: add      byte ptr [rax], al
0x180010d3a: add      byte ptr [rax], al
0x180010d3c: add      byte ptr [rax], al
0x180010d3e: add      byte ptr [rax], al
0x180010d40: add      byte ptr [rax], al
0x180010d42: add      byte ptr [rax], al
0x180010d44: add      byte ptr [rax], al
0x180010d46: add      byte ptr [rax], al
0x180010d48: add      byte ptr [rax], al
0x180010d4a: add      byte ptr [rax], al
0x180010d4c: add      byte ptr [rax], al
0x180010d4e: add      byte ptr [rax], al
0x180010d50: add      byte ptr [rax], al
0x180010d52: add      byte ptr [rax], al
0x180010d54: add      byte ptr [rax], al
0x180010d56: add      byte ptr [rax], al
0x180010d58: add      byte ptr [rax], al
0x180010d5a: add      byte ptr [rax], al
0x180010d5c: add      byte ptr [rax], al
0x180010d5e: add      byte ptr [rax], al
0x180010d60: add      byte ptr [rax], al
0x180010d62: add      byte ptr [rax], al
0x180010d64: add      byte ptr [rax], al
0x180010d66: add      byte ptr [rax], al
0x180010d68: add      byte ptr [rax], al
0x180010d6a: add      byte ptr [rax], al
0x180010d6c: add      byte ptr [rax], al
0x180010d6e: add      byte ptr [rax], al
0x180010d70: add      byte ptr [rax], al
0x180010d72: add      byte ptr [rax], al
0x180010d74: add      byte ptr [rax], al
0x180010d76: add      byte ptr [rax], al
0x180010d78: add      byte ptr [rax], al
0x180010d7a: add      byte ptr [rax], al
0x180010d7c: add      byte ptr [rax], al
0x180010d7e: add      byte ptr [rax], al
0x180010d80: add      byte ptr [rax], al
0x180010d82: add      byte ptr [rax], al
0x180010d84: add      byte ptr [rax], al
0x180010d86: add      byte ptr [rax], al
0x180010d88: add      byte ptr [rax], al
0x180010d8a: add      byte ptr [rax], al
0x180010d8c: add      byte ptr [rax], al
0x180010d8e: add      byte ptr [rax], al
0x180010d90: add      byte ptr [rax], al
0x180010d92: add      byte ptr [rax], al
0x180010d94: add      byte ptr [rax], al
0x180010d96: add      byte ptr [rax], al
0x180010d98: add      byte ptr [rax], al
0x180010d9a: add      byte ptr [rax], al
0x180010d9c: add      byte ptr [rax], al
0x180010d9e: add      byte ptr [rax], al
0x180010da0: add      byte ptr [rax], al
0x180010da2: add      byte ptr [rax], al
0x180010da4: add      byte ptr [rax], al
0x180010da6: add      byte ptr [rax], al
0x180010da8: add      byte ptr [rax], al
0x180010daa: add      byte ptr [rax], al
0x180010dac: add      byte ptr [rax], al
0x180010dae: add      byte ptr [rax], al
0x180010db0: add      byte ptr [rax], al
0x180010db2: add      byte ptr [rax], al
0x180010db4: add      byte ptr [rax], al
0x180010db6: add      byte ptr [rax], al
0x180010db8: add      byte ptr [rax], al
0x180010dba: add      byte ptr [rax], al
0x180010dbc: add      byte ptr [rax], al
0x180010dbe: add      byte ptr [rax], al
0x180010dc0: add      byte ptr [rax], al
0x180010dc2: add      byte ptr [rax], al
0x180010dc4: add      byte ptr [rax], al
0x180010dc6: add      byte ptr [rax], al
0x180010dc8: add      byte ptr [rax], al
0x180010dca: add      byte ptr [rax], al
0x180010dcc: add      byte ptr [rax], al
0x180010dce: add      byte ptr [rax], al
0x180010dd0: add      byte ptr [rax], al
0x180010dd2: add      byte ptr [rax], al
0x180010dd4: add      byte ptr [rax], al
0x180010dd6: add      byte ptr [rax], al
0x180010dd8: add      byte ptr [rax], al
0x180010dda: add      byte ptr [rax], al
0x180010ddc: add      byte ptr [rax], al
0x180010dde: add      byte ptr [rax], al
0x180010de0: add      byte ptr [rax], al
0x180010de2: add      byte ptr [rax], al
0x180010de4: add      byte ptr [rax], al
0x180010de6: add      byte ptr [rax], al
0x180010de8: add      byte ptr [rax], al
0x180010dea: add      byte ptr [rax], al
0x180010dec: add      byte ptr [rax], al
0x180010dee: add      byte ptr [rax], al
0x180010df0: add      byte ptr [rax], al
0x180010df2: add      byte ptr [rax], al
0x180010df4: add      byte ptr [rax], al
0x180010df6: add      byte ptr [rax], al
0x180010df8: add      byte ptr [rax], al
0x180010dfa: add      byte ptr [rax], al
0x180010dfc: add      byte ptr [rax], al
0x180010dfe: add      byte ptr [rax], al
0x180010e00: add      byte ptr [rax], al
0x180010e02: add      byte ptr [rax], al
0x180010e04: add      byte ptr [rax], al
0x180010e06: add      byte ptr [rax], al
0x180010e08: add      byte ptr [rax], al
0x180010e0a: add      byte ptr [rax], al
0x180010e0c: add      byte ptr [rax], al
0x180010e0e: add      byte ptr [rax], al
0x180010e10: add      byte ptr [rax], al
0x180010e12: add      byte ptr [rax], al
0x180010e14: add      byte ptr [rax], al
0x180010e16: add      byte ptr [rax], al
0x180010e18: add      byte ptr [rax], al
0x180010e1a: add      byte ptr [rax], al
0x180010e1c: add      byte ptr [rax], al
0x180010e1e: add      byte ptr [rax], al
0x180010e20: add      byte ptr [rax], al
0x180010e22: add      byte ptr [rax], al
0x180010e24: add      byte ptr [rax], al
0x180010e26: add      byte ptr [rax], al
0x180010e28: add      byte ptr [rax], al
0x180010e2a: add      byte ptr [rax], al
0x180010e2c: add      byte ptr [rax], al
0x180010e2e: add      byte ptr [rax], al
0x180010e30: add      byte ptr [rax], al
0x180010e32: add      byte ptr [rax], al
0x180010e34: add      byte ptr [rax], al
0x180010e36: add      byte ptr [rax], al
0x180010e38: add      byte ptr [rax], al
0x180010e3a: add      byte ptr [rax], al
0x180010e3c: add      byte ptr [rax], al
0x180010e3e: add      byte ptr [rax], al
0x180010e40: add      byte ptr [rax], al
0x180010e42: add      byte ptr [rax], al
0x180010e44: add      byte ptr [rax], al
0x180010e46: add      byte ptr [rax], al
0x180010e48: add      byte ptr [rax], al
0x180010e4a: add      byte ptr [rax], al
0x180010e4c: add      byte ptr [rax], al
0x180010e4e: add      byte ptr [rax], al
0x180010e50: add      byte ptr [rax], al
0x180010e52: add      byte ptr [rax], al
0x180010e54: add      byte ptr [rax], al
0x180010e56: add      byte ptr [rax], al
0x180010e58: add      byte ptr [rax], al
0x180010e5a: add      byte ptr [rax], al
0x180010e5c: add      byte ptr [rax], al
0x180010e5e: add      byte ptr [rax], al
0x180010e60: add      byte ptr [rax], al
0x180010e62: add      byte ptr [rax], al
0x180010e64: add      byte ptr [rax], al
0x180010e66: add      byte ptr [rax], al
0x180010e68: add      byte ptr [rax], al
0x180010e6a: add      byte ptr [rax], al
0x180010e6c: add      byte ptr [rax], al
0x180010e6e: add      byte ptr [rax], al
0x180010e70: add      byte ptr [rax], al
0x180010e72: add      byte ptr [rax], al
0x180010e74: add      byte ptr [rax], al
0x180010e76: add      byte ptr [rax], al
0x180010e78: add      byte ptr [rax], al
0x180010e7a: add      byte ptr [rax], al
0x180010e7c: add      byte ptr [rax], al
0x180010e7e: add      byte ptr [rax], al
0x180010e80: add      byte ptr [rax], al
0x180010e82: add      byte ptr [rax], al
0x180010e84: add      byte ptr [rax], al
0x180010e86: add      byte ptr [rax], al
0x180010e88: add      byte ptr [rax], al
0x180010e8a: add      byte ptr [rax], al
0x180010e8c: add      byte ptr [rax], al
0x180010e8e: add      byte ptr [rax], al
0x180010e90: add      byte ptr [rax], al
0x180010e92: add      byte ptr [rax], al
0x180010e94: add      byte ptr [rax], al
0x180010e96: add      byte ptr [rax], al
0x180010e98: add      byte ptr [rax], al
0x180010e9a: add      byte ptr [rax], al
0x180010e9c: add      byte ptr [rax], al
0x180010e9e: add      byte ptr [rax], al
0x180010ea0: add      byte ptr [rax], al
0x180010ea2: add      byte ptr [rax], al
0x180010ea4: add      byte ptr [rax], al
0x180010ea6: add      byte ptr [rax], al
0x180010ea8: add      byte ptr [rax], al
0x180010eaa: add      byte ptr [rax], al
0x180010eac: add      byte ptr [rax], al
0x180010eae: add      byte ptr [rax], al
0x180010eb0: add      byte ptr [rax], al
0x180010eb2: add      byte ptr [rax], al
0x180010eb4: add      byte ptr [rax], al
0x180010eb6: add      byte ptr [rax], al
0x180010eb8: add      byte ptr [rax], al
0x180010eba: add      byte ptr [rax], al
0x180010ebc: add      byte ptr [rax], al
0x180010ebe: add      byte ptr [rax], al
0x180010ec0: add      byte ptr [rax], al
0x180010ec2: add      byte ptr [rax], al
0x180010ec4: add      byte ptr [rax], al
0x180010ec6: add      byte ptr [rax], al
0x180010ec8: add      byte ptr [rax], al
0x180010eca: add      byte ptr [rax], al
0x180010ecc: add      byte ptr [rax], al
0x180010ece: add      byte ptr [rax], al
0x180010ed0: add      byte ptr [rax], al
0x180010ed2: add      byte ptr [rax], al
0x180010ed4: add      byte ptr [rax], al
0x180010ed6: add      byte ptr [rax], al
0x180010ed8: add      byte ptr [rax], al
0x180010eda: add      byte ptr [rax], al
0x180010edc: add      byte ptr [rax], al
0x180010ede: add      byte ptr [rax], al
0x180010ee0: add      byte ptr [rax], al
0x180010ee2: add      byte ptr [rax], al
0x180010ee4: add      byte ptr [rax], al
0x180010ee6: add      byte ptr [rax], al
0x180010ee8: add      byte ptr [rax], al
0x180010eea: add      byte ptr [rax], al
0x180010eec: add      byte ptr [rax], al
0x180010eee: add      byte ptr [rax], al
0x180010ef0: add      byte ptr [rax], al
0x180010ef2: add      byte ptr [rax], al
0x180010ef4: add      byte ptr [rax], al
0x180010ef6: add      byte ptr [rax], al
0x180010ef8: add      byte ptr [rax], al
0x180010efa: add      byte ptr [rax], al
0x180010efc: add      byte ptr [rax], al
0x180010efe: add      byte ptr [rax], al
0x180010f00: add      byte ptr [rax], al
0x180010f02: add      byte ptr [rax], al
0x180010f04: add      byte ptr [rax], al
0x180010f06: add      byte ptr [rax], al
0x180010f08: add      byte ptr [rax], al
0x180010f0a: add      byte ptr [rax], al
0x180010f0c: add      byte ptr [rax], al
0x180010f0e: add      byte ptr [rax], al
0x180010f10: add      byte ptr [rax], al
0x180010f12: add      byte ptr [rax], al
0x180010f14: add      byte ptr [rax], al
0x180010f16: add      byte ptr [rax], al
0x180010f18: add      byte ptr [rax], al
0x180010f1a: add      byte ptr [rax], al
0x180010f1c: add      byte ptr [rax], al
0x180010f1e: add      byte ptr [rax], al
0x180010f20: add      byte ptr [rax], al
0x180010f22: add      byte ptr [rax], al
0x180010f24: add      byte ptr [rax], al
0x180010f26: add      byte ptr [rax], al
0x180010f28: add      byte ptr [rax], al
0x180010f2a: add      byte ptr [rax], al
0x180010f2c: add      byte ptr [rax], al
0x180010f2e: add      byte ptr [rax], al
0x180010f30: add      byte ptr [rax], al
0x180010f32: add      byte ptr [rax], al
0x180010f34: add      byte ptr [rax], al
0x180010f36: add      byte ptr [rax], al
0x180010f38: add      byte ptr [rax], al
0x180010f3a: add      byte ptr [rax], al
0x180010f3c: add      byte ptr [rax], al
0x180010f3e: add      byte ptr [rax], al
0x180010f40: add      byte ptr [rax], al
0x180010f42: add      byte ptr [rax], al
0x180010f44: add      byte ptr [rax], al
0x180010f46: add      byte ptr [rax], al
0x180010f48: add      byte ptr [rax], al
0x180010f4a: add      byte ptr [rax], al
0x180010f4c: add      byte ptr [rax], al
0x180010f4e: add      byte ptr [rax], al
0x180010f50: add      byte ptr [rax], al
0x180010f52: add      byte ptr [rax], al
0x180010f54: add      byte ptr [rax], al
0x180010f56: add      byte ptr [rax], al
0x180010f58: add      byte ptr [rax], al
0x180010f5a: add      byte ptr [rax], al
0x180010f5c: add      byte ptr [rax], al
0x180010f5e: add      byte ptr [rax], al
0x180010f60: add      byte ptr [rax], al
0x180010f62: add      byte ptr [rax], al
0x180010f64: add      byte ptr [rax], al
0x180010f66: add      byte ptr [rax], al
0x180010f68: add      byte ptr [rax], al
0x180010f6a: add      byte ptr [rax], al
0x180010f6c: add      byte ptr [rax], al
0x180010f6e: add      byte ptr [rax], al
0x180010f70: add      byte ptr [rax], al
0x180010f72: add      byte ptr [rax], al
0x180010f74: add      byte ptr [rax], al
0x180010f76: add      byte ptr [rax], al
0x180010f78: add      byte ptr [rax], al
0x180010f7a: add      byte ptr [rax], al
0x180010f7c: add      byte ptr [rax], al
0x180010f7e: add      byte ptr [rax], al
0x180010f80: add      byte ptr [rax], al
0x180010f82: add      byte ptr [rax], al
0x180010f84: add      byte ptr [rax], al
0x180010f86: add      byte ptr [rax], al
0x180010f88: add      byte ptr [rax], al
0x180010f8a: add      byte ptr [rax], al
0x180010f8c: add      byte ptr [rax], al
0x180010f8e: add      byte ptr [rax], al
0x180010f90: add      byte ptr [rax], al
0x180010f92: add      byte ptr [rax], al
0x180010f94: add      byte ptr [rax], al
0x180010f96: add      byte ptr [rax], al
0x180010f98: add      byte ptr [rax], al
0x180010f9a: add      byte ptr [rax], al
0x180010f9c: add      byte ptr [rax], al
0x180010f9e: add      byte ptr [rax], al
0x180010fa0: add      byte ptr [rax], al
0x180010fa2: add      byte ptr [rax], al
0x180010fa4: add      byte ptr [rax], al
0x180010fa6: add      byte ptr [rax], al
0x180010fa8: add      byte ptr [rax], al
0x180010faa: add      byte ptr [rax], al
0x180010fac: add      byte ptr [rax], al
0x180010fae: add      byte ptr [rax], al
0x180010fb0: add      byte ptr [rax], al
0x180010fb2: add      byte ptr [rax], al
0x180010fb4: add      byte ptr [rax], al
0x180010fb6: add      byte ptr [rax], al
0x180010fb8: add      byte ptr [rax], al
0x180010fba: add      byte ptr [rax], al
0x180010fbc: add      byte ptr [rax], al
0x180010fbe: add      byte ptr [rax], al
0x180010fc0: add      byte ptr [rax], al
0x180010fc2: add      byte ptr [rax], al
0x180010fc4: add      byte ptr [rax], al
0x180010fc6: add      byte ptr [rax], al
0x180010fc8: add      byte ptr [rax], al
0x180010fca: add      byte ptr [rax], al
0x180010fcc: add      byte ptr [rax], al
0x180010fce: add      byte ptr [rax], al
0x180010fd0: add      byte ptr [rax], al
0x180010fd2: add      byte ptr [rax], al
0x180010fd4: add      byte ptr [rax], al
0x180010fd6: add      byte ptr [rax], al
0x180010fd8: add      byte ptr [rax], al
0x180010fda: add      byte ptr [rax], al
0x180010fdc: add      byte ptr [rax], al
0x180010fde: add      byte ptr [rax], al
0x180010fe0: add      byte ptr [rax], al
0x180010fe2: add      byte ptr [rax], al
0x180010fe4: add      byte ptr [rax], al
0x180010fe6: add      byte ptr [rax], al
0x180010fe8: add      byte ptr [rax], al
0x180010fea: add      byte ptr [rax], al
0x180010fec: add      byte ptr [rax], al
0x180010fee: add      byte ptr [rax], al
0x180010ff0: add      byte ptr [rax], al
0x180010ff2: add      byte ptr [rax], al
0x180010ff4: add      byte ptr [rax], al
0x180010ff6: add      byte ptr [rax], al
0x180010ff8: add      byte ptr [rax], al
0x180010ffa: add      byte ptr [rax], al
0x180010ffc: add      byte ptr [rax], al
0x180010ffe: add      byte ptr [rax], al
```
