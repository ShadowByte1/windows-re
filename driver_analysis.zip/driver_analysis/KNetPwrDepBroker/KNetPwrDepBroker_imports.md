# KNetPwrDepBroker.sys — Raw Import Table

## ntoskrnl.exe
  0x18000a000           ExInitializeResourceLite
  0x18000a008           ExAcquireResourceExclusiveLite
  0x18000a010           ExDeleteResourceLite
  0x18000a018           KeQueryTimeIncrement
  0x18000a020           ExDeleteTimer
  0x18000a028           KeSetEvent
  0x18000a038           ExSetTimer
  0x18000a040           ExReleaseResourceLite
  0x18000a048           EtwWriteTransfer
  0x18000a050           ExAllocatePool2
  0x18000a058           ExFreePoolWithTag
  0x18000a060           EtwRegister
  0x18000a068           EtwSetInformation
  0x18000a070           EtwUnregister
  0x18000a078           KeInitializeTimerEx
  0x18000a080           KeInitializeDpc
  0x18000a088           KeInitializeEvent
  0x18000a090           ExQueueWorkItem
  0x18000a098           KeSetTimerEx
  0x18000a0a0           KeCancelTimer
  0x18000a0a8           KeWaitForSingleObject
  0x18000a0b0           KeInitializeSpinLock
  0x18000a0b8           ExRundownCompleted
  0x18000a0c0           ExWaitForRundownProtectionRelease
  0x18000a0c8           ExInitializeRundownProtection
  0x18000a0d0           ZwPowerInformation
  0x18000a0d8           ExAcquireRundownProtection
  0x18000a0e0           ExReleaseRundownProtection
  0x18000a0e8           KeInitializeMutex
  0x18000a0f0           KeReleaseMutex
  0x18000a0f8           KeResetEvent
  0x18000a100           RtlFreeAnsiString
  0x18000a108           RtlQueryRegistryValuesEx
  0x18000a110           KeGetCurrentIrql
  0x18000a118           DbgkWerCaptureLiveKernelDump
  0x18000a120           RtlInitUnicodeString
  0x18000a128           RtlUnicodeStringToAnsiString
  0x18000a130           RtlInitAnsiString
  0x18000a138           KeAcquireSpinLockRaiseToDpc
  0x18000a140           KeReleaseSpinLock

## EXPORTS
  DllInitialize
  DllUnload
  ImsBrokerKeepAliveCompleted
  ImsBrokerNetworkActivityCompleted
  ImsBrokerRecoveryCompleted
  ImsBrokerRequestKeepAlive
  ImsBrokerRequestNetworkActivation
  ImsBrokerRequestRecovery
  NpdBrokerAcquireWithTimeout
  NpdBrokerInitialize
  NpdBrokerUninitialize