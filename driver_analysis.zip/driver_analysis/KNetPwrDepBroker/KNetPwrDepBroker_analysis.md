# KNetPwrDepBroker.sys — Static Analysis Report

## File Metadata
| Field | Value |
|---|---|
| File | KNetPwrDepBroker.sys |
| Type | PE32+ native kernel driver (DLL type — exports functions) |
| Size | 80 KB |
| Architecture | x86-64 |
| Sections | 13 |
| Build Timestamp | Normalized/reproducible build |
| Image Base | 0x180000000 |
| Purpose | Network Power Dependency Broker (IMS/LTE keepalive, NPD acquisition) |

## Mitigation Summary (DllCharacteristics: 0x4160)
| Mitigation | Status |
|---|---|
| ASLR / DYNAMIC_BASE | PRESENT |
| NX / DEP | PRESENT |
| HIGH_ENTROPY_VA | PRESENT |
| WDM_DRIVER | PRESENT |
| FORCE_INTEGRITY | MISSING |
| GUARD_CF (PE DllChars flag) | MISSING (CFG table present) |

## Load Config / CFG — Most Hardened of the Three
| Field | Value |
|---|---|
| SecurityCookie (/GS) | 0x180008100 (PRESENT) |
| GuardCFCheckFunction | 0x18000a150 (PRESENT) |
| GuardFlags | 0x10514500 |
| CF_INSTRUMENTED | YES |
| CF_FUNCTION_TABLE_PRESENT | YES |
| RF_INSTRUMENTED (return flow) | YES |
| RF_STRICT | YES |
| CF_EXPORT_SUPPRESSION | YES |
| CF_LONGJUMP_TABLE | YES |
| XFG (eXtended Flow Guard) | YES |

This driver has the strongest mitigation posture of the three: XFG enabled
provides type-safe indirect call checking beyond standard CFG.

## Section Map
| Section | VA | Raw Size | Entropy |
|---|---|---|---|
| .text | 0x1000 | 0x4000 | 5.676 |
| fothk | 0x5000 | 0x1000 | 0.030 |
| .rdata | 0x6000 | 0x2000 | 4.264 |
| .data | 0x8000 | 0x1000 | 0.148 |
| .pdata | 0x9000 | 0x1000 | 1.470 |
| .idata | 0xa000 | 0x1000 | 2.215 |
| NONPAGE | 0xb000 | 0x1000 | 0.036 |
| PAGE | 0xc000 | 0x3000 | 4.764 |
| .edata | 0xf000 | 0x1000 | 0.870 |
| INIT | 0x10000 | 0x1000 | 0.146 |
| GFIDS | 0x11000 | 0x1000 | 0.175 |
| .rsrc | 0x12000 | 0x1000 | 1.145 |
| .reloc | 0x13000 | 0x1000 | 1.502 |

`fothk` section (entropy ~0) is a forward-only trampoline table — hooks for
fast-path dispatch. `NONPAGE` is nonpaged code (ISR/DPC level routines).

## Exports (Callable API Surface)
```
DllInitialize
DllUnload
ImsBrokerKeepAliveCompleted
ImsBrokerNetworkActivityCompleted
ImsBrokerRecoveryCompleted
ImsBrokerRequestKeepAlive
ImsBrokerRequestNetworkActivation
ImsBrokerRequestRecovery
NpdBrokerAcquireWithTimeout
NpdBrokerInitialize
NpdBrokerUninitialize
```

These exports are callable by other kernel drivers. The IMS* exports relate to
IP Multimedia Subsystem (LTE/5G) keepalive state machine. The Npd* exports manage
network power dependency acquisition.

## ntoskrnl.exe Imports (40 total)
```
-- Resource locks --
ExInitializeResourceLite / ExDeleteResourceLite
ExAcquireResourceExclusiveLite / ExReleaseResourceLite

-- Timers --
KeInitializeTimerEx
KeSetTimerEx
KeCancelTimer
ExAllocateTimer / ExSetTimer / ExDeleteTimer   -- NEW timer API

-- Events --
KeInitializeEvent / KeSetEvent / KeResetEvent
KeWaitForSingleObject

-- Pool --
ExAllocatePool2          -- MODERN API (correct)
ExFreePoolWithTag        -- correct paired free

-- Rundown protection --
ExInitializeRundownProtection
ExAcquireRundownProtection / ExReleaseRundownProtection
ExWaitForRundownProtectionRelease / ExRundownCompleted

-- Synchronisation --
KeInitializeSpinLock
KeAcquireSpinLockRaiseToDpc / KeReleaseSpinLock
KeInitializeMutex / KeReleaseMutex
ExQueueWorkItem

-- Power --
ZwPowerInformation

-- ETW tracing --
EtwRegister / EtwUnregister / EtwWriteTransfer / EtwSetInformation

-- Registry --
RtlQueryRegistryValuesEx

-- String --
RtlInitUnicodeString / RtlUnicodeStringToAnsiString
RtlInitAnsiString / RtlFreeAnsiString
KeGetCurrentIrql

-- Debug/WER --
DbgkWerCaptureLiveKernelDump    -- notable: kernel dump capture
```

---

## Attack Surface Overview

This driver exposes a set of exported functions callable by other kernel components.
The primary concern is the interaction between:
- Caller-supplied parameters to the exported functions
- The timer subsystem (ExSetTimer / KeSetTimerEx)
- The rundown protection model
- The DbgkWerCaptureLiveKernelDump import

---

## FINDING 1 — Timer Race Condition (ExSetTimer + ExDeleteTimer)
**Severity:** Medium  
**APIs:** ExAllocateTimer, ExSetTimer, ExDeleteTimer, ExQueueWorkItem

### Detail
The driver uses the newer `ExAllocateTimer` / `ExSetTimer` / `ExDeleteTimer` API
alongside the older `KeSetTimerEx` / `KeCancelTimer`. This mixed usage indicates
at least two distinct timer objects in the driver.

The `ExDeleteTimer` function has two modes:
- `Cancel = TRUE`: waits for any in-progress callback to complete before returning
- `Cancel = FALSE`: cancels the timer but does NOT wait for callbacks

If `ExDeleteTimer(..., FALSE, FALSE, NULL)` is used during a cleanup path while
a timer callback is concurrently executing, and the callback accesses a context
object that has already been freed, a use-after-free occurs.

Pattern of concern:
```
Thread A (NpdBrokerUninitialize):       Thread B (timer callback):
  ExFreePoolWithTag(ctx)                  [ctx->field access]  <- UAF
  ExDeleteTimer(timer, FALSE, ...)
```

Rundown protection (`ExInitializeRundownProtection` / `ExAcquireRundownProtection`)
is present and is the correct mechanism to guard against this, but only if
the timer callback acquires rundown protection before accessing the context.
Whether it does so correctly requires dynamic tracing.

### How to Verify
Set a breakpoint on `ExDeleteTimer` in WinDbg, capture the second argument
(Cancel flag), then trace whether any timer callback can still be in-flight.
Driver Verifier with "Force Pending I/O Requests" and concurrency testing
will surface this class of bug.

---

## FINDING 2 — NpdBrokerAcquireWithTimeout: Timeout Parameter Handling
**Severity:** Low-Medium  
**Export:** NpdBrokerAcquireWithTimeout

### Detail
The function name implies a caller-supplied timeout value. Timeout values
passed to kernel timer APIs are typically in 100-nanosecond units (LARGE_INTEGER
negative for relative, positive for absolute).

Risk: if the caller-supplied timeout is stored and then multiplied before being
passed to `KeSetTimerEx` or `ExSetTimer` (e.g. converted from milliseconds to
100ns units by multiplying by 10,000), an unchecked 64-bit multiplication can
overflow.

Example dangerous pattern:
```c
LONGLONG timeout_100ns = caller_timeout_ms * 10000LL;  // overflows if ms > 0x1999999999999
KeSetTimerEx(&timer, *(PLARGE_INTEGER)&timeout_100ns, period, &dpc);
```

Whether this pattern is present requires disassembling `NpdBrokerAcquireWithTimeout`
in the PAGE section — the export table points into PAGE.

---

## FINDING 3 — DbgkWerCaptureLiveKernelDump Import
**Severity:** Informational / Information Disclosure (context-dependent)

### Detail
`DbgkWerCaptureLiveKernelDump` captures a live kernel minidump. This function
is not normally imported by production drivers. Its presence indicates the driver
has an internal error path that captures kernel memory state on unexpected failures.

If any error condition reachable through the exported API (e.g. `ImsBrokerRequestRecovery`
with a malformed input) triggers this code path, the resulting dump file contains
kernel memory readable by an administrator.

In a defence-in-depth model, this is an unnecessary capability and the import should
be removed unless the dump capture is strictly gated behind debug builds.

---

## FINDING 4 — FORCE_INTEGRITY Missing
**Severity:** Informational

Same as other drivers: without `FORCE_INTEGRITY`, the loader does not enforce
signature verification in all boot configurations. Enable in linker flags.

---

## Positive Observations
- Uses `ExAllocatePool2` (modern, zero-initialising) — correct
- Paired with `ExFreePoolWithTag` — correct
- Rundown protection pattern present — correct approach for concurrent cleanup
- XFG enabled — strongest indirect-call protection of the three drivers
- Return-flow guard (RF_STRICT) enabled

---

## Recommended Mitigations
1. Audit `ExDeleteTimer` call sites: ensure `Cancel=TRUE` or rundown
   protection is held by callbacks before context is freed
2. Add overflow check on timeout parameter in `NpdBrokerAcquireWithTimeout`
   before any unit conversion multiplication
3. Gate `DbgkWerCaptureLiveKernelDump` behind a compile-time debug flag
4. Enable `FORCE_INTEGRITY` linker flag
