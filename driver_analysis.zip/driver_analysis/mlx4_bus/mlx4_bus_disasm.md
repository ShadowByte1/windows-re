# mlx4_bus.sys — Disassembly Traces

## Dangerous Call Sites with Context

### MmAllocateContiguousMemorySpecifyCache @ 0x14000abf5 (.text)
```asm
0x14000abc4: xor      esi, esi
0x14000abc6: call     0x1400c29fc
0x14000abcb: and      dword ptr [rsp + 0x20], esi
0x14000abcf: movabs   rdi, 0x40000000000000
0x14000abd9: mov      ebx, 0x8000000
0x14000abde: mov      qword ptr [rsp + 0x70], rax
0x14000abe3: mov      ebp, 0x1000
0x14000abe8: mov      r8, rdi
0x14000abeb: mov      edx, ebx
0x14000abed: mov      ecx, ebp
0x14000abef: mov      r9d, esi
0x14000abf2: mov      r12, rax
0x14000abf5: call     qword ptr [rip + 0xcd4bd]  ; <-- CALL
0x14000abfb: test     rax, rax
```

### MmAllocateContiguousMemorySpecifyCache @ 0x14000ac26 (.text)
```asm
0x14000abfb: test     rax, rax
0x14000abfe: je       0x14000ad79
0x14000ac04: xor      r8d, r8d
0x14000ac07: mov      rdx, rbp
0x14000ac0a: mov      rcx, rax
0x14000ac0d: call     qword ptr [rip + 0xcd4ad]
0x14000ac13: and      dword ptr [rsp + 0x20], esi
0x14000ac17: add      rbx, rbx
0x14000ac1a: mov      rdx, rbx
0x14000ac1d: mov      r9, rsi
0x14000ac20: mov      r8, rdi
0x14000ac23: mov      rcx, rbp
0x14000ac26: call     qword ptr [rip + 0xcd48c]  ; <-- CALL
0x14000ac2c: test     rax, rax
```

### MmAllocateContiguousMemorySpecifyCache @ 0x14000ac72 (.text)
```asm
0x14000ac46: cmovb    rbp, rax
0x14000ac4a: sar      rbx, 1
0x14000ac4d: xor      r13d, r13d
0x14000ac50: lea      r15, [rbp + 1]
0x14000ac54: cmp      r15, rbp
0x14000ac57: jb       0x14000ad11
0x14000ac5d: and      dword ptr [rsp + 0x20], esi
0x14000ac61: mov      r9, rsi
0x14000ac64: mov      r8, rdi
0x14000ac67: mov      rdx, rbx
0x14000ac6a: mov      ecx, 0x1000
0x14000ac6f: inc      r13d
0x14000ac72: call     qword ptr [rip + 0xcd440]  ; <-- CALL
0x14000ac78: mov      r12, rax
```

### MmAllocateContiguousMemorySpecifyCache @ 0x14000addc (.text)
```asm
0x14000adb5: xor      ebx, ebx
0x14000adb7: xor      edi, edi
0x14000adb9: call     0x1400c29fc
0x14000adbe: and      dword ptr [rsp + 0x20], ebx
0x14000adc2: mov      r13d, 0x1000
0x14000adc8: mov      ecx, r13d
0x14000adcb: xor      r14d, r14d
0x14000adce: xor      ebp, ebp
0x14000add0: mov      r9d, edi
0x14000add3: or       r8, 0xffffffffffffffff
0x14000add7: mov      edx, ebx
0x14000add9: mov      r15, rax
0x14000addc: call     qword ptr [rip + 0xcd2d6]  ; <-- CALL
0x14000ade2: mov      r12d, 0x40000000
```

### MmAllocateContiguousMemorySpecifyCache @ 0x14000ae21 (.text)
```asm
0x14000adf9: cmp      rbx, r12
0x14000adfc: jge      0x14000ae0a
0x14000adfe: inc      r14
0x14000ae01: add      rbx, 0x8000000
0x14000ae08: jmp      0x14000ae10
0x14000ae0a: inc      rbp
0x14000ae0d: add      rbx, r12
0x14000ae10: and      dword ptr [rsp + 0x20], edi
0x14000ae14: mov      r9, rdi
0x14000ae17: or       r8, 0xffffffffffffffff
0x14000ae1b: mov      rdx, rbx
0x14000ae1e: mov      rcx, r13
0x14000ae21: call     qword ptr [rip + 0xcd291]  ; <-- CALL
0x14000ae27: test     rax, rax
```

### MmMapIoSpaceEx @ 0x140013737 (.text)
```asm
0x14001370b: mov      edx, ebp
0x14001370d: shl      edx, 4
0x140013710: mov      dword ptr [rdi + 0x20], edx
0x140013713: mov      r8d, dword ptr [r14 + 4]
0x140013717: mov      eax, r8d
0x14001371a: and      eax, 7
0x14001371d: mov      rcx, qword ptr [rsi + rax*4 + 0x10]
0x140013722: mov      eax, 0xfffffff8
0x140013727: and      r8, rax
0x14001372a: and      rcx, 0xfffffffffffffff0
0x14001372e: add      rcx, r8
0x140013731: mov      r8d, 0x204
0x140013737: call     qword ptr [rip + 0xc4a7b]  ; <-- CALL
0x14001373d: mov      qword ptr [rdi], rax
```

### MmMapIoSpaceEx @ 0x140013853 (.text)
```asm
0x140013826: lea      edx, [rbp + 0x3f]
0x140013829: and      eax, 7
0x14001382c: shr      edx, 6
0x14001382f: shl      edx, 3
0x140013832: mov      r8, qword ptr [rsi + rax*4 + 0x10]
0x140013837: mov      eax, 0xfffffff8
0x14001383c: and      r8, 0xfffffffffffffff0
0x140013840: mov      dword ptr [rdi + 0x24], edx
0x140013843: mov      ecx, dword ptr [r14 + 8]
0x140013847: and      rcx, rax
0x14001384a: add      rcx, r8
0x14001384d: mov      r8d, 0x204
0x140013853: call     qword ptr [rip + 0xc495f]  ; <-- CALL
0x140013859: mov      qword ptr [rdi + 8], rax
```

### MmMapIoSpaceEx @ 0x140013a1a (.text)
```asm
0x1400139f0: pop      rdi
0x1400139f1: ret      
0x1400139f2: int3     
0x1400139f3: int3     
0x1400139f4: push     rbx
0x1400139f6: sub      rsp, 0x20
0x1400139fa: mov      rax, qword ptr [rcx + 8]
0x1400139fe: mov      rbx, rcx
0x140013a01: mov      edx, 4
0x140013a06: mov      r8d, 0x204
0x140013a0c: mov      rcx, qword ptr [rax + 0x228]
0x140013a13: add      rcx, 0x8069c
0x140013a1a: call     qword ptr [rip + 0xc4798]  ; <-- CALL
0x140013a20: test     rax, rax
```

### MmMapIoSpaceEx @ 0x140013acf (.text)
```asm
0x140013a9c: call     qword ptr [rip + 0xc4706]
0x140013aa2: add      rsp, 0x20
0x140013aa6: pop      rbx
0x140013aa7: ret      
0x140013aa8: mov      qword ptr [rsp + 8], rbx
0x140013aad: push     rdi
0x140013aae: sub      rsp, 0x20
0x140013ab2: mov      rax, qword ptr [rcx + 8]
0x140013ab6: mov      edx, 4
0x140013abb: mov      r8d, 0x204
0x140013ac1: mov      rcx, qword ptr [rax + 0x228]
0x140013ac8: add      rcx, 0x8069c
0x140013acf: call     qword ptr [rip + 0xc46e3]  ; <-- CALL
0x140013ad5: xor      edi, edi
```

### MmMapIoSpaceEx @ 0x140013f29 (.text)
```asm
0x140013ef9: test     eax, eax
0x140013efb: je       0x1400140ff
0x140013f01: cmp      dword ptr [rbp + 0x5470], 0
0x140013f08: je       0x1400140ff
0x140013f0e: mov      ecx, dword ptr [r13 + 4]
0x140013f12: mov      eax, r14d
0x140013f15: shl      eax, 4
0x140013f18: and      rcx, rdx
0x140013f1b: add      rcx, r12
0x140013f1e: mov      edx, eax
0x140013f20: mov      r8d, 0x204
0x140013f26: mov      r12d, eax
0x140013f29: call     qword ptr [rip + 0xc4289]  ; <-- CALL
0x140013f2f: mov      r15, rax
```

### MmMapIoSpaceEx @ 0x140014046 (.text)
```asm
0x140014015: mov      rcx, r15
0x140014018: call     qword ptr [rip + 0xc4192]
0x14001401e: mov      ecx, dword ptr [r13 + 8]
0x140014022: lea      eax, [r14 + 0x3f]
0x140014026: shr      eax, 6
0x140014029: mov      edx, 0xfffffff8
0x14001402e: shl      eax, 3
0x140014031: and      rcx, rdx
0x140014034: add      rcx, qword ptr [rsp + 0xa8]
0x14001403c: mov      r8d, 0x204
0x140014042: mov      edx, eax
0x140014044: mov      esi, eax
0x140014046: call     qword ptr [rip + 0xc416c]  ; <-- CALL
0x14001404c: mov      rbx, rax
```

### MmMapIoSpaceEx @ 0x14001442b (.text)
```asm
0x1400143f9: cmp      dword ptr [rdi + 0xc], 0
0x1400143fd: je       0x140014601
0x140014403: cmp      dword ptr [rbp + 0x5470], 0
0x14001440a: je       0x140014601
0x140014410: mov      ecx, dword ptr [r13 + 4]
0x140014414: mov      eax, r14d
0x140014417: shl      eax, 4
0x14001441a: and      rcx, rdx
0x14001441d: add      rcx, r12
0x140014420: mov      edx, eax
0x140014422: mov      r8d, 0x204
0x140014428: mov      r12d, eax
0x14001442b: call     qword ptr [rip + 0xc3d87]  ; <-- CALL
0x140014431: mov      r15, rax
```

### MmMapIoSpaceEx @ 0x140014548 (.text)
```asm
0x140014517: mov      rcx, r15
0x14001451a: call     qword ptr [rip + 0xc3c90]
0x140014520: mov      ecx, dword ptr [r13 + 8]
0x140014524: lea      eax, [r14 + 0x3f]
0x140014528: shr      eax, 6
0x14001452b: mov      edx, 0xfffffff8
0x140014530: shl      eax, 3
0x140014533: and      rcx, rdx
0x140014536: add      rcx, qword ptr [rsp + 0xa8]
0x14001453e: mov      r8d, 0x204
0x140014544: mov      edx, eax
0x140014546: mov      esi, eax
0x140014548: call     qword ptr [rip + 0xc3c6a]  ; <-- CALL
0x14001454e: mov      rbx, rax
```

### MmMapIoSpaceEx @ 0x140014ffe (.text)
```asm
0x140014fc6: test     r12b, al
0x140014fc9: je       0x140014fdf
0x140014fcb: mov      rcx, qword ptr [rcx + 0x198]
0x140014fd2: mov      edx, 0x42
0x140014fd7: mov      r8, rsi
0x140014fda: call     0x14000d348
0x140014fdf: mov      rsi, qword ptr [rbp + 0x228]
0x140014fe6: mov      edx, 0x400
0x140014feb: add      rsi, 0xf0000
0x140014ff2: mov      r8d, 0x204
0x140014ff8: mov      rcx, rsi
0x140014ffb: mov      r14d, ebx
0x140014ffe: call     qword ptr [rip + 0xc31b4]  ; <-- CALL
0x140015004: mov      rdi, rax
```

### MmMapIoSpaceEx @ 0x140015247 (.text)
```asm
0x140015206: je       0x140015220
0x140015208: mov      rcx, qword ptr [rcx + 0x198]
0x14001520f: lea      r8, [rip + 0xc5922]
0x140015216: mov      edx, 0x48
0x14001521b: call     0x14000d348
0x140015220: mov      edx, 0x400
0x140015225: mov      rcx, rdi
0x140015228: call     qword ptr [rip + 0xc2f82]
0x14001522e: mov      rcx, qword ptr [rbp + 0x228]
0x140015235: mov      edx, 4
0x14001523a: add      rcx, 0x806a0
0x140015241: mov      r8d, 0x204
0x140015247: call     qword ptr [rip + 0xc2f6b]  ; <-- CALL
0x14001524d: mov      rsi, rax
```

### MmMapIoSpaceEx @ 0x1400155a3 (.text)
```asm
0x140015565: mov      rcx, qword ptr [rip + 0xd1484]
0x14001556c: mov      rcx, qword ptr [rcx + 0x198]
0x140015573: call     0x14000db54
0x140015578: mov      ecx, dword ptr [r14 + 0x5b70]
0x14001557f: mov      eax, dword ptr [r14 + 0x5b6c]
0x140015586: mov      edx, 0x10
0x14001558b: mov      r12d, ecx
0x14001558e: add      rax, 0x17
0x140015592: mov      r8d, 0x204
0x140015598: lea      rax, [rax + rax*2]
0x14001559c: add      r12, qword ptr [r14 + rax*8]
0x1400155a0: mov      rcx, r12
0x1400155a3: call     qword ptr [rip + 0xc2c0f]  ; <-- CALL
0x1400155a9: mov      r15, rax
```

### MmMapIoSpaceEx @ 0x140015961 (.text)
```asm
0x14001592a: test     r15b, al
0x14001592d: je       0x140015943
0x14001592f: mov      rcx, qword ptr [rcx + 0x198]
0x140015936: mov      edx, 0x52
0x14001593b: mov      r8, rdi
0x14001593e: call     0x14000d348
0x140015943: mov      rbx, qword ptr [rsi + 0x228]
0x14001594a: xor      edi, edi
0x14001594c: add      rbx, 0xf0000
0x140015953: mov      edx, 0x400
0x140015958: mov      rcx, rbx
0x14001595b: mov      r8d, 0x204
0x140015961: call     qword ptr [rip + 0xc2851]  ; <-- CALL
0x140015967: mov      r14, rax
```

### MmMapIoSpaceEx @ 0x140015bf8 (.text)
```asm
0x140015bb7: je       0x140015bd1
0x140015bb9: mov      rcx, qword ptr [rcx + 0x198]
0x140015bc0: lea      r8, [rip + 0xc4f71]
0x140015bc7: mov      edx, 0x58
0x140015bcc: call     0x14000d348
0x140015bd1: mov      edx, 0x400
0x140015bd6: mov      rcx, r14
0x140015bd9: call     qword ptr [rip + 0xc25d1]
0x140015bdf: mov      rcx, qword ptr [rsi + 0x228]
0x140015be6: mov      edx, 4
0x140015beb: add      rcx, 0x806a0
0x140015bf2: mov      r8d, 0x204
0x140015bf8: call     qword ptr [rip + 0xc25ba]  ; <-- CALL
0x140015bfe: mov      rdi, rax
```

### ExAllocatePoolWithTag @ 0x140016265 (.text)
```asm
0x14001623d: int3     
0x14001623e: int3     
0x14001623f: int3     
0x140016240: mov      qword ptr [rsp + 8], rbx
0x140016245: mov      qword ptr [rsp + 0x10], rsi
0x14001624a: push     rdi
0x14001624b: sub      rsp, 0x20
0x14001624f: mov      rdi, rdx
0x140016252: mov      rsi, rcx
0x140016255: mov      edx, 0x1e
0x14001625a: mov      ecx, 0x200
0x14001625f: mov      r8d, 0x4c4e784d
0x140016265: call     qword ptr [rip + 0xc1f5d]  ; <-- CALL
0x14001626b: mov      rbx, rax
```

### ExAllocatePoolWithTag @ 0x14001ab8c (.text)
```asm
0x14001ab64: xor      ebp, ebp
0x14001ab66: mov      rcx, rsi
0x14001ab69: cmp      qword ptr [rcx], rdi
0x14001ab6c: je       0x14001ab7e
0x14001ab6e: inc      ebp
0x14001ab70: add      rcx, 8
0x14001ab74: cmp      rcx, rdx
0x14001ab77: jl       0x14001ab69
0x14001ab79: jmp      0x14001acbf
0x14001ab7e: mov      edx, 0x1010
0x14001ab83: mov      r8d, 0x54415453
0x14001ab89: mov      ecx, r13d
0x14001ab8c: call     qword ptr [rip + 0xbd636]  ; <-- CALL
0x14001ab92: mov      rbx, rax
```

### ExAllocatePoolWithTag @ 0x14001abb8 (.text)
```asm
0x14001ab89: mov      ecx, r13d
0x14001ab8c: call     qword ptr [rip + 0xbd636]
0x14001ab92: mov      rbx, rax
0x14001ab95: test     rax, rax
0x14001ab98: je       0x14001abf3
0x14001ab9a: xor      edx, edx
0x14001ab9c: mov      r8d, 0x1010
0x14001aba2: mov      rcx, rax
0x14001aba5: call     0x1400cacc0
0x14001abaa: mov      edx, 0xf0
0x14001abaf: mov      r8d, 0x54415453
0x14001abb5: mov      ecx, r13d
0x14001abb8: call     qword ptr [rip + 0xbd60a]  ; <-- CALL
0x14001abbe: mov      rsi, rax
```

### ExAllocatePoolWithTag @ 0x14001ac7b (.text)
```asm
0x14001ac51: je       0x14001ac6d
0x14001ac53: inc      esi
0x14001ac55: add      rcx, 8
0x14001ac59: jmp      0x14001ac4d
0x14001ac5b: xor      edx, edx
0x14001ac5d: mov      r8d, 0xf0
0x14001ac63: mov      rcx, rdi
0x14001ac66: call     0x1400cacc0
0x14001ac6b: jmp      0x14001aca6
0x14001ac6d: mov      edx, 0xf0
0x14001ac72: mov      r8d, 0x54415453
0x14001ac78: mov      ecx, r13d
0x14001ac7b: call     qword ptr [rip + 0xbd547]  ; <-- CALL
0x14001ac81: mov      rdi, rax
```

### ExAllocatePoolWithTag @ 0x14001b170 (.text)
```asm
0x14001b124: movups   xmmword ptr [rip + 0xee055], xmm0
0x14001b12b: call     qword ptr [rip + 0xbd037]
0x14001b131: xorps    xmm0, xmm0
0x14001b134: lea      rcx, [rip + 0xe15ad]
0x14001b13b: movups   xmmword ptr [rip + 0xe15a6], xmm0
0x14001b142: call     qword ptr [rip + 0xbd020]
0x14001b148: and      dword ptr [rip + 0xe15c1], 0
0x14001b14f: mov      edx, 0xc00000
0x14001b154: and      dword ptr [rip + 0xe15bd], 0
0x14001b15b: mov      ecx, 0x200
0x14001b160: mov      r8d, 0x46425445
0x14001b166: mov      dword ptr [rip + 0xe15a4], 0xc00000
0x14001b170: call     qword ptr [rip + 0xbd052]  ; <-- CALL
0x14001b176: mov      rbx, rax
```

### PsCreateSystemThread @ 0x14001fb3e (.text)
```asm
0x14001fafa: lea      r8, [rsp + 0x40]
0x14001faff: xorps    xmm0, xmm0
0x14001fb02: mov      qword ptr [rsp + 0x30], rdi
0x14001fb07: mov      qword ptr [rsp + 0x28], rax
0x14001fb0c: lea      rcx, [rsp + 0x80]
0x14001fb14: and      qword ptr [rsp + 0x20], 0
0x14001fb1a: xor      r9d, r9d
0x14001fb1d: mov      edx, 0x1fffff
0x14001fb22: mov      dword ptr [rsp + 0x40], 0x30
0x14001fb2a: mov      dword ptr [rsp + 0x58], 0x200
0x14001fb32: movdqu   xmmword ptr [rsp + 0x60], xmm0
0x14001fb38: mov      dword ptr [rdi + 0x24000], ebx
0x14001fb3e: call     qword ptr [rip + 0xb86fc]  ; <-- CALL
0x14001fb44: mov      ebx, eax
```

### MmMapIoSpaceEx @ 0x1400250e4 (.text)
```asm
0x1400250b8: push     r13
0x1400250ba: push     r14
0x1400250bc: push     r15
0x1400250be: sub      rsp, 0x40
0x1400250c2: mov      rbx, qword ptr [rcx + 0x228]
0x1400250c9: mov      r12, rdx
0x1400250cc: mov      edx, dword ptr [rcx + 0x238]
0x1400250d2: mov      r14, rcx
0x1400250d5: xor      edi, edi
0x1400250d7: mov      rcx, rbx
0x1400250da: mov      r8d, 0x204
0x1400250e0: mov      dword ptr [rsp + 0x30], edi
0x1400250e4: call     qword ptr [rip + 0xb30ce]  ; <-- CALL
0x1400250ea: mov      rbp, rax
```

### MmMapIoSpaceEx @ 0x140026723 (.text)
```asm
0x1400266f3: push     r13
0x1400266f5: push     r14
0x1400266f7: push     r15
0x1400266f9: sub      rsp, 0x30
0x1400266fd: mov      rdi, qword ptr [rcx + 0x228]
0x140026704: mov      r14, r8
0x140026707: add      rdi, 0xf0014
0x14002670e: mov      r15, rdx
0x140026711: mov      r12d, 4
0x140026717: mov      rcx, rdi
0x14002671a: mov      r8d, 0x204
0x140026720: mov      edx, r12d
0x140026723: call     qword ptr [rip + 0xb1a8f]  ; <-- CALL
0x140026729: mov      rsi, rax
```

### ProbeForWrite @ 0x140028c10 (.text)
```asm
0x140028bdf: mov      dword ptr [rcx], eax
0x140028be1: jmp      0x140028d04
0x140028be6: test     eax, eax
0x140028be8: je       0x140028bf4
0x140028bea: mov      edi, 0xc0000001
0x140028bef: jmp      0x140028d07
0x140028bf4: test     rbx, rbx
0x140028bf7: je       0x140028d04
0x140028bfd: mov      edx, dword ptr [rsp + 0x44]
0x140028c01: mov      r8d, 8
0x140028c07: mov      rcx, qword ptr [rsp + 0x48]
0x140028c0c: mov      rcx, qword ptr [rcx + 8]
0x140028c10: call     qword ptr [rip + 0xaf68a]  ; <-- CALL
0x140028c16: mov      rax, qword ptr [rsp + 0x48]
```

### RtlWriteRegistryValue @ 0x14002b651 (.text)
```asm
0x14002b61a: test     al, al
0x14002b61c: je       0x14002b70c
0x14002b622: mov      r13d, 1
0x14002b628: lea      rax, [rbp - 0x7c]
0x14002b62c: lea      r8, [rip + 0xa019d]
0x14002b633: mov      dword ptr [rbp - 0x7c], r13d
0x14002b637: lea      rdx, [rip + 0xa3272]
0x14002b63e: lea      ecx, [r13 + 3]
0x14002b642: mov      dword ptr [rsp + 0x28], ecx
0x14002b646: mov      r9d, ecx
0x14002b649: mov      ecx, r13d
0x14002b64c: mov      qword ptr [rsp + 0x20], rax
0x14002b651: call     qword ptr [rip + 0xacc61]  ; <-- CALL
0x14002b657: mov      r9d, eax
```

### sprintf_s @ 0x14002e8aa (.text)
```asm
0x14002e874: ret      
0x14002e875: ror      rcx, 0x10
0x14002e879: jmp      0x14002e840
0x14002e87e: int3     
0x14002e87f: int3     
0x14002e880: jmp      qword ptr [rip + 0xa9d2a]
0x14002e886: jmp      qword ptr [rip + 0xa9a3c]
0x14002e88c: jmp      qword ptr [rip + 0xa9d16]
0x14002e892: jmp      qword ptr [rip + 0xa9d08]
0x14002e898: jmp      qword ptr [rip + 0xa9cfa]
0x14002e89e: jmp      qword ptr [rip + 0xa9a74]
0x14002e8a4: jmp      qword ptr [rip + 0xa9806]
0x14002e8aa: jmp      qword ptr [rip + 0xa9880]  ; <-- CALL
0x14002e8b0: jmp      qword ptr [rip + 0xa9882]
```

### swprintf_s @ 0x14002e8b0 (.text)
```asm
0x14002e875: ror      rcx, 0x10
0x14002e879: jmp      0x14002e840
0x14002e87e: int3     
0x14002e87f: int3     
0x14002e880: jmp      qword ptr [rip + 0xa9d2a]
0x14002e886: jmp      qword ptr [rip + 0xa9a3c]
0x14002e88c: jmp      qword ptr [rip + 0xa9d16]
0x14002e892: jmp      qword ptr [rip + 0xa9d08]
0x14002e898: jmp      qword ptr [rip + 0xa9cfa]
0x14002e89e: jmp      qword ptr [rip + 0xa9a74]
0x14002e8a4: jmp      qword ptr [rip + 0xa9806]
0x14002e8aa: jmp      qword ptr [rip + 0xa9880]
0x14002e8b0: jmp      qword ptr [rip + 0xa9882]  ; <-- CALL
0x14002e8b6: jmp      qword ptr [rip + 0xa9884]
```

### swscanf_s @ 0x14002e8b6 (.text)
```asm
0x14002e879: jmp      0x14002e840
0x14002e87e: int3     
0x14002e87f: int3     
0x14002e880: jmp      qword ptr [rip + 0xa9d2a]
0x14002e886: jmp      qword ptr [rip + 0xa9a3c]
0x14002e88c: jmp      qword ptr [rip + 0xa9d16]
0x14002e892: jmp      qword ptr [rip + 0xa9d08]
0x14002e898: jmp      qword ptr [rip + 0xa9cfa]
0x14002e89e: jmp      qword ptr [rip + 0xa9a74]
0x14002e8a4: jmp      qword ptr [rip + 0xa9806]
0x14002e8aa: jmp      qword ptr [rip + 0xa9880]
0x14002e8b0: jmp      qword ptr [rip + 0xa9882]
0x14002e8b6: jmp      qword ptr [rip + 0xa9884]  ; <-- CALL
0x14002e8bc: sub      rsp, 0x28
```

### ExAllocatePoolWithTag @ 0x140032617 (.text)
```asm
0x1400325ec: mov      edx, 0x6e47784d
0x1400325f1: jmp      qword ptr [rip + 0xa5bf0]
0x1400325f8: test     rcx, rcx
0x1400325fb: jne      0x140032600
0x1400325fd: xor      eax, eax
0x1400325ff: ret      
0x140032600: test     edx, edx
0x140032602: mov      r8d, 0x6e47784d
0x140032608: mov      rdx, rcx
0x14003260b: mov      ecx, 1
0x140032610: jne      0x140032617
0x140032612: mov      ecx, 0x200
0x140032617: jmp      qword ptr [rip + 0xa5baa]  ; <-- CALL
0x14003261e: int3     
```

### PsCreateSystemThread @ 0x140033242 (.text)
```asm
0x140033204: mov      rbx, rcx
0x140033207: mov      qword ptr [rax - 0x48], rcx
0x14003320b: movdqu   xmmword ptr [rax - 0x18], xmm0
0x140033210: mov      dword ptr [rax - 0x38], 0x30
0x140033217: mov      dword ptr [rax - 0x20], 0x200
0x14003321e: lea      rax, [rip - 0x105]
0x140033225: mov      qword ptr [rcx + 0x10], rdx
0x140033229: mov      edx, 0x1fffff
0x14003322e: mov      qword ptr [rcx + 0x18], r8
0x140033232: lea      r8, [rsp + 0x40]
0x140033237: mov      qword ptr [rsp + 0x28], rax
0x14003323c: and      qword ptr [rsp + 0x20], 0
0x140033242: call     qword ptr [rip + 0xa4ff8]  ; <-- CALL
0x140033248: test     eax, eax
```

### MmMapIoSpaceEx @ 0x140036d76 (.text)
```asm
0x140036d42: test     eax, eax
0x140036d44: jne      0x140036fa3
0x140036d4a: lea      rbx, [rdi + 0x3160]
0x140036d51: mov      rcx, rsi
0x140036d54: mov      rdx, rbx
0x140036d57: call     0x14007f3d0
0x140036d5c: test     eax, eax
0x140036d5e: jne      0x140036f97
0x140036d64: mov      rcx, qword ptr [rbx]
0x140036d67: mov      edx, 0x1000
0x140036d6c: shl      rcx, 0xc
0x140036d70: mov      r8d, 0x204
0x140036d76: call     qword ptr [rip + 0xa143c]  ; <-- CALL
0x140036d7c: mov      qword ptr [rdi + 0x3188], rax
```

### RtlWriteRegistryValue @ 0x140036e83 (.text)
```asm
0x140036e50: lea      rdx, [rbp - 0x29]
0x140036e54: mov      rcx, rdi
0x140036e57: call     0x140035f30
0x140036e5c: test     eax, eax
0x140036e5e: jne      0x140036f6d
0x140036e64: lea      r9d, [rax + 4]
0x140036e68: xor      ecx, ecx
0x140036e6a: lea      rax, [rbp - 0x29]
0x140036e6e: mov      dword ptr [rsp + 0x28], r9d
0x140036e73: lea      r8, [rbp - 0x19]
0x140036e77: mov      qword ptr [rsp + 0x20], rax
0x140036e7c: lea      rdx, [rip + 0x9919d]
0x140036e83: call     qword ptr [rip + 0xa142f]  ; <-- CALL
0x140036e89: test     eax, eax
```

### PsCreateSystemThread @ 0x14003f142 (.text)
```asm
0x14003f10f: mov      rcx, qword ptr [rsi]
0x14003f112: test     rcx, rcx
0x14003f115: je       0x14003f11d
0x14003f117: call     qword ptr [rip + 0x98fdb]
0x14003f11d: lea      rax, [rip + 0xbc]
0x14003f124: mov      qword ptr [rsp + 0x30], rbx
0x14003f129: mov      qword ptr [rsp + 0x28], rax
0x14003f12e: xor      r9d, r9d
0x14003f131: and      qword ptr [rsp + 0x20], 0
0x14003f137: xor      r8d, r8d
0x14003f13a: mov      edx, 0x1fffff
0x14003f13f: mov      rcx, rsi
0x14003f142: call     qword ptr [rip + 0x990f8]  ; <-- CALL
0x14003f148: mov      esi, eax
```

### PsCreateSystemThread @ 0x14005b751 (.text)
```asm
0x14005b710: and      qword ptr [rsp + 0x50], 0
0x14005b716: lea      rcx, [rsp + 0x80]
0x14005b71e: mov      qword ptr [rsp + 0x30], rbx
0x14005b723: xorps    xmm0, xmm0
0x14005b726: mov      qword ptr [rsp + 0x28], rdi
0x14005b72b: xor      r9d, r9d
0x14005b72e: and      qword ptr [rsp + 0x20], 0
0x14005b734: mov      edi, 0x1fffff
0x14005b739: mov      edx, edi
0x14005b73b: mov      dword ptr [rsp + 0x40], 0x30
0x14005b743: mov      dword ptr [rsp + 0x58], 0x200
0x14005b74b: movdqu   xmmword ptr [rsp + 0x60], xmm0
0x14005b751: call     qword ptr [rip + 0x7cae9]  ; <-- CALL
0x14005b757: mov      ebx, eax
```

### MmMapIoSpaceEx @ 0x140072ddb (.text)
```asm
0x140072d98: mov      edx, 1
0x140072d9d: call     qword ptr [rip + 0x6552d]
0x140072da3: and      qword ptr [rbx + 0xb8b8], 0
0x140072dab: and      qword ptr [rbx + 0xb9c8], 0
0x140072db3: mov      eax, dword ptr [rbx + 0x10]
0x140072db6: test     al, 8
0x140072db8: jne      0x140072e3f
0x140072dbe: mov      rax, qword ptr [rbx + 8]
0x140072dc2: mov      edx, 0x1c
0x140072dc7: mov      r8d, 0x204
0x140072dcd: mov      rcx, qword ptr [rax + 0x228]
0x140072dd4: add      rcx, 0x80680
0x140072ddb: call     qword ptr [rip + 0x653d7]  ; <-- CALL
0x140072de1: mov      qword ptr [rbx + 0xb8b8], rax
```

## Finding 1 — Full ICM Overflow Trace

### Overflow site (0x140036d4a – 0x140036d7c)
```asm
0x140036d4a: lea      rbx, [rdi + 0x3160]
0x140036d51: mov      rcx, rsi
0x140036d54: mov      rdx, rbx
0x140036d57: call     0x14007f3d0
0x140036d5c: test     eax, eax
0x140036d5e: jne      0x140036f97
0x140036d64: mov      rcx, qword ptr [rbx]  ; rcx = page_count from firmware
0x140036d67: mov      edx, 0x1000
0x140036d6c: shl      rcx, 0xc  ; *** OVERFLOW: rcx *= 4096, no bounds check ***
0x140036d70: mov      r8d, 0x204
0x140036d76: call     qword ptr [rip + 0xa143c]  ; MmMapIoSpaceEx(phys, OVERFLOW_SIZE, 0x204)
0x140036d7c: mov      qword ptr [rdi + 0x3188], rax  ; store mapped VA
0x140036d83: test     rax, rax
0x140036d86: je       0x140036f8c
0x140036d8c: mov      rcx, rdi
0x140036d8f: call     0x1400379c8
0x140036d94: test     eax, eax
0x140036d96: jne      0x140036f7a
0x140036d9c: lea      rcx, [rdi + 0x31d8]
0x140036da3: xorps    xmm0, xmm0
0x140036da6: movups   xmmword ptr [rcx], xmm0
```

### sub_14007f3d0 — page_count writer
```asm
0x14007f3d0: mov      qword ptr [rsp + 8], rbx
0x14007f3d5: push     rdi
0x14007f3d6: sub      rsp, 0x20
0x14007f3da: test     byte ptr [rcx + 0x8ea0], 2
0x14007f3e1: mov      rdi, rdx
0x14007f3e4: mov      rbx, rcx
0x14007f3e7: je       0x14007f3f0
0x14007f3e9: mov      eax, 0xfffffffb
0x14007f3ee: jmp      0x14007f44c
0x14007f3f0: add      rcx, 0xe8f8
0x14007f3f7: call     0x1400824f0
0x14007f3fc: mov      dword ptr [rdi + 8], eax
0x14007f3ff: mov      r9d, eax
0x14007f402: cmp      eax, -1
0x14007f405: jne      0x14007f40d
0x14007f407: lea      eax, [r9 - 0xb]
0x14007f40b: jmp      0x14007f44c
0x14007f40d: mov      eax, dword ptr [rbx + 0x10]
0x14007f410: mov      r8, qword ptr [rbx + 8]
0x14007f414: test     al, 8
0x14007f416: je       0x14007f431
0x14007f418: mov      eax, dword ptr [r8 + 0x250]
0x14007f41f: cdq      
0x14007f420: idiv     dword ptr [rbx + 0xbc]
0x14007f426: mov      ecx, eax
0x14007f428: mov      eax, r9d
0x14007f42b: cdq      
0x14007f42c: idiv     ecx
0x14007f42e: mov      r9d, edx
0x14007f431: mov      rcx, qword ptr [r8 + 0x240]  ; dev->caps.reserved_mtts
0x14007f438: and      qword ptr [rdi + 0x28], 0
0x14007f43d: shr      rcx, 0xc  ; bytes -> pages
0x14007f441: movsxd   rax, r9d
0x14007f444: add      rcx, rax  ; add firmware-reported new_entries
0x14007f447: mov      qword ptr [rdi], rcx  ; write page_count to ICM table struct
0x14007f44a: xor      eax, eax
0x14007f44c: mov      rbx, qword ptr [rsp + 0x30]
0x14007f451: add      rsp, 0x20
0x14007f455: pop      rdi
0x14007f456: ret      
0x14007f457: int3     
0x14007f458: int3     
0x14007f459: int3     
0x14007f45a: int3     
0x14007f45b: int3     
0x14007f45c: int3     
0x14007f45d: int3     
0x14007f45e: int3     
0x14007f45f: int3     
```

### Finding 2 — Double-deref before ProbeForWrite (0x140028bf4)
```asm
0x140028be6: test     eax, eax
0x140028be8: je       0x140028bf4
0x140028bea: mov      edi, 0xc0000001
0x140028bef: jmp      0x140028d07
0x140028bf4: test     rbx, rbx
0x140028bf7: je       0x140028d04
0x140028bfd: mov      edx, dword ptr [rsp + 0x44]
0x140028c01: mov      r8d, 8
0x140028c07: mov      rcx, qword ptr [rsp + 0x48]
0x140028c0c: mov      rcx, qword ptr [rcx + 8]  ; *** DEREF user ptr+8 WITHOUT ProbeForRead ***
0x140028c10: call     qword ptr [rip + 0xaf68a]  ; ProbeForWrite on already-dereferenced ptr
0x140028c16: mov      rax, qword ptr [rsp + 0x48]
0x140028c1b: mov      rsi, qword ptr [rax + 8]
0x140028c1f: mov      r8d, dword ptr [rbx + 0x18]
0x140028c23: mov      rdx, rbx
```

### Finding 3 — 32-bit shift overflow site 1 (0x140013f08)
```asm
0x140013f01: cmp      dword ptr [rbp + 0x5470], 0
0x140013f08: je       0x1400140ff
0x140013f0e: mov      ecx, dword ptr [r13 + 4]
0x140013f12: mov      eax, r14d
0x140013f15: shl      eax, 4  ; *** shl eax,4 on 32-bit reg -- wraps if r14d >= 0x10000000 ***
0x140013f18: and      rcx, rdx
0x140013f1b: add      rcx, r12
0x140013f1e: mov      edx, eax  ; SIZE = wrapped value
0x140013f20: mov      r8d, 0x204
0x140013f26: mov      r12d, eax
0x140013f29: call     qword ptr [rip + 0xc4289]  ; MmMapIoSpaceEx with potentially-zero size
0x140013f2f: mov      r15, rax
0x140013f32: test     rax, rax
0x140013f35: jne      0x140013f7e
0x140013f37: mov      rcx, qword ptr [rip + 0xd2ab2]
0x140013f3e: cmp      rcx, rsi
```

### Finding 3 — 32-bit shift overflow site 2 (0x14001440a)
```asm
0x140014403: cmp      dword ptr [rbp + 0x5470], 0
0x14001440a: je       0x140014601
0x140014410: mov      ecx, dword ptr [r13 + 4]
0x140014414: mov      eax, r14d
0x140014417: shl      eax, 4  ; *** shl eax,4 on 32-bit reg -- duplicate site ***
0x14001441a: and      rcx, rdx
0x14001441d: add      rcx, r12
0x140014420: mov      edx, eax
0x140014422: mov      r8d, 0x204
0x140014428: mov      r12d, eax
0x14001442b: call     qword ptr [rip + 0xc3d87]  ; MmMapIoSpaceEx
0x140014431: mov      r15, rax
0x140014434: test     rax, rax
0x140014437: jne      0x140014480
0x140014439: mov      rcx, qword ptr [rip + 0xd25b0]
0x140014440: cmp      rcx, rsi
```
