# mlx4_bus.sys — Static Analysis Report

## File Metadata
| Field | Value |
|---|---|
| File | mlx4_bus.sys |
| Type | PE32+ native kernel driver (WDM) |
| Size | 1.1 MB |
| Architecture | x86-64 |
| Sections | 8 |
| Build Timestamp | 2019-06-19 13:21:08 UTC |
| Image Base | 0x140000000 |
| Image Size | 0x129000 |
| Source tree | Y:\BUILDS\winof\5_50\14695\MLNX_WinOF-5_50\hw\mlx4\kernel\bus\net\ |

## Mitigation Summary (DllCharacteristics: 0x4160)
| Mitigation | Status |
|---|---|
| ASLR / DYNAMIC_BASE | PRESENT |
| NX / DEP | PRESENT |
| HIGH_ENTROPY_VA | PRESENT |
| WDM_DRIVER | PRESENT |
| FORCE_INTEGRITY | MISSING |
| GUARD_CF (PE DllChars flag) | MISSING |

## Load Config / CFG
| Field | Value |
|---|---|
| SecurityCookie (/GS) | 0x1400f9850 (PRESENT) |
| GuardCFCheckFunction | 0x1400d85c0 (PRESENT) |
| GuardFlags | 0x14500 |
| CF_INSTRUMENTED | YES |
| CF_FUNCTION_TABLE_PRESENT | YES |
| RF_INSTRUMENTED (return flow) | NO |
| XFG | NO |

Forward-edge CFG present, return-flow protection absent.

## Section Map
| Section | VA | Raw Size | Entropy |
|---|---|---|---|
| .text | 0x1000 | 0xd6a00 | 6.442 |
| .rdata | 0xd8000 | 0xc600 | 4.776 |
| .data | 0xe5000 | 0x15c00 | 3.635 |
| .pdata | 0x10e000 | 0x6000 | 5.939 |
| PAGE | 0x114000 | 0xa00 | 5.556 |
| INIT | 0x115000 | 0x1800 | 4.964 |
| .rsrc | 0x117000 | 0x10a00 | 3.687 |
| .reloc | 0x128000 | 0x600 | 5.066 |

No elevated entropy — no packed/encrypted sections.

## Imported DLLs
- ntoskrnl.exe — 170 imports
- HAL.dll — 1 import (KeQueryPerformanceCounter)
- NETIO.SYS — 5 imports (GetIfTable2, NotifyUnicastIpAddressChange, CancelMibChangeNotify2, FreeMibTable, GetUnicastIpAddressTable)
- WDFLDR.SYS — 4 imports (WdfVersionBind/Unbind/BindClass/UnbindClass)

## Security-Relevant Imports
```
ExAllocatePoolWithTag          -- DEPRECATED; returns uninitialised memory
ExAllocatePoolWithTagPriority  -- DEPRECATED
MmMapIoSpaceEx                 -- physical memory mapping; size must be validated
MmAllocateContiguousMemorySpecifyCache -- multiple call sites
MmAllocateContiguousNodeMemory
ProbeForWrite / MmProbeAndLockPages
MmSecureVirtualMemory / MmUnsecureVirtualMemory
IoConnectInterrupt / IoConnectInterruptEx
PsCreateSystemThread           -- 4 call sites
RtlWriteRegistryValue
rand                           -- non-CSPRNG, non-thread-safe
sprintf_s / swprintf_s / sscanf_s / swscanf_s / _snprintf_s
KeStackAttachProcess / KeUnstackDetachProcess
DbgBreakPointWithStatus        -- present in release binary
IoGetDmaAdapter
```

## IOCTL / Device Interface Strings
```
Bus: ioctl_Create_Control_Device ended with %#x
ioctl_Create_Control_Device
ioctl_Delete_Control_Device
IOCTL FIFWorkItem
Ioctl4Hca_%d.%d.%d            -- control device name pattern
```

---

## FINDING 1 — Integer Overflow → MmMapIoSpaceEx (ICM Page Count)
**Severity:** High  
**Location:** .text @ 0x140036d64 – 0x140036d7c  
**Source file:** icm.c (embedded build path)

### Disassembly
```asm
0x140036d4a: lea  rbx, [rdi + 0x3160]      ; rbx -> ICM table struct inside mlx4_dev
0x140036d51: mov  rcx, rsi
0x140036d54: mov  rdx, rbx
0x140036d57: call sub_14007f3d0            ; populate ICM table: writes page_count to [rbx]
0x140036d5c: test eax, eax
0x140036d5e: jne  0x140036f97             ; bail on error
0x140036d64: mov  rcx, qword ptr [rbx]    ; rcx = ICM page_count (FROM FIRMWARE)
0x140036d67: mov  edx, 0x1000
0x140036d6c: shl  rcx, 0xc               ; rcx *= 4096 -- NO OVERFLOW CHECK
0x140036d70: mov  r8d, 0x204             ; PAGE_READWRITE | MmNonCached
0x140036d76: call MmMapIoSpaceEx         ; maps rcx bytes of physical memory
0x140036d7c: mov  qword ptr [rdi+0x3188], rax  ; store mapped VA
```

### sub_14007f3d0 — ICM page count writer
```asm
0x14007f3f0: add  rcx, 0xe8f8            ; rcx -> dev->bitmap (ICM allocation bitmap)
0x14007f3f7: call sub_1400824f0          ; scan bitmap; return highest-set-bit index
0x14007f3fc: mov  dword ptr [rdi + 8], eax
0x14007f431: mov  rcx, qword ptr [r8 + 0x240]  ; rcx = dev->caps.reserved_mtts
0x14007f43d: shr  rcx, 0xc              ; reserved_mtts bytes -> pages
0x14007f441: movsxd rax, r9d            ; rax = new_entries (firmware-reported)
0x14007f444: add  rcx, rax              ; total_pages = reserved + new_entries
0x14007f447: mov  qword ptr [rdi], rcx  ; write -> [rdi] = [rbx+0x3160] in caller
```

### Data Flow Chain
```
Firmware QUERY_DEV_CAP mailbox response
          |
          v
dev->caps.reserved_mtts  (offset +0x240)
          |
          v
sub_14007f3d0:
  total_pages = (reserved_mtts >> 12) + bitmap_scan_result
          |
          v
[rdi + 0x3160] = total_pages   (ICM table struct field 0)
          |
          v
shl rcx, 0xc   (total_pages * 4096 = byte_size)  <-- NO BOUNDS CHECK HERE
          |
          v
MmMapIoSpaceEx(phys_addr, byte_size, PAGE_READWRITE|MmNonCached)
```

### Overflow Condition
- `total_pages` is a 64-bit QWORD derived from firmware-reported `reserved_mtts`
- `shl rcx, 0xc` (left shift 12) has no preceding bounds check
- If `total_pages >= 0x0010000000000000` (2^52), the product overflows 64-bit and wraps
- Result: `MmMapIoSpaceEx` receives an undersized mapping
- The driver then uses the stored VA at `[rdi+0x3188]` for ICM reads/writes → OOB physical memory access

### Attack Surface
- `reserved_mtts` comes from the HCA firmware's `QUERY_DEV_CAP` command response over MMIO
- A malicious or compromised NIC firmware can supply an oversized value
- In SR-IOV configurations, a guest VM influencing VF reset flows may affect the value
- `MLX4_CMD_SET_ICM_SIZE` (also imported) accepts a related size parameter feeding the same path

### Fix
```c
// Before: shl rcx, 0xc
if (total_pages > (MAXUINT64 >> 12)) {
    return STATUS_INVALID_PARAMETER;
}
byte_size = total_pages << 12;
```

---

## FINDING 2 — Unprobed Double-Dereference Before ProbeForWrite
**Severity:** Medium-High  
**Location:** .text @ 0x140028be6 – 0x140028c16

### Disassembly
```asm
0x140028bf4: test rbx, rbx                     ; null check outer pointer
0x140028bf7: je   0x140028d04
0x140028bfd: mov  edx, dword ptr [rsp + 0x44]  ; alignment (from IOCTL input)
0x140028c01: mov  r8d, 8                        ; probe size = 8
0x140028c07: mov  rcx, qword ptr [rsp + 0x48]  ; user-supplied buffer pointer
0x140028c0c: mov  rcx, qword ptr [rcx + 8]     ; DEREF user ptr+8 WITHOUT ProbeForRead
0x140028c10: call ProbeForWrite                 ; too late -- already dereferenced
```

### Issue
Correct pattern requires ProbeForRead on the source pointer before dereferencing it
to extract an inner pointer, then ProbeForWrite on the inner pointer:

```c
// WRONG (as implemented):
inner = *(PVOID*)(user_ptr + 8);   // deref without probe
ProbeForWrite(inner, 8, align);

// CORRECT:
ProbeForRead(user_ptr, 16, 1);     // validate source range first
inner = *(PVOID*)(user_ptr + 8);   // safe to deref
ProbeForWrite(inner, 8, align);    // validate destination
```

The deref happens inside a __try block (SEH), but this does not eliminate the TOCTOU
window: the value at user_ptr+8 can change between the kernel read and the subsequent
ProbeForWrite call if the buffer is in shared memory with a user-mode thread.

---

## FINDING 3 — 32-bit Shift Overflow → MmMapIoSpaceEx (Two Sites)
**Severity:** Medium  
**Locations:**
- .text @ 0x140013f08 – 0x140013f2f
- .text @ 0x14001440a – 0x14001442b (near-identical duplicate)

### Disassembly (first site)
```asm
0x140013f01: cmp  dword ptr [rbp + 0x5470], 0  ; feature flag guard
0x140013f08: je   0x1400140ff                  ; skip if disabled
0x140013f0e: mov  ecx, dword ptr [r13 + 4]     ; ecx = 32-bit field from device struct
0x140013f12: mov  eax, r14d                    ; eax = entry count (32-bit)
0x140013f15: shl  eax, 4                       ; eax *= 16 -- WRAPS at r14d >= 0x10000000
0x140013f18: and  rcx, rdx
0x140013f1b: add  rcx, r12                     ; physical base address
0x140013f1e: mov  edx, eax                     ; SIZE = wrapped value
0x140013f20: mov  r8d, 0x204
0x140013f29: call MmMapIoSpaceEx
```

### Overflow Condition
- `shl eax, 4` operates on a 32-bit register
- If `r14d >= 0x10000000` (268M), product overflows; `edx` wraps to a small or zero value
- `MmMapIoSpaceEx` with size 0 may return non-NULL but maps nothing
- Subsequent driver access to the stored VA = OOB physical memory access
- Two identical sites suggest copy-pasted BAR-sizing code for two resource types

### Fix
```c
// Promote to 64-bit before shift:
ULONG64 size = (ULONG64)r14d << 4;
if (size > MAXULONG) return STATUS_INVALID_PARAMETER;
```

---

## FINDING 4 — rand() Usage in Kernel Driver
**Severity:** Low-Medium  
**Location:** IAT (import)

`rand()` is a CRT linear-congruential PRNG: shared global state, no IRQL protection,
not thread-safe, not cryptographically secure. The driver also imports `RtlRandomEx`
which is the correct kernel PRNG. Usage should be consolidated to `RtlRandomEx`
or `BCryptGenRandom` for security-sensitive values.

---

## FINDING 5 — Deprecated Pool Allocation APIs
**Severity:** Low  
**APIs:** ExAllocatePoolWithTag, ExAllocatePoolWithTagPriority

Deprecated since Windows 10 21H2 in favour of ExAllocatePool2.
ExAllocatePool2 zeroes allocations before returning, preventing uninitialised
pool content from leaking to user mode via IOCTL output buffers.
ExAllocatePool2 is available across the full supported OS range of this driver.

---

## Key Strings
```
MLX4_CMD_QUERY_DEV_CAP
MLX4_CMD_MAP_ICM / UNMAP_ICM
MLX4_CMD_SET_ICM_SIZE
MLX4_CMD_INIT_HCA
QUERY_DEV_CAP command failed, aborting.
Before MAP_ICM
Incorrect toggle %d from slave %d. *** MASTERSTATE COMPROMISED ***
Bus: AllocateCommonBuffer: contiguous memory allocation took too long - %d ms
icm.c:129 / icm.c:141 / icm.c:474  (embedded assert paths)
```
