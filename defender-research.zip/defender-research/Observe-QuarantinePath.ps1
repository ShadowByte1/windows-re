#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Observe Windows Defender quarantine metadata for security research.
    Drops an EICAR test string, waits for quarantine, then inspects the
    Quarantine\Entries directory to identify restore path storage.

.NOTES
    Run in a snapshotted VM. Restore snapshot after each test.
    EICAR is a safe, standardized AV test string — not real malware.
#>

$ErrorActionPreference = 'Stop'

# ── Config ──────────────────────────────────────────────────────────────────
$TestDir        = "C:\AVResearch"
$EicarPath      = "$TestDir\eicar_test.txt"
$QuarantineBase = "C:\ProgramData\Microsoft\Windows Defender\Quarantine"
$EntriesDir     = "$QuarantineBase\Entries"
$OutputDir      = "$TestDir\findings"

# EICAR standard test string — triggers AV detection, completely safe
$EicarString    = 'X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*'
# ────────────────────────────────────────────────────────────────────────────

function Write-Step($msg) { Write-Host "[*] $msg" -ForegroundColor Cyan }
function Write-Find($msg) { Write-Host "[+] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[!] $msg" -ForegroundColor Yellow }

# ── Setup ────────────────────────────────────────────────────────────────────
New-Item -ItemType Directory -Force -Path $TestDir, $OutputDir | Out-Null

# ── Step 1: Snapshot Entries dir BEFORE ──────────────────────────────────────
Write-Step "Snapshotting Quarantine\Entries before EICAR drop..."
$before = @{}
if (Test-Path $EntriesDir) {
    Get-ChildItem $EntriesDir -File | ForEach-Object {
        $before[$_.Name] = $_.LastWriteTime
    }
}
Write-Step "Entries dir has $($before.Count) files before test"

# ── Step 2: Check ACLs on Entries dir ────────────────────────────────────────
Write-Step "Checking ACLs on Quarantine directories..."
$aclTargets = @($QuarantineBase, $EntriesDir, "$QuarantineBase\ResourceData")
foreach ($path in $aclTargets) {
    if (Test-Path $path) {
        $acl = Get-Acl $path
        $acl.Access | ForEach-Object {
            $id = $_.IdentityReference.Value
            $rights = $_.FileSystemRights
            $type = $_.AccessControlType
            if ($id -notmatch 'SYSTEM|TrustedInstaller|Administrators' -and $type -eq 'Allow') {
                Write-Find "WRITABLE by non-admin: $path → $id : $rights"
                "WRITABLE: $path | $id | $rights" | Out-File "$OutputDir\acl_findings.txt" -Append
            } else {
                Write-Host "    $path → $id : $rights ($type)" -ForegroundColor DarkGray
            }
        }
    } else {
        Write-Warn "Path not found: $path"
    }
}

# ── Step 3: Drop EICAR ───────────────────────────────────────────────────────
Write-Step "Writing EICAR test file to $EicarPath ..."
Set-Content -Path $EicarPath -Value $EicarString -Encoding ASCII
Write-Step "EICAR dropped. Waiting for Defender to quarantine (up to 30s)..."

$quarantined = $false
for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 1
    if (-not (Test-Path $EicarPath)) {
        Write-Find "EICAR file removed by Defender after $($i+1)s"
        $quarantined = $true
        break
    }
    Write-Host "    $($i+1)s..." -NoNewline
}
Write-Host ""

if (-not $quarantined) {
    Write-Warn "EICAR file still present after 30s — real-time protection may be off"
    Write-Warn "Try: Set-MpPreference -DisableRealtimeMonitoring `$false"
}

# ── Step 4: Diff Entries dir ─────────────────────────────────────────────────
Write-Step "Diffing Quarantine\Entries for new files..."
$newEntries = @()
if (Test-Path $EntriesDir) {
    Get-ChildItem $EntriesDir -File | ForEach-Object {
        if (-not $before.ContainsKey($_.Name)) {
            $newEntries += $_
            Write-Find "New entry file: $($_.FullName) ($($_.Length) bytes)"
        }
    }
}

if ($newEntries.Count -eq 0) {
    Write-Warn "No new entry files found. Check ResourceData directory instead."
    Get-ChildItem $QuarantineBase -Recurse -File | 
        Where-Object { $_.LastWriteTime -gt (Get-Date).AddMinutes(-2) } |
        ForEach-Object { Write-Find "Recently modified: $($_.FullName)" }
}

# ── Step 5: Dump entry files for analysis ────────────────────────────────────
foreach ($entry in $newEntries) {
    Write-Step "Dumping entry: $($entry.Name)"
    
    # Copy raw bytes for hex analysis
    $destRaw = "$OutputDir\$($entry.Name).bin"
    Copy-Item $entry.FullName $destRaw
    Write-Find "  Raw copy → $destRaw"
    
    # Try to extract printable strings
    $bytes  = [System.IO.File]::ReadAllBytes($entry.FullName)
    $text   = [System.Text.Encoding]::Unicode.GetString($bytes)
    $ascii  = [System.Text.Encoding]::ASCII.GetString($bytes)
    
    # Look for path-like strings
    $pathPattern = '[A-Za-z]:\\[^\x00-\x1F"<>|?*]{4,}'
    $unicodePaths = [regex]::Matches($text,  $pathPattern) | Select-Object -ExpandProperty Value -Unique
    $asciiPaths   = [regex]::Matches($ascii, $pathPattern) | Select-Object -ExpandProperty Value -Unique
    
    $allPaths = ($unicodePaths + $asciiPaths) | Sort-Object -Unique
    if ($allPaths) {
        Write-Find "  Paths found in entry metadata:"
        $allPaths | ForEach-Object { Write-Find "    $_" }
        $allPaths | Out-File "$OutputDir\paths_$($entry.Name).txt"
    } else {
        Write-Warn "  No path strings found (may be encrypted/encoded)"
    }
    
    # Hex dump first 512 bytes for manual analysis
    $hexDump = ($bytes | Select-Object -First 512 | ForEach-Object { "{0:X2}" -f $_ }) -join ' '
    $hexDump | Out-File "$OutputDir\hexdump_$($entry.Name).txt"
    Write-Find "  Hex dump (512 bytes) → $OutputDir\hexdump_$($entry.Name).txt"
}

# ── Step 6: Defender event log ───────────────────────────────────────────────
Write-Step "Pulling relevant Defender event log entries..."
try {
    $events = Get-WinEvent -LogName 'Microsoft-Windows-Windows Defender/Operational' -MaxEvents 20 |
        Where-Object { $_.Id -in @(1116, 1117, 2004, 5007) } |  # Detection, remediation, platform config
        Select-Object TimeCreated, Id, Message
    
    $events | ForEach-Object {
        Write-Host "  [EventID $($_.Id)] $($_.TimeCreated)" -ForegroundColor DarkGray
        # Extract first 3 lines of message
        ($_.Message -split "`n" | Select-Object -First 3) | 
            ForEach-Object { Write-Host "    $_" -ForegroundColor DarkGray }
    }
    $events | Out-File "$OutputDir\defender_events.txt"
} catch {
    Write-Warn "Could not read event log: $_"
}

# ── Step 7: Summary ──────────────────────────────────────────────────────────
Write-Host ""
Write-Host "════════════════════════════════════════" -ForegroundColor White
Write-Host " Research Summary" -ForegroundColor White
Write-Host "════════════════════════════════════════" -ForegroundColor White
Write-Host "  Quarantine base:  $QuarantineBase"
Write-Host "  New entry files:  $($newEntries.Count)"
Write-Host "  Output dir:       $OutputDir"
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "  1. Open the .bin files in a hex editor (e.g. HxD)"
Write-Host "  2. Search for your original file path ($EicarPath)"
Write-Host "  3. If found verbatim: test whether editing the path + triggering"
Write-Host "     restore writes the quarantined file to the modified path"
Write-Host "  4. Trigger restore via: Start-MpScan -ScanType 3 or the UI"
Write-Host "  5. Monitor with ProcMon filter: Process=MsMpEng.exe, Op=WriteFile"
Write-Host ""
Write-Host "  REVERT VM SNAPSHOT before further testing" -ForegroundColor Red
