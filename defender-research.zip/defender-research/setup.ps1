#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Install research tooling for Windows Defender analysis.
    Run once in a fresh VM before testing.
#>

$ErrorActionPreference = 'Continue'

function Write-Step($msg) { Write-Host "[*] $msg" -ForegroundColor Cyan }
function Write-OK($msg)   { Write-Host "[+] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[!] $msg" -ForegroundColor Yellow }

# ── 1. Sysinternals Suite (Process Monitor, Process Explorer, AccessChk) ─────
Write-Step "Installing Sysinternals Suite..."
winget install --id Microsoft.Sysinternals.ProcessMonitor --silent --accept-package-agreements --accept-source-agreements
winget install --id Microsoft.Sysinternals.ProcessExplorer --silent --accept-package-agreements --accept-source-agreements
winget install --id Microsoft.Sysinternals.Sysmon --silent --accept-package-agreements --accept-source-agreements

# AccessChk — not on winget, download directly
Write-Step "Downloading AccessChk..."
$acUrl  = "https://download.sysinternals.com/files/AccessChk.zip"
$acDest = "$env:TEMP\AccessChk.zip"
Invoke-WebRequest -Uri $acUrl -OutFile $acDest
Expand-Archive -Path $acDest -DestinationPath "C:\Tools\Sysinternals" -Force
Write-OK "AccessChk → C:\Tools\Sysinternals\accesschk64.exe"

# ── 2. WinDbg (for crash analysis / TTD) ─────────────────────────────────────
Write-Step "Installing WinDbg..."
winget install --id Microsoft.WinDbg --silent --accept-package-agreements --accept-source-agreements

# ── 3. Sysmon with default config ─────────────────────────────────────────────
Write-Step "Configuring Sysmon..."
$sysmonPath = (Get-Command sysmon64.exe -ErrorAction SilentlyContinue)?.Source
if (-not $sysmonPath) {
    winget install --id Microsoft.Sysinternals.Sysmon --silent --accept-package-agreements --accept-source-agreements
    $sysmonPath = "C:\Program Files\Sysinternals\sysmon64.exe"
}
# Minimal config — log file creates, process creates, network connections
$sysmonCfg = @"
<Sysmon schemaversion="4.82">
  <EventFiltering>
    <RuleGroup name="" groupRelation="or">
      <ProcessCreate onmatch="include">
        <Image condition="contains">MsMpEng</Image>
        <Image condition="contains">MpCmdRun</Image>
      </ProcessCreate>
      <FileCreate onmatch="include">
        <Image condition="contains">MsMpEng</Image>
      </FileCreate>
      <NetworkConnect onmatch="include">
        <Image condition="contains">MsMpEng</Image>
      </NetworkConnect>
    </RuleGroup>
  </EventFiltering>
</Sysmon>
"@
$cfgPath = "C:\Tools\sysmon-defender.xml"
New-Item -ItemType Directory -Force -Path "C:\Tools" | Out-Null
$sysmonCfg | Out-File $cfgPath -Encoding UTF8
& $sysmonPath -accepteula -i $cfgPath 2>&1 | Out-Null
Write-OK "Sysmon installed with Defender-focused config"

# ── 4. HxD (hex editor) ───────────────────────────────────────────────────────
Write-Step "Installing HxD hex editor..."
winget install --id MHNexus.HxD --silent --accept-package-agreements --accept-source-agreements 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Warn "HxD not in winget — download manually: https://mh-nexus.de/en/hxd/"
}

# ── 5. 7-Zip ──────────────────────────────────────────────────────────────────
Write-Step "Installing 7-Zip..."
winget install --id 7zip.7zip --silent --accept-package-agreements --accept-source-agreements

# ── 6. Python 3 + pefile (for offline PE analysis) ───────────────────────────
Write-Step "Installing Python 3..."
winget install --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
Write-Step "Installing pefile..."
Start-Process -FilePath "python" -ArgumentList "-m pip install pefile --quiet" -Wait -NoNewWindow

# ── 7. WerFault / WER crash dump config ──────────────────────────────────────
Write-Step "Configuring WER to keep all crash dumps..."
$werKey = "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting"
New-Item -Path "$werKey\LocalDumps" -Force | Out-Null
Set-ItemProperty -Path "$werKey\LocalDumps" -Name "DumpFolder" -Value "C:\CrashDumps"
Set-ItemProperty -Path "$werKey\LocalDumps" -Name "DumpCount" -Value 10 -Type DWORD
Set-ItemProperty -Path "$werKey\LocalDumps" -Name "DumpType" -Value 2 -Type DWORD  # Full dump
New-Item -ItemType Directory -Force -Path "C:\CrashDumps" | Out-Null
Write-OK "Crash dumps → C:\CrashDumps\ (full dumps, keep last 10)"
# MsMpEng-specific dump config
New-Item -Path "$werKey\LocalDumps\MsMpEng.exe" -Force | Out-Null
Set-ItemProperty -Path "$werKey\LocalDumps\MsMpEng.exe" -Name "DumpFolder" -Value "C:\CrashDumps"
Set-ItemProperty -Path "$werKey\LocalDumps\MsMpEng.exe" -Name "DumpType" -Value 2 -Type DWORD
Write-OK "MsMpEng.exe crash dumps configured"

# ── 8. Defender logging verbosity ─────────────────────────────────────────────
Write-Step "Enabling verbose Defender operational logging..."
wevtutil sl "Microsoft-Windows-Windows Defender/Operational" /ms:104857600  # 100MB log
Write-OK "Defender event log max size → 100MB"

# ── 9. Research directory structure ───────────────────────────────────────────
Write-Step "Creating research directory structure..."
$dirs = @(
    "C:\AVResearch",
    "C:\AVResearch\corpus",      # seed files for fuzzing
    "C:\AVResearch\findings",    # script output
    "C:\AVResearch\crashes",     # crash reproducers
    "C:\AVResearch\procmon",     # ProcMon captures
    "C:\CrashDumps",
    "C:\Tools"
)
$dirs | ForEach-Object { New-Item -ItemType Directory -Force -Path $_ | Out-Null }

# Seed corpus with common file types
Write-Step "Creating test corpus seed files..."
# Minimal valid PDF
[System.IO.File]::WriteAllBytes("C:\AVResearch\corpus\seed.pdf",
    [System.Text.Encoding]::ASCII.GetBytes("%PDF-1.4`n1 0 obj<</Type /Catalog /Pages 2 0 R>>endobj`n2 0 obj<</Type /Pages /Kids [3 0 R] /Count 1>>endobj`n3 0 obj<</Type /Page /Parent 2 0 R /MediaBox [0 0 612 792]>>endobj`nxref`n0 4`n0000000000 65535 f`n0000000009 00000 n`n0000000058 00000 n`n0000000115 00000 n`ntrailer<</Size 4 /Root 1 0 R>>startxref`n190`n%%EOF"))
# Minimal ZIP
$zipBytes = [byte[]](0x50,0x4B,0x05,0x06,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)
[System.IO.File]::WriteAllBytes("C:\AVResearch\corpus\seed.zip", $zipBytes)
Write-OK "Seed corpus → C:\AVResearch\corpus\"

# ── Summary ───────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "════════════════════════════════════════" -ForegroundColor White
Write-Host " Setup Complete" -ForegroundColor White
Write-Host "════════════════════════════════════════" -ForegroundColor White
Write-Host "  Tools:       C:\Tools\"
Write-Host "  Research:    C:\AVResearch\"
Write-Host "  Crashes:     C:\CrashDumps\"
Write-Host ""
Write-Host "Installed:" -ForegroundColor Yellow
Write-Host "  - Process Monitor (Sysinternals)"
Write-Host "  - Process Explorer (Sysinternals)"
Write-Host "  - AccessChk (Sysinternals)"
Write-Host "  - Sysmon (configured for MsMpEng)"
Write-Host "  - WinDbg"
Write-Host "  - HxD (hex editor)"
Write-Host "  - 7-Zip"
Write-Host "  - Python 3.12 + pefile"
Write-Host "  - WER full crash dump config"
Write-Host ""
Write-Host "Take a clean VM snapshot NOW before running any tests." -ForegroundColor Red
