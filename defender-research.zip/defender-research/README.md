# Windows Defender Research Toolkit

## Purpose
Static analysis findings from mpengine.dll and tooling for responsible disclosure
research against Windows Defender's quarantine/remediation logic.

## Contents
- `Observe-QuarantinePath.ps1` — EICAR quarantine metadata observer
- `mpengine_research.md` — Static analysis findings (attack surface map)
- `setup.ps1` — Install research tools (Sysinternals, WinDbg, etc.)
- `README.md` — This file

## VM Setup
1. Windows 11 VM (Hyper-V or VMware), snapshot before any testing
2. Network: Host-only or None
3. Defender: fully enabled, real-time protection ON
4. Run `setup.ps1` as admin first

## Workflow
1. Take clean VM snapshot
2. Run `Observe-QuarantinePath.ps1` as admin
3. Inspect output in C:\AVResearch\findings\
4. Revert snapshot between tests

## Disclosure
Submit findings to: https://msrc.microsoft.com/report
