# mpengine.dll Static Analysis — Bug Surface Research
**Version:** 1.1.26030.3008 (build hash f5eeade182dbc48f048d25031e1330bd24ca8e47)  
**Compiled:** Mon Jun 27 14:43:11 2022 UTC  
**Size:** 18 MB | **MD5:** 5b83a74f7a6288feeca9b4ad19429578  
**SHA1:** ae876ce766522489edb24c4901669685889ad883

---

## Security Mitigations

| Mitigation | Status |
|---|---|
| ASLR (DYNAMIC_BASE) | ✅ Enabled |
| DEP (NX_COMPAT) | ✅ Enabled |
| CFG (Control Flow Guard) | ✅ Enabled (+ long jump) |
| Stack Cookie (`/GS`) | ✅ Enabled (SecurityCookie @ 0x180fe4d00) |
| SafeSEH | ✅ (0 SEH handlers — x64, structured exception not used) |
| RFG (Return Flow Guard) | ❌ Not enabled |

**Takeaway:** Memory corruption exploitation is hard — ASLR+CFG+stack cookies all present. Logic bugs (RedSun/UnDefend class) remain the high-ROI surface.

---

## Exported API — Primary Attack Surface

Only 17 exports. The `MpContainer*` family is the key public interface:

```
MpContainerOpen        — open a file/stream for scanning
MpContainerRead        — read container content
MpContainerWrite       — write to container
MpContainerOpenObject  — open an object within a container
MpContainerGetNext     — enumerate container objects
MpContainerAnalyze     — trigger analysis
MpContainerCommit      — commit changes
MpContainerDelete      — delete container/object
MpContainerClose       — close handle
MpContainerSetSize     — set container size
MpContainerFreeObjectInfo
MpBootStrap            — engine init
rsignal / __rsignal    — internal signal dispatch
FreeSigFiles / GetSigFiles — signature file management
```

**Research angle:** `MpContainerWrite` + `MpContainerSetSize` accepting attacker-controlled sizes. Look for integer overflow between `SetSize` and subsequent `Write`/`Read` bounds checks — classic SYSTEM-reachable write primitive.

---

## File Format Parser Surface (Historically Richest Attack Surface)

The engine parses **all** of these formats internally — each is a parser written in C++, each is potential memory corruption / logic bug surface:

### Archive / Container Formats
- ZIP, GZIP, BZIP2, RAR, RAR SFX, CAB, CAB SFX, 7-Zip, LZMA, XZ, TAR, DMG
- **XZStream** has its own namespace with multiple BCJ filter classes (ARM, SPARC, PPC, Delta) — these are complex decompression transforms, historically buggy

### Document Formats
- PDF (full parser with XFA, XRef streams, object streams, LZW, RLE, multiple filters)
- OLE2 / CFB (DOC, XLS, PPT)
- OOXML (DOCX, XLSX, PPTX via ZIP + XML)
- RTF, CHM, MHT, MIME, EML, MSG, PST, DBX

### Executable / Code Formats
- PE/MZ (multiple packers: PECompact 0.91/0.93/0.971/0.975/0.978/0.9781/2.x/2.50)
- ELF, MachO (SELF.COM)
- DEX (Android), APK
- VHD, VHDX (disk images)
- SWF (Flash)
- LNK

### Scripting / Active Content
- JavaScript (full emulator: `JSEmu Evaluation`, JScript)
- VBScript
- PowerShell (AMSI integration + base64 decode)
- Lua (embedded 5.1 engine — runs signature scripts)
- VBA / Office macros
- AutoIt, NSIS, InnoSetup (installer parsers)
- Python detection

---

## High-Priority Bug Classes

### 1. PDF Parser — `PDF_IgnoreLengthField` / `PDF_TrustLengthFields`

The existence of **both** `PDF_IgnoreLengthField` and `PDF_TrustLengthFields` as runtime flags means there's a length-field handling mode that can be toggled. This suggests the engine has known issues with PDF stream length consistency — worth fuzzing with mismatched `/Length` vs actual stream content. Tavis Ormandy found similar issues (CVE-2017-0290) in an earlier engine version via PDF stream parsing.

**Test vector:** Craft a PDF with a stream object where `/Length` significantly underreports the actual content. Then try the inverse — `/Length` larger than actual data, forcing a read-past-end.

**Also note:** `PdfAutoPreventDeepNesting` class exists — meaning the engine *knows* about PDF nesting depth issues but relies on a single class to prevent them. Test whether this is bypassable via object stream nesting (XRef streams containing object streams containing references back to root).

### 2. XZStream BCJ Filters — Multiple Architecture Filter Transforms

RTTI reveals: `ArmFilter`, `SparcFilter`, `PPCFilter`, `DeltaFilter` — all in the `XZStream` namespace. BCJ (Branch/Call/Jump) filters decode architecture-specific branch instructions and convert them. They do address arithmetic on the decoded bytes:

```
decoded_addr = (raw_bytes[i:i+4] as uint32) + current_offset
```

If `current_offset` can overflow a 32-bit boundary and the result is used in subsequent operations without bounds checking, you get an integer overflow leading to memory corruption. This is the exact class of bug found in liblzma/xz-utils.

**Test vector:** Craft a `.xz` file with an ARM BCJ filter and branch offsets near `0xFFFFFFFF`. Trigger via `MpCmdRun.exe -Scan -ScanType 3 -File <file>`.

### 3. PE Container API — `SetSize` / `Write` Integer Overflow

The `MpContainerSetSize` + `MpContainerWrite` export pair handles user-controlled sizes. Classic pattern for integer truncation:

```
SetSize(0x100000001)  →  stored as DWORD = 0x00000001
Write(large_buffer)   →  bounds check against truncated size → heap overflow
```

The string `ServerStreamSetSizeInvalidContext` / `ServerStreamGetSizeInvalidContext` suggests there are validation paths that might not cover all callers. Worth reverse-engineering the size validation logic in `MpContainerSetSize` in Ghidra — look for `DWORD` vs `QWORD` inconsistencies.

### 4. Lua Signature Engine — Arbitrary Memory Read Primitive

The engine runs Lua 5.1 as its signature scripting language. Key observations:
- `mp.readfile()` with configurable `MpLuaMaxFileReadTotalSize` and `MpLuaMaxBufferSize` limits
- `mp.readprocessmem(addr=0x%llx, cb=%u)` — **reads process memory from Lua scripts**
- `readu_u16`, `readu_u32` with explicit error messages: `"readu_u16 string buffer too small: %d + %d bytes!"`, `"invalid index %d"`
- `mp.DecodeAsn1()`, `mp.crc32()`, `mp.utf16to8()`, `mp.utf8to16()` — all with buffer size params

**Research angle:** If a malicious signature (or a signature loaded via a writable path) can be injected, the Lua engine provides direct process memory read/write. Even without sig injection, any Lua parser bug in the signature deserializer could be exploited.

**Also:** `C stack overflow` error string — Lua's error for native stack overflow. If signature recursion detection can be bypassed, infinite recursion in the Lua engine = DoS or potentially exploitable stack corruption.

### 5. Remediation / Quarantine — Nightmare-Eclipse Class Bugs

The remediation flow surface is **much larger** than RedSun targeted. Key components:

```
CQuarantineAction       — quarantines a file
CQuarantineCommitAction — commits the quarantine (writes metadata)
CFixRestoreWU_BITS      — restores Windows Update / BITS entries
CQuarantineSizeCheckAction — checks size before quarantine
ResmgrFileRestore       — restores a file from quarantine
ResmgrRegKeyRestore     — restores a registry key
ResmgrServiceRestore    — restores a service
ResmgrWMIRestore        — restores WMI entries
```

**TOCTOU windows identified:**
- `BackupRead` / `BackupWrite` API calls — these operate on file handles; if a symlink/junction can be substituted between the `CreateFile` that opened the handle and the `BackupWrite` that writes the restore, arbitrary file write as SYSTEM
- `CFixRestoreWU_BITS` — restores Windows Update / BITS configuration. If the stored restore data (in the quarantine SQLite DB at `MetaVaultRecord*`) is attacker-controllable → BITS/WU configuration write as SYSTEM
- `ActionTagFileHardLink` + `ActionTagFileRename` tracking in BM — the engine tracks hardlink/rename events as threat indicators. If you can trigger a rename/hardlink mid-remediation, there may be a TOCTOU between detection and deletion

**The quarantine metadata store:** SQLite DB (`MetaVaultRecord*`, `BackupProcessInfo` table). Strings: `SELECT ID FROM BackupProcessInfo WHERE Key = ?` — the quarantine entries are keyed. If the key derivation or the path stored in the entry is influenced by attacker-controlled data, you get path traversal on restore → arbitrary SYSTEM write (same root cause as RedSun).

### 6. VHD/VHDX Parser

`.?AVVhdVolume@@` RTTI + `novhdxfile` + `vhdxfileH9` — the engine parses VHD/VHDX disk images to scan their contents. These are complex binary formats with their own FAT/NTFS parser stacks. Parsing a VHD triggers the full NTFS/FAT parser internally. This is a deep attack surface rarely looked at:

- VHD: fixed, dynamic, differencing types — differencing VHDs follow a parent chain. If parent path resolution is not sandboxed, directory traversal on the host
- VHDX: block allocation table (BAT) with sector bitmaps — integer overflow in BAT index calculation → out-of-bounds read during sector mapping

**Test vector:** Craft a dynamic VHD with a corrupted BAT. Also craft a differencing VHD pointing to a nonexistent/malformed parent.

---

## Architecture Notes (For Ghidra/IDA Work)

### Internal Subsystems
```
AntiRootkit namespace    — kernel/driver analysis (Win64 sensor, FltCallback table)
ObjectManager namespace  — tracks File, Thread, Mutant, Semaphore, Event objects
NtfsVolume namespace     — direct NTFS parsing (MFT records, file names)
VirtualDirectory         — virtual FS abstraction
XZStream                 — XZ/LZMA decompression with BCJ filters
MetaStore                — SQLite-backed metadata vault
VSS                      — Volume Shadow Copy integration
ValidateTrust            — Authenticode/catalog verification
CPECompact2V250Unpacker  — PE packer unpacking logic
```

### Source Tree (leaked via assert strings)
```
src\epp\common\Source\oss\boost\...
  - boost/json (parser, stream_parser, basic_parser_impl)
  - boost/property_tree (XML parser via rapidxml)
```
Boost JSON parser is used internally — check it against known Boost JSON CVEs (multiple integer overflow issues in older versions).

### CFG Guard Table
Located at `.gfids` / `.giats` sections. With CFG enabled, indirect call targets must be registered. This limits ROP gadgets significantly — any exploitation would need a CFG bypass or must operate purely through logic bugs.

---

## Recommended Research Priority (Highest ROI First)

1. **Quarantine metadata path traversal** — follow `ResmgrFileRestore` in Ghidra, trace where the restore path comes from in the SQLite `BackupProcessInfo` table. If the path is stored verbatim from the quarantine entry and not re-validated on restore, that's a write-as-SYSTEM bug directly in the RedSun family.

2. **PDF stream length inconsistency** — fuzz `PDF_IgnoreLengthField` vs actual stream sizes. Craft PDFs with mismatched `/Length` and monitor for MsMpEng crashes via WER.

3. **XZStream BCJ ARM/SPARC filter overflow** — craft `.xz` files with BCJ-encoded data and branch offsets near INT32_MAX. Monitor for crashes.

4. **VHD/VHDX parser** — craft malformed dynamic VHDs with corrupt BAT. Very low competition for this surface.

5. **Lua `mp.readprocessmem()` exposure** — investigate whether signature files on disk can be tampered with (check ACLs on definition directory). If writable by non-admin, arbitrary process memory read via Lua is trivially exploitable.

---

## Tooling for Next Steps

```bash
# Get Ghidra to load this for function-level analysis
# Recommended: start with MpContainerOpen → trace to MpContainerSetSize
# Look for: DWORD vs QWORD size promotion, memcpy/memmove calls with derived sizes

# For fuzzing PDF parser:
MpCmdRun.exe -Scan -ScanType 3 -File <mutated.pdf>
# Watch: WER dumps in C:\ProgramData\Microsoft\Windows\WER\ReportQueue\

# For quarantine flow analysis:
# 1. Drop EICAR, watch ProcMon for MsMpEng.exe WriteFile ops
# 2. Note the path written to in Quarantine\Entries\
# 3. Hex-edit the entry file (if writable), change restore path, trigger restore
# 4. Observe where the file is written

# Check definition directory ACLs:
icacls "C:\ProgramData\Microsoft\Windows Defender\Definition Updates" /T
# If any subfolder writable by Users → Lua sig injection path
```

---

## MSRC Disclosure Notes

- This version (1.1.26030.3008, June 2022) is over 3 years old — current production is likely 1.1.2500x+
- Confirm any findings on the **latest** engine version before submitting to MSRC
- MSRC submission: https://msrc.microsoft.com/report
- Defender engine bugs typically qualify for bounty under the **Windows Defender** category
- Logic bugs (file write primitives, remediation path traversal) have historically been rated **Important** (LPE) to **Critical** (if reachable pre-auth or from low-integrity)
